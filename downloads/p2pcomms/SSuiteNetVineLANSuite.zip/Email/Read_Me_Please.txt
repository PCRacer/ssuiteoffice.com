	************************************************************************************
	******									      ******
	******	   How to properly run this portable LAN/Wi-Fi network application    ******
	******									      ******
	************************************************************************************

To run this application properly and with success, do one of the following:

1. Right-Click on the application and select the "Run As Administrator" option in the popup menu.

		OR

2. To make this option permanent, right-click on the application executable and select the "Properties" option at the bottom of the popup menu. On the window that opens, click on the "Compatibility" tab and at the bottom, select the "Run as an Administrator" checkbox and click on the "Apply" button.


The application will now run perfectly.