	************************************************************************************
	******									      ******
	******	   Windows 95 / 98SE / ME LAN Network and Wi-Fi Connection Update     ******
	******									      ******
	************************************************************************************

The big question?

How do I connect my Windows 95/98/XP system with my other PC/Laptop/Netbook/Tablet running Windows Vista/7/8/10 on my network LAN / WLAN router or switch?


If you need to connect your Windows 95/98/XP computer onto a network to a PC running Windows Vista/7/8/10, simply double-click ont the Windows patch file in this diretory on your Windows 95/98SE/ME.

This file will enable your Windows 95/98/XP system to see your other PC's running Windows Vista/7/8/10 on your LAN network.

			{ 98 >> XP >> Vista >> 7 >> 8 >> 8.1 >> 10}

 

Just run the patch file on your Windows 98 / XP system and follow the instructions given. You will now be able to connect your computers over the network to each other.