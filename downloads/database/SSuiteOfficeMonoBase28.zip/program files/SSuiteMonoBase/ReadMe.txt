NEW FEATURES ADDED
*******************

1. Referencial integrity for connecting database tables
2. Primary and foreign keys creation on table
3. View Master/detail tables and edit detail table according to primary and foreign keys
4. Run queries and view data results in full colour charts ( Pie, Bar, Line / 2D or 3D)
5. Export tables and queries directly to csv and xml files.
6. MonoBase can now accept Blob fields - {Binary Data files}
  
Var-Binary, Blobs, and Image files not supported in xml export.


Charting Functions
*******************

When viewing a chart, you may do the following:

1. Right-Click and hold down on chart to move it around for a better view
2. Left-Click and select(move right and down) on an area to zoom into.
3. Left-Click and Select(move left and down) to reset the chart to normal view.



*** PLEASE TAKE NOTE OF THE FOLLOWING ***
******************************************

There is a sample database and a pair of reports included with this distribution, which is called 'SampleDB'. The 'SampleDB' folder is located in the same directory as the application executable.

If this sample database is not listed in the database drop down list, then please do the following:

1. Open your control panel and run the BDE Administrator applet.( Appears in Classic view for XP )
2. In the database list, select the 'SampleDB' option
3. The path that is displayed next to the 'SampleDB' option must be changed to the following:
   'C:\Program Files\SSuiteMonoBase\SampleDB' OR 'C:\Program Files(x86)\SSuiteMonoBase\SampleDB'
4. Apply the changes made and exit the BDE Administrator.


This will now make the sample database appear in the database drop down list in MonoBase. Please remember to restart Monobase to refresh the database list if MonoBase is already open. You do NOT need to restart MonoBase when a new database is created or a new ODBC database is linked to MonoBase.

All the other databases listed inside of the BDE Administrator, are ODBC data sources and other databases available to your system. If you don't want them to be listed, simply delete them with the 'Delete Database' button in MonoBase.


To view the sample reports, you need to go to the SampleDB folder, which is located with the application executable.


******************************* IMPORTANT!! ****************************

When installing or running "MonoBase.exe" on Windows Vista or Windows 7 / 8 / 10 please run this application executable as an "Administrator".



*** When installing this database application on Windows 64-bit systems: ***


- Make sure the path changes to: Params=PATH:C:\Program Files(x86)\SSuiteMonoBase\SampleDB


This must be done before installation in the ***  BDEMerge.ini ***   file.

See our helpdesk or Blog for more information if you need it.


**********************************************************************


SSuite Office - Monobase is the all in one database creator and administrator.


Please use responsibly.


SSuite Office


http://www.ssuitesoft.com