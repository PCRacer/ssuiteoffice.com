/*******************************************************************************

    uBlock Origin - a comprehensive, efficient content blocker
    Copyright (C) 2026-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/* global browser */

import { hostnameFromURI } from './uri-utils.js';
import webext from './webext.js';

/******************************************************************************/

function uBO_isolatedCode(mainCode) {
    if ( self.vapiScripting ) { return 0; }
    self.vapiScripting = true;

    (function isolatedCode(){})();

    if ( mainCode ) {
        let script;
        try {
            const doc = document;
            script = doc.createElement('script');
            script.appendChild(doc.createTextNode(mainCode));
            (doc.head || doc.documentElement).appendChild(script);
        } catch {
        }
        if ( script ) {
            script.remove();
            script.textContent = '';
        }
    }

    return 0;
}

function uBO_assembleIsolatedCode(details) {
    const { isolatedCode = '', mainCode = '' } = details;
    if ( Boolean(isolatedCode) === false ) {
        if ( Boolean(mainCode) === false ) { return; }
    }
    let code = [
        `// ${details.hostname}`,
        '(function uBO_isolatedWorldWrapper() {',
    ];
    if ( details.earlyBailoutCode ) {
        code.push(details.earlyBailoutCode);
    }
    code.push(
        `(${uBO_isolatedCode.toString()})(`,
        JSON.stringify(`// ${details.hostname}\n${mainCode}`),
        `);`
    );
    code.push('})();');
    code = code.join('\n');
    const match = /\(function isolatedCode\(\)\{\}\)\(\);/.exec(code);
    return code.slice(0, match.index) +
        isolatedCode +
        code.slice(match.index + match[0].length);
}

/******************************************************************************/

const CONTENTSCRIPT_DICT_MAX_LOW = 128;
const CONTENTSCRIPT_DICT_MAX_HIGH = CONTENTSCRIPT_DICT_MAX_LOW +
    (CONTENTSCRIPT_DICT_MAX_LOW >>> 3);
const reIsHTTP = /^https?:\/\//;
const tabDict = new Map();
const contentScriptDict = new Map();
let getContentScripts;

function getEffectiveURL(tabId, frameId) {
    const tabData = tabDict.get(tabId);
    if ( tabData === undefined ) { return; }
    const { frameDict } = tabData;
    let frameData = frameDict.get(frameId);
    for (;;) {
        if ( /^https?:/.test(frameData.url) ) { break; }
        frameId = frameData.parentId;
        if ( frameId === -1 ) { break; }
        frameData = frameDict.get(frameId);
        if ( Boolean(frameData) === false ) { return; }
    }
    return frameData.url;
}

function registerContentScript(url) {
    const hostname = hostnameFromURI(url);
    if ( hostname === '' ) { return; }
    if ( contentScriptDict.has(hostname) ) { return; }
    const result = getContentScripts(url);
    const code = uBO_assembleIsolatedCode(result) ?? null;
    contentScriptDict.set(hostname, { code, t: Date.now() });
    return code;
}

function onBeforeNavigate(details) {
    const { tabId } = details;
    if ( tabId < 0 ) { return; }
    const tabData = tabDict.get(tabId) ?? { tabId };
    if ( tabData.frameDict === undefined ) {
        tabData.frameDict = new Map();
        tabDict.set(tabId, tabData);
    }
    const { frameDict } = tabData;
    let { frameId, url } = details;
    if ( frameId === 0 ) {
        frameDict.clear();
    }
    let frameData = { frameId, parentId: details.parentFrameId, url };
    frameDict.set(frameId, frameData);
    // Every 64 frames, we rebuild to ensure no unbound growth as there is no
    // API for removed frames
    // TODO: spin off frames management to be reused across all of uBO
    if ( (frameDict.size & 0b111111) === 0 ) {
        const key = self.crypto.randomUUID();
        tabData.gettingFrames = key;
        webext.webNavigation.getAllFrames({ tabId }).then(frames => {
            if ( tabData.gettingFrames !== key ) { return; }
            if ( tabDict.has(tabId) === false ) { return; }
            frameDict.clear();
            for ( const { frameId, parentFrameId, url } of frames ) {
                frameDict.set(frameId, { frameId, parentId: parentFrameId, url });
            }
        });
    }
    if ( frameId !== 0 && reIsHTTP.test(url) === false ) {
        url = getEffectiveURL(tabId, frameId);
        if ( url === undefined ) { return; }
    }
    if ( reIsHTTP.test(url) === false ) { return; }
    registerContentScript(url);
}

function onCommitted(details) {
    const { tabId, frameId } = details;
    if ( tabId < 0 ) { return; }
    let { url } = details;
    if ( frameId !== 0 && reIsHTTP.test(url) === false ) {
        url = getEffectiveURL(tabId, frameId);
        if ( url === undefined ) { return; }
    }
    if ( reIsHTTP.test(url) === false ) { return; }
    const hostname = hostnameFromURI(url);
    if ( hostname === '' ) { return; }
    const entry = contentScriptDict.get(hostname);
    if ( Boolean(entry?.code) === false ) { return; }
    webext.tabs.executeScript(tabId, {
        frameId,
        matchAboutBlank: true,
        runAt: 'document_start',
        code: entry.code,
    });
    entry.t = Date.now();
    if ( contentScriptDict.size <= CONTENTSCRIPT_DICT_MAX_HIGH ) { return; }
    const sortedKeys = Array.from(contentScriptDict.keys()).toSorted((a, b) =>
        contentScriptDict.get(a).t - contentScriptDict.get(b).t
    ).slice(0, -CONTENTSCRIPT_DICT_MAX_LOW);
    for ( const key of sortedKeys ) {
        contentScriptDict.delete(key);
    }
}

function onTabRemoved(tabId) {
    tabDict.delete(tabId);
}

/******************************************************************************/

export async function start(fn) {
    const initialized = Boolean(getContentScripts);
    getContentScripts = fn;
    if ( initialized ) { return; }

    // https://github.com/chrisaljoudi/uBlock/issues/129
    //  Find out whether content scripts need to be injected
    //  programmatically. This may be necessary for web pages which
    //  were loaded before uBO launched.
    const manifest = browser.runtime.getManifest();
    const injectDeclarativeContentScripts = tabId => {
        webext.tabs.executeScript(tabId, {
            file: 'js/scriptlets/should-inject-contentscript.js'
        }).then(result => {
            if ( result !== true ) { return; }
            for ( const contentScript of manifest.content_scripts ) {
                for ( const file of contentScript.js ) {
                    webext.tabs.executeScript(tabId, {
                        file,
                        allFrames: contentScript.all_frames,
                        runAt: contentScript.run_at,
                    });
                }
            }
        });
    };

    const tabs = await webext.tabs.query({ url: [ 'http://*/*', 'https://*/*' ] });
    for ( const tab of tabs ) {
        if ( tab.discarded ) { continue; }
        if ( tab.status === 'unloaded' ) { continue; }
        const { id, url } = tab;
        const code = registerContentScript(url);
        if ( code ) {
            webext.tabs.executeScript(id, {
                allFrames: true,
                matchAboutBlank: true,
                runAt: 'document_start',
                code,
            });
        }
        injectDeclarativeContentScripts(id);
    }

    browser.webNavigation.onBeforeNavigate.addListener(onBeforeNavigate);
    browser.webNavigation.onCommitted.addListener(onCommitted);
    browser.tabs.onRemoved.addListener(onTabRemoved);
}

export function reset() {
    contentScriptDict.clear();
}
