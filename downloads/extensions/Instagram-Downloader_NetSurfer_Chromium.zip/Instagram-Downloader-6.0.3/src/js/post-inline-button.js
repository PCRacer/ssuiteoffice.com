(() => {
    const BUTTON_CLASS = 'igd-post-inline-download';
    const DOWNLOAD_ALL_BUTTON_CLASS = 'igd-post-inline-download-all';
    const OWN_BUTTONS = `.${BUTTON_CLASS}, .${DOWNLOAD_ALL_BUTTON_CLASS}`;
    let updateQueued = false;

    function isSupportedView() {
        return window.location.pathname === '/' || IG_POST_REGEX.test(window.location.pathname);
    }

    // /reels/:code is a vertical feed: every reel shares the page URL, which
    // tracks only the reel currently on screen, and its actions are a column.
    function isReelsFeed() {
        return /^\/reels\/[A-Za-z0-9_-]+/.test(window.location.pathname);
    }

    function isActiveReel(root) {
        const video = root.querySelector?.('video');
        if (!video) return false;
        const rect = video.getBoundingClientRect();
        return rect.top <= innerHeight / 2 && rect.bottom >= innerHeight / 2;
    }

    function isVisible(element) {
        const rect = element.getBoundingClientRect();
        const style = getComputedStyle(element);
        return rect.width > 0 && rect.height > 0 && style.display !== 'none' && style.visibility !== 'hidden';
    }

    // Icon geometry is independent of Instagram's translated accessibility labels.
    // Keep the label fallback for older icon variants.
    function isShareIcon(icon) {
        const path = icon.querySelector('path')?.getAttribute('d') ?? '';
        return path.startsWith('M13.973 20.046') || ['Share', 'Share Post'].includes(icon.getAttribute('aria-label'));
    }

    function findPostActionTargets() {
        const targets = [];
        const handledRoots = new Set();
        for (const icon of document.querySelectorAll('svg[aria-label]')) {
            if (!isShareIcon(icon) || !isVisible(icon)) continue;
            const anchorButton = icon.closest('button, [role="button"]');
            if (!anchorButton) continue;
            const root = getPostRoot(anchorButton);
            if (handledRoots.has(root) || (root === document && !IG_POST_REGEX.test(location.pathname))) continue;
            const reelsFeed = isReelsFeed();
            if (reelsFeed && !isActiveReel(root)) continue;
            const directions = reelsFeed ? ['column', 'column-reverse'] : ['row', 'row-reverse'];

            // Stop at the innermost action group (a column on /reels/). The outer grid has
            // a separate Save cell: inserting a new child there creates a new row.
            let container = anchorButton.parentElement;
            while (container && container !== root && container !== document.body) {
                const style = getComputedStyle(container);
                if (style.display === 'grid' || style.display === 'inline-grid') break;
                const icons = [...container.querySelectorAll('svg[aria-label]')].filter(
                    (item) => !item.closest(OWN_BUTTONS),
                );
                if (
                    ['flex', 'inline-flex'].includes(style.display) &&
                    directions.includes(style.flexDirection) &&
                    icons.length >= 3 &&
                    icons.length <= 6
                ) {
                    handledRoots.add(root);
                    targets.push({ actionsContainer: container, anchorButton });
                    break;
                }
                container = container.parentElement;
            }
        }

        // Some posts do not render a Share action at all. Fall back to the
        // horizontal post action section and insert before its final action
        // (normally Save). This structural fallback also works with translated
        // accessibility labels.
        if (!isReelsFeed()) {
            for (const section of document.querySelectorAll('section')) {
                if (!isVisible(section)) continue;
                const sectionStyle = getComputedStyle(section);
                const sectionIcons = [...section.querySelectorAll('svg[aria-label]')].filter(
                    (icon) => isVisible(icon) && !icon.closest(OWN_BUTTONS),
                );
                if (sectionIcons.length < 3 || sectionIcons.length > 6) continue;

                let actionsContainer = section;
                let icons = sectionIcons;
                let minimumActionItems = 3;
                let useLastNativeItem = false;
                if (['grid', 'inline-grid'].includes(sectionStyle.display)) {
                    actionsContainer = [...section.children].find((child) => {
                        const style = getComputedStyle(child);
                        const childIcons = [...child.querySelectorAll('svg[aria-label]')].filter(
                            (icon) => isVisible(icon) && !icon.closest(OWN_BUTTONS),
                        );
                        return (
                            isVisible(child) &&
                            ['flex', 'inline-flex'].includes(style.display) &&
                            ['row', 'row-reverse'].includes(style.flexDirection) &&
                            childIcons.length >= 2
                        );
                    });
                    if (!actionsContainer) continue;
                    icons = [...actionsContainer.querySelectorAll('svg[aria-label]')].filter(
                        (icon) => isVisible(icon) && !icon.closest(OWN_BUTTONS),
                    );
                    minimumActionItems = 2;
                    useLastNativeItem = true;
                } else if (
                    !['flex', 'inline-flex'].includes(sectionStyle.display) ||
                    !['row', 'row-reverse'].includes(sectionStyle.flexDirection)
                ) {
                    continue;
                }

                const actionItems = icons
                    .map((icon) => icon.closest('button, [role="button"]'))
                    .map((button) => findDirectChild(actionsContainer, button))
                    .filter((item, index, items) => item && items.indexOf(item) === index);
                if (actionItems.length < minimumActionItems) continue;

                const anchorItem = useLastNativeItem
                    ? [...actionsContainer.children].filter((item) => !item.matches(OWN_BUTTONS)).at(-1)
                    : actionItems[actionItems.length - 2];
                if (!anchorItem) continue;
                const root = getPostRoot(anchorItem);
                if (handledRoots.has(root) || (root === document && !IG_POST_REGEX.test(location.pathname))) continue;

                handledRoots.add(root);
                targets.push({ actionsContainer, anchorButton: anchorItem });
            }
        }
        return targets;
    }

    function findDirectChild(container, descendant) {
        let child = descendant;
        while (child?.parentElement && child.parentElement !== container) child = child.parentElement;
        return child?.parentElement === container ? child : null;
    }

    function getPostRoot(actionButton) {
        const article = actionButton.closest('article');
        if (article || !isReelsFeed()) return article ?? document;
        // A reel's own container is the largest ancestor holding only its Share
        // button. Its video can be missing while it loads lazily off screen.
        let reel = actionButton;
        while (
            reel.parentElement &&
            reel.parentElement !== document.body &&
            countShareButtons(reel.parentElement) === 1
        ) {
            reel = reel.parentElement;
        }
        return reel;
    }

    function countShareButtons(element) {
        return [...element.querySelectorAll('svg[aria-label]')].filter(
            (icon) => isShareIcon(icon) && icon.closest('button, [role="button"]'),
        ).length;
    }

    function extractShortcode(href) {
        const path = new URL(href, window.location.origin).pathname;
        const match = path.match(/\/(?:p|tv|reel|reels)\/([A-Za-z0-9_-]+)/);
        if (!match || ['audio', 'liked_by'].includes(match[1])) return '';
        return match[1];
    }

    function getPostShortcode(root) {
        if (root === document) return window.location.pathname.match(IG_POST_REGEX)?.[2] ?? '';

        const links = [...root.querySelectorAll('a[href]')];
        const postLink = links.find((link) => /\/p\/[A-Za-z0-9_-]+/.test(link.getAttribute('href') ?? ''));
        if (postLink) return extractShortcode(postLink.getAttribute('href'));

        for (const mediaLink of links) {
            const href = mediaLink.getAttribute('href') ?? '';
            if (!/\/(?:tv|reel|reels)\/[A-Za-z0-9_-]+/.test(href)) continue;
            const shortcode = extractShortcode(href);
            if (shortcode) return shortcode;
        }

        return window.location.pathname.match(IG_POST_REGEX)?.[2] ?? '';
    }

    function isCarouselPost(root) {
        const activeSlide = root.querySelector('button[aria-current="step"]');
        if (getSlideButtons(activeSlide).length > 1) return true;

        const media = [...root.querySelectorAll('img, video')]
            .filter(isVisible)
            .map((element) => element.getBoundingClientRect())
            .filter((rect) => rect.width >= 200 && rect.height >= 200 && rect.bottom > 0 && rect.top < innerHeight);
        if (!media.length) return false;

        const largestArea = Math.max(...media.map((rect) => rect.width * rect.height));
        const mainMedia = media.filter((rect) => rect.width * rect.height >= largestArea * 0.65);
        const controls = [...root.querySelectorAll('button, [role="button"]')].filter((element) => {
            if (!isVisible(element) || element.closest(`.${BUTTON_CLASS}, .${DOWNLOAD_ALL_BUTTON_CLASS}`)) return false;
            const rect = element.getBoundingClientRect();
            if (rect.width > 64 || rect.height > 64) return false;
            return mainMedia.some((mediaRect) => {
                const centerX = rect.left + rect.width / 2;
                const centerY = rect.top + rect.height / 2;
                const nearHorizontalEdge =
                    Math.abs(centerX - mediaRect.left) <= 48 || Math.abs(centerX - mediaRect.right) <= 48;
                const nearVerticalCenter =
                    Math.abs(centerY - (mediaRect.top + mediaRect.height / 2)) <= mediaRect.height * 0.25;
                return nearHorizontalEdge && nearVerticalCenter;
            });
        });

        return controls.some((control) => {
            const rect = control.getBoundingClientRect();
            const centerX = rect.left + rect.width / 2;
            const centerY = rect.top + rect.height / 2;
            return mainMedia.some(
                (mediaRect) =>
                    centerX >= mediaRect.left &&
                    centerX <= mediaRect.right &&
                    centerY >= mediaRect.top &&
                    centerY <= mediaRect.bottom,
            );
        });
    }

    function getSlideButtons(activeSlide) {
        if (!activeSlide) return [];
        let container = activeSlide.parentElement;
        while (container && container !== document.body) {
            const buttons = [...container.querySelectorAll('button')].filter((button) => {
                const rect = button.getBoundingClientRect();
                return isVisible(button) && rect.width <= 32 && rect.height <= 32;
            });
            if (buttons.length > 1 && buttons.length <= 20 && buttons.includes(activeSlide)) return buttons;
            container = container.parentElement;
        }
        return [];
    }

    function getCurrentPostMediaState(root) {
        const activeSlide = root.querySelector('button[aria-current="step"]');
        const slideButtons = getSlideButtons(activeSlide);
        const activeIndex = slideButtons.indexOf(activeSlide);
        if (activeIndex >= 0) {
            return { index: activeIndex, itemCount: slideButtons.length, indexConfident: true };
        }

        if (!isCarouselPost(root)) return { index: 0, itemCount: 1, indexConfident: true };
        return { index: -1, itemCount: 0, indexConfident: false };
    }

    function getVisiblePostMediaSource(root) {
        const candidates = [...root.querySelectorAll('img, video')]
            .map((media) => {
                const rect = media.getBoundingClientRect();
                const visibleWidth = Math.max(0, Math.min(rect.right, innerWidth) - Math.max(rect.left, 0));
                const visibleHeight = Math.max(0, Math.min(rect.bottom, innerHeight) - Math.max(rect.top, 0));
                return { media, rect, visibleArea: visibleWidth * visibleHeight };
            })
            .filter(({ rect, visibleArea }) => rect.width >= 200 && rect.height >= 200 && visibleArea > 0)
            .sort((first, second) => second.visibleArea - first.visibleArea);
        const currentMedia = candidates[0]?.media;
        return currentMedia?.currentSrc || currentMedia?.src || '';
    }

    function readPostSelection(root) {
        const mediaState = getCurrentPostMediaState(root);
        return {
            shortcode: getPostShortcode(root),
            sourceUrl: getVisiblePostMediaSource(root),
            ...mediaState,
        };
    }

    function postSelectionsMatch(first, second) {
        return (
            first.shortcode === second.shortcode &&
            first.sourceUrl === second.sourceUrl &&
            first.index === second.index &&
            first.itemCount === second.itemCount
        );
    }

    async function getStablePostSelection(root) {
        const first = readPostSelection(root);
        /**
         * During navigation, Instagram can update the URL, carousel/progress indicators, and visible media across separate render frames.
         * Waiting for one animation frame and verifying the selection again prevents us from downloading the previous item while the UI is still transitioning.
         */
        await new Promise((resolve) => requestAnimationFrame(resolve));
        await new Promise((resolve) => requestAnimationFrame(resolve));
        const second = readPostSelection(root);
        return {
            ...second,
            stable: postSelectionsMatch(first, second),
            indexConfident: first.indexConfident && second.indexConfident,
        };
    }

    function createPostDownloadButton({ downloadAll, root, shortcode }) {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = downloadAll ? DOWNLOAD_ALL_BUTTON_CLASS : BUTTON_CLASS;
        button.dataset.postShortcode = shortcode;
        button.title = downloadAll ? 'Download all post media as ZIP' : 'Download current post media';
        button.setAttribute(
            'aria-label',
            downloadAll ? 'Download all post media as ZIP' : 'Download current post media',
        );
        button.innerHTML = downloadAll
            ? `<svg aria-hidden="true" viewBox="0 0 24 24" width="24" height="24">
                    <path d="M4 4h16v4H4zM5 8h14v12H5zM12 10v6m0 0 3-3m-3 3-3-3" />
               </svg>`
            : `<svg aria-hidden="true" viewBox="0 0 24 24" width="24" height="24">
                    <path d="M12 3v11m0 0 4-4m-4 4-4-4M5 19h14" />
               </svg>`;
        button.addEventListener('click', async (event) => {
            event.preventDefault();
            event.stopPropagation();
            const selection = downloadAll ? null : await getStablePostSelection(root);
            downloadInlineMedia({
                button,
                type: 'post',
                downloadAll,
                index: selection?.index ?? 0,
                selection,
                shortcode,
            });
        });
        return button;
    }

    function findOwnButton(container, className) {
        return [...container.children].find((element) => element.classList.contains(className)) ?? null;
    }

    function syncPostDownloadButtons() {
        const activeButtons = new Set();
        const existingButtons = document.querySelectorAll(`.${BUTTON_CLASS}, .${DOWNLOAD_ALL_BUTTON_CLASS}`);
        if (!isSupportedView() || !downloadUiPreferences.shows('inline')) {
            existingButtons.forEach((button) => button.remove());
            return;
        }

        const handledContainers = new Set();
        for (const { actionsContainer, anchorButton } of findPostActionTargets()) {
            if (!actionsContainer || handledContainers.has(actionsContainer)) continue;
            handledContainers.add(actionsContainer);

            const anchorItem = findDirectChild(actionsContainer, anchorButton);
            const root = getPostRoot(anchorButton);
            const shortcode = getPostShortcode(root);
            if (!anchorItem || !shortcode) continue;

            let singleButton = findOwnButton(actionsContainer, BUTTON_CLASS);
            if (!singleButton || singleButton.dataset.postShortcode !== shortcode) {
                singleButton?.remove();
                singleButton = createPostDownloadButton({ downloadAll: false, root, shortcode });
            }
            activeButtons.add(singleButton);
            singleButton.classList.toggle('igd-post-inline-download-reel', isReelsFeed());

            let downloadAllButton = findOwnButton(actionsContainer, DOWNLOAD_ALL_BUTTON_CLASS);
            if (isCarouselPost(root)) {
                if (!downloadAllButton || downloadAllButton.dataset.postShortcode !== shortcode) {
                    downloadAllButton?.remove();
                    downloadAllButton = createPostDownloadButton({ downloadAll: true, root, shortcode });
                }
                activeButtons.add(downloadAllButton);
                if (anchorItem.nextElementSibling !== downloadAllButton) {
                    anchorItem.insertAdjacentElement('afterend', downloadAllButton);
                }
                if (downloadAllButton.nextElementSibling !== singleButton) {
                    downloadAllButton.insertAdjacentElement('afterend', singleButton);
                }
            } else {
                downloadAllButton?.remove();
                if (anchorItem.nextElementSibling !== singleButton) {
                    anchorItem.insertAdjacentElement('afterend', singleButton);
                }
            }
        }

        existingButtons.forEach((button) => {
            if (!activeButtons.has(button)) button.remove();
        });
    }

    function queueUpdate() {
        if (updateQueued) return;
        updateQueued = true;
        requestAnimationFrame(() => {
            updateQueued = false;
            // Our insertions must not schedule another layout pass.
            observer.disconnect();
            try {
                syncPostDownloadButtons();
            } finally {
                observePage();
            }
        });
    }

    const observer = new MutationObserver((records) => {
        if (records.some((record) => !record.target.closest?.(OWN_BUTTONS))) queueUpdate();
    });
    function observePage() {
        observer.observe(document.body, {
            childList: true,
            subtree: true,
            attributes: true,
            attributeFilter: ['aria-current'],
        });
    }
    observePage();
    window.addEventListener('downloadUiModeChange', queueUpdate);
    navigation.addEventListener('navigate', queueUpdate);
    // The reels feed scrolls inside a nested container; the active reel changes without a URL change until it settles.
    document.addEventListener('scrollend', queueUpdate, true);
    queueUpdate();
})();
