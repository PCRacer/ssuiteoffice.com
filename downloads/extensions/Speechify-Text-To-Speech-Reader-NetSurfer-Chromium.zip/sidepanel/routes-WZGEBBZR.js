import{a}from"./chunk-GJGOSAEA.js";import"./chunk-V2L5DJQO.js";import"./chunk-7DWBZSFS.js";export{a as fetch};
//# sourceMappingURL=routes-WZGEBBZR.js.map
