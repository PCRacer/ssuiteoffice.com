import{p as a,q as b,r as c}from"./chunk-GJGOSAEA.js";import"./chunk-V2L5DJQO.js";import"./chunk-7DWBZSFS.js";export{a as playbackState,c as useOrator,b as usePlaybackState};
//# sourceMappingURL=orator-QGBKU2AA.js.map
