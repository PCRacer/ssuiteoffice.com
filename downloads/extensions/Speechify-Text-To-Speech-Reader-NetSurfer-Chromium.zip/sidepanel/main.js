import{a as kn,b as Gr,c as qu,d as Xu,e as Hu,f as io,g as Zu,h as hs,i as ju,j as oo,k as Qu,l as Ju,m as ms,n as _s,o as ys,q as ef,r as ao,s as tf}from"./chunk-GJGOSAEA.js";import{a as Ku}from"./chunk-IDIA6O63.js";import{a as nr,b as dn,c as rr,d as ir,g as Uu,h as Bu,i as Fu,k as Gu,l as Wu,m as $u,n as zu,o as Vu,p as Yu}from"./chunk-IV62XIZ7.js";import{a as Oe,b as Mu,d as Du,k as be}from"./chunk-V2L5DJQO.js";import{b as ro,d as we,f as F,g as C,i as d,j as W,k as Pu,m as C2,n as w}from"./chunk-7DWBZSFS.js";var Tf=ro(de=>{"use strict";w();C();var Fe=typeof Symbol=="function"&&Symbol.for,Ss=Fe?Symbol.for("react.element"):60103,Cs=Fe?Symbol.for("react.portal"):60106,ho=Fe?Symbol.for("react.fragment"):60107,mo=Fe?Symbol.for("react.strict_mode"):60108,_o=Fe?Symbol.for("react.profiler"):60114,yo=Fe?Symbol.for("react.provider"):60109,vo=Fe?Symbol.for("react.context"):60110,ws=Fe?Symbol.for("react.async_mode"):60111,xo=Fe?Symbol.for("react.concurrent_mode"):60111,bo=Fe?Symbol.for("react.forward_ref"):60112,So=Fe?Symbol.for("react.suspense"):60113,P2=Fe?Symbol.for("react.suspense_list"):60120,Co=Fe?Symbol.for("react.memo"):60115,wo=Fe?Symbol.for("react.lazy"):60116,M2=Fe?Symbol.for("react.block"):60121,D2=Fe?Symbol.for("react.fundamental"):60117,U2=Fe?Symbol.for("react.responder"):60118,B2=Fe?Symbol.for("react.scope"):60119;function ft(n){if(typeof n=="object"&&n!==null){var o=n.$$typeof;switch(o){case Ss:switch(n=n.type,n){case ws:case xo:case ho:case _o:case mo:case So:return n;default:switch(n=n&&n.$$typeof,n){case vo:case bo:case wo:case Co:case yo:return n;default:return o}}case Cs:return o}}}function wf(n){return ft(n)===xo}de.AsyncMode=ws;de.ConcurrentMode=xo;de.ContextConsumer=vo;de.ContextProvider=yo;de.Element=Ss;de.ForwardRef=bo;de.Fragment=ho;de.Lazy=wo;de.Memo=Co;de.Portal=Cs;de.Profiler=_o;de.StrictMode=mo;de.Suspense=So;de.isAsyncMode=function(n){return wf(n)||ft(n)===ws};de.isConcurrentMode=wf;de.isContextConsumer=function(n){return ft(n)===vo};de.isContextProvider=function(n){return ft(n)===yo};de.isElement=function(n){return typeof n=="object"&&n!==null&&n.$$typeof===Ss};de.isForwardRef=function(n){return ft(n)===bo};de.isFragment=function(n){return ft(n)===ho};de.isLazy=function(n){return ft(n)===wo};de.isMemo=function(n){return ft(n)===Co};de.isPortal=function(n){return ft(n)===Cs};de.isProfiler=function(n){return ft(n)===_o};de.isStrictMode=function(n){return ft(n)===mo};de.isSuspense=function(n){return ft(n)===So};de.isValidElementType=function(n){return typeof n=="string"||typeof n=="function"||n===ho||n===xo||n===_o||n===mo||n===So||n===P2||typeof n=="object"&&n!==null&&(n.$$typeof===wo||n.$$typeof===Co||n.$$typeof===yo||n.$$typeof===vo||n.$$typeof===bo||n.$$typeof===D2||n.$$typeof===U2||n.$$typeof===B2||n.$$typeof===M2)};de.typeOf=ft});var If=ro((J3,Ef)=>{"use strict";w();C();Ef.exports=Tf()});var Pf=ro((nS,kf)=>{"use strict";w();C();var Ts=If(),F2={childContextTypes:!0,contextType:!0,contextTypes:!0,defaultProps:!0,displayName:!0,getDefaultProps:!0,getDerivedStateFromError:!0,getDerivedStateFromProps:!0,mixins:!0,propTypes:!0,type:!0},G2={name:!0,length:!0,prototype:!0,caller:!0,callee:!0,arguments:!0,arity:!0},W2={$$typeof:!0,render:!0,defaultProps:!0,displayName:!0,propTypes:!0},Nf={$$typeof:!0,compare:!0,defaultProps:!0,displayName:!0,propTypes:!0,type:!0},Es={};Es[Ts.ForwardRef]=W2;Es[Ts.Memo]=Nf;function Af(n){return Ts.isMemo(n)?Nf:Es[n.$$typeof]||F2}var $2=Object.defineProperty,z2=Object.getOwnPropertyNames,Lf=Object.getOwnPropertySymbols,V2=Object.getOwnPropertyDescriptor,Y2=Object.getPrototypeOf,Of=Object.prototype;function Rf(n,o,a){if(typeof o!="string"){if(Of){var f=Y2(o);f&&f!==Of&&Rf(n,f,a)}var p=z2(o);Lf&&(p=p.concat(Lf(o)));for(var m=Af(n),x=Af(o),S=0;S<p.length;++S){var I=p[S];if(!G2[I]&&!(a&&a[I])&&!(x&&x[I])&&!(m&&m[I])){var k=V2(o,I);try{$2(n,I,k)}catch{}}}}return n}kf.exports=Rf});var cp=ro((mr,ai)=>{"use strict";w();C();(function(){var n,o="4.17.21",a=200,f="Unsupported core-js use. Try https://npms.io/search?q=ponyfill.",p="Expected a function",m="Invalid `variable` option passed into `_.template`",x="__lodash_hash_undefined__",S=500,I="__lodash_placeholder__",k=1,V=2,U=4,B=1,z=2,N=1,R=2,K=4,c=8,h=16,y=32,O=64,P=128,q=256,G=512,Se=30,ge="...",pe=800,Q=16,ve=1,Ie=2,en=3,De=1/0,ze=9007199254740991,Bt=17976931348623157e292,pt=NaN,Ke=4294967295,yr=Ke-1,Wn=Ke>>>1,Ft=[["ary",P],["bind",N],["bindKey",R],["curry",c],["curryRight",h],["flip",G],["partial",y],["partialRight",O],["rearg",q]],Ge="[object Arguments]",Et="[object Array]",vr="[object AsyncFunction]",Sn="[object Boolean]",Cn="[object Date]",Fp="[object DOMException]",fi="[object Error]",di="[object Function]",rl="[object GeneratorFunction]",It="[object Map]",xr="[object Number]",Gp="[object Null]",Gt="[object Object]",il="[object Promise]",Wp="[object Proxy]",br="[object RegExp]",At="[object Set]",Sr="[object String]",pi="[object Symbol]",$p="[object Undefined]",Cr="[object WeakMap]",zp="[object WeakSet]",wr="[object ArrayBuffer]",$n="[object DataView]",Xo="[object Float32Array]",Ho="[object Float64Array]",Zo="[object Int8Array]",jo="[object Int16Array]",Qo="[object Int32Array]",Jo="[object Uint8Array]",ea="[object Uint8ClampedArray]",ta="[object Uint16Array]",na="[object Uint32Array]",Vp=/\b__p \+= '';/g,Yp=/\b(__p \+=) '' \+/g,Kp=/(__e\(.*?\)|\b__t\)) \+\n'';/g,ol=/&(?:amp|lt|gt|quot|#39);/g,al=/[&<>"']/g,qp=RegExp(ol.source),Xp=RegExp(al.source),Hp=/<%-([\s\S]+?)%>/g,Zp=/<%([\s\S]+?)%>/g,sl=/<%=([\s\S]+?)%>/g,jp=/\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/,Qp=/^\w*$/,Jp=/[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g,ra=/[\\^$.*+?()[\]{}|]/g,e1=RegExp(ra.source),ia=/^\s+/,t1=/\s/,n1=/\{(?:\n\/\* \[wrapped with .+\] \*\/)?\n?/,r1=/\{\n\/\* \[wrapped with (.+)\] \*/,i1=/,? & /,o1=/[^\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7f]+/g,a1=/[()=,{}\[\]\/\s]/,s1=/\\(\\)?/g,l1=/\$\{([^\\}]*(?:\\.[^\\}]*)*)\}/g,ll=/\w*$/,c1=/^[-+]0x[0-9a-f]+$/i,u1=/^0b[01]+$/i,f1=/^\[object .+?Constructor\]$/,d1=/^0o[0-7]+$/i,p1=/^(?:0|[1-9]\d*)$/,g1=/[\xc0-\xd6\xd8-\xf6\xf8-\xff\u0100-\u017f]/g,gi=/($^)/,h1=/['\n\r\u2028\u2029\\]/g,hi="\\ud800-\\udfff",m1="\\u0300-\\u036f",_1="\\ufe20-\\ufe2f",y1="\\u20d0-\\u20ff",cl=m1+_1+y1,ul="\\u2700-\\u27bf",fl="a-z\\xdf-\\xf6\\xf8-\\xff",v1="\\xac\\xb1\\xd7\\xf7",x1="\\x00-\\x2f\\x3a-\\x40\\x5b-\\x60\\x7b-\\xbf",b1="\\u2000-\\u206f",S1=" \\t\\x0b\\f\\xa0\\ufeff\\n\\r\\u2028\\u2029\\u1680\\u180e\\u2000\\u2001\\u2002\\u2003\\u2004\\u2005\\u2006\\u2007\\u2008\\u2009\\u200a\\u202f\\u205f\\u3000",dl="A-Z\\xc0-\\xd6\\xd8-\\xde",pl="\\ufe0e\\ufe0f",gl=v1+x1+b1+S1,oa="['’]",C1="["+hi+"]",hl="["+gl+"]",mi="["+cl+"]",ml="\\d+",w1="["+ul+"]",_l="["+fl+"]",yl="[^"+hi+gl+ml+ul+fl+dl+"]",aa="\\ud83c[\\udffb-\\udfff]",T1="(?:"+mi+"|"+aa+")",vl="[^"+hi+"]",sa="(?:\\ud83c[\\udde6-\\uddff]){2}",la="[\\ud800-\\udbff][\\udc00-\\udfff]",zn="["+dl+"]",xl="\\u200d",bl="(?:"+_l+"|"+yl+")",E1="(?:"+zn+"|"+yl+")",Sl="(?:"+oa+"(?:d|ll|m|re|s|t|ve))?",Cl="(?:"+oa+"(?:D|LL|M|RE|S|T|VE))?",wl=T1+"?",Tl="["+pl+"]?",I1="(?:"+xl+"(?:"+[vl,sa,la].join("|")+")"+Tl+wl+")*",A1="\\d*(?:1st|2nd|3rd|(?![123])\\dth)(?=\\b|[A-Z_])",L1="\\d*(?:1ST|2ND|3RD|(?![123])\\dTH)(?=\\b|[a-z_])",El=Tl+wl+I1,O1="(?:"+[w1,sa,la].join("|")+")"+El,N1="(?:"+[vl+mi+"?",mi,sa,la,C1].join("|")+")",R1=RegExp(oa,"g"),k1=RegExp(mi,"g"),ca=RegExp(aa+"(?="+aa+")|"+N1+El,"g"),P1=RegExp([zn+"?"+_l+"+"+Sl+"(?="+[hl,zn,"$"].join("|")+")",E1+"+"+Cl+"(?="+[hl,zn+bl,"$"].join("|")+")",zn+"?"+bl+"+"+Sl,zn+"+"+Cl,L1,A1,ml,O1].join("|"),"g"),M1=RegExp("["+xl+hi+cl+pl+"]"),D1=/[a-z][A-Z]|[A-Z]{2}[a-z]|[0-9][a-zA-Z]|[a-zA-Z][0-9]|[^a-zA-Z0-9 ]/,U1=["Array","Buffer","DataView","Date","Error","Float32Array","Float64Array","Function","Int8Array","Int16Array","Int32Array","Map","Math","Object","Promise","RegExp","Set","String","Symbol","TypeError","Uint8Array","Uint8ClampedArray","Uint16Array","Uint32Array","WeakMap","_","clearTimeout","isFinite","parseInt","setTimeout"],B1=-1,ye={};ye[Xo]=ye[Ho]=ye[Zo]=ye[jo]=ye[Qo]=ye[Jo]=ye[ea]=ye[ta]=ye[na]=!0,ye[Ge]=ye[Et]=ye[wr]=ye[Sn]=ye[$n]=ye[Cn]=ye[fi]=ye[di]=ye[It]=ye[xr]=ye[Gt]=ye[br]=ye[At]=ye[Sr]=ye[Cr]=!1;var _e={};_e[Ge]=_e[Et]=_e[wr]=_e[$n]=_e[Sn]=_e[Cn]=_e[Xo]=_e[Ho]=_e[Zo]=_e[jo]=_e[Qo]=_e[It]=_e[xr]=_e[Gt]=_e[br]=_e[At]=_e[Sr]=_e[pi]=_e[Jo]=_e[ea]=_e[ta]=_e[na]=!0,_e[fi]=_e[di]=_e[Cr]=!1;var F1={À:"A",Á:"A",Â:"A",Ã:"A",Ä:"A",Å:"A",à:"a",á:"a",â:"a",ã:"a",ä:"a",å:"a",Ç:"C",ç:"c",Ð:"D",ð:"d",È:"E",É:"E",Ê:"E",Ë:"E",è:"e",é:"e",ê:"e",ë:"e",Ì:"I",Í:"I",Î:"I",Ï:"I",ì:"i",í:"i",î:"i",ï:"i",Ñ:"N",ñ:"n",Ò:"O",Ó:"O",Ô:"O",Õ:"O",Ö:"O",Ø:"O",ò:"o",ó:"o",ô:"o",õ:"o",ö:"o",ø:"o",Ù:"U",Ú:"U",Û:"U",Ü:"U",ù:"u",ú:"u",û:"u",ü:"u",Ý:"Y",ý:"y",ÿ:"y",Æ:"Ae",æ:"ae",Þ:"Th",þ:"th",ß:"ss",Ā:"A",Ă:"A",Ą:"A",ā:"a",ă:"a",ą:"a",Ć:"C",Ĉ:"C",Ċ:"C",Č:"C",ć:"c",ĉ:"c",ċ:"c",č:"c",Ď:"D",Đ:"D",ď:"d",đ:"d",Ē:"E",Ĕ:"E",Ė:"E",Ę:"E",Ě:"E",ē:"e",ĕ:"e",ė:"e",ę:"e",ě:"e",Ĝ:"G",Ğ:"G",Ġ:"G",Ģ:"G",ĝ:"g",ğ:"g",ġ:"g",ģ:"g",Ĥ:"H",Ħ:"H",ĥ:"h",ħ:"h",Ĩ:"I",Ī:"I",Ĭ:"I",Į:"I",İ:"I",ĩ:"i",ī:"i",ĭ:"i",į:"i",ı:"i",Ĵ:"J",ĵ:"j",Ķ:"K",ķ:"k",ĸ:"k",Ĺ:"L",Ļ:"L",Ľ:"L",Ŀ:"L",Ł:"L",ĺ:"l",ļ:"l",ľ:"l",ŀ:"l",ł:"l",Ń:"N",Ņ:"N",Ň:"N",Ŋ:"N",ń:"n",ņ:"n",ň:"n",ŋ:"n",Ō:"O",Ŏ:"O",Ő:"O",ō:"o",ŏ:"o",ő:"o",Ŕ:"R",Ŗ:"R",Ř:"R",ŕ:"r",ŗ:"r",ř:"r",Ś:"S",Ŝ:"S",Ş:"S",Š:"S",ś:"s",ŝ:"s",ş:"s",š:"s",Ţ:"T",Ť:"T",Ŧ:"T",ţ:"t",ť:"t",ŧ:"t",Ũ:"U",Ū:"U",Ŭ:"U",Ů:"U",Ű:"U",Ų:"U",ũ:"u",ū:"u",ŭ:"u",ů:"u",ű:"u",ų:"u",Ŵ:"W",ŵ:"w",Ŷ:"Y",ŷ:"y",Ÿ:"Y",Ź:"Z",Ż:"Z",Ž:"Z",ź:"z",ż:"z",ž:"z",Ĳ:"IJ",ĳ:"ij",Œ:"Oe",œ:"oe",ŉ:"'n",ſ:"s"},G1={"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"},W1={"&amp;":"&","&lt;":"<","&gt;":">","&quot;":'"',"&#39;":"'"},$1={"\\":"\\","'":"'","\n":"n","\r":"r","\u2028":"u2028","\u2029":"u2029"},z1=parseFloat,V1=parseInt,Il=typeof global=="object"&&global&&global.Object===Object&&global,Y1=typeof self=="object"&&self&&self.Object===Object&&self,Ue=Il||Y1||Function("return this")(),ua=typeof mr=="object"&&mr&&!mr.nodeType&&mr,wn=ua&&typeof ai=="object"&&ai&&!ai.nodeType&&ai,Al=wn&&wn.exports===ua,fa=Al&&Il.process,gt=function(){try{var v=wn&&wn.require&&wn.require("util").types;return v||fa&&fa.binding&&fa.binding("util")}catch{}}(),Ll=gt&&gt.isArrayBuffer,Ol=gt&&gt.isDate,Nl=gt&&gt.isMap,Rl=gt&&gt.isRegExp,kl=gt&&gt.isSet,Pl=gt&&gt.isTypedArray;function ot(v,E,T){switch(T.length){case 0:return v.call(E);case 1:return v.call(E,T[0]);case 2:return v.call(E,T[0],T[1]);case 3:return v.call(E,T[0],T[1],T[2])}return v.apply(E,T)}function K1(v,E,T,Y){for(var J=-1,ce=v==null?0:v.length;++J<ce;){var Pe=v[J];E(Y,Pe,T(Pe),v)}return Y}function ht(v,E){for(var T=-1,Y=v==null?0:v.length;++T<Y&&E(v[T],T,v)!==!1;);return v}function q1(v,E){for(var T=v==null?0:v.length;T--&&E(v[T],T,v)!==!1;);return v}function Ml(v,E){for(var T=-1,Y=v==null?0:v.length;++T<Y;)if(!E(v[T],T,v))return!1;return!0}function tn(v,E){for(var T=-1,Y=v==null?0:v.length,J=0,ce=[];++T<Y;){var Pe=v[T];E(Pe,T,v)&&(ce[J++]=Pe)}return ce}function _i(v,E){var T=v==null?0:v.length;return!!T&&Vn(v,E,0)>-1}function da(v,E,T){for(var Y=-1,J=v==null?0:v.length;++Y<J;)if(T(E,v[Y]))return!0;return!1}function xe(v,E){for(var T=-1,Y=v==null?0:v.length,J=Array(Y);++T<Y;)J[T]=E(v[T],T,v);return J}function nn(v,E){for(var T=-1,Y=E.length,J=v.length;++T<Y;)v[J+T]=E[T];return v}function pa(v,E,T,Y){var J=-1,ce=v==null?0:v.length;for(Y&&ce&&(T=v[++J]);++J<ce;)T=E(T,v[J],J,v);return T}function X1(v,E,T,Y){var J=v==null?0:v.length;for(Y&&J&&(T=v[--J]);J--;)T=E(T,v[J],J,v);return T}function ga(v,E){for(var T=-1,Y=v==null?0:v.length;++T<Y;)if(E(v[T],T,v))return!0;return!1}var H1=ha("length");function Z1(v){return v.split("")}function j1(v){return v.match(o1)||[]}function Dl(v,E,T){var Y;return T(v,function(J,ce,Pe){if(E(J,ce,Pe))return Y=ce,!1}),Y}function yi(v,E,T,Y){for(var J=v.length,ce=T+(Y?1:-1);Y?ce--:++ce<J;)if(E(v[ce],ce,v))return ce;return-1}function Vn(v,E,T){return E===E?cg(v,E,T):yi(v,Ul,T)}function Q1(v,E,T,Y){for(var J=T-1,ce=v.length;++J<ce;)if(Y(v[J],E))return J;return-1}function Ul(v){return v!==v}function Bl(v,E){var T=v==null?0:v.length;return T?_a(v,E)/T:pt}function ha(v){return function(E){return E==null?n:E[v]}}function ma(v){return function(E){return v==null?n:v[E]}}function Fl(v,E,T,Y,J){return J(v,function(ce,Pe,he){T=Y?(Y=!1,ce):E(T,ce,Pe,he)}),T}function J1(v,E){var T=v.length;for(v.sort(E);T--;)v[T]=v[T].value;return v}function _a(v,E){for(var T,Y=-1,J=v.length;++Y<J;){var ce=E(v[Y]);ce!==n&&(T=T===n?ce:T+ce)}return T}function ya(v,E){for(var T=-1,Y=Array(v);++T<v;)Y[T]=E(T);return Y}function eg(v,E){return xe(E,function(T){return[T,v[T]]})}function Gl(v){return v&&v.slice(0,Vl(v)+1).replace(ia,"")}function at(v){return function(E){return v(E)}}function va(v,E){return xe(E,function(T){return v[T]})}function Tr(v,E){return v.has(E)}function Wl(v,E){for(var T=-1,Y=v.length;++T<Y&&Vn(E,v[T],0)>-1;);return T}function $l(v,E){for(var T=v.length;T--&&Vn(E,v[T],0)>-1;);return T}function tg(v,E){for(var T=v.length,Y=0;T--;)v[T]===E&&++Y;return Y}var ng=ma(F1),rg=ma(G1);function ig(v){return"\\"+$1[v]}function og(v,E){return v==null?n:v[E]}function Yn(v){return M1.test(v)}function ag(v){return D1.test(v)}function sg(v){for(var E,T=[];!(E=v.next()).done;)T.push(E.value);return T}function xa(v){var E=-1,T=Array(v.size);return v.forEach(function(Y,J){T[++E]=[J,Y]}),T}function zl(v,E){return function(T){return v(E(T))}}function rn(v,E){for(var T=-1,Y=v.length,J=0,ce=[];++T<Y;){var Pe=v[T];(Pe===E||Pe===I)&&(v[T]=I,ce[J++]=T)}return ce}function xi(v){var E=-1,T=Array(v.size);return v.forEach(function(Y){T[++E]=Y}),T}function lg(v){var E=-1,T=Array(v.size);return v.forEach(function(Y){T[++E]=[Y,Y]}),T}function cg(v,E,T){for(var Y=T-1,J=v.length;++Y<J;)if(v[Y]===E)return Y;return-1}function ug(v,E,T){for(var Y=T+1;Y--;)if(v[Y]===E)return Y;return Y}function Kn(v){return Yn(v)?dg(v):H1(v)}function Lt(v){return Yn(v)?pg(v):Z1(v)}function Vl(v){for(var E=v.length;E--&&t1.test(v.charAt(E)););return E}var fg=ma(W1);function dg(v){for(var E=ca.lastIndex=0;ca.test(v);)++E;return E}function pg(v){return v.match(ca)||[]}function gg(v){return v.match(P1)||[]}var hg=function v(E){E=E==null?Ue:on.defaults(Ue.Object(),E,on.pick(Ue,U1));var T=E.Array,Y=E.Date,J=E.Error,ce=E.Function,Pe=E.Math,he=E.Object,ba=E.RegExp,mg=E.String,mt=E.TypeError,bi=T.prototype,_g=ce.prototype,qn=he.prototype,Si=E["__core-js_shared__"],Ci=_g.toString,fe=qn.hasOwnProperty,yg=0,Yl=function(){var e=/[^.]+$/.exec(Si&&Si.keys&&Si.keys.IE_PROTO||"");return e?"Symbol(src)_1."+e:""}(),wi=qn.toString,vg=Ci.call(he),xg=Ue._,bg=ba("^"+Ci.call(fe).replace(ra,"\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g,"$1.*?")+"$"),Ti=Al?E.Buffer:n,an=E.Symbol,Ei=E.Uint8Array,Kl=Ti?Ti.allocUnsafe:n,Ii=zl(he.getPrototypeOf,he),ql=he.create,Xl=qn.propertyIsEnumerable,Ai=bi.splice,Hl=an?an.isConcatSpreadable:n,Er=an?an.iterator:n,Tn=an?an.toStringTag:n,Li=function(){try{var e=On(he,"defineProperty");return e({},"",{}),e}catch{}}(),Sg=E.clearTimeout!==Ue.clearTimeout&&E.clearTimeout,Cg=Y&&Y.now!==Ue.Date.now&&Y.now,wg=E.setTimeout!==Ue.setTimeout&&E.setTimeout,Oi=Pe.ceil,Ni=Pe.floor,Sa=he.getOwnPropertySymbols,Tg=Ti?Ti.isBuffer:n,Zl=E.isFinite,Eg=bi.join,Ig=zl(he.keys,he),Me=Pe.max,Ve=Pe.min,Ag=Y.now,Lg=E.parseInt,jl=Pe.random,Og=bi.reverse,Ca=On(E,"DataView"),Ir=On(E,"Map"),wa=On(E,"Promise"),Xn=On(E,"Set"),Ar=On(E,"WeakMap"),Lr=On(he,"create"),Ri=Ar&&new Ar,Hn={},Ng=Nn(Ca),Rg=Nn(Ir),kg=Nn(wa),Pg=Nn(Xn),Mg=Nn(Ar),ki=an?an.prototype:n,Or=ki?ki.valueOf:n,Ql=ki?ki.toString:n;function l(e){if(Te(e)&&!ee(e)&&!(e instanceof oe)){if(e instanceof _t)return e;if(fe.call(e,"__wrapped__"))return Jc(e)}return new _t(e)}var Zn=function(){function e(){}return function(t){if(!Ce(t))return{};if(ql)return ql(t);e.prototype=t;var r=new e;return e.prototype=n,r}}();function Pi(){}function _t(e,t){this.__wrapped__=e,this.__actions__=[],this.__chain__=!!t,this.__index__=0,this.__values__=n}l.templateSettings={escape:Hp,evaluate:Zp,interpolate:sl,variable:"",imports:{_:l}},l.prototype=Pi.prototype,l.prototype.constructor=l,_t.prototype=Zn(Pi.prototype),_t.prototype.constructor=_t;function oe(e){this.__wrapped__=e,this.__actions__=[],this.__dir__=1,this.__filtered__=!1,this.__iteratees__=[],this.__takeCount__=Ke,this.__views__=[]}function Dg(){var e=new oe(this.__wrapped__);return e.__actions__=et(this.__actions__),e.__dir__=this.__dir__,e.__filtered__=this.__filtered__,e.__iteratees__=et(this.__iteratees__),e.__takeCount__=this.__takeCount__,e.__views__=et(this.__views__),e}function Ug(){if(this.__filtered__){var e=new oe(this);e.__dir__=-1,e.__filtered__=!0}else e=this.clone(),e.__dir__*=-1;return e}function Bg(){var e=this.__wrapped__.value(),t=this.__dir__,r=ee(e),i=t<0,s=r?e.length:0,u=Zh(0,s,this.__views__),g=u.start,_=u.end,b=_-g,A=i?_:g-1,L=this.__iteratees__,D=L.length,$=0,X=Ve(b,this.__takeCount__);if(!r||!i&&s==b&&X==b)return Sc(e,this.__actions__);var Z=[];e:for(;b--&&$<X;){A+=t;for(var ne=-1,j=e[A];++ne<D;){var ie=L[ne],ae=ie.iteratee,ct=ie.type,He=ae(j);if(ct==Ie)j=He;else if(!He){if(ct==ve)continue e;break e}}Z[$++]=j}return Z}oe.prototype=Zn(Pi.prototype),oe.prototype.constructor=oe;function En(e){var t=-1,r=e==null?0:e.length;for(this.clear();++t<r;){var i=e[t];this.set(i[0],i[1])}}function Fg(){this.__data__=Lr?Lr(null):{},this.size=0}function Gg(e){var t=this.has(e)&&delete this.__data__[e];return this.size-=t?1:0,t}function Wg(e){var t=this.__data__;if(Lr){var r=t[e];return r===x?n:r}return fe.call(t,e)?t[e]:n}function $g(e){var t=this.__data__;return Lr?t[e]!==n:fe.call(t,e)}function zg(e,t){var r=this.__data__;return this.size+=this.has(e)?0:1,r[e]=Lr&&t===n?x:t,this}En.prototype.clear=Fg,En.prototype.delete=Gg,En.prototype.get=Wg,En.prototype.has=$g,En.prototype.set=zg;function Wt(e){var t=-1,r=e==null?0:e.length;for(this.clear();++t<r;){var i=e[t];this.set(i[0],i[1])}}function Vg(){this.__data__=[],this.size=0}function Yg(e){var t=this.__data__,r=Mi(t,e);if(r<0)return!1;var i=t.length-1;return r==i?t.pop():Ai.call(t,r,1),--this.size,!0}function Kg(e){var t=this.__data__,r=Mi(t,e);return r<0?n:t[r][1]}function qg(e){return Mi(this.__data__,e)>-1}function Xg(e,t){var r=this.__data__,i=Mi(r,e);return i<0?(++this.size,r.push([e,t])):r[i][1]=t,this}Wt.prototype.clear=Vg,Wt.prototype.delete=Yg,Wt.prototype.get=Kg,Wt.prototype.has=qg,Wt.prototype.set=Xg;function $t(e){var t=-1,r=e==null?0:e.length;for(this.clear();++t<r;){var i=e[t];this.set(i[0],i[1])}}function Hg(){this.size=0,this.__data__={hash:new En,map:new(Ir||Wt),string:new En}}function Zg(e){var t=qi(this,e).delete(e);return this.size-=t?1:0,t}function jg(e){return qi(this,e).get(e)}function Qg(e){return qi(this,e).has(e)}function Jg(e,t){var r=qi(this,e),i=r.size;return r.set(e,t),this.size+=r.size==i?0:1,this}$t.prototype.clear=Hg,$t.prototype.delete=Zg,$t.prototype.get=jg,$t.prototype.has=Qg,$t.prototype.set=Jg;function In(e){var t=-1,r=e==null?0:e.length;for(this.__data__=new $t;++t<r;)this.add(e[t])}function eh(e){return this.__data__.set(e,x),this}function th(e){return this.__data__.has(e)}In.prototype.add=In.prototype.push=eh,In.prototype.has=th;function Ot(e){var t=this.__data__=new Wt(e);this.size=t.size}function nh(){this.__data__=new Wt,this.size=0}function rh(e){var t=this.__data__,r=t.delete(e);return this.size=t.size,r}function ih(e){return this.__data__.get(e)}function oh(e){return this.__data__.has(e)}function ah(e,t){var r=this.__data__;if(r instanceof Wt){var i=r.__data__;if(!Ir||i.length<a-1)return i.push([e,t]),this.size=++r.size,this;r=this.__data__=new $t(i)}return r.set(e,t),this.size=r.size,this}Ot.prototype.clear=nh,Ot.prototype.delete=rh,Ot.prototype.get=ih,Ot.prototype.has=oh,Ot.prototype.set=ah;function Jl(e,t){var r=ee(e),i=!r&&Rn(e),s=!r&&!i&&fn(e),u=!r&&!i&&!s&&er(e),g=r||i||s||u,_=g?ya(e.length,mg):[],b=_.length;for(var A in e)(t||fe.call(e,A))&&!(g&&(A=="length"||s&&(A=="offset"||A=="parent")||u&&(A=="buffer"||A=="byteLength"||A=="byteOffset")||Kt(A,b)))&&_.push(A);return _}function ec(e){var t=e.length;return t?e[Ma(0,t-1)]:n}function sh(e,t){return Xi(et(e),An(t,0,e.length))}function lh(e){return Xi(et(e))}function Ta(e,t,r){(r!==n&&!Nt(e[t],r)||r===n&&!(t in e))&&zt(e,t,r)}function Nr(e,t,r){var i=e[t];(!(fe.call(e,t)&&Nt(i,r))||r===n&&!(t in e))&&zt(e,t,r)}function Mi(e,t){for(var r=e.length;r--;)if(Nt(e[r][0],t))return r;return-1}function ch(e,t,r,i){return sn(e,function(s,u,g){t(i,s,r(s),g)}),i}function tc(e,t){return e&&Pt(t,Be(t),e)}function uh(e,t){return e&&Pt(t,nt(t),e)}function zt(e,t,r){t=="__proto__"&&Li?Li(e,t,{configurable:!0,enumerable:!0,value:r,writable:!0}):e[t]=r}function Ea(e,t){for(var r=-1,i=t.length,s=T(i),u=e==null;++r<i;)s[r]=u?n:as(e,t[r]);return s}function An(e,t,r){return e===e&&(r!==n&&(e=e<=r?e:r),t!==n&&(e=e>=t?e:t)),e}function yt(e,t,r,i,s,u){var g,_=t&k,b=t&V,A=t&U;if(r&&(g=s?r(e,i,s,u):r(e)),g!==n)return g;if(!Ce(e))return e;var L=ee(e);if(L){if(g=Qh(e),!_)return et(e,g)}else{var D=Ye(e),$=D==di||D==rl;if(fn(e))return Tc(e,_);if(D==Gt||D==Ge||$&&!s){if(g=b||$?{}:Vc(e),!_)return b?Wh(e,uh(g,e)):Gh(e,tc(g,e))}else{if(!_e[D])return s?e:{};g=Jh(e,D,_)}}u||(u=new Ot);var X=u.get(e);if(X)return X;u.set(e,g),vu(e)?e.forEach(function(j){g.add(yt(j,t,r,j,e,u))}):_u(e)&&e.forEach(function(j,ie){g.set(ie,yt(j,t,r,ie,e,u))});var Z=A?b?Ka:Ya:b?nt:Be,ne=L?n:Z(e);return ht(ne||e,function(j,ie){ne&&(ie=j,j=e[ie]),Nr(g,ie,yt(j,t,r,ie,e,u))}),g}function fh(e){var t=Be(e);return function(r){return nc(r,e,t)}}function nc(e,t,r){var i=r.length;if(e==null)return!i;for(e=he(e);i--;){var s=r[i],u=t[s],g=e[s];if(g===n&&!(s in e)||!u(g))return!1}return!0}function rc(e,t,r){if(typeof e!="function")throw new mt(p);return Br(function(){e.apply(n,r)},t)}function Rr(e,t,r,i){var s=-1,u=_i,g=!0,_=e.length,b=[],A=t.length;if(!_)return b;r&&(t=xe(t,at(r))),i?(u=da,g=!1):t.length>=a&&(u=Tr,g=!1,t=new In(t));e:for(;++s<_;){var L=e[s],D=r==null?L:r(L);if(L=i||L!==0?L:0,g&&D===D){for(var $=A;$--;)if(t[$]===D)continue e;b.push(L)}else u(t,D,i)||b.push(L)}return b}var sn=Oc(kt),ic=Oc(Aa,!0);function dh(e,t){var r=!0;return sn(e,function(i,s,u){return r=!!t(i,s,u),r}),r}function Di(e,t,r){for(var i=-1,s=e.length;++i<s;){var u=e[i],g=t(u);if(g!=null&&(_===n?g===g&&!lt(g):r(g,_)))var _=g,b=u}return b}function ph(e,t,r,i){var s=e.length;for(r=te(r),r<0&&(r=-r>s?0:s+r),i=i===n||i>s?s:te(i),i<0&&(i+=s),i=r>i?0:bu(i);r<i;)e[r++]=t;return e}function oc(e,t){var r=[];return sn(e,function(i,s,u){t(i,s,u)&&r.push(i)}),r}function We(e,t,r,i,s){var u=-1,g=e.length;for(r||(r=tm),s||(s=[]);++u<g;){var _=e[u];t>0&&r(_)?t>1?We(_,t-1,r,i,s):nn(s,_):i||(s[s.length]=_)}return s}var Ia=Nc(),ac=Nc(!0);function kt(e,t){return e&&Ia(e,t,Be)}function Aa(e,t){return e&&ac(e,t,Be)}function Ui(e,t){return tn(t,function(r){return qt(e[r])})}function Ln(e,t){t=cn(t,e);for(var r=0,i=t.length;e!=null&&r<i;)e=e[Mt(t[r++])];return r&&r==i?e:n}function sc(e,t,r){var i=t(e);return ee(e)?i:nn(i,r(e))}function qe(e){return e==null?e===n?$p:Gp:Tn&&Tn in he(e)?Hh(e):lm(e)}function La(e,t){return e>t}function gh(e,t){return e!=null&&fe.call(e,t)}function hh(e,t){return e!=null&&t in he(e)}function mh(e,t,r){return e>=Ve(t,r)&&e<Me(t,r)}function Oa(e,t,r){for(var i=r?da:_i,s=e[0].length,u=e.length,g=u,_=T(u),b=1/0,A=[];g--;){var L=e[g];g&&t&&(L=xe(L,at(t))),b=Ve(L.length,b),_[g]=!r&&(t||s>=120&&L.length>=120)?new In(g&&L):n}L=e[0];var D=-1,$=_[0];e:for(;++D<s&&A.length<b;){var X=L[D],Z=t?t(X):X;if(X=r||X!==0?X:0,!($?Tr($,Z):i(A,Z,r))){for(g=u;--g;){var ne=_[g];if(!(ne?Tr(ne,Z):i(e[g],Z,r)))continue e}$&&$.push(Z),A.push(X)}}return A}function _h(e,t,r,i){return kt(e,function(s,u,g){t(i,r(s),u,g)}),i}function kr(e,t,r){t=cn(t,e),e=Xc(e,t);var i=e==null?e:e[Mt(xt(t))];return i==null?n:ot(i,e,r)}function lc(e){return Te(e)&&qe(e)==Ge}function yh(e){return Te(e)&&qe(e)==wr}function vh(e){return Te(e)&&qe(e)==Cn}function Pr(e,t,r,i,s){return e===t?!0:e==null||t==null||!Te(e)&&!Te(t)?e!==e&&t!==t:xh(e,t,r,i,Pr,s)}function xh(e,t,r,i,s,u){var g=ee(e),_=ee(t),b=g?Et:Ye(e),A=_?Et:Ye(t);b=b==Ge?Gt:b,A=A==Ge?Gt:A;var L=b==Gt,D=A==Gt,$=b==A;if($&&fn(e)){if(!fn(t))return!1;g=!0,L=!1}if($&&!L)return u||(u=new Ot),g||er(e)?Wc(e,t,r,i,s,u):qh(e,t,b,r,i,s,u);if(!(r&B)){var X=L&&fe.call(e,"__wrapped__"),Z=D&&fe.call(t,"__wrapped__");if(X||Z){var ne=X?e.value():e,j=Z?t.value():t;return u||(u=new Ot),s(ne,j,r,i,u)}}return $?(u||(u=new Ot),Xh(e,t,r,i,s,u)):!1}function bh(e){return Te(e)&&Ye(e)==It}function Na(e,t,r,i){var s=r.length,u=s,g=!i;if(e==null)return!u;for(e=he(e);s--;){var _=r[s];if(g&&_[2]?_[1]!==e[_[0]]:!(_[0]in e))return!1}for(;++s<u;){_=r[s];var b=_[0],A=e[b],L=_[1];if(g&&_[2]){if(A===n&&!(b in e))return!1}else{var D=new Ot;if(i)var $=i(A,L,b,e,t,D);if(!($===n?Pr(L,A,B|z,i,D):$))return!1}}return!0}function cc(e){if(!Ce(e)||rm(e))return!1;var t=qt(e)?bg:f1;return t.test(Nn(e))}function Sh(e){return Te(e)&&qe(e)==br}function Ch(e){return Te(e)&&Ye(e)==At}function wh(e){return Te(e)&&eo(e.length)&&!!ye[qe(e)]}function uc(e){return typeof e=="function"?e:e==null?rt:typeof e=="object"?ee(e)?pc(e[0],e[1]):dc(e):Ru(e)}function Ra(e){if(!Ur(e))return Ig(e);var t=[];for(var r in he(e))fe.call(e,r)&&r!="constructor"&&t.push(r);return t}function Th(e){if(!Ce(e))return sm(e);var t=Ur(e),r=[];for(var i in e)i=="constructor"&&(t||!fe.call(e,i))||r.push(i);return r}function ka(e,t){return e<t}function fc(e,t){var r=-1,i=tt(e)?T(e.length):[];return sn(e,function(s,u,g){i[++r]=t(s,u,g)}),i}function dc(e){var t=Xa(e);return t.length==1&&t[0][2]?Kc(t[0][0],t[0][1]):function(r){return r===e||Na(r,e,t)}}function pc(e,t){return Za(e)&&Yc(t)?Kc(Mt(e),t):function(r){var i=as(r,e);return i===n&&i===t?ss(r,e):Pr(t,i,B|z)}}function Bi(e,t,r,i,s){e!==t&&Ia(t,function(u,g){if(s||(s=new Ot),Ce(u))Eh(e,t,g,r,Bi,i,s);else{var _=i?i(Qa(e,g),u,g+"",e,t,s):n;_===n&&(_=u),Ta(e,g,_)}},nt)}function Eh(e,t,r,i,s,u,g){var _=Qa(e,r),b=Qa(t,r),A=g.get(b);if(A){Ta(e,r,A);return}var L=u?u(_,b,r+"",e,t,g):n,D=L===n;if(D){var $=ee(b),X=!$&&fn(b),Z=!$&&!X&&er(b);L=b,$||X||Z?ee(_)?L=_:Ae(_)?L=et(_):X?(D=!1,L=Tc(b,!0)):Z?(D=!1,L=Ec(b,!0)):L=[]:Fr(b)||Rn(b)?(L=_,Rn(_)?L=Su(_):(!Ce(_)||qt(_))&&(L=Vc(b))):D=!1}D&&(g.set(b,L),s(L,b,i,u,g),g.delete(b)),Ta(e,r,L)}function gc(e,t){var r=e.length;if(r)return t+=t<0?r:0,Kt(t,r)?e[t]:n}function hc(e,t,r){t.length?t=xe(t,function(u){return ee(u)?function(g){return Ln(g,u.length===1?u[0]:u)}:u}):t=[rt];var i=-1;t=xe(t,at(H()));var s=fc(e,function(u,g,_){var b=xe(t,function(A){return A(u)});return{criteria:b,index:++i,value:u}});return J1(s,function(u,g){return Fh(u,g,r)})}function Ih(e,t){return mc(e,t,function(r,i){return ss(e,i)})}function mc(e,t,r){for(var i=-1,s=t.length,u={};++i<s;){var g=t[i],_=Ln(e,g);r(_,g)&&Mr(u,cn(g,e),_)}return u}function Ah(e){return function(t){return Ln(t,e)}}function Pa(e,t,r,i){var s=i?Q1:Vn,u=-1,g=t.length,_=e;for(e===t&&(t=et(t)),r&&(_=xe(e,at(r)));++u<g;)for(var b=0,A=t[u],L=r?r(A):A;(b=s(_,L,b,i))>-1;)_!==e&&Ai.call(_,b,1),Ai.call(e,b,1);return e}function _c(e,t){for(var r=e?t.length:0,i=r-1;r--;){var s=t[r];if(r==i||s!==u){var u=s;Kt(s)?Ai.call(e,s,1):Ba(e,s)}}return e}function Ma(e,t){return e+Ni(jl()*(t-e+1))}function Lh(e,t,r,i){for(var s=-1,u=Me(Oi((t-e)/(r||1)),0),g=T(u);u--;)g[i?u:++s]=e,e+=r;return g}function Da(e,t){var r="";if(!e||t<1||t>ze)return r;do t%2&&(r+=e),t=Ni(t/2),t&&(e+=e);while(t);return r}function re(e,t){return Ja(qc(e,t,rt),e+"")}function Oh(e){return ec(tr(e))}function Nh(e,t){var r=tr(e);return Xi(r,An(t,0,r.length))}function Mr(e,t,r,i){if(!Ce(e))return e;t=cn(t,e);for(var s=-1,u=t.length,g=u-1,_=e;_!=null&&++s<u;){var b=Mt(t[s]),A=r;if(b==="__proto__"||b==="constructor"||b==="prototype")return e;if(s!=g){var L=_[b];A=i?i(L,b,_):n,A===n&&(A=Ce(L)?L:Kt(t[s+1])?[]:{})}Nr(_,b,A),_=_[b]}return e}var yc=Ri?function(e,t){return Ri.set(e,t),e}:rt,Rh=Li?function(e,t){return Li(e,"toString",{configurable:!0,enumerable:!1,value:cs(t),writable:!0})}:rt;function kh(e){return Xi(tr(e))}function vt(e,t,r){var i=-1,s=e.length;t<0&&(t=-t>s?0:s+t),r=r>s?s:r,r<0&&(r+=s),s=t>r?0:r-t>>>0,t>>>=0;for(var u=T(s);++i<s;)u[i]=e[i+t];return u}function Ph(e,t){var r;return sn(e,function(i,s,u){return r=t(i,s,u),!r}),!!r}function Fi(e,t,r){var i=0,s=e==null?i:e.length;if(typeof t=="number"&&t===t&&s<=Wn){for(;i<s;){var u=i+s>>>1,g=e[u];g!==null&&!lt(g)&&(r?g<=t:g<t)?i=u+1:s=u}return s}return Ua(e,t,rt,r)}function Ua(e,t,r,i){var s=0,u=e==null?0:e.length;if(u===0)return 0;t=r(t);for(var g=t!==t,_=t===null,b=lt(t),A=t===n;s<u;){var L=Ni((s+u)/2),D=r(e[L]),$=D!==n,X=D===null,Z=D===D,ne=lt(D);if(g)var j=i||Z;else A?j=Z&&(i||$):_?j=Z&&$&&(i||!X):b?j=Z&&$&&!X&&(i||!ne):X||ne?j=!1:j=i?D<=t:D<t;j?s=L+1:u=L}return Ve(u,yr)}function vc(e,t){for(var r=-1,i=e.length,s=0,u=[];++r<i;){var g=e[r],_=t?t(g):g;if(!r||!Nt(_,b)){var b=_;u[s++]=g===0?0:g}}return u}function xc(e){return typeof e=="number"?e:lt(e)?pt:+e}function st(e){if(typeof e=="string")return e;if(ee(e))return xe(e,st)+"";if(lt(e))return Ql?Ql.call(e):"";var t=e+"";return t=="0"&&1/e==-De?"-0":t}function ln(e,t,r){var i=-1,s=_i,u=e.length,g=!0,_=[],b=_;if(r)g=!1,s=da;else if(u>=a){var A=t?null:Yh(e);if(A)return xi(A);g=!1,s=Tr,b=new In}else b=t?[]:_;e:for(;++i<u;){var L=e[i],D=t?t(L):L;if(L=r||L!==0?L:0,g&&D===D){for(var $=b.length;$--;)if(b[$]===D)continue e;t&&b.push(D),_.push(L)}else s(b,D,r)||(b!==_&&b.push(D),_.push(L))}return _}function Ba(e,t){return t=cn(t,e),e=Xc(e,t),e==null||delete e[Mt(xt(t))]}function bc(e,t,r,i){return Mr(e,t,r(Ln(e,t)),i)}function Gi(e,t,r,i){for(var s=e.length,u=i?s:-1;(i?u--:++u<s)&&t(e[u],u,e););return r?vt(e,i?0:u,i?u+1:s):vt(e,i?u+1:0,i?s:u)}function Sc(e,t){var r=e;return r instanceof oe&&(r=r.value()),pa(t,function(i,s){return s.func.apply(s.thisArg,nn([i],s.args))},r)}function Fa(e,t,r){var i=e.length;if(i<2)return i?ln(e[0]):[];for(var s=-1,u=T(i);++s<i;)for(var g=e[s],_=-1;++_<i;)_!=s&&(u[s]=Rr(u[s]||g,e[_],t,r));return ln(We(u,1),t,r)}function Cc(e,t,r){for(var i=-1,s=e.length,u=t.length,g={};++i<s;){var _=i<u?t[i]:n;r(g,e[i],_)}return g}function Ga(e){return Ae(e)?e:[]}function Wa(e){return typeof e=="function"?e:rt}function cn(e,t){return ee(e)?e:Za(e,t)?[e]:Qc(ue(e))}var Mh=re;function un(e,t,r){var i=e.length;return r=r===n?i:r,!t&&r>=i?e:vt(e,t,r)}var wc=Sg||function(e){return Ue.clearTimeout(e)};function Tc(e,t){if(t)return e.slice();var r=e.length,i=Kl?Kl(r):new e.constructor(r);return e.copy(i),i}function $a(e){var t=new e.constructor(e.byteLength);return new Ei(t).set(new Ei(e)),t}function Dh(e,t){var r=t?$a(e.buffer):e.buffer;return new e.constructor(r,e.byteOffset,e.byteLength)}function Uh(e){var t=new e.constructor(e.source,ll.exec(e));return t.lastIndex=e.lastIndex,t}function Bh(e){return Or?he(Or.call(e)):{}}function Ec(e,t){var r=t?$a(e.buffer):e.buffer;return new e.constructor(r,e.byteOffset,e.length)}function Ic(e,t){if(e!==t){var r=e!==n,i=e===null,s=e===e,u=lt(e),g=t!==n,_=t===null,b=t===t,A=lt(t);if(!_&&!A&&!u&&e>t||u&&g&&b&&!_&&!A||i&&g&&b||!r&&b||!s)return 1;if(!i&&!u&&!A&&e<t||A&&r&&s&&!i&&!u||_&&r&&s||!g&&s||!b)return-1}return 0}function Fh(e,t,r){for(var i=-1,s=e.criteria,u=t.criteria,g=s.length,_=r.length;++i<g;){var b=Ic(s[i],u[i]);if(b){if(i>=_)return b;var A=r[i];return b*(A=="desc"?-1:1)}}return e.index-t.index}function Ac(e,t,r,i){for(var s=-1,u=e.length,g=r.length,_=-1,b=t.length,A=Me(u-g,0),L=T(b+A),D=!i;++_<b;)L[_]=t[_];for(;++s<g;)(D||s<u)&&(L[r[s]]=e[s]);for(;A--;)L[_++]=e[s++];return L}function Lc(e,t,r,i){for(var s=-1,u=e.length,g=-1,_=r.length,b=-1,A=t.length,L=Me(u-_,0),D=T(L+A),$=!i;++s<L;)D[s]=e[s];for(var X=s;++b<A;)D[X+b]=t[b];for(;++g<_;)($||s<u)&&(D[X+r[g]]=e[s++]);return D}function et(e,t){var r=-1,i=e.length;for(t||(t=T(i));++r<i;)t[r]=e[r];return t}function Pt(e,t,r,i){var s=!r;r||(r={});for(var u=-1,g=t.length;++u<g;){var _=t[u],b=i?i(r[_],e[_],_,r,e):n;b===n&&(b=e[_]),s?zt(r,_,b):Nr(r,_,b)}return r}function Gh(e,t){return Pt(e,Ha(e),t)}function Wh(e,t){return Pt(e,$c(e),t)}function Wi(e,t){return function(r,i){var s=ee(r)?K1:ch,u=t?t():{};return s(r,e,H(i,2),u)}}function jn(e){return re(function(t,r){var i=-1,s=r.length,u=s>1?r[s-1]:n,g=s>2?r[2]:n;for(u=e.length>3&&typeof u=="function"?(s--,u):n,g&&Xe(r[0],r[1],g)&&(u=s<3?n:u,s=1),t=he(t);++i<s;){var _=r[i];_&&e(t,_,i,u)}return t})}function Oc(e,t){return function(r,i){if(r==null)return r;if(!tt(r))return e(r,i);for(var s=r.length,u=t?s:-1,g=he(r);(t?u--:++u<s)&&i(g[u],u,g)!==!1;);return r}}function Nc(e){return function(t,r,i){for(var s=-1,u=he(t),g=i(t),_=g.length;_--;){var b=g[e?_:++s];if(r(u[b],b,u)===!1)break}return t}}function $h(e,t,r){var i=t&N,s=Dr(e);function u(){var g=this&&this!==Ue&&this instanceof u?s:e;return g.apply(i?r:this,arguments)}return u}function Rc(e){return function(t){t=ue(t);var r=Yn(t)?Lt(t):n,i=r?r[0]:t.charAt(0),s=r?un(r,1).join(""):t.slice(1);return i[e]()+s}}function Qn(e){return function(t){return pa(Ou(Lu(t).replace(R1,"")),e,"")}}function Dr(e){return function(){var t=arguments;switch(t.length){case 0:return new e;case 1:return new e(t[0]);case 2:return new e(t[0],t[1]);case 3:return new e(t[0],t[1],t[2]);case 4:return new e(t[0],t[1],t[2],t[3]);case 5:return new e(t[0],t[1],t[2],t[3],t[4]);case 6:return new e(t[0],t[1],t[2],t[3],t[4],t[5]);case 7:return new e(t[0],t[1],t[2],t[3],t[4],t[5],t[6])}var r=Zn(e.prototype),i=e.apply(r,t);return Ce(i)?i:r}}function zh(e,t,r){var i=Dr(e);function s(){for(var u=arguments.length,g=T(u),_=u,b=Jn(s);_--;)g[_]=arguments[_];var A=u<3&&g[0]!==b&&g[u-1]!==b?[]:rn(g,b);if(u-=A.length,u<r)return Uc(e,t,$i,s.placeholder,n,g,A,n,n,r-u);var L=this&&this!==Ue&&this instanceof s?i:e;return ot(L,this,g)}return s}function kc(e){return function(t,r,i){var s=he(t);if(!tt(t)){var u=H(r,3);t=Be(t),r=function(_){return u(s[_],_,s)}}var g=e(t,r,i);return g>-1?s[u?t[g]:g]:n}}function Pc(e){return Yt(function(t){var r=t.length,i=r,s=_t.prototype.thru;for(e&&t.reverse();i--;){var u=t[i];if(typeof u!="function")throw new mt(p);if(s&&!g&&Ki(u)=="wrapper")var g=new _t([],!0)}for(i=g?i:r;++i<r;){u=t[i];var _=Ki(u),b=_=="wrapper"?qa(u):n;b&&ja(b[0])&&b[1]==(P|c|y|q)&&!b[4].length&&b[9]==1?g=g[Ki(b[0])].apply(g,b[3]):g=u.length==1&&ja(u)?g[_]():g.thru(u)}return function(){var A=arguments,L=A[0];if(g&&A.length==1&&ee(L))return g.plant(L).value();for(var D=0,$=r?t[D].apply(this,A):L;++D<r;)$=t[D].call(this,$);return $}})}function $i(e,t,r,i,s,u,g,_,b,A){var L=t&P,D=t&N,$=t&R,X=t&(c|h),Z=t&G,ne=$?n:Dr(e);function j(){for(var ie=arguments.length,ae=T(ie),ct=ie;ct--;)ae[ct]=arguments[ct];if(X)var He=Jn(j),ut=tg(ae,He);if(i&&(ae=Ac(ae,i,s,X)),u&&(ae=Lc(ae,u,g,X)),ie-=ut,X&&ie<A){var Le=rn(ae,He);return Uc(e,t,$i,j.placeholder,r,ae,Le,_,b,A-ie)}var Rt=D?r:this,Ht=$?Rt[e]:e;return ie=ae.length,_?ae=cm(ae,_):Z&&ie>1&&ae.reverse(),L&&b<ie&&(ae.length=b),this&&this!==Ue&&this instanceof j&&(Ht=ne||Dr(Ht)),Ht.apply(Rt,ae)}return j}function Mc(e,t){return function(r,i){return _h(r,e,t(i),{})}}function zi(e,t){return function(r,i){var s;if(r===n&&i===n)return t;if(r!==n&&(s=r),i!==n){if(s===n)return i;typeof r=="string"||typeof i=="string"?(r=st(r),i=st(i)):(r=xc(r),i=xc(i)),s=e(r,i)}return s}}function za(e){return Yt(function(t){return t=xe(t,at(H())),re(function(r){var i=this;return e(t,function(s){return ot(s,i,r)})})})}function Vi(e,t){t=t===n?" ":st(t);var r=t.length;if(r<2)return r?Da(t,e):t;var i=Da(t,Oi(e/Kn(t)));return Yn(t)?un(Lt(i),0,e).join(""):i.slice(0,e)}function Vh(e,t,r,i){var s=t&N,u=Dr(e);function g(){for(var _=-1,b=arguments.length,A=-1,L=i.length,D=T(L+b),$=this&&this!==Ue&&this instanceof g?u:e;++A<L;)D[A]=i[A];for(;b--;)D[A++]=arguments[++_];return ot($,s?r:this,D)}return g}function Dc(e){return function(t,r,i){return i&&typeof i!="number"&&Xe(t,r,i)&&(r=i=n),t=Xt(t),r===n?(r=t,t=0):r=Xt(r),i=i===n?t<r?1:-1:Xt(i),Lh(t,r,i,e)}}function Yi(e){return function(t,r){return typeof t=="string"&&typeof r=="string"||(t=bt(t),r=bt(r)),e(t,r)}}function Uc(e,t,r,i,s,u,g,_,b,A){var L=t&c,D=L?g:n,$=L?n:g,X=L?u:n,Z=L?n:u;t|=L?y:O,t&=~(L?O:y),t&K||(t&=~(N|R));var ne=[e,t,s,X,D,Z,$,_,b,A],j=r.apply(n,ne);return ja(e)&&Hc(j,ne),j.placeholder=i,Zc(j,e,t)}function Va(e){var t=Pe[e];return function(r,i){if(r=bt(r),i=i==null?0:Ve(te(i),292),i&&Zl(r)){var s=(ue(r)+"e").split("e"),u=t(s[0]+"e"+(+s[1]+i));return s=(ue(u)+"e").split("e"),+(s[0]+"e"+(+s[1]-i))}return t(r)}}var Yh=Xn&&1/xi(new Xn([,-0]))[1]==De?function(e){return new Xn(e)}:ds;function Bc(e){return function(t){var r=Ye(t);return r==It?xa(t):r==At?lg(t):eg(t,e(t))}}function Vt(e,t,r,i,s,u,g,_){var b=t&R;if(!b&&typeof e!="function")throw new mt(p);var A=i?i.length:0;if(A||(t&=~(y|O),i=s=n),g=g===n?g:Me(te(g),0),_=_===n?_:te(_),A-=s?s.length:0,t&O){var L=i,D=s;i=s=n}var $=b?n:qa(e),X=[e,t,r,i,s,L,D,u,g,_];if($&&am(X,$),e=X[0],t=X[1],r=X[2],i=X[3],s=X[4],_=X[9]=X[9]===n?b?0:e.length:Me(X[9]-A,0),!_&&t&(c|h)&&(t&=~(c|h)),!t||t==N)var Z=$h(e,t,r);else t==c||t==h?Z=zh(e,t,_):(t==y||t==(N|y))&&!s.length?Z=Vh(e,t,r,i):Z=$i.apply(n,X);var ne=$?yc:Hc;return Zc(ne(Z,X),e,t)}function Fc(e,t,r,i){return e===n||Nt(e,qn[r])&&!fe.call(i,r)?t:e}function Gc(e,t,r,i,s,u){return Ce(e)&&Ce(t)&&(u.set(t,e),Bi(e,t,n,Gc,u),u.delete(t)),e}function Kh(e){return Fr(e)?n:e}function Wc(e,t,r,i,s,u){var g=r&B,_=e.length,b=t.length;if(_!=b&&!(g&&b>_))return!1;var A=u.get(e),L=u.get(t);if(A&&L)return A==t&&L==e;var D=-1,$=!0,X=r&z?new In:n;for(u.set(e,t),u.set(t,e);++D<_;){var Z=e[D],ne=t[D];if(i)var j=g?i(ne,Z,D,t,e,u):i(Z,ne,D,e,t,u);if(j!==n){if(j)continue;$=!1;break}if(X){if(!ga(t,function(ie,ae){if(!Tr(X,ae)&&(Z===ie||s(Z,ie,r,i,u)))return X.push(ae)})){$=!1;break}}else if(!(Z===ne||s(Z,ne,r,i,u))){$=!1;break}}return u.delete(e),u.delete(t),$}function qh(e,t,r,i,s,u,g){switch(r){case $n:if(e.byteLength!=t.byteLength||e.byteOffset!=t.byteOffset)return!1;e=e.buffer,t=t.buffer;case wr:return!(e.byteLength!=t.byteLength||!u(new Ei(e),new Ei(t)));case Sn:case Cn:case xr:return Nt(+e,+t);case fi:return e.name==t.name&&e.message==t.message;case br:case Sr:return e==t+"";case It:var _=xa;case At:var b=i&B;if(_||(_=xi),e.size!=t.size&&!b)return!1;var A=g.get(e);if(A)return A==t;i|=z,g.set(e,t);var L=Wc(_(e),_(t),i,s,u,g);return g.delete(e),L;case pi:if(Or)return Or.call(e)==Or.call(t)}return!1}function Xh(e,t,r,i,s,u){var g=r&B,_=Ya(e),b=_.length,A=Ya(t),L=A.length;if(b!=L&&!g)return!1;for(var D=b;D--;){var $=_[D];if(!(g?$ in t:fe.call(t,$)))return!1}var X=u.get(e),Z=u.get(t);if(X&&Z)return X==t&&Z==e;var ne=!0;u.set(e,t),u.set(t,e);for(var j=g;++D<b;){$=_[D];var ie=e[$],ae=t[$];if(i)var ct=g?i(ae,ie,$,t,e,u):i(ie,ae,$,e,t,u);if(!(ct===n?ie===ae||s(ie,ae,r,i,u):ct)){ne=!1;break}j||(j=$=="constructor")}if(ne&&!j){var He=e.constructor,ut=t.constructor;He!=ut&&"constructor"in e&&"constructor"in t&&!(typeof He=="function"&&He instanceof He&&typeof ut=="function"&&ut instanceof ut)&&(ne=!1)}return u.delete(e),u.delete(t),ne}function Yt(e){return Ja(qc(e,n,nu),e+"")}function Ya(e){return sc(e,Be,Ha)}function Ka(e){return sc(e,nt,$c)}var qa=Ri?function(e){return Ri.get(e)}:ds;function Ki(e){for(var t=e.name+"",r=Hn[t],i=fe.call(Hn,t)?r.length:0;i--;){var s=r[i],u=s.func;if(u==null||u==e)return s.name}return t}function Jn(e){var t=fe.call(l,"placeholder")?l:e;return t.placeholder}function H(){var e=l.iteratee||us;return e=e===us?uc:e,arguments.length?e(arguments[0],arguments[1]):e}function qi(e,t){var r=e.__data__;return nm(t)?r[typeof t=="string"?"string":"hash"]:r.map}function Xa(e){for(var t=Be(e),r=t.length;r--;){var i=t[r],s=e[i];t[r]=[i,s,Yc(s)]}return t}function On(e,t){var r=og(e,t);return cc(r)?r:n}function Hh(e){var t=fe.call(e,Tn),r=e[Tn];try{e[Tn]=n;var i=!0}catch{}var s=wi.call(e);return i&&(t?e[Tn]=r:delete e[Tn]),s}var Ha=Sa?function(e){return e==null?[]:(e=he(e),tn(Sa(e),function(t){return Xl.call(e,t)}))}:ps,$c=Sa?function(e){for(var t=[];e;)nn(t,Ha(e)),e=Ii(e);return t}:ps,Ye=qe;(Ca&&Ye(new Ca(new ArrayBuffer(1)))!=$n||Ir&&Ye(new Ir)!=It||wa&&Ye(wa.resolve())!=il||Xn&&Ye(new Xn)!=At||Ar&&Ye(new Ar)!=Cr)&&(Ye=function(e){var t=qe(e),r=t==Gt?e.constructor:n,i=r?Nn(r):"";if(i)switch(i){case Ng:return $n;case Rg:return It;case kg:return il;case Pg:return At;case Mg:return Cr}return t});function Zh(e,t,r){for(var i=-1,s=r.length;++i<s;){var u=r[i],g=u.size;switch(u.type){case"drop":e+=g;break;case"dropRight":t-=g;break;case"take":t=Ve(t,e+g);break;case"takeRight":e=Me(e,t-g);break}}return{start:e,end:t}}function jh(e){var t=e.match(r1);return t?t[1].split(i1):[]}function zc(e,t,r){t=cn(t,e);for(var i=-1,s=t.length,u=!1;++i<s;){var g=Mt(t[i]);if(!(u=e!=null&&r(e,g)))break;e=e[g]}return u||++i!=s?u:(s=e==null?0:e.length,!!s&&eo(s)&&Kt(g,s)&&(ee(e)||Rn(e)))}function Qh(e){var t=e.length,r=new e.constructor(t);return t&&typeof e[0]=="string"&&fe.call(e,"index")&&(r.index=e.index,r.input=e.input),r}function Vc(e){return typeof e.constructor=="function"&&!Ur(e)?Zn(Ii(e)):{}}function Jh(e,t,r){var i=e.constructor;switch(t){case wr:return $a(e);case Sn:case Cn:return new i(+e);case $n:return Dh(e,r);case Xo:case Ho:case Zo:case jo:case Qo:case Jo:case ea:case ta:case na:return Ec(e,r);case It:return new i;case xr:case Sr:return new i(e);case br:return Uh(e);case At:return new i;case pi:return Bh(e)}}function em(e,t){var r=t.length;if(!r)return e;var i=r-1;return t[i]=(r>1?"& ":"")+t[i],t=t.join(r>2?", ":" "),e.replace(n1,`{
/* [wrapped with `+t+`] */
`)}function tm(e){return ee(e)||Rn(e)||!!(Hl&&e&&e[Hl])}function Kt(e,t){var r=typeof e;return t=t??ze,!!t&&(r=="number"||r!="symbol"&&p1.test(e))&&e>-1&&e%1==0&&e<t}function Xe(e,t,r){if(!Ce(r))return!1;var i=typeof t;return(i=="number"?tt(r)&&Kt(t,r.length):i=="string"&&t in r)?Nt(r[t],e):!1}function Za(e,t){if(ee(e))return!1;var r=typeof e;return r=="number"||r=="symbol"||r=="boolean"||e==null||lt(e)?!0:Qp.test(e)||!jp.test(e)||t!=null&&e in he(t)}function nm(e){var t=typeof e;return t=="string"||t=="number"||t=="symbol"||t=="boolean"?e!=="__proto__":e===null}function ja(e){var t=Ki(e),r=l[t];if(typeof r!="function"||!(t in oe.prototype))return!1;if(e===r)return!0;var i=qa(r);return!!i&&e===i[0]}function rm(e){return!!Yl&&Yl in e}var im=Si?qt:gs;function Ur(e){var t=e&&e.constructor,r=typeof t=="function"&&t.prototype||qn;return e===r}function Yc(e){return e===e&&!Ce(e)}function Kc(e,t){return function(r){return r==null?!1:r[e]===t&&(t!==n||e in he(r))}}function om(e){var t=Qi(e,function(i){return r.size===S&&r.clear(),i}),r=t.cache;return t}function am(e,t){var r=e[1],i=t[1],s=r|i,u=s<(N|R|P),g=i==P&&r==c||i==P&&r==q&&e[7].length<=t[8]||i==(P|q)&&t[7].length<=t[8]&&r==c;if(!(u||g))return e;i&N&&(e[2]=t[2],s|=r&N?0:K);var _=t[3];if(_){var b=e[3];e[3]=b?Ac(b,_,t[4]):_,e[4]=b?rn(e[3],I):t[4]}return _=t[5],_&&(b=e[5],e[5]=b?Lc(b,_,t[6]):_,e[6]=b?rn(e[5],I):t[6]),_=t[7],_&&(e[7]=_),i&P&&(e[8]=e[8]==null?t[8]:Ve(e[8],t[8])),e[9]==null&&(e[9]=t[9]),e[0]=t[0],e[1]=s,e}function sm(e){var t=[];if(e!=null)for(var r in he(e))t.push(r);return t}function lm(e){return wi.call(e)}function qc(e,t,r){return t=Me(t===n?e.length-1:t,0),function(){for(var i=arguments,s=-1,u=Me(i.length-t,0),g=T(u);++s<u;)g[s]=i[t+s];s=-1;for(var _=T(t+1);++s<t;)_[s]=i[s];return _[t]=r(g),ot(e,this,_)}}function Xc(e,t){return t.length<2?e:Ln(e,vt(t,0,-1))}function cm(e,t){for(var r=e.length,i=Ve(t.length,r),s=et(e);i--;){var u=t[i];e[i]=Kt(u,r)?s[u]:n}return e}function Qa(e,t){if(!(t==="constructor"&&typeof e[t]=="function")&&t!="__proto__")return e[t]}var Hc=jc(yc),Br=wg||function(e,t){return Ue.setTimeout(e,t)},Ja=jc(Rh);function Zc(e,t,r){var i=t+"";return Ja(e,em(i,um(jh(i),r)))}function jc(e){var t=0,r=0;return function(){var i=Ag(),s=Q-(i-r);if(r=i,s>0){if(++t>=pe)return arguments[0]}else t=0;return e.apply(n,arguments)}}function Xi(e,t){var r=-1,i=e.length,s=i-1;for(t=t===n?i:t;++r<t;){var u=Ma(r,s),g=e[u];e[u]=e[r],e[r]=g}return e.length=t,e}var Qc=om(function(e){var t=[];return e.charCodeAt(0)===46&&t.push(""),e.replace(Jp,function(r,i,s,u){t.push(s?u.replace(s1,"$1"):i||r)}),t});function Mt(e){if(typeof e=="string"||lt(e))return e;var t=e+"";return t=="0"&&1/e==-De?"-0":t}function Nn(e){if(e!=null){try{return Ci.call(e)}catch{}try{return e+""}catch{}}return""}function um(e,t){return ht(Ft,function(r){var i="_."+r[0];t&r[1]&&!_i(e,i)&&e.push(i)}),e.sort()}function Jc(e){if(e instanceof oe)return e.clone();var t=new _t(e.__wrapped__,e.__chain__);return t.__actions__=et(e.__actions__),t.__index__=e.__index__,t.__values__=e.__values__,t}function fm(e,t,r){(r?Xe(e,t,r):t===n)?t=1:t=Me(te(t),0);var i=e==null?0:e.length;if(!i||t<1)return[];for(var s=0,u=0,g=T(Oi(i/t));s<i;)g[u++]=vt(e,s,s+=t);return g}function dm(e){for(var t=-1,r=e==null?0:e.length,i=0,s=[];++t<r;){var u=e[t];u&&(s[i++]=u)}return s}function pm(){var e=arguments.length;if(!e)return[];for(var t=T(e-1),r=arguments[0],i=e;i--;)t[i-1]=arguments[i];return nn(ee(r)?et(r):[r],We(t,1))}var gm=re(function(e,t){return Ae(e)?Rr(e,We(t,1,Ae,!0)):[]}),hm=re(function(e,t){var r=xt(t);return Ae(r)&&(r=n),Ae(e)?Rr(e,We(t,1,Ae,!0),H(r,2)):[]}),mm=re(function(e,t){var r=xt(t);return Ae(r)&&(r=n),Ae(e)?Rr(e,We(t,1,Ae,!0),n,r):[]});function _m(e,t,r){var i=e==null?0:e.length;return i?(t=r||t===n?1:te(t),vt(e,t<0?0:t,i)):[]}function ym(e,t,r){var i=e==null?0:e.length;return i?(t=r||t===n?1:te(t),t=i-t,vt(e,0,t<0?0:t)):[]}function vm(e,t){return e&&e.length?Gi(e,H(t,3),!0,!0):[]}function xm(e,t){return e&&e.length?Gi(e,H(t,3),!0):[]}function bm(e,t,r,i){var s=e==null?0:e.length;return s?(r&&typeof r!="number"&&Xe(e,t,r)&&(r=0,i=s),ph(e,t,r,i)):[]}function eu(e,t,r){var i=e==null?0:e.length;if(!i)return-1;var s=r==null?0:te(r);return s<0&&(s=Me(i+s,0)),yi(e,H(t,3),s)}function tu(e,t,r){var i=e==null?0:e.length;if(!i)return-1;var s=i-1;return r!==n&&(s=te(r),s=r<0?Me(i+s,0):Ve(s,i-1)),yi(e,H(t,3),s,!0)}function nu(e){var t=e==null?0:e.length;return t?We(e,1):[]}function Sm(e){var t=e==null?0:e.length;return t?We(e,De):[]}function Cm(e,t){var r=e==null?0:e.length;return r?(t=t===n?1:te(t),We(e,t)):[]}function wm(e){for(var t=-1,r=e==null?0:e.length,i={};++t<r;){var s=e[t];i[s[0]]=s[1]}return i}function ru(e){return e&&e.length?e[0]:n}function Tm(e,t,r){var i=e==null?0:e.length;if(!i)return-1;var s=r==null?0:te(r);return s<0&&(s=Me(i+s,0)),Vn(e,t,s)}function Em(e){var t=e==null?0:e.length;return t?vt(e,0,-1):[]}var Im=re(function(e){var t=xe(e,Ga);return t.length&&t[0]===e[0]?Oa(t):[]}),Am=re(function(e){var t=xt(e),r=xe(e,Ga);return t===xt(r)?t=n:r.pop(),r.length&&r[0]===e[0]?Oa(r,H(t,2)):[]}),Lm=re(function(e){var t=xt(e),r=xe(e,Ga);return t=typeof t=="function"?t:n,t&&r.pop(),r.length&&r[0]===e[0]?Oa(r,n,t):[]});function Om(e,t){return e==null?"":Eg.call(e,t)}function xt(e){var t=e==null?0:e.length;return t?e[t-1]:n}function Nm(e,t,r){var i=e==null?0:e.length;if(!i)return-1;var s=i;return r!==n&&(s=te(r),s=s<0?Me(i+s,0):Ve(s,i-1)),t===t?ug(e,t,s):yi(e,Ul,s,!0)}function Rm(e,t){return e&&e.length?gc(e,te(t)):n}var km=re(iu);function iu(e,t){return e&&e.length&&t&&t.length?Pa(e,t):e}function Pm(e,t,r){return e&&e.length&&t&&t.length?Pa(e,t,H(r,2)):e}function Mm(e,t,r){return e&&e.length&&t&&t.length?Pa(e,t,n,r):e}var Dm=Yt(function(e,t){var r=e==null?0:e.length,i=Ea(e,t);return _c(e,xe(t,function(s){return Kt(s,r)?+s:s}).sort(Ic)),i});function Um(e,t){var r=[];if(!(e&&e.length))return r;var i=-1,s=[],u=e.length;for(t=H(t,3);++i<u;){var g=e[i];t(g,i,e)&&(r.push(g),s.push(i))}return _c(e,s),r}function es(e){return e==null?e:Og.call(e)}function Bm(e,t,r){var i=e==null?0:e.length;return i?(r&&typeof r!="number"&&Xe(e,t,r)?(t=0,r=i):(t=t==null?0:te(t),r=r===n?i:te(r)),vt(e,t,r)):[]}function Fm(e,t){return Fi(e,t)}function Gm(e,t,r){return Ua(e,t,H(r,2))}function Wm(e,t){var r=e==null?0:e.length;if(r){var i=Fi(e,t);if(i<r&&Nt(e[i],t))return i}return-1}function $m(e,t){return Fi(e,t,!0)}function zm(e,t,r){return Ua(e,t,H(r,2),!0)}function Vm(e,t){var r=e==null?0:e.length;if(r){var i=Fi(e,t,!0)-1;if(Nt(e[i],t))return i}return-1}function Ym(e){return e&&e.length?vc(e):[]}function Km(e,t){return e&&e.length?vc(e,H(t,2)):[]}function qm(e){var t=e==null?0:e.length;return t?vt(e,1,t):[]}function Xm(e,t,r){return e&&e.length?(t=r||t===n?1:te(t),vt(e,0,t<0?0:t)):[]}function Hm(e,t,r){var i=e==null?0:e.length;return i?(t=r||t===n?1:te(t),t=i-t,vt(e,t<0?0:t,i)):[]}function Zm(e,t){return e&&e.length?Gi(e,H(t,3),!1,!0):[]}function jm(e,t){return e&&e.length?Gi(e,H(t,3)):[]}var Qm=re(function(e){return ln(We(e,1,Ae,!0))}),Jm=re(function(e){var t=xt(e);return Ae(t)&&(t=n),ln(We(e,1,Ae,!0),H(t,2))}),e0=re(function(e){var t=xt(e);return t=typeof t=="function"?t:n,ln(We(e,1,Ae,!0),n,t)});function t0(e){return e&&e.length?ln(e):[]}function n0(e,t){return e&&e.length?ln(e,H(t,2)):[]}function r0(e,t){return t=typeof t=="function"?t:n,e&&e.length?ln(e,n,t):[]}function ts(e){if(!(e&&e.length))return[];var t=0;return e=tn(e,function(r){if(Ae(r))return t=Me(r.length,t),!0}),ya(t,function(r){return xe(e,ha(r))})}function ou(e,t){if(!(e&&e.length))return[];var r=ts(e);return t==null?r:xe(r,function(i){return ot(t,n,i)})}var i0=re(function(e,t){return Ae(e)?Rr(e,t):[]}),o0=re(function(e){return Fa(tn(e,Ae))}),a0=re(function(e){var t=xt(e);return Ae(t)&&(t=n),Fa(tn(e,Ae),H(t,2))}),s0=re(function(e){var t=xt(e);return t=typeof t=="function"?t:n,Fa(tn(e,Ae),n,t)}),l0=re(ts);function c0(e,t){return Cc(e||[],t||[],Nr)}function u0(e,t){return Cc(e||[],t||[],Mr)}var f0=re(function(e){var t=e.length,r=t>1?e[t-1]:n;return r=typeof r=="function"?(e.pop(),r):n,ou(e,r)});function au(e){var t=l(e);return t.__chain__=!0,t}function d0(e,t){return t(e),e}function Hi(e,t){return t(e)}var p0=Yt(function(e){var t=e.length,r=t?e[0]:0,i=this.__wrapped__,s=function(u){return Ea(u,e)};return t>1||this.__actions__.length||!(i instanceof oe)||!Kt(r)?this.thru(s):(i=i.slice(r,+r+(t?1:0)),i.__actions__.push({func:Hi,args:[s],thisArg:n}),new _t(i,this.__chain__).thru(function(u){return t&&!u.length&&u.push(n),u}))});function g0(){return au(this)}function h0(){return new _t(this.value(),this.__chain__)}function m0(){this.__values__===n&&(this.__values__=xu(this.value()));var e=this.__index__>=this.__values__.length,t=e?n:this.__values__[this.__index__++];return{done:e,value:t}}function _0(){return this}function y0(e){for(var t,r=this;r instanceof Pi;){var i=Jc(r);i.__index__=0,i.__values__=n,t?s.__wrapped__=i:t=i;var s=i;r=r.__wrapped__}return s.__wrapped__=e,t}function v0(){var e=this.__wrapped__;if(e instanceof oe){var t=e;return this.__actions__.length&&(t=new oe(this)),t=t.reverse(),t.__actions__.push({func:Hi,args:[es],thisArg:n}),new _t(t,this.__chain__)}return this.thru(es)}function x0(){return Sc(this.__wrapped__,this.__actions__)}var b0=Wi(function(e,t,r){fe.call(e,r)?++e[r]:zt(e,r,1)});function S0(e,t,r){var i=ee(e)?Ml:dh;return r&&Xe(e,t,r)&&(t=n),i(e,H(t,3))}function C0(e,t){var r=ee(e)?tn:oc;return r(e,H(t,3))}var w0=kc(eu),T0=kc(tu);function E0(e,t){return We(Zi(e,t),1)}function I0(e,t){return We(Zi(e,t),De)}function A0(e,t,r){return r=r===n?1:te(r),We(Zi(e,t),r)}function su(e,t){var r=ee(e)?ht:sn;return r(e,H(t,3))}function lu(e,t){var r=ee(e)?q1:ic;return r(e,H(t,3))}var L0=Wi(function(e,t,r){fe.call(e,r)?e[r].push(t):zt(e,r,[t])});function O0(e,t,r,i){e=tt(e)?e:tr(e),r=r&&!i?te(r):0;var s=e.length;return r<0&&(r=Me(s+r,0)),to(e)?r<=s&&e.indexOf(t,r)>-1:!!s&&Vn(e,t,r)>-1}var N0=re(function(e,t,r){var i=-1,s=typeof t=="function",u=tt(e)?T(e.length):[];return sn(e,function(g){u[++i]=s?ot(t,g,r):kr(g,t,r)}),u}),R0=Wi(function(e,t,r){zt(e,r,t)});function Zi(e,t){var r=ee(e)?xe:fc;return r(e,H(t,3))}function k0(e,t,r,i){return e==null?[]:(ee(t)||(t=t==null?[]:[t]),r=i?n:r,ee(r)||(r=r==null?[]:[r]),hc(e,t,r))}var P0=Wi(function(e,t,r){e[r?0:1].push(t)},function(){return[[],[]]});function M0(e,t,r){var i=ee(e)?pa:Fl,s=arguments.length<3;return i(e,H(t,4),r,s,sn)}function D0(e,t,r){var i=ee(e)?X1:Fl,s=arguments.length<3;return i(e,H(t,4),r,s,ic)}function U0(e,t){var r=ee(e)?tn:oc;return r(e,Ji(H(t,3)))}function B0(e){var t=ee(e)?ec:Oh;return t(e)}function F0(e,t,r){(r?Xe(e,t,r):t===n)?t=1:t=te(t);var i=ee(e)?sh:Nh;return i(e,t)}function G0(e){var t=ee(e)?lh:kh;return t(e)}function W0(e){if(e==null)return 0;if(tt(e))return to(e)?Kn(e):e.length;var t=Ye(e);return t==It||t==At?e.size:Ra(e).length}function $0(e,t,r){var i=ee(e)?ga:Ph;return r&&Xe(e,t,r)&&(t=n),i(e,H(t,3))}var z0=re(function(e,t){if(e==null)return[];var r=t.length;return r>1&&Xe(e,t[0],t[1])?t=[]:r>2&&Xe(t[0],t[1],t[2])&&(t=[t[0]]),hc(e,We(t,1),[])}),ji=Cg||function(){return Ue.Date.now()};function V0(e,t){if(typeof t!="function")throw new mt(p);return e=te(e),function(){if(--e<1)return t.apply(this,arguments)}}function cu(e,t,r){return t=r?n:t,t=e&&t==null?e.length:t,Vt(e,P,n,n,n,n,t)}function uu(e,t){var r;if(typeof t!="function")throw new mt(p);return e=te(e),function(){return--e>0&&(r=t.apply(this,arguments)),e<=1&&(t=n),r}}var ns=re(function(e,t,r){var i=N;if(r.length){var s=rn(r,Jn(ns));i|=y}return Vt(e,i,t,r,s)}),fu=re(function(e,t,r){var i=N|R;if(r.length){var s=rn(r,Jn(fu));i|=y}return Vt(t,i,e,r,s)});function du(e,t,r){t=r?n:t;var i=Vt(e,c,n,n,n,n,n,t);return i.placeholder=du.placeholder,i}function pu(e,t,r){t=r?n:t;var i=Vt(e,h,n,n,n,n,n,t);return i.placeholder=pu.placeholder,i}function gu(e,t,r){var i,s,u,g,_,b,A=0,L=!1,D=!1,$=!0;if(typeof e!="function")throw new mt(p);t=bt(t)||0,Ce(r)&&(L=!!r.leading,D="maxWait"in r,u=D?Me(bt(r.maxWait)||0,t):u,$="trailing"in r?!!r.trailing:$);function X(Le){var Rt=i,Ht=s;return i=s=n,A=Le,g=e.apply(Ht,Rt),g}function Z(Le){return A=Le,_=Br(ie,t),L?X(Le):g}function ne(Le){var Rt=Le-b,Ht=Le-A,ku=t-Rt;return D?Ve(ku,u-Ht):ku}function j(Le){var Rt=Le-b,Ht=Le-A;return b===n||Rt>=t||Rt<0||D&&Ht>=u}function ie(){var Le=ji();if(j(Le))return ae(Le);_=Br(ie,ne(Le))}function ae(Le){return _=n,$&&i?X(Le):(i=s=n,g)}function ct(){_!==n&&wc(_),A=0,i=b=s=_=n}function He(){return _===n?g:ae(ji())}function ut(){var Le=ji(),Rt=j(Le);if(i=arguments,s=this,b=Le,Rt){if(_===n)return Z(b);if(D)return wc(_),_=Br(ie,t),X(b)}return _===n&&(_=Br(ie,t)),g}return ut.cancel=ct,ut.flush=He,ut}var Y0=re(function(e,t){return rc(e,1,t)}),K0=re(function(e,t,r){return rc(e,bt(t)||0,r)});function q0(e){return Vt(e,G)}function Qi(e,t){if(typeof e!="function"||t!=null&&typeof t!="function")throw new mt(p);var r=function(){var i=arguments,s=t?t.apply(this,i):i[0],u=r.cache;if(u.has(s))return u.get(s);var g=e.apply(this,i);return r.cache=u.set(s,g)||u,g};return r.cache=new(Qi.Cache||$t),r}Qi.Cache=$t;function Ji(e){if(typeof e!="function")throw new mt(p);return function(){var t=arguments;switch(t.length){case 0:return!e.call(this);case 1:return!e.call(this,t[0]);case 2:return!e.call(this,t[0],t[1]);case 3:return!e.call(this,t[0],t[1],t[2])}return!e.apply(this,t)}}function X0(e){return uu(2,e)}var H0=Mh(function(e,t){t=t.length==1&&ee(t[0])?xe(t[0],at(H())):xe(We(t,1),at(H()));var r=t.length;return re(function(i){for(var s=-1,u=Ve(i.length,r);++s<u;)i[s]=t[s].call(this,i[s]);return ot(e,this,i)})}),rs=re(function(e,t){var r=rn(t,Jn(rs));return Vt(e,y,n,t,r)}),hu=re(function(e,t){var r=rn(t,Jn(hu));return Vt(e,O,n,t,r)}),Z0=Yt(function(e,t){return Vt(e,q,n,n,n,t)});function j0(e,t){if(typeof e!="function")throw new mt(p);return t=t===n?t:te(t),re(e,t)}function Q0(e,t){if(typeof e!="function")throw new mt(p);return t=t==null?0:Me(te(t),0),re(function(r){var i=r[t],s=un(r,0,t);return i&&nn(s,i),ot(e,this,s)})}function J0(e,t,r){var i=!0,s=!0;if(typeof e!="function")throw new mt(p);return Ce(r)&&(i="leading"in r?!!r.leading:i,s="trailing"in r?!!r.trailing:s),gu(e,t,{leading:i,maxWait:t,trailing:s})}function e_(e){return cu(e,1)}function t_(e,t){return rs(Wa(t),e)}function n_(){if(!arguments.length)return[];var e=arguments[0];return ee(e)?e:[e]}function r_(e){return yt(e,U)}function i_(e,t){return t=typeof t=="function"?t:n,yt(e,U,t)}function o_(e){return yt(e,k|U)}function a_(e,t){return t=typeof t=="function"?t:n,yt(e,k|U,t)}function s_(e,t){return t==null||nc(e,t,Be(t))}function Nt(e,t){return e===t||e!==e&&t!==t}var l_=Yi(La),c_=Yi(function(e,t){return e>=t}),Rn=lc(function(){return arguments}())?lc:function(e){return Te(e)&&fe.call(e,"callee")&&!Xl.call(e,"callee")},ee=T.isArray,u_=Ll?at(Ll):yh;function tt(e){return e!=null&&eo(e.length)&&!qt(e)}function Ae(e){return Te(e)&&tt(e)}function f_(e){return e===!0||e===!1||Te(e)&&qe(e)==Sn}var fn=Tg||gs,d_=Ol?at(Ol):vh;function p_(e){return Te(e)&&e.nodeType===1&&!Fr(e)}function g_(e){if(e==null)return!0;if(tt(e)&&(ee(e)||typeof e=="string"||typeof e.splice=="function"||fn(e)||er(e)||Rn(e)))return!e.length;var t=Ye(e);if(t==It||t==At)return!e.size;if(Ur(e))return!Ra(e).length;for(var r in e)if(fe.call(e,r))return!1;return!0}function h_(e,t){return Pr(e,t)}function m_(e,t,r){r=typeof r=="function"?r:n;var i=r?r(e,t):n;return i===n?Pr(e,t,n,r):!!i}function is(e){if(!Te(e))return!1;var t=qe(e);return t==fi||t==Fp||typeof e.message=="string"&&typeof e.name=="string"&&!Fr(e)}function __(e){return typeof e=="number"&&Zl(e)}function qt(e){if(!Ce(e))return!1;var t=qe(e);return t==di||t==rl||t==vr||t==Wp}function mu(e){return typeof e=="number"&&e==te(e)}function eo(e){return typeof e=="number"&&e>-1&&e%1==0&&e<=ze}function Ce(e){var t=typeof e;return e!=null&&(t=="object"||t=="function")}function Te(e){return e!=null&&typeof e=="object"}var _u=Nl?at(Nl):bh;function y_(e,t){return e===t||Na(e,t,Xa(t))}function v_(e,t,r){return r=typeof r=="function"?r:n,Na(e,t,Xa(t),r)}function x_(e){return yu(e)&&e!=+e}function b_(e){if(im(e))throw new J(f);return cc(e)}function S_(e){return e===null}function C_(e){return e==null}function yu(e){return typeof e=="number"||Te(e)&&qe(e)==xr}function Fr(e){if(!Te(e)||qe(e)!=Gt)return!1;var t=Ii(e);if(t===null)return!0;var r=fe.call(t,"constructor")&&t.constructor;return typeof r=="function"&&r instanceof r&&Ci.call(r)==vg}var os=Rl?at(Rl):Sh;function w_(e){return mu(e)&&e>=-ze&&e<=ze}var vu=kl?at(kl):Ch;function to(e){return typeof e=="string"||!ee(e)&&Te(e)&&qe(e)==Sr}function lt(e){return typeof e=="symbol"||Te(e)&&qe(e)==pi}var er=Pl?at(Pl):wh;function T_(e){return e===n}function E_(e){return Te(e)&&Ye(e)==Cr}function I_(e){return Te(e)&&qe(e)==zp}var A_=Yi(ka),L_=Yi(function(e,t){return e<=t});function xu(e){if(!e)return[];if(tt(e))return to(e)?Lt(e):et(e);if(Er&&e[Er])return sg(e[Er]());var t=Ye(e),r=t==It?xa:t==At?xi:tr;return r(e)}function Xt(e){if(!e)return e===0?e:0;if(e=bt(e),e===De||e===-De){var t=e<0?-1:1;return t*Bt}return e===e?e:0}function te(e){var t=Xt(e),r=t%1;return t===t?r?t-r:t:0}function bu(e){return e?An(te(e),0,Ke):0}function bt(e){if(typeof e=="number")return e;if(lt(e))return pt;if(Ce(e)){var t=typeof e.valueOf=="function"?e.valueOf():e;e=Ce(t)?t+"":t}if(typeof e!="string")return e===0?e:+e;e=Gl(e);var r=u1.test(e);return r||d1.test(e)?V1(e.slice(2),r?2:8):c1.test(e)?pt:+e}function Su(e){return Pt(e,nt(e))}function O_(e){return e?An(te(e),-ze,ze):e===0?e:0}function ue(e){return e==null?"":st(e)}var N_=jn(function(e,t){if(Ur(t)||tt(t)){Pt(t,Be(t),e);return}for(var r in t)fe.call(t,r)&&Nr(e,r,t[r])}),Cu=jn(function(e,t){Pt(t,nt(t),e)}),no=jn(function(e,t,r,i){Pt(t,nt(t),e,i)}),R_=jn(function(e,t,r,i){Pt(t,Be(t),e,i)}),k_=Yt(Ea);function P_(e,t){var r=Zn(e);return t==null?r:tc(r,t)}var M_=re(function(e,t){e=he(e);var r=-1,i=t.length,s=i>2?t[2]:n;for(s&&Xe(t[0],t[1],s)&&(i=1);++r<i;)for(var u=t[r],g=nt(u),_=-1,b=g.length;++_<b;){var A=g[_],L=e[A];(L===n||Nt(L,qn[A])&&!fe.call(e,A))&&(e[A]=u[A])}return e}),D_=re(function(e){return e.push(n,Gc),ot(wu,n,e)});function U_(e,t){return Dl(e,H(t,3),kt)}function B_(e,t){return Dl(e,H(t,3),Aa)}function F_(e,t){return e==null?e:Ia(e,H(t,3),nt)}function G_(e,t){return e==null?e:ac(e,H(t,3),nt)}function W_(e,t){return e&&kt(e,H(t,3))}function $_(e,t){return e&&Aa(e,H(t,3))}function z_(e){return e==null?[]:Ui(e,Be(e))}function V_(e){return e==null?[]:Ui(e,nt(e))}function as(e,t,r){var i=e==null?n:Ln(e,t);return i===n?r:i}function Y_(e,t){return e!=null&&zc(e,t,gh)}function ss(e,t){return e!=null&&zc(e,t,hh)}var K_=Mc(function(e,t,r){t!=null&&typeof t.toString!="function"&&(t=wi.call(t)),e[t]=r},cs(rt)),q_=Mc(function(e,t,r){t!=null&&typeof t.toString!="function"&&(t=wi.call(t)),fe.call(e,t)?e[t].push(r):e[t]=[r]},H),X_=re(kr);function Be(e){return tt(e)?Jl(e):Ra(e)}function nt(e){return tt(e)?Jl(e,!0):Th(e)}function H_(e,t){var r={};return t=H(t,3),kt(e,function(i,s,u){zt(r,t(i,s,u),i)}),r}function Z_(e,t){var r={};return t=H(t,3),kt(e,function(i,s,u){zt(r,s,t(i,s,u))}),r}var j_=jn(function(e,t,r){Bi(e,t,r)}),wu=jn(function(e,t,r,i){Bi(e,t,r,i)}),Q_=Yt(function(e,t){var r={};if(e==null)return r;var i=!1;t=xe(t,function(u){return u=cn(u,e),i||(i=u.length>1),u}),Pt(e,Ka(e),r),i&&(r=yt(r,k|V|U,Kh));for(var s=t.length;s--;)Ba(r,t[s]);return r});function J_(e,t){return Tu(e,Ji(H(t)))}var ey=Yt(function(e,t){return e==null?{}:Ih(e,t)});function Tu(e,t){if(e==null)return{};var r=xe(Ka(e),function(i){return[i]});return t=H(t),mc(e,r,function(i,s){return t(i,s[0])})}function ty(e,t,r){t=cn(t,e);var i=-1,s=t.length;for(s||(s=1,e=n);++i<s;){var u=e==null?n:e[Mt(t[i])];u===n&&(i=s,u=r),e=qt(u)?u.call(e):u}return e}function ny(e,t,r){return e==null?e:Mr(e,t,r)}function ry(e,t,r,i){return i=typeof i=="function"?i:n,e==null?e:Mr(e,t,r,i)}var Eu=Bc(Be),Iu=Bc(nt);function iy(e,t,r){var i=ee(e),s=i||fn(e)||er(e);if(t=H(t,4),r==null){var u=e&&e.constructor;s?r=i?new u:[]:Ce(e)?r=qt(u)?Zn(Ii(e)):{}:r={}}return(s?ht:kt)(e,function(g,_,b){return t(r,g,_,b)}),r}function oy(e,t){return e==null?!0:Ba(e,t)}function ay(e,t,r){return e==null?e:bc(e,t,Wa(r))}function sy(e,t,r,i){return i=typeof i=="function"?i:n,e==null?e:bc(e,t,Wa(r),i)}function tr(e){return e==null?[]:va(e,Be(e))}function ly(e){return e==null?[]:va(e,nt(e))}function cy(e,t,r){return r===n&&(r=t,t=n),r!==n&&(r=bt(r),r=r===r?r:0),t!==n&&(t=bt(t),t=t===t?t:0),An(bt(e),t,r)}function uy(e,t,r){return t=Xt(t),r===n?(r=t,t=0):r=Xt(r),e=bt(e),mh(e,t,r)}function fy(e,t,r){if(r&&typeof r!="boolean"&&Xe(e,t,r)&&(t=r=n),r===n&&(typeof t=="boolean"?(r=t,t=n):typeof e=="boolean"&&(r=e,e=n)),e===n&&t===n?(e=0,t=1):(e=Xt(e),t===n?(t=e,e=0):t=Xt(t)),e>t){var i=e;e=t,t=i}if(r||e%1||t%1){var s=jl();return Ve(e+s*(t-e+z1("1e-"+((s+"").length-1))),t)}return Ma(e,t)}var dy=Qn(function(e,t,r){return t=t.toLowerCase(),e+(r?Au(t):t)});function Au(e){return ls(ue(e).toLowerCase())}function Lu(e){return e=ue(e),e&&e.replace(g1,ng).replace(k1,"")}function py(e,t,r){e=ue(e),t=st(t);var i=e.length;r=r===n?i:An(te(r),0,i);var s=r;return r-=t.length,r>=0&&e.slice(r,s)==t}function gy(e){return e=ue(e),e&&Xp.test(e)?e.replace(al,rg):e}function hy(e){return e=ue(e),e&&e1.test(e)?e.replace(ra,"\\$&"):e}var my=Qn(function(e,t,r){return e+(r?"-":"")+t.toLowerCase()}),_y=Qn(function(e,t,r){return e+(r?" ":"")+t.toLowerCase()}),yy=Rc("toLowerCase");function vy(e,t,r){e=ue(e),t=te(t);var i=t?Kn(e):0;if(!t||i>=t)return e;var s=(t-i)/2;return Vi(Ni(s),r)+e+Vi(Oi(s),r)}function xy(e,t,r){e=ue(e),t=te(t);var i=t?Kn(e):0;return t&&i<t?e+Vi(t-i,r):e}function by(e,t,r){e=ue(e),t=te(t);var i=t?Kn(e):0;return t&&i<t?Vi(t-i,r)+e:e}function Sy(e,t,r){return r||t==null?t=0:t&&(t=+t),Lg(ue(e).replace(ia,""),t||0)}function Cy(e,t,r){return(r?Xe(e,t,r):t===n)?t=1:t=te(t),Da(ue(e),t)}function wy(){var e=arguments,t=ue(e[0]);return e.length<3?t:t.replace(e[1],e[2])}var Ty=Qn(function(e,t,r){return e+(r?"_":"")+t.toLowerCase()});function Ey(e,t,r){return r&&typeof r!="number"&&Xe(e,t,r)&&(t=r=n),r=r===n?Ke:r>>>0,r?(e=ue(e),e&&(typeof t=="string"||t!=null&&!os(t))&&(t=st(t),!t&&Yn(e))?un(Lt(e),0,r):e.split(t,r)):[]}var Iy=Qn(function(e,t,r){return e+(r?" ":"")+ls(t)});function Ay(e,t,r){return e=ue(e),r=r==null?0:An(te(r),0,e.length),t=st(t),e.slice(r,r+t.length)==t}function Ly(e,t,r){var i=l.templateSettings;r&&Xe(e,t,r)&&(t=n),e=ue(e),t=no({},t,i,Fc);var s=no({},t.imports,i.imports,Fc),u=Be(s),g=va(s,u),_,b,A=0,L=t.interpolate||gi,D="__p += '",$=ba((t.escape||gi).source+"|"+L.source+"|"+(L===sl?l1:gi).source+"|"+(t.evaluate||gi).source+"|$","g"),X="//# sourceURL="+(fe.call(t,"sourceURL")?(t.sourceURL+"").replace(/\s/g," "):"lodash.templateSources["+ ++B1+"]")+`
`;e.replace($,function(j,ie,ae,ct,He,ut){return ae||(ae=ct),D+=e.slice(A,ut).replace(h1,ig),ie&&(_=!0,D+=`' +
__e(`+ie+`) +
'`),He&&(b=!0,D+=`';
`+He+`;
__p += '`),ae&&(D+=`' +
((__t = (`+ae+`)) == null ? '' : __t) +
'`),A=ut+j.length,j}),D+=`';
`;var Z=fe.call(t,"variable")&&t.variable;if(!Z)D=`with (obj) {
`+D+`
}
`;else if(a1.test(Z))throw new J(m);D=(b?D.replace(Vp,""):D).replace(Yp,"$1").replace(Kp,"$1;"),D="function("+(Z||"obj")+`) {
`+(Z?"":`obj || (obj = {});
`)+"var __t, __p = ''"+(_?", __e = _.escape":"")+(b?`, __j = Array.prototype.join;
function print() { __p += __j.call(arguments, '') }
`:`;
`)+D+`return __p
}`;var ne=Nu(function(){return ce(u,X+"return "+D).apply(n,g)});if(ne.source=D,is(ne))throw ne;return ne}function Oy(e){return ue(e).toLowerCase()}function Ny(e){return ue(e).toUpperCase()}function Ry(e,t,r){if(e=ue(e),e&&(r||t===n))return Gl(e);if(!e||!(t=st(t)))return e;var i=Lt(e),s=Lt(t),u=Wl(i,s),g=$l(i,s)+1;return un(i,u,g).join("")}function ky(e,t,r){if(e=ue(e),e&&(r||t===n))return e.slice(0,Vl(e)+1);if(!e||!(t=st(t)))return e;var i=Lt(e),s=$l(i,Lt(t))+1;return un(i,0,s).join("")}function Py(e,t,r){if(e=ue(e),e&&(r||t===n))return e.replace(ia,"");if(!e||!(t=st(t)))return e;var i=Lt(e),s=Wl(i,Lt(t));return un(i,s).join("")}function My(e,t){var r=Se,i=ge;if(Ce(t)){var s="separator"in t?t.separator:s;r="length"in t?te(t.length):r,i="omission"in t?st(t.omission):i}e=ue(e);var u=e.length;if(Yn(e)){var g=Lt(e);u=g.length}if(r>=u)return e;var _=r-Kn(i);if(_<1)return i;var b=g?un(g,0,_).join(""):e.slice(0,_);if(s===n)return b+i;if(g&&(_+=b.length-_),os(s)){if(e.slice(_).search(s)){var A,L=b;for(s.global||(s=ba(s.source,ue(ll.exec(s))+"g")),s.lastIndex=0;A=s.exec(L);)var D=A.index;b=b.slice(0,D===n?_:D)}}else if(e.indexOf(st(s),_)!=_){var $=b.lastIndexOf(s);$>-1&&(b=b.slice(0,$))}return b+i}function Dy(e){return e=ue(e),e&&qp.test(e)?e.replace(ol,fg):e}var Uy=Qn(function(e,t,r){return e+(r?" ":"")+t.toUpperCase()}),ls=Rc("toUpperCase");function Ou(e,t,r){return e=ue(e),t=r?n:t,t===n?ag(e)?gg(e):j1(e):e.match(t)||[]}var Nu=re(function(e,t){try{return ot(e,n,t)}catch(r){return is(r)?r:new J(r)}}),By=Yt(function(e,t){return ht(t,function(r){r=Mt(r),zt(e,r,ns(e[r],e))}),e});function Fy(e){var t=e==null?0:e.length,r=H();return e=t?xe(e,function(i){if(typeof i[1]!="function")throw new mt(p);return[r(i[0]),i[1]]}):[],re(function(i){for(var s=-1;++s<t;){var u=e[s];if(ot(u[0],this,i))return ot(u[1],this,i)}})}function Gy(e){return fh(yt(e,k))}function cs(e){return function(){return e}}function Wy(e,t){return e==null||e!==e?t:e}var $y=Pc(),zy=Pc(!0);function rt(e){return e}function us(e){return uc(typeof e=="function"?e:yt(e,k))}function Vy(e){return dc(yt(e,k))}function Yy(e,t){return pc(e,yt(t,k))}var Ky=re(function(e,t){return function(r){return kr(r,e,t)}}),qy=re(function(e,t){return function(r){return kr(e,r,t)}});function fs(e,t,r){var i=Be(t),s=Ui(t,i);r==null&&!(Ce(t)&&(s.length||!i.length))&&(r=t,t=e,e=this,s=Ui(t,Be(t)));var u=!(Ce(r)&&"chain"in r)||!!r.chain,g=qt(e);return ht(s,function(_){var b=t[_];e[_]=b,g&&(e.prototype[_]=function(){var A=this.__chain__;if(u||A){var L=e(this.__wrapped__),D=L.__actions__=et(this.__actions__);return D.push({func:b,args:arguments,thisArg:e}),L.__chain__=A,L}return b.apply(e,nn([this.value()],arguments))})}),e}function Xy(){return Ue._===this&&(Ue._=xg),this}function ds(){}function Hy(e){return e=te(e),re(function(t){return gc(t,e)})}var Zy=za(xe),jy=za(Ml),Qy=za(ga);function Ru(e){return Za(e)?ha(Mt(e)):Ah(e)}function Jy(e){return function(t){return e==null?n:Ln(e,t)}}var e2=Dc(),t2=Dc(!0);function ps(){return[]}function gs(){return!1}function n2(){return{}}function r2(){return""}function i2(){return!0}function o2(e,t){if(e=te(e),e<1||e>ze)return[];var r=Ke,i=Ve(e,Ke);t=H(t),e-=Ke;for(var s=ya(i,t);++r<e;)t(r);return s}function a2(e){return ee(e)?xe(e,Mt):lt(e)?[e]:et(Qc(ue(e)))}function s2(e){var t=++yg;return ue(e)+t}var l2=zi(function(e,t){return e+t},0),c2=Va("ceil"),u2=zi(function(e,t){return e/t},1),f2=Va("floor");function d2(e){return e&&e.length?Di(e,rt,La):n}function p2(e,t){return e&&e.length?Di(e,H(t,2),La):n}function g2(e){return Bl(e,rt)}function h2(e,t){return Bl(e,H(t,2))}function m2(e){return e&&e.length?Di(e,rt,ka):n}function _2(e,t){return e&&e.length?Di(e,H(t,2),ka):n}var y2=zi(function(e,t){return e*t},1),v2=Va("round"),x2=zi(function(e,t){return e-t},0);function b2(e){return e&&e.length?_a(e,rt):0}function S2(e,t){return e&&e.length?_a(e,H(t,2)):0}return l.after=V0,l.ary=cu,l.assign=N_,l.assignIn=Cu,l.assignInWith=no,l.assignWith=R_,l.at=k_,l.before=uu,l.bind=ns,l.bindAll=By,l.bindKey=fu,l.castArray=n_,l.chain=au,l.chunk=fm,l.compact=dm,l.concat=pm,l.cond=Fy,l.conforms=Gy,l.constant=cs,l.countBy=b0,l.create=P_,l.curry=du,l.curryRight=pu,l.debounce=gu,l.defaults=M_,l.defaultsDeep=D_,l.defer=Y0,l.delay=K0,l.difference=gm,l.differenceBy=hm,l.differenceWith=mm,l.drop=_m,l.dropRight=ym,l.dropRightWhile=vm,l.dropWhile=xm,l.fill=bm,l.filter=C0,l.flatMap=E0,l.flatMapDeep=I0,l.flatMapDepth=A0,l.flatten=nu,l.flattenDeep=Sm,l.flattenDepth=Cm,l.flip=q0,l.flow=$y,l.flowRight=zy,l.fromPairs=wm,l.functions=z_,l.functionsIn=V_,l.groupBy=L0,l.initial=Em,l.intersection=Im,l.intersectionBy=Am,l.intersectionWith=Lm,l.invert=K_,l.invertBy=q_,l.invokeMap=N0,l.iteratee=us,l.keyBy=R0,l.keys=Be,l.keysIn=nt,l.map=Zi,l.mapKeys=H_,l.mapValues=Z_,l.matches=Vy,l.matchesProperty=Yy,l.memoize=Qi,l.merge=j_,l.mergeWith=wu,l.method=Ky,l.methodOf=qy,l.mixin=fs,l.negate=Ji,l.nthArg=Hy,l.omit=Q_,l.omitBy=J_,l.once=X0,l.orderBy=k0,l.over=Zy,l.overArgs=H0,l.overEvery=jy,l.overSome=Qy,l.partial=rs,l.partialRight=hu,l.partition=P0,l.pick=ey,l.pickBy=Tu,l.property=Ru,l.propertyOf=Jy,l.pull=km,l.pullAll=iu,l.pullAllBy=Pm,l.pullAllWith=Mm,l.pullAt=Dm,l.range=e2,l.rangeRight=t2,l.rearg=Z0,l.reject=U0,l.remove=Um,l.rest=j0,l.reverse=es,l.sampleSize=F0,l.set=ny,l.setWith=ry,l.shuffle=G0,l.slice=Bm,l.sortBy=z0,l.sortedUniq=Ym,l.sortedUniqBy=Km,l.split=Ey,l.spread=Q0,l.tail=qm,l.take=Xm,l.takeRight=Hm,l.takeRightWhile=Zm,l.takeWhile=jm,l.tap=d0,l.throttle=J0,l.thru=Hi,l.toArray=xu,l.toPairs=Eu,l.toPairsIn=Iu,l.toPath=a2,l.toPlainObject=Su,l.transform=iy,l.unary=e_,l.union=Qm,l.unionBy=Jm,l.unionWith=e0,l.uniq=t0,l.uniqBy=n0,l.uniqWith=r0,l.unset=oy,l.unzip=ts,l.unzipWith=ou,l.update=ay,l.updateWith=sy,l.values=tr,l.valuesIn=ly,l.without=i0,l.words=Ou,l.wrap=t_,l.xor=o0,l.xorBy=a0,l.xorWith=s0,l.zip=l0,l.zipObject=c0,l.zipObjectDeep=u0,l.zipWith=f0,l.entries=Eu,l.entriesIn=Iu,l.extend=Cu,l.extendWith=no,fs(l,l),l.add=l2,l.attempt=Nu,l.camelCase=dy,l.capitalize=Au,l.ceil=c2,l.clamp=cy,l.clone=r_,l.cloneDeep=o_,l.cloneDeepWith=a_,l.cloneWith=i_,l.conformsTo=s_,l.deburr=Lu,l.defaultTo=Wy,l.divide=u2,l.endsWith=py,l.eq=Nt,l.escape=gy,l.escapeRegExp=hy,l.every=S0,l.find=w0,l.findIndex=eu,l.findKey=U_,l.findLast=T0,l.findLastIndex=tu,l.findLastKey=B_,l.floor=f2,l.forEach=su,l.forEachRight=lu,l.forIn=F_,l.forInRight=G_,l.forOwn=W_,l.forOwnRight=$_,l.get=as,l.gt=l_,l.gte=c_,l.has=Y_,l.hasIn=ss,l.head=ru,l.identity=rt,l.includes=O0,l.indexOf=Tm,l.inRange=uy,l.invoke=X_,l.isArguments=Rn,l.isArray=ee,l.isArrayBuffer=u_,l.isArrayLike=tt,l.isArrayLikeObject=Ae,l.isBoolean=f_,l.isBuffer=fn,l.isDate=d_,l.isElement=p_,l.isEmpty=g_,l.isEqual=h_,l.isEqualWith=m_,l.isError=is,l.isFinite=__,l.isFunction=qt,l.isInteger=mu,l.isLength=eo,l.isMap=_u,l.isMatch=y_,l.isMatchWith=v_,l.isNaN=x_,l.isNative=b_,l.isNil=C_,l.isNull=S_,l.isNumber=yu,l.isObject=Ce,l.isObjectLike=Te,l.isPlainObject=Fr,l.isRegExp=os,l.isSafeInteger=w_,l.isSet=vu,l.isString=to,l.isSymbol=lt,l.isTypedArray=er,l.isUndefined=T_,l.isWeakMap=E_,l.isWeakSet=I_,l.join=Om,l.kebabCase=my,l.last=xt,l.lastIndexOf=Nm,l.lowerCase=_y,l.lowerFirst=yy,l.lt=A_,l.lte=L_,l.max=d2,l.maxBy=p2,l.mean=g2,l.meanBy=h2,l.min=m2,l.minBy=_2,l.stubArray=ps,l.stubFalse=gs,l.stubObject=n2,l.stubString=r2,l.stubTrue=i2,l.multiply=y2,l.nth=Rm,l.noConflict=Xy,l.noop=ds,l.now=ji,l.pad=vy,l.padEnd=xy,l.padStart=by,l.parseInt=Sy,l.random=fy,l.reduce=M0,l.reduceRight=D0,l.repeat=Cy,l.replace=wy,l.result=ty,l.round=v2,l.runInContext=v,l.sample=B0,l.size=W0,l.snakeCase=Ty,l.some=$0,l.sortedIndex=Fm,l.sortedIndexBy=Gm,l.sortedIndexOf=Wm,l.sortedLastIndex=$m,l.sortedLastIndexBy=zm,l.sortedLastIndexOf=Vm,l.startCase=Iy,l.startsWith=Ay,l.subtract=x2,l.sum=b2,l.sumBy=S2,l.template=Ly,l.times=o2,l.toFinite=Xt,l.toInteger=te,l.toLength=bu,l.toLower=Oy,l.toNumber=bt,l.toSafeInteger=O_,l.toString=ue,l.toUpper=Ny,l.trim=Ry,l.trimEnd=ky,l.trimStart=Py,l.truncate=My,l.unescape=Dy,l.uniqueId=s2,l.upperCase=Uy,l.upperFirst=ls,l.each=su,l.eachRight=lu,l.first=ru,fs(l,function(){var e={};return kt(l,function(t,r){fe.call(l.prototype,r)||(e[r]=t)}),e}(),{chain:!1}),l.VERSION=o,ht(["bind","bindKey","curry","curryRight","partial","partialRight"],function(e){l[e].placeholder=l}),ht(["drop","take"],function(e,t){oe.prototype[e]=function(r){r=r===n?1:Me(te(r),0);var i=this.__filtered__&&!t?new oe(this):this.clone();return i.__filtered__?i.__takeCount__=Ve(r,i.__takeCount__):i.__views__.push({size:Ve(r,Ke),type:e+(i.__dir__<0?"Right":"")}),i},oe.prototype[e+"Right"]=function(r){return this.reverse()[e](r).reverse()}}),ht(["filter","map","takeWhile"],function(e,t){var r=t+1,i=r==ve||r==en;oe.prototype[e]=function(s){var u=this.clone();return u.__iteratees__.push({iteratee:H(s,3),type:r}),u.__filtered__=u.__filtered__||i,u}}),ht(["head","last"],function(e,t){var r="take"+(t?"Right":"");oe.prototype[e]=function(){return this[r](1).value()[0]}}),ht(["initial","tail"],function(e,t){var r="drop"+(t?"":"Right");oe.prototype[e]=function(){return this.__filtered__?new oe(this):this[r](1)}}),oe.prototype.compact=function(){return this.filter(rt)},oe.prototype.find=function(e){return this.filter(e).head()},oe.prototype.findLast=function(e){return this.reverse().find(e)},oe.prototype.invokeMap=re(function(e,t){return typeof e=="function"?new oe(this):this.map(function(r){return kr(r,e,t)})}),oe.prototype.reject=function(e){return this.filter(Ji(H(e)))},oe.prototype.slice=function(e,t){e=te(e);var r=this;return r.__filtered__&&(e>0||t<0)?new oe(r):(e<0?r=r.takeRight(-e):e&&(r=r.drop(e)),t!==n&&(t=te(t),r=t<0?r.dropRight(-t):r.take(t-e)),r)},oe.prototype.takeRightWhile=function(e){return this.reverse().takeWhile(e).reverse()},oe.prototype.toArray=function(){return this.take(Ke)},kt(oe.prototype,function(e,t){var r=/^(?:filter|find|map|reject)|While$/.test(t),i=/^(?:head|last)$/.test(t),s=l[i?"take"+(t=="last"?"Right":""):t],u=i||/^find/.test(t);s&&(l.prototype[t]=function(){var g=this.__wrapped__,_=i?[1]:arguments,b=g instanceof oe,A=_[0],L=b||ee(g),D=function(ie){var ae=s.apply(l,nn([ie],_));return i&&$?ae[0]:ae};L&&r&&typeof A=="function"&&A.length!=1&&(b=L=!1);var $=this.__chain__,X=!!this.__actions__.length,Z=u&&!$,ne=b&&!X;if(!u&&L){g=ne?g:new oe(this);var j=e.apply(g,_);return j.__actions__.push({func:Hi,args:[D],thisArg:n}),new _t(j,$)}return Z&&ne?e.apply(this,_):(j=this.thru(D),Z?i?j.value()[0]:j.value():j)})}),ht(["pop","push","shift","sort","splice","unshift"],function(e){var t=bi[e],r=/^(?:push|sort|unshift)$/.test(e)?"tap":"thru",i=/^(?:pop|shift)$/.test(e);l.prototype[e]=function(){var s=arguments;if(i&&!this.__chain__){var u=this.value();return t.apply(ee(u)?u:[],s)}return this[r](function(g){return t.apply(ee(g)?g:[],s)})}}),kt(oe.prototype,function(e,t){var r=l[t];if(r){var i=r.name+"";fe.call(Hn,i)||(Hn[i]=[]),Hn[i].push({name:t,func:r})}}),Hn[$i(n,R).name]=[{name:"wrapper",func:n}],oe.prototype.clone=Dg,oe.prototype.reverse=Ug,oe.prototype.value=Bg,l.prototype.at=p0,l.prototype.chain=g0,l.prototype.commit=h0,l.prototype.next=m0,l.prototype.plant=y0,l.prototype.reverse=v0,l.prototype.toJSON=l.prototype.valueOf=l.prototype.value=x0,l.prototype.first=l.prototype.head,Er&&(l.prototype[Er]=_0),l},on=hg();typeof define=="function"&&typeof define.amd=="object"&&define.amd?(Ue._=on,define(function(){return on})):wn?((wn.exports=on)._=on,ua._=on):Ue._=on}).call(mr)});w();C();C2();w();C();w();C();var Tt=we(Oe());w();C();w();C();function w2(n){if(n.sheet)return n.sheet;for(var o=0;o<document.styleSheets.length;o++)if(document.styleSheets[o].ownerNode===n)return document.styleSheets[o]}function T2(n){var o=document.createElement("style");return o.setAttribute("data-emotion",n.key),n.nonce!==void 0&&o.setAttribute("nonce",n.nonce),o.appendChild(document.createTextNode("")),o.setAttribute("data-s",""),o}var nf=function(){function n(a){var f=this;this._insertTag=function(p){var m;f.tags.length===0?f.insertionPoint?m=f.insertionPoint.nextSibling:f.prepend?m=f.container.firstChild:m=f.before:m=f.tags[f.tags.length-1].nextSibling,f.container.insertBefore(p,m),f.tags.push(p)},this.isSpeedy=a.speedy===void 0?!1:a.speedy,this.tags=[],this.ctr=0,this.nonce=a.nonce,this.key=a.key,this.container=a.container,this.prepend=a.prepend,this.insertionPoint=a.insertionPoint,this.before=null}var o=n.prototype;return o.hydrate=function(f){f.forEach(this._insertTag)},o.insert=function(f){this.ctr%(this.isSpeedy?65e3:1)===0&&this._insertTag(T2(this));var p=this.tags[this.tags.length-1];if(0)var m;if(this.isSpeedy){var x=w2(p);try{x.insertRule(f,x.cssRules.length)}catch{}}else p.appendChild(document.createTextNode(f));this.ctr++},o.flush=function(){this.tags.forEach(function(f){return f.parentNode&&f.parentNode.removeChild(f)}),this.tags=[],this.ctr=0},n}();w();C();var $e="-ms-",Wr="-moz-",le="-webkit-",so="comm",or="rule",ar="decl";var rf="@import";var lo="@keyframes";var of="@layer";w();C();var af=Math.abs,Pn=String.fromCharCode,sf=Object.assign;function lf(n,o){return Ne(n,0)^45?(((o<<2^Ne(n,0))<<2^Ne(n,1))<<2^Ne(n,2))<<2^Ne(n,3):0}function co(n){return n.trim()}function vs(n,o){return(n=o.exec(n))?n[0]:n}function se(n,o,a){return n.replace(o,a)}function $r(n,o){return n.indexOf(o)}function Ne(n,o){return n.charCodeAt(o)|0}function pn(n,o,a){return n.slice(o,a)}function Ze(n){return n.length}function sr(n){return n.length}function lr(n,o){return o.push(n),n}function xs(n,o){return n.map(o).join("")}w();C();w();C();var uo=1,cr=1,cf=0,je=0,ke=0,fr="";function zr(n,o,a,f,p,m,x){return{value:n,root:o,parent:a,type:f,props:p,children:m,line:uo,column:cr,length:x,return:""}}function dr(n,o){return sf(zr("",null,null,"",null,null,0),n,{length:-n.length},o)}function uf(){return ke}function ff(){return ke=je>0?Ne(fr,--je):0,cr--,ke===10&&(cr=1,uo--),ke}function Qe(){return ke=je<cf?Ne(fr,je++):0,cr++,ke===10&&(cr=1,uo++),ke}function St(){return Ne(fr,je)}function Vr(){return je}function pr(n,o){return pn(fr,n,o)}function ur(n){switch(n){case 0:case 9:case 10:case 13:case 32:return 5;case 33:case 43:case 44:case 47:case 62:case 64:case 126:case 59:case 123:case 125:return 4;case 58:return 3;case 34:case 39:case 40:case 91:return 2;case 41:case 93:return 1}return 0}function fo(n){return uo=cr=1,cf=Ze(fr=n),je=0,[]}function po(n){return fr="",n}function gr(n){return co(pr(je-1,bs(n===91?n+2:n===40?n+1:n)))}function df(n){for(;(ke=St())&&ke<33;)Qe();return ur(n)>2||ur(ke)>3?"":" "}function pf(n,o){for(;--o&&Qe()&&!(ke<48||ke>102||ke>57&&ke<65||ke>70&&ke<97););return pr(n,Vr()+(o<6&&St()==32&&Qe()==32))}function bs(n){for(;Qe();)switch(ke){case n:return je;case 34:case 39:n!==34&&n!==39&&bs(ke);break;case 40:n===41&&bs(n);break;case 92:Qe();break}return je}function gf(n,o){for(;Qe()&&n+ke!==57;)if(n+ke===84&&St()===47)break;return"/*"+pr(o,je-1)+"*"+Pn(n===47?n:Qe())}function hf(n){for(;!ur(St());)Qe();return pr(n,je)}function yf(n){return po(go("",null,null,null,[""],n=fo(n),0,[0],n))}function go(n,o,a,f,p,m,x,S,I){for(var k=0,V=0,U=x,B=0,z=0,N=0,R=1,K=1,c=1,h=0,y="",O=p,P=m,q=f,G=y;K;)switch(N=h,h=Qe()){case 40:if(N!=108&&Ne(G,U-1)==58){$r(G+=se(gr(h),"&","&\f"),"&\f")!=-1&&(c=-1);break}case 34:case 39:case 91:G+=gr(h);break;case 9:case 10:case 13:case 32:G+=df(N);break;case 92:G+=pf(Vr()-1,7);continue;case 47:switch(St()){case 42:case 47:lr(E2(gf(Qe(),Vr()),o,a),I);break;default:G+="/"}break;case 123*R:S[k++]=Ze(G)*c;case 125*R:case 59:case 0:switch(h){case 0:case 125:K=0;case 59+V:c==-1&&(G=se(G,/\f/g,"")),z>0&&Ze(G)-U&&lr(z>32?_f(G+";",f,a,U-1):_f(se(G," ","")+";",f,a,U-2),I);break;case 59:G+=";";default:if(lr(q=mf(G,o,a,k,V,p,S,y,O=[],P=[],U),m),h===123)if(V===0)go(G,o,q,q,O,m,U,S,P);else switch(B===99&&Ne(G,3)===110?100:B){case 100:case 108:case 109:case 115:go(n,q,q,f&&lr(mf(n,q,q,0,0,p,S,y,p,O=[],U),P),p,P,U,S,f?O:P);break;default:go(G,q,q,q,[""],P,0,S,P)}}k=V=z=0,R=c=1,y=G="",U=x;break;case 58:U=1+Ze(G),z=N;default:if(R<1){if(h==123)--R;else if(h==125&&R++==0&&ff()==125)continue}switch(G+=Pn(h),h*R){case 38:c=V>0?1:(G+="\f",-1);break;case 44:S[k++]=(Ze(G)-1)*c,c=1;break;case 64:St()===45&&(G+=gr(Qe())),B=St(),V=U=Ze(y=G+=hf(Vr())),h++;break;case 45:N===45&&Ze(G)==2&&(R=0)}}return m}function mf(n,o,a,f,p,m,x,S,I,k,V){for(var U=p-1,B=p===0?m:[""],z=sr(B),N=0,R=0,K=0;N<f;++N)for(var c=0,h=pn(n,U+1,U=af(R=x[N])),y=n;c<z;++c)(y=co(R>0?B[c]+" "+h:se(h,/&\f/g,B[c])))&&(I[K++]=y);return zr(n,o,a,p===0?or:S,I,k,V)}function E2(n,o,a){return zr(n,o,a,so,Pn(uf()),pn(n,2,-2),0)}function _f(n,o,a,f){return zr(n,o,a,ar,pn(n,0,f),pn(n,f+1,-1),f)}w();C();function Mn(n,o){for(var a="",f=sr(n),p=0;p<f;p++)a+=o(n[p],p,n,o)||"";return a}function vf(n,o,a,f){switch(n.type){case of:if(n.children.length)break;case rf:case ar:return n.return=n.return||n.value;case so:return"";case lo:return n.return=n.value+"{"+Mn(n.children,f)+"}";case or:n.value=n.props.join(",")}return Ze(a=Mn(n.children,f))?n.return=n.value+"{"+a+"}":""}w();C();function xf(n){var o=sr(n);return function(a,f,p,m){for(var x="",S=0;S<o;S++)x+=n[S](a,f,p,m)||"";return x}}function bf(n){return function(o){o.root||(o=o.return)&&n(o)}}w();C();w();C();var I2=function(o,a,f){for(var p=0,m=0;p=m,m=St(),p===38&&m===12&&(a[f]=1),!ur(m);)Qe();return pr(o,je)},A2=function(o,a){var f=-1,p=44;do switch(ur(p)){case 0:p===38&&St()===12&&(a[f]=1),o[f]+=I2(je-1,a,f);break;case 2:o[f]+=gr(p);break;case 4:if(p===44){o[++f]=St()===58?"&\f":"",a[f]=o[f].length;break}default:o[f]+=Pn(p)}while(p=Qe());return o},L2=function(o,a){return po(A2(fo(o),a))},Sf=new WeakMap,O2=function(o){if(!(o.type!=="rule"||!o.parent||o.length<1)){for(var a=o.value,f=o.parent,p=o.column===f.column&&o.line===f.line;f.type!=="rule";)if(f=f.parent,!f)return;if(!(o.props.length===1&&a.charCodeAt(0)!==58&&!Sf.get(f))&&!p){Sf.set(o,!0);for(var m=[],x=L2(a,m),S=f.props,I=0,k=0;I<x.length;I++)for(var V=0;V<S.length;V++,k++)o.props[k]=m[I]?x[I].replace(/&\f/g,S[V]):S[V]+" "+x[I]}}},N2=function(o){if(o.type==="decl"){var a=o.value;a.charCodeAt(0)===108&&a.charCodeAt(2)===98&&(o.return="",o.value="")}};function Cf(n,o){switch(lf(n,o)){case 5103:return le+"print-"+n+n;case 5737:case 4201:case 3177:case 3433:case 1641:case 4457:case 2921:case 5572:case 6356:case 5844:case 3191:case 6645:case 3005:case 6391:case 5879:case 5623:case 6135:case 4599:case 4855:case 4215:case 6389:case 5109:case 5365:case 5621:case 3829:return le+n+n;case 5349:case 4246:case 4810:case 6968:case 2756:return le+n+Wr+n+$e+n+n;case 6828:case 4268:return le+n+$e+n+n;case 6165:return le+n+$e+"flex-"+n+n;case 5187:return le+n+se(n,/(\w+).+(:[^]+)/,le+"box-$1$2"+$e+"flex-$1$2")+n;case 5443:return le+n+$e+"flex-item-"+se(n,/flex-|-self/,"")+n;case 4675:return le+n+$e+"flex-line-pack"+se(n,/align-content|flex-|-self/,"")+n;case 5548:return le+n+$e+se(n,"shrink","negative")+n;case 5292:return le+n+$e+se(n,"basis","preferred-size")+n;case 6060:return le+"box-"+se(n,"-grow","")+le+n+$e+se(n,"grow","positive")+n;case 4554:return le+se(n,/([^-])(transform)/g,"$1"+le+"$2")+n;case 6187:return se(se(se(n,/(zoom-|grab)/,le+"$1"),/(image-set)/,le+"$1"),n,"")+n;case 5495:case 3959:return se(n,/(image-set\([^]*)/,le+"$1$`$1");case 4968:return se(se(n,/(.+:)(flex-)?(.*)/,le+"box-pack:$3"+$e+"flex-pack:$3"),/s.+-b[^;]+/,"justify")+le+n+n;case 4095:case 3583:case 4068:case 2532:return se(n,/(.+)-inline(.+)/,le+"$1$2")+n;case 8116:case 7059:case 5753:case 5535:case 5445:case 5701:case 4933:case 4677:case 5533:case 5789:case 5021:case 4765:if(Ze(n)-1-o>6)switch(Ne(n,o+1)){case 109:if(Ne(n,o+4)!==45)break;case 102:return se(n,/(.+:)(.+)-([^]+)/,"$1"+le+"$2-$3$1"+Wr+(Ne(n,o+3)==108?"$3":"$2-$3"))+n;case 115:return~$r(n,"stretch")?Cf(se(n,"stretch","fill-available"),o)+n:n}break;case 4949:if(Ne(n,o+1)!==115)break;case 6444:switch(Ne(n,Ze(n)-3-(~$r(n,"!important")&&10))){case 107:return se(n,":",":"+le)+n;case 101:return se(n,/(.+:)([^;!]+)(;|!.+)?/,"$1"+le+(Ne(n,14)===45?"inline-":"")+"box$3$1"+le+"$2$3$1"+$e+"$2box$3")+n}break;case 5936:switch(Ne(n,o+11)){case 114:return le+n+$e+se(n,/[svh]\w+-[tblr]{2}/,"tb")+n;case 108:return le+n+$e+se(n,/[svh]\w+-[tblr]{2}/,"tb-rl")+n;case 45:return le+n+$e+se(n,/[svh]\w+-[tblr]{2}/,"lr")+n}return le+n+$e+n+n}return n}var R2=function(o,a,f,p){if(o.length>-1&&!o.return)switch(o.type){case ar:o.return=Cf(o.value,o.length);break;case lo:return Mn([dr(o,{value:se(o.value,"@","@"+le)})],p);case or:if(o.length)return xs(o.props,function(m){switch(vs(m,/(::plac\w+|:read-\w+)/)){case":read-only":case":read-write":return Mn([dr(o,{props:[se(m,/:(read-\w+)/,":"+Wr+"$1")]})],p);case"::placeholder":return Mn([dr(o,{props:[se(m,/:(plac\w+)/,":"+le+"input-$1")]}),dr(o,{props:[se(m,/:(plac\w+)/,":"+Wr+"$1")]}),dr(o,{props:[se(m,/:(plac\w+)/,$e+"input-$1")]})],p)}return""})}},k2=[R2],Dn=function(o){var a=o.key;if(!a)throw new Error(`You have to configure \`key\` for your cache. Please make sure it's unique (and not equal to 'css') as it's used for linking styles to your cache.
If multiple caches share the same key they might "fight" for each other's style elements.`);if(a==="css"){var f=document.querySelectorAll("style[data-emotion]:not([data-s])");Array.prototype.forEach.call(f,function(R){var K=R.getAttribute("data-emotion");K.indexOf(" ")!==-1&&(document.head.appendChild(R),R.setAttribute("data-s",""))})}var p=o.stylisPlugins||k2,m={},x,S=[];x=o.container||document.head,Array.prototype.forEach.call(document.querySelectorAll('style[data-emotion^="'+a+' "]'),function(R){for(var K=R.getAttribute("data-emotion").split(" "),c=1;c<K.length;c++)m[K[c]]=!0;S.push(R)});var I,k=[O2,N2];{var V,U=[vf,bf(function(R){V.insert(R)})],B=xf(k.concat(p,U)),z=function(K){return Mn(yf(K),B)};I=function(K,c,h,y){V=h,z(K?K+"{"+c.styles+"}":c.styles),y&&(N.inserted[c.name]=!0)}}var N={key:a,sheet:new nf({key:a,container:x,nonce:o.nonce,speedy:o.speedy,prepend:o.prepend,insertionPoint:o.insertionPoint}),nonce:o.nonce,inserted:m,registered:{},insert:I};return N.sheet.hydrate(S),N};w();C();w();C();var gn=we(Oe()),Zr=we(Oe());w();C();function Yr(){return Yr=Object.assign?Object.assign.bind():function(n){for(var o=1;o<arguments.length;o++){var a=arguments[o];for(var f in a)({}).hasOwnProperty.call(a,f)&&(n[f]=a[f])}return n},Yr.apply(null,arguments)}w();C();var K2=!0;function To(n,o,a){var f="";return a.split(" ").forEach(function(p){n[p]!==void 0?o.push(n[p]+";"):f+=p+" "}),f}var Kr=function(o,a,f){var p=o.key+"-"+a.name;(f===!1||K2===!1)&&o.registered[p]===void 0&&(o.registered[p]=a.styles)},Eo=function(o,a,f){Kr(o,a,f);var p=o.key+"-"+a.name;if(o.inserted[a.name]===void 0){var m=a;do o.insert(a===m?"."+p:"",m,o.sheet,!0),m=m.next;while(m!==void 0)}};w();C();w();C();function Mf(n){for(var o=0,a,f=0,p=n.length;p>=4;++f,p-=4)a=n.charCodeAt(f)&255|(n.charCodeAt(++f)&255)<<8|(n.charCodeAt(++f)&255)<<16|(n.charCodeAt(++f)&255)<<24,a=(a&65535)*1540483477+((a>>>16)*59797<<16),a^=a>>>24,o=(a&65535)*1540483477+((a>>>16)*59797<<16)^(o&65535)*1540483477+((o>>>16)*59797<<16);switch(p){case 3:o^=(n.charCodeAt(f+2)&255)<<16;case 2:o^=(n.charCodeAt(f+1)&255)<<8;case 1:o^=n.charCodeAt(f)&255,o=(o&65535)*1540483477+((o>>>16)*59797<<16)}return o^=o>>>13,o=(o&65535)*1540483477+((o>>>16)*59797<<16),((o^o>>>15)>>>0).toString(36)}w();C();var Df={animationIterationCount:1,aspectRatio:1,borderImageOutset:1,borderImageSlice:1,borderImageWidth:1,boxFlex:1,boxFlexGroup:1,boxOrdinalGroup:1,columnCount:1,columns:1,flex:1,flexGrow:1,flexPositive:1,flexShrink:1,flexNegative:1,flexOrder:1,gridRow:1,gridRowEnd:1,gridRowSpan:1,gridRowStart:1,gridColumn:1,gridColumnEnd:1,gridColumnSpan:1,gridColumnStart:1,msGridRow:1,msGridRowSpan:1,msGridColumn:1,msGridColumnSpan:1,fontWeight:1,lineHeight:1,opacity:1,order:1,orphans:1,tabSize:1,widows:1,zIndex:1,zoom:1,WebkitLineClamp:1,fillOpacity:1,floodOpacity:1,stopOpacity:1,strokeDasharray:1,strokeDashoffset:1,strokeMiterlimit:1,strokeOpacity:1,strokeWidth:1};w();C();function Uf(n){var o=Object.create(null);return function(a){return o[a]===void 0&&(o[a]=n(a)),o[a]}}var q2=/[A-Z]|^ms/g,X2=/_EMO_([^_]+?)_([^]*?)_EMO_/g,Ls=function(o){return o.charCodeAt(1)===45},Bf=function(o){return o!=null&&typeof o!="boolean"},Is=Uf(function(n){return Ls(n)?n:n.replace(q2,"-$&").toLowerCase()}),Io=function(o,a){switch(o){case"animation":case"animationName":if(typeof a=="string")return a.replace(X2,function(f,p,m){return Dt={name:p,styles:m,next:Dt},p})}return Df[o]!==1&&!Ls(o)&&typeof a=="number"&&a!==0?a+"px":a};Ff=/(var|attr|counters?|url|element|(((repeating-)?(linear|radial))|conic)-gradient)\(|(no-)?(open|close)-quote/,Gf=["normal","none","initial","inherit","unset"],Wf=Io,$f=/^-ms-/,zf=/-(.)/g,As={},Io=function(o,a){if(o==="content"&&(typeof a!="string"||Gf.indexOf(a)===-1&&!Ff.test(a)&&(a.charAt(0)!==a.charAt(a.length-1)||a.charAt(0)!=='"'&&a.charAt(0)!=="'")))throw new Error("You seem to be using a value for 'content' without quotes, try replacing it with `content: '\""+a+"\"'`");var f=Wf(o,a);return f!==""&&!Ls(o)&&o.indexOf("-")!==-1&&As[o]===void 0&&(As[o]=!0,console.error("Using kebab-case for css properties in objects is not supported. Did you mean "+o.replace($f,"ms-").replace(zf,function(p,m){return m.toUpperCase()})+"?")),f};var Ff,Gf,Wf,$f,zf,As;function qr(n,o,a){if(a==null)return"";if(a.__emotion_styles!==void 0)return a;switch(typeof a){case"boolean":return"";case"object":{if(a.anim===1)return Dt={name:a.name,styles:a.styles,next:Dt},a.name;if(a.styles!==void 0){var f=a.next;if(f!==void 0)for(;f!==void 0;)Dt={name:f.name,styles:f.styles,next:Dt},f=f.next;var p=a.styles+";";return p}return H2(n,o,a)}case"function":{if(n!==void 0){var m=Dt,x=a(n);return Dt=m,qr(n,o,x)}break}case"string":if(0)var S,I;break}if(o==null)return a;var k=o[a];return k!==void 0?k:a}function H2(n,o,a){var f="";if(Array.isArray(a))for(var p=0;p<a.length;p++)f+=qr(n,o,a[p])+";";else for(var m in a){var x=a[m];if(typeof x!="object")o!=null&&o[x]!==void 0?f+=m+"{"+o[x]+"}":Bf(x)&&(f+=Is(m)+":"+Io(m,x)+";");else if(Array.isArray(x)&&typeof x[0]=="string"&&(o==null||o[x[0]]===void 0))for(var S=0;S<x.length;S++)Bf(x[S])&&(f+=Is(m)+":"+Io(m,x[S])+";");else{var I=qr(n,o,x);switch(m){case"animation":case"animationName":{f+=Is(m)+":"+I+";";break}default:f+=m+"{"+I+"}"}}}return f}var Vf=/label:\s*([^\s;\n{]+)\s*(;|$)/g;var Dt,Xr=function(o,a,f){if(o.length===1&&typeof o[0]=="object"&&o[0]!==null&&o[0].styles!==void 0)return o[0];var p=!0,m="";Dt=void 0;var x=o[0];x==null||x.raw===void 0?(p=!1,m+=qr(f,a,x)):m+=x[0];for(var S=1;S<o.length;S++)m+=qr(f,a,o[S]),p&&(m+=x[S]);var I;Vf.lastIndex=0;for(var k="",V;(V=Vf.exec(m))!==null;)k+="-"+V[1];var U=Mf(m)+k;return{name:U,styles:m,next:Dt}};w();C();var Ao=we(Oe()),Z2=function(o){return o()},j2=Ao.useInsertionEffect?Ao.useInsertionEffect:!1,Lo=j2||Z2;var Q2=!0,kS={}.hasOwnProperty,Hr=gn.createContext(typeof HTMLElement<"u"?Dn({key:"speechify"}):null);Hr.displayName="EmotionCacheContext";var jr=Hr.Provider;var Oo=function(o){return(0,Zr.forwardRef)(function(a,f){var p=(0,Zr.useContext)(Hr);return o(a,p,f)})};Q2||(Oo=function(o){return function(a){var f=(0,Zr.useContext)(Hr);return f===null?(f=Dn({key:"css"}),gn.createElement(Hr.Provider,{value:f},o(a,f))):o(a,f)}});var Os=gn.createContext({});var No=we(Oe());var XS=we(Pf());function J2(){for(var n=arguments.length,o=new Array(n),a=0;a<n;a++)o[a]=arguments[a];return Xr(o)}var Qr=function(){var o=J2.apply(void 0,arguments),a="animation-"+o.name;return{name:a,styles:"@keyframes "+a+"{"+o.styles+"}",anim:1,toString:function(){return"_EMO_"+this.name+"_"+this.styles+"_EMO_"}}};w();C();w();C();var Yf=Ju(async()=>{let{userAgent:n,brave:o}=navigator,a=n.toLowerCase(),f=/chrome|crios/.test(a)&&!/edge|edg\/|opr\//.test(a);return f&&o?.isBrave&&await o.isBrave()?"brave":f&&globalThis.chrome?"chrome":a.includes("edg/")?"microsoft edge":a.includes("opr/")&&globalThis.opr?"opera":"other"});var Kf=be("SidepanelAnalytics");async function Je(n,o={}){try{let a=null;try{let{useSidepanelStore:x}=await import("./store-B2UMPKPP.js");a=x.getState().currentUrl}catch(x){Kf.warn("Could not access sidepanel store for URL, using fallback:",x)}let f=a||window.location.href,p=(()=>{try{return new URL(f).hostname}catch{return f}})(),m={...o,source:"sidepanel",timestamp:Date.now(),hostname:p,webpage:f,browser:await Yf()};await kn("/analytics/log",{eventName:n,properties:m})}catch(a){Kf.error("Failed to log analytics event:",n,a)}}w();C();w();C();var qf={length:"medium",mode:"paragraph"};function Xf(){let n=nr(a=>a.currentUrlState),o=Gr(a=>a.summarySettings);return n?.summaryData?.settings?{...n.summaryData.settings,source:"current"}:o?{...o,source:"global"}:{...qf,source:"default"}}function Hf(n){return{length:n.length.charAt(0).toUpperCase()+n.length.slice(1),format:n.mode==="paragraph"?"Paragraph":"Outline"}}function Zf(){return Gr.getState().summarySettings||qf}w();C();var Ct=we(Oe()),bd=we(Oe());w();C();w();C();var hn=we(Oe());w();C();w();C();function jf(n){var o=Object.create(null);return function(a){return o[a]===void 0&&(o[a]=n(a)),o[a]}}var ev=/^((children|dangerouslySetInnerHTML|key|ref|autoFocus|defaultValue|defaultChecked|innerHTML|suppressContentEditableWarning|suppressHydrationWarning|valueLink|abbr|accept|acceptCharset|accessKey|action|allow|allowUserMedia|allowPaymentRequest|allowFullScreen|allowTransparency|alt|async|autoComplete|autoPlay|capture|cellPadding|cellSpacing|challenge|charSet|checked|cite|classID|className|cols|colSpan|content|contentEditable|contextMenu|controls|controlsList|coords|crossOrigin|data|dateTime|decoding|default|defer|dir|disabled|disablePictureInPicture|download|draggable|encType|enterKeyHint|form|formAction|formEncType|formMethod|formNoValidate|formTarget|frameBorder|headers|height|hidden|high|href|hrefLang|htmlFor|httpEquiv|id|inputMode|integrity|is|keyParams|keyType|kind|label|lang|list|loading|loop|low|marginHeight|marginWidth|max|maxLength|media|mediaGroup|method|min|minLength|multiple|muted|name|nonce|noValidate|open|optimum|pattern|placeholder|playsInline|poster|preload|profile|radioGroup|readOnly|referrerPolicy|rel|required|reversed|role|rows|rowSpan|sandbox|scope|scoped|scrolling|seamless|selected|shape|size|sizes|slot|span|spellCheck|src|srcDoc|srcLang|srcSet|start|step|style|summary|tabIndex|target|title|translate|type|useMap|value|width|wmode|wrap|about|datatype|inlist|prefix|property|resource|typeof|vocab|autoCapitalize|autoCorrect|autoSave|color|incremental|fallback|inert|itemProp|itemScope|itemType|itemID|itemRef|on|option|results|security|unselectable|accentHeight|accumulate|additive|alignmentBaseline|allowReorder|alphabetic|amplitude|arabicForm|ascent|attributeName|attributeType|autoReverse|azimuth|baseFrequency|baselineShift|baseProfile|bbox|begin|bias|by|calcMode|capHeight|clip|clipPathUnits|clipPath|clipRule|colorInterpolation|colorInterpolationFilters|colorProfile|colorRendering|contentScriptType|contentStyleType|cursor|cx|cy|d|decelerate|descent|diffuseConstant|direction|display|divisor|dominantBaseline|dur|dx|dy|edgeMode|elevation|enableBackground|end|exponent|externalResourcesRequired|fill|fillOpacity|fillRule|filter|filterRes|filterUnits|floodColor|floodOpacity|focusable|fontFamily|fontSize|fontSizeAdjust|fontStretch|fontStyle|fontVariant|fontWeight|format|from|fr|fx|fy|g1|g2|glyphName|glyphOrientationHorizontal|glyphOrientationVertical|glyphRef|gradientTransform|gradientUnits|hanging|horizAdvX|horizOriginX|ideographic|imageRendering|in|in2|intercept|k|k1|k2|k3|k4|kernelMatrix|kernelUnitLength|kerning|keyPoints|keySplines|keyTimes|lengthAdjust|letterSpacing|lightingColor|limitingConeAngle|local|markerEnd|markerMid|markerStart|markerHeight|markerUnits|markerWidth|mask|maskContentUnits|maskUnits|mathematical|mode|numOctaves|offset|opacity|operator|order|orient|orientation|origin|overflow|overlinePosition|overlineThickness|panose1|paintOrder|pathLength|patternContentUnits|patternTransform|patternUnits|pointerEvents|points|pointsAtX|pointsAtY|pointsAtZ|preserveAlpha|preserveAspectRatio|primitiveUnits|r|radius|refX|refY|renderingIntent|repeatCount|repeatDur|requiredExtensions|requiredFeatures|restart|result|rotate|rx|ry|scale|seed|shapeRendering|slope|spacing|specularConstant|specularExponent|speed|spreadMethod|startOffset|stdDeviation|stemh|stemv|stitchTiles|stopColor|stopOpacity|strikethroughPosition|strikethroughThickness|string|stroke|strokeDasharray|strokeDashoffset|strokeLinecap|strokeLinejoin|strokeMiterlimit|strokeOpacity|strokeWidth|surfaceScale|systemLanguage|tableValues|targetX|targetY|textAnchor|textDecoration|textRendering|textLength|to|transform|u1|u2|underlinePosition|underlineThickness|unicode|unicodeBidi|unicodeRange|unitsPerEm|vAlphabetic|vHanging|vIdeographic|vMathematical|values|vectorEffect|version|vertAdvY|vertOriginX|vertOriginY|viewBox|viewTarget|visibility|widths|wordSpacing|writingMode|x|xHeight|x1|x2|xChannelSelector|xlinkActuate|xlinkArcrole|xlinkHref|xlinkRole|xlinkShow|xlinkTitle|xlinkType|xmlBase|xmlns|xmlnsXlink|xmlLang|xmlSpace|y|y1|y2|yChannelSelector|z|zoomAndPan|for|class|autofocus)|(([Dd][Aa][Tt][Aa]|[Aa][Rr][Ii][Aa]|x)-.*))$/,Qf=jf(function(n){return ev.test(n)||n.charCodeAt(0)===111&&n.charCodeAt(1)===110&&n.charCodeAt(2)<91});var tv=Qf,nv=function(o){return o!=="theme"},Jf=function(o){return typeof o=="string"&&o.charCodeAt(0)>96?tv:nv},ed=function(o,a,f){var p;if(a){var m=a.shouldForwardProp;p=o.__emotion_forwardProp&&m?function(x){return o.__emotion_forwardProp(x)&&m(x)}:m}return typeof p!="function"&&f&&(p=o.__emotion_forwardProp),p};var rv=function(o){var a=o.cache,f=o.serialized,p=o.isStringTag;return Kr(a,f,p),Lo(function(){return Eo(a,f,p)}),null},td=function n(o,a){if(o===void 0)throw new Error(`You are trying to create a styled element with an undefined component.
You may have forgotten to import it.`);var f=o.__emotion_real===o,p=f&&o.__emotion_base||o,m,x;a!==void 0&&(m=a.label,x=a.target);var S=ed(o,a,f),I=S||Jf(p),k=!I("as");return function(){var V=arguments,U=f&&o.__emotion_styles!==void 0?o.__emotion_styles.slice(0):[];if(m!==void 0&&U.push("label:"+m+";"),V[0]==null||V[0].raw===void 0)U.push.apply(U,V);else{U.push(V[0][0]);for(var B=V.length,z=1;z<B;z++)U.push(V[z],V[0][z])}var N=Oo(function(R,K,c){var h=k&&R.as||p,y="",O=[],P=R;if(R.theme==null){P={};for(var q in R)P[q]=R[q];P.theme=hn.useContext(Os)}typeof R.className=="string"?y=To(K.registered,O,R.className):R.className!=null&&(y=R.className+" ");var G=Xr(U.concat(O),K.registered,P);y+=K.key+"-"+G.name,x!==void 0&&(y+=" "+x);var Se=k&&S===void 0?Jf(h):I,ge={};for(var pe in R)k&&pe==="as"||Se(pe)&&(ge[pe]=R[pe]);return ge.className=y,ge.ref=c,hn.createElement(hn.Fragment,null,hn.createElement(rv,{cache:K,serialized:G,isStringTag:typeof h=="string"}),hn.createElement(h,ge))});return N.displayName=m!==void 0?m:"Styled("+(typeof p=="string"?p:p.displayName||p.name||"Component")+")",N.defaultProps=o.defaultProps,N.__emotion_real=N,N.__emotion_base=p,N.__emotion_styles=U,N.__emotion_forwardProp=S,Object.defineProperty(N,"toString",{value:function(){return"."+x}}),N.withComponent=function(R,K){return n(R,Yr({},a,K,{shouldForwardProp:ed(N,K,!0)})).apply(void 0,U)},N}};var BC=we(Oe());var iv=["a","abbr","address","area","article","aside","audio","b","base","bdi","bdo","big","blockquote","body","br","button","canvas","caption","cite","code","col","colgroup","data","datalist","dd","del","details","dfn","dialog","div","dl","dt","em","embed","fieldset","figcaption","figure","footer","form","h1","h2","h3","h4","h5","h6","head","header","hgroup","hr","html","i","iframe","img","input","ins","kbd","keygen","label","legend","li","link","main","map","mark","marquee","menu","menuitem","meta","meter","nav","noscript","object","ol","optgroup","option","output","p","param","picture","pre","progress","q","rp","rt","ruby","s","samp","script","section","select","small","source","span","strong","style","sub","summary","sup","table","tbody","td","textarea","tfoot","th","thead","time","title","tr","track","u","ul","var","video","wbr","circle","clipPath","defs","ellipse","foreignObject","g","image","line","linearGradient","mask","path","pattern","polygon","polyline","radialGradient","rect","stop","svg","text","tspan"],M=td.bind();iv.forEach(function(n){M[n]=M(n)});w();C();w();C();var ov=n=>d("svg",{width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg",...n},d("path",{d:"M13.5303 3.53033C13.8232 3.23744 13.8232 2.76256 13.5303 2.46967C13.2374 2.17678 12.7626 2.17678 12.4697 2.46967L8 6.93934L3.53033 2.46967C3.23744 2.17678 2.76256 2.17678 2.46967 2.46967C2.17678 2.76256 2.17678 3.23744 2.46967 3.53033L6.93934 8L2.46967 12.4697C2.17678 12.7626 2.17678 13.2374 2.46967 13.5303C2.76256 13.8232 3.23744 13.8232 3.53033 13.5303L8 9.06066L12.4697 13.5303C12.7626 13.8232 13.2374 13.8232 13.5303 13.5303C13.8232 13.2374 13.8232 12.7626 13.5303 12.4697L9.06066 8L13.5303 3.53033Z",fill:"white"})),av=M.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #36373acc;
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 2000;
  opacity: ${({isOpen:n})=>n?1:0};
  visibility: ${({isOpen:n})=>n?"visible":"hidden"};
  transition: all 0.2s ease;
`,sv=M.div`
  background-color: #1e1e1f;
  border-radius: 16px;
  padding: 32px 40px 16px 40px;
  margin: 16px;
  max-width: 328px;
  width: 90%;
  position: relative;
  text-align: center;
  transform: ${({isOpen:n})=>n?"scale(1)":"scale(0.95)"};
  transition: transform 0.2s ease;
  box-sizing: border-box;
`,lv=M.button`
  position: absolute;
  top: 0;
  right: 0;
  background: none;
  border: none;
  color: #ffffff;
  cursor: pointer;
  padding: 4px;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 32px;
  height: 32px;

  transition: opacity 0.1s ease;

  &:hover {
    opacity: 0.75;
  }

  & svg {
    width: 16px;
    height: 16px;
  }
`,Ro=M.h3`
  color: #ffffff;
  font-size: 1.125rem; /* subheading-4 */
  font-weight: 500;
  line-height: 1.33; /* 24px line-height */
  letter-spacing: -0.01125rem;
  margin: 0 0 8px 0;
  text-align: center;
`,nd=M.p`
  color: #ffffff;
  font-size: 14px;
  font-weight: 400;
  line-height: 20px;
  letter-spacing: -0.0275rem;
  margin: 0 0 20px 0;
  text-align: center;
`,ko=M.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
`,rd=M.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
  width: 100%;
`,Jr=M.button`
  width: 100%;
  padding: 12px 20px;
  border-radius: 10px;
  border: none;
  cursor: pointer;
  transition: all 0.15s ease;

  ${({variant:n})=>n==="primary"?`
        background-color: #EB3830;
        color: #ffffff;
        font-size: 0.875rem; /* heading-6 */
        font-weight: 700;
        line-height: 1.43;
        letter-spacing: -0.004375rem;

        &:hover {
          background-color: #d4362f;
        }

        &:active {
          background-color: #bd342d;
        }
      `:n==="save"?`
        background-color: #4759F7;
        color: #ffffff;
        font-size: 0.875rem; /* heading-6 */
        font-weight: 700;
        line-height: 1.43;
        letter-spacing: -0.004375rem;

        &:hover {
          background-color: #4454E3;
        }

        &:active {
          background-color: #3441d5;
        }
      `:`
        background-color: transparent;
        color: #9899A6;
        border: none;
        font-size: 0.875rem;
        font-weight: 500;
        line-height: 1.43;
        letter-spacing: -0.004375rem;

        &:hover, &:active, &:focus {
          background-color: #252627;
          color: #ffffff;
        }
      `}
`;function Po({isOpen:n,onClose:o,children:a}){return d(av,{isOpen:n,onClick:o},d(sv,{isOpen:n,onClick:f=>f.stopPropagation()},d(lv,{onClick:o},d(ov,null)),a))}function id({isOpen:n,onClose:o,onConfirm:a}){return d(Po,{isOpen:n,onClose:o},d(ko,null,d(Ro,null,"Clear Chat"),d(nd,null,"Are you sure you want to clear this chat?",d("br",null),"All message history will be removed and cannot be restored."),d(rd,null,d(Jr,{variant:"primary",onClick:a},"Clear Chat"),d(Jr,{variant:"secondary",onClick:o},"Cancel"))))}w();C();var mn=M.svg`
  width: ${({width:n,size:o})=>parseInt(`${n??o??"20"}`)+"px"};
  height: ${({height:n,size:o})=>parseInt(`${n??o??"20"}`)+"px"};
  ${({color:n})=>n&&`color: ${n}`};
  fill: ${({fill:n})=>n??"currentColor"};
  ${({style:n})=>n&&`style: ${n}`};

  ${({onClick:n})=>n&&"cursor: pointer;"}
`;function od(n){return d(mn,{viewBox:"0 0 20 20",fill:"none",...n},d("path",{"fill-rule":"evenodd","clip-rule":"evenodd",d:"M15.8333 8.33325C14.9128 8.33325 14.1666 9.07944 14.1666 9.99992C14.1666 10.9204 14.9128 11.6666 15.8333 11.6666C16.7538 11.6666 17.5 10.9204 17.5 9.99992C17.5 9.07944 16.7538 8.33325 15.8333 8.33325ZM9.99992 11.6666C9.07944 11.6666 8.33325 10.9204 8.33325 9.99992C8.33325 9.07944 9.07944 8.33325 9.99992 8.33325C10.9204 8.33325 11.6666 9.07944 11.6666 9.99992C11.6666 10.9204 10.9204 11.6666 9.99992 11.6666ZM2.5 9.99992C2.5 9.07944 3.24619 8.33325 4.16667 8.33325C5.08714 8.33325 5.83333 9.07944 5.83333 9.99992C5.83333 10.9204 5.08714 11.6666 4.16667 11.6666C3.24619 11.6666 2.5 10.9204 2.5 9.99992Z",fill:"currentColor"}))}function cv(n){return d("svg",{width:"44",height:"44",stroke:"#4759F7",viewBox:"0 0 44 44",xmlns:"http://www.w3.org/2000/svg",...n},d("g",null,d("circle",{cx:"22",cy:"22",r:"20",fill:"none","stroke-width":"2"})))}var uv=M(cv)`
  left: ${({left:n})=>n??"-6px"};
  pointer-events: none;
  position: absolute;
  top: ${({top:n})=>n??"-4px"};
  width: ${({size:n})=>n??"26px"};
  height: ${({size:n})=>n??"26px"};

  g {
    transform-origin: center;
    animation: spinner_rotation 2s linear infinite;
  }

  g circle {
    stroke-linecap: round;
    animation: spinner_dash 2s ease-in-out infinite;
  }

  @keyframes spinner_rotation {
    100% {
      transform: rotate(360deg);
    }
  }

  @keyframes spinner_dash {
    0% {
      stroke-dasharray: 0 330;
      stroke-dashoffset: 0;
    }

    47.5% {
      stroke-dasharray: 92 330;
      stroke-dashoffset: -35;
    }

    95%,
    100% {
      stroke-dasharray: 92 330;
      stroke-dashoffset: -119;
    }
  }
`,ad=({variant:n,...o})=>{let a=`clip0_playPause_${n}`;return d(mn,{xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 32 32",width:"20px",height:"20px",...o},d("g",{clipPath:`url(#${a})`},d("circle",{cx:"16",cy:"16",r:"16",className:"icon-circle"}),n==="play"?d("path",{d:"M22.2 14.9608C23 15.4227 23 16.5774 22.2 17.0392L13.8 21.889C13 22.3509 12 21.7735 12 20.8498L12 11.1503C12 10.2265 13 9.64917 13.8 10.111L22.2 14.9608Z",fill:"white"}):d(W,null,d("path",{d:"M11 11C11 10.4477 11.4477 10 12 10H14C14.5523 10 15 10.4477 15 11V21C15 21.5523 14.5523 22 14 22H12C11.4477 22 11 21.5523 11 21V11Z",fill:"white"}),d("path",{d:"M17 11C17 10.4477 17.4477 10 18 10H20C20.5523 10 21 10.4477 21 11V21C21 21.5523 20.5523 22 20 22H18C17.4477 22 17 21.5523 17 21V11Z",fill:"white"}))),d("defs",null,d("clipPath",{id:a},d("rect",{width:"32",height:"32",fill:"white"}))))},sd=n=>d(W,null,d(uv,{top:"-3px",left:"-3px"}),d(Ns,{...n})),Ns=n=>d(ad,{variant:"play",...n}),ld=n=>d(ad,{variant:"pause",...n}),cd=n=>d(mn,{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 20 20",fill:"none",...n},d("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M8.66692 1.99997C7.43968 1.99997 6.44478 2.99479 6.44469 4.22203L6.44452 6.44443H3.77778C2.79594 6.44443 2 7.24037 2 8.22221V16.2222C2 17.2041 2.79594 18 3.77778 18H11.7778C12.7596 18 13.5556 17.2041 13.5556 16.2222V13.5556H15.7775C17.0048 13.5556 17.9997 12.5607 17.9998 11.3334L18 4.22227C18 2.99494 17.0051 1.99997 15.7778 1.99997H8.66692ZM13.5556 11.7778H15.7775C16.023 11.7778 16.222 11.5788 16.222 11.3333L16.2222 4.22221C16.2222 3.97674 16.0232 3.77775 15.7778 3.77775H8.66692C8.42147 3.77775 8.22249 3.97672 8.22247 4.22216L8.2223 6.44443H11.7778C12.7596 6.44443 13.5556 7.24037 13.5556 8.22221V11.7778ZM3.77778 8.22221H11.7778V16.2222H3.77778L3.77778 8.22221Z",fill:"currentColor"}));function ud(n){return d(mn,{viewBox:"0 0 20 20",fill:"none",...n},d("path",{"fill-rule":"evenodd","clip-rule":"evenodd",d:"M9.99984 1.70001C9.65549 1.70001 9.34978 1.92036 9.24089 2.24703L8.48857 4.50401C8.20055 5.36804 7.71533 6.15315 7.07132 6.79716L6.36847 7.50001H3.33317C2.4127 7.50001 1.6665 8.2462 1.6665 9.16668V15.8333C1.6665 16.7538 2.4127 17.5 3.33317 17.5L7.49984 17.4667H13.7467C15.3416 17.4667 16.7082 16.3261 16.9935 14.757L17.9297 9.60793C18.205 8.09379 17.0418 6.70001 15.5028 6.70001H12.6109L12.9655 4.5722C13.2161 3.06868 12.0567 1.70001 10.5324 1.70001H9.99984ZM5.8665 9.10001V15.9H3.33317C3.29635 15.9 3.2665 15.8702 3.2665 15.8333V9.16668C3.2665 9.12986 3.29635 9.10001 3.33317 9.10001H5.8665ZM7.49984 15.8667H13.7467C14.5683 15.8667 15.2723 15.2791 15.4193 14.4708L16.3555 9.32171C16.4522 8.78972 16.0435 8.30001 15.5028 8.30001H11.6665C11.4313 8.30001 11.2081 8.19655 11.0561 8.01711C10.9041 7.83768 10.8387 7.60046 10.8774 7.36849L11.3873 4.30916C11.4729 3.79536 11.0899 3.32638 10.5761 3.30108L10.0065 5.00997C9.6399 6.10965 9.02234 7.10888 8.20269 7.92853L7.49984 8.63138V15.8667Z"}))}function fd(n){return d(mn,{viewBox:"0 0 20 20",fill:"none",...n},d("path",{"fill-rule":"evenodd","clip-rule":"evenodd",d:"M12.5001 2.53333V2.5H16.6668C17.5873 2.5 18.3335 3.24619 18.3335 4.16667V10.8333C18.3335 11.7538 17.5873 12.5 16.6668 12.5H13.6315L12.9287 13.2029C12.2846 13.8469 11.7994 14.632 11.5114 15.496L10.7591 17.753C10.6502 18.0797 10.3445 18.3 10.0001 18.3L9.46757 18.3C7.94332 18.3 6.78388 16.9313 7.03447 15.4278L7.38911 13.3H4.49716C2.9582 13.3 1.79499 11.9062 2.07028 10.3921L3.00648 5.24301C3.29177 3.67389 4.65841 2.53333 6.25325 2.53333L12.5001 2.53333ZM12.5001 4.13333L6.25325 4.13333C5.43166 4.13333 4.72764 4.72089 4.58067 5.52923L3.64448 10.6783C3.54775 11.2103 3.95645 11.7 4.49716 11.7L8.33347 11.7C8.56864 11.7 8.79189 11.8035 8.94389 11.9829C9.09589 12.1623 9.16125 12.3996 9.12259 12.6315L8.6127 15.6909C8.52707 16.2047 8.9101 16.6736 9.42389 16.6989L9.99352 14.99C10.3601 13.8904 10.9776 12.8911 11.7973 12.0715L12.5001 11.3686L12.5001 4.13333ZM14.1335 10.9H16.6668C16.7036 10.9 16.7335 10.8702 16.7335 10.8333V4.16667C16.7335 4.12985 16.7036 4.1 16.6668 4.1L14.1335 4.1L14.1335 10.9Z"}))}function dd(n){return d(mn,{viewBox:"0 0 20 20",fill:"none",...n},d("path",{"fill-rule":"evenodd","clip-rule":"evenodd",d:"M18.0168 4.59663C18.4073 4.98716 18.4073 5.62033 18.0168 6.01084L8.62378 15.4033C8.43623 15.5908 8.18185 15.6962 7.91662 15.6961C7.65139 15.6961 7.39703 15.5907 7.20951 15.4032L1.98324 10.1758C1.59276 9.78519 1.59283 9.15202 1.9834 8.76154C2.37397 8.37106 3.00713 8.37113 3.39761 8.7617L7.91679 13.2819L16.6026 4.59658C16.9932 4.20607 17.6263 4.20609 18.0168 4.59663Z",fill:"#9899A6"}))}function pd(n){return d(mn,{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 20 20",fill:"none",...n},d("path",{"fill-rule":"evenodd","clip-rule":"evenodd",d:"M15.4238 6.41626C14.2593 4.65741 12.2641 3.5 10 3.5C6.41015 3.5 3.5 6.41015 3.5 10C3.5 13.5898 6.41015 16.5 10 16.5C13.3367 16.5 16.0874 13.9849 16.4576 10.7477C16.5203 10.199 17.016 9.80501 17.5647 9.86775C18.1134 9.93048 18.5073 10.4262 18.4446 10.9749C17.9603 15.2106 14.365 18.5 10 18.5C5.30558 18.5 1.5 14.6944 1.5 10C1.5 5.30558 5.30558 1.5 10 1.5C12.7528 1.5 15.1988 2.80879 16.7514 4.83533V3.54052C16.7514 2.98823 17.1991 2.54052 17.7514 2.54052C18.3037 2.54052 18.7514 2.98823 18.7514 3.54052V7.41626C18.7514 7.96855 18.3037 8.41626 17.7514 8.41626L13.8756 8.41626C13.3233 8.41626 12.8756 7.96855 12.8756 7.41626C12.8756 6.86398 13.3233 6.41626 13.8756 6.41626L15.4238 6.41626Z",fill:"currentColor"}))}function gd(n){return d(mn,{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 20 20",fill:"none",...n},d("path",{"fill-rule":"evenodd","clip-rule":"evenodd",d:"M3.17505 5.07115C3.17505 3.46952 4.47342 2.17115 6.07505 2.17115H8.95519C9.45225 2.17115 9.85519 2.57409 9.85519 3.07115C9.85519 3.56821 9.45225 3.97115 8.95519 3.97115H6.07505C5.46754 3.97115 4.97505 4.46364 4.97505 5.07115V14.4665C4.97505 14.9316 5.24823 15.2714 5.58972 15.3648C6.66481 15.6588 8.23178 15.9562 10.0489 15.9562C11.851 15.9562 13.3593 15.6637 14.3996 15.3731C14.7426 15.2772 15.0169 14.9331 15.0169 14.4665V9.98185C15.0169 9.48479 15.4198 9.08185 15.9169 9.08185C16.4139 9.08185 16.8169 9.48479 16.8169 9.98185V14.4665C16.8169 15.6276 16.1085 16.7646 14.8839 17.1067C13.7156 17.4331 12.0428 17.7562 10.0489 17.7562C8.0415 17.7562 6.313 17.4287 5.11494 17.101C3.88637 16.7651 3.17505 15.6291 3.17505 14.4665V5.07115Z",fill:"currentColor"}),d("path",{"fill-rule":"evenodd","clip-rule":"evenodd",d:"M6.5957 9.10631C6.5957 8.60926 6.99865 8.20631 7.4957 8.20631H10.0014C10.4984 8.20631 10.9014 8.60926 10.9014 9.10631C10.9014 9.60337 10.4984 10.0063 10.0014 10.0063H7.4957C6.99865 10.0063 6.5957 9.60337 6.5957 9.10631Z",fill:"currentColor"}),d("path",{"fill-rule":"evenodd","clip-rule":"evenodd",d:"M6.5957 12.8998C6.5957 12.4027 6.99865 11.9998 7.4957 11.9998H12.6444C13.1414 11.9998 13.5444 12.4027 13.5444 12.8998C13.5444 13.3968 13.1414 13.7998 12.6444 13.7998H7.4957C6.99865 13.7998 6.5957 13.3968 6.5957 12.8998Z",fill:"currentColor"}),d("path",{d:"M14.1299 0.72626C14.4979 -0.0129202 15.5524 -0.0129198 15.9204 0.72626L16.5607 2.01262C16.6576 2.20741 16.8155 2.36527 17.0103 2.46223L18.2967 3.10254C19.0358 3.47048 19.0358 4.52505 18.2967 4.89299L17.0103 5.5333C16.8155 5.63026 16.6576 5.78811 16.5607 5.98291L15.9204 7.26926C15.5524 8.00844 14.4979 8.00844 14.1299 7.26926L13.4896 5.9829C13.3927 5.78811 13.2348 5.63026 13.04 5.5333L11.7537 4.89299C11.0145 4.52505 11.0145 3.47048 11.7537 3.10254L13.04 2.46223C13.2348 2.36527 13.3927 2.20741 13.4896 2.01262L14.1299 0.72626Z",fill:"currentColor"}))}function Rs(n){return d("svg",{width:"140",height:"140",viewBox:"0 0 140 140",fill:"none",xmlns:"http://www.w3.org/2000/svg",...n},d("g",{"clip-path":"url(#clip0_5161_1858)"},d("path",{"fill-rule":"evenodd","clip-rule":"evenodd",d:"M0.90002 42.9138C1.97944 27.1559 2.51915 19.2769 10.9755 10.8414C19.4318 2.40579 27.252 1.88942 42.8922 0.856688C50.7115 0.340376 59.7525 0 70 0C80.2475 0 89.2885 0.340376 97.1078 0.856687C112.748 1.88942 120.568 2.40579 129.025 10.8414C137.481 19.2769 138.021 27.1559 139.1 42.9138C139.64 50.8046 140 59.863 140 70C140 79.5518 139.681 88.1461 139.192 95.7081C138.122 112.252 137.587 120.524 129.134 128.997C120.682 137.471 112.352 138.03 95.6931 139.149C88.0563 139.662 79.4427 140 70 140C60.5573 140 51.9437 139.662 44.3069 139.149C27.648 138.03 19.3185 137.471 10.8658 128.997C2.41318 120.524 1.87821 112.252 0.808262 95.7081C0.319199 88.1461 0 79.5518 0 70C0 59.863 0.359506 50.8045 0.90002 42.9138Z",fill:"#1E1E1F"}),d("path",{d:"M22.9036 51.7375C22.2724 48.5869 24.3149 45.521 27.4656 44.8898L55.7409 39.2252C57.3113 38.9106 58.9419 39.2573 60.2485 40.1835L74.6995 50.4274C75.9108 51.2861 76.748 52.5753 77.0396 54.0311L86.1891 99.7019C86.8203 102.853 84.7779 105.918 81.6272 106.55L41.4315 114.602C38.2808 115.234 35.215 113.191 34.5838 110.04L22.9036 51.7375Z",fill:"url(#paint0_linear_5161_1858)"}),d("path",{d:"M61.9277 29.9458C62.2616 26.8006 65.0819 24.5216 68.2271 24.8555L99.4008 28.1646C100.968 28.331 102.398 29.1363 103.353 30.3906L115.003 45.6938C115.888 46.8567 116.295 48.3139 116.141 49.7672L110.841 99.6974C110.507 102.843 107.686 105.122 104.541 104.788L60.2414 100.085C57.0962 99.7515 54.8172 96.9311 55.1511 93.7859L61.9277 29.9458Z",fill:"#3D3D3D"}),d("path",{d:"M77.292 52.5967L95.4755 75.7194",stroke:"#1E1E1F","stroke-width":"8.01761","stroke-linecap":"round"}),d("path",{d:"M97.9453 55.0659L74.8227 73.2496",stroke:"#1E1E1F","stroke-width":"8.01761","stroke-linecap":"round"})),d("defs",null,d("linearGradient",{id:"paint0_linear_5161_1858",x1:"83.9487",y1:"139.324",x2:"-15.0211",y2:"75.4955",gradientUnits:"userSpaceOnUse"},d("stop",{offset:"0.195387","stop-color":"#2E2E2E"}),d("stop",{offset:"0.760496","stop-color":"#3D3D3D"})),d("clipPath",{id:"clip0_5161_1858"},d("rect",{width:"140",height:"140",fill:"white"}))))}w();C();var ti=we(Oe());var fv=M.div`
  display: flex;
  flex-direction: column;
  gap: 16px;
  text-align: left;
`,hd=M.div`
  display: flex;
  flex-direction: column;
  gap: 4px;
`,md=M.label`
  color: #ffffff;
  font-size: 14px;
  font-weight: 500;
  line-height: 20px;
  letter-spacing: -0.0275rem;
  margin: 0;
`,_d=M.div`
  display: flex;
  gap: 8px;
`,ei=M.button`
  flex: 1;
  padding: 8px;
  border-radius: 8px;
  border: none;
  background-color: ${({isSelected:n})=>n?"#262940":"#252627"};
  color: ${({isSelected:n})=>n?"#8894FE":"#ffffff"};
  font-size: 14px;
  font-weight: 500;
  line-height: 20px;
  cursor: ${({isSelected:n})=>n?"default":"pointer"};
  transition: all 0.15s ease;

  &:hover {
    background-color: ${({isSelected:n})=>n?"#262940":"#2d2d2f"};
  }

  &:active {
    background-color: ${({isSelected:n})=>n?"#262940":"#2d2d2f"};
  }
`,dv=M.div`
  display: flex;
  justify-content: center;
  width: 100%;
  margin: 8px 0;
`;function yd({isOpen:n,onClose:o,onSave:a}){let f=Xf(),p=Zu(),[m,x]=(0,ti.useState)(f.length),[S,I]=(0,ti.useState)(f.mode);return(0,ti.useEffect)(()=>{n&&(x(f.length),I(f.mode))},[n,f.length,f.mode]),d(Po,{isOpen:n,onClose:o},d(ko,null,d(Ro,null,"Summary Settings"),d(fv,null,d(hd,null,d(md,null,"Length"),d(_d,null,d(ei,{isSelected:m==="short",onClick:()=>x("short")},"Short"),d(ei,{isSelected:m==="medium",onClick:()=>x("medium")},"Medium"),d(ei,{isSelected:m==="long",onClick:()=>x("long")},"Long"))),d(hd,null,d(md,null,"Mode"),d(_d,null,d(ei,{isSelected:S==="paragraph",onClick:()=>I("paragraph")},"Paragraph"),d(ei,{isSelected:S==="bullet-points",onClick:()=>I("bullet-points")},"Bullet Points")))),d(dv,null,d(Jr,{variant:"save",onClick:()=>{p({length:m,mode:S}),a?.(),o()}},"Save"))))}w();C();var Ps=async()=>{try{return(await F.tabs.query({active:!0,currentWindow:!0}))[0]?.id?await F.tabs.captureVisibleTab({format:"png",quality:90}):null}catch(n){return console.error("Failed to capture page preview:",n),null}},vd=async()=>{try{let o=(await F.tabs.query({active:!0,currentWindow:!0}))[0];return o?.id&&(await F.scripting.executeScript({target:{tabId:o.id},func:async()=>{let f=B=>!B||B.startsWith("data:")?null:B.startsWith("//")?`https:${B}`:B.startsWith("/")?`${window.location.origin}${B}`:B.startsWith("http")?B:`${window.location.origin}/${B}`,p=B=>{let z=B.toLowerCase();return[/miro\.medium\.com/i,/cdn-images-\d+\.medium\.com/i,/medium\.com.*\/[a-f0-9-]+\*\d+/i,/[\w-]+\.medium\.com.*\.(jpg|jpeg|png|webp|gif)/i].some(R=>R.test(z))},m=B=>{let z=B.toLowerCase();return["medium.com/_/stat","medium.com/m/global-identity","medium.com/_/api"].some(R=>z.includes(R))},x=(B,z,N,R,K)=>{let c=0,h=B.toLowerCase();if(N&&R){let O=N*R;O>64e4?c+=100:O>4e5?c+=80:O>16e4?c+=60:O>4e4?c+=40:O<1e4&&(c-=30)}if(p(B)&&(c+=60,h.includes("*1400")||h.includes("*1200")?c+=50:h.includes("*800")||h.includes("*1000")?c+=40:h.includes("*600")||h.includes("*720")?c+=30:(h.includes("*400")||h.includes("*480"))&&(c+=20),(h.includes("max-")||h.includes("fit-"))&&(c+=15)),m(B)&&(c-=100),h.includes(".jpg")||h.includes(".jpeg")?c+=20:h.includes(".png")?c+=15:h.includes(".webp")&&(c+=25),(h.includes("hero")||h.includes("featured"))&&(c+=30),(h.includes("article")||h.includes("story"))&&(c+=25),(h.includes("main")||h.includes("primary"))&&(c+=20),(h.includes("thumb")||h.includes("small"))&&(c-=20),(h.includes("icon")||h.includes("logo"))&&(c-=30),(h.includes("avatar")||h.includes("profile"))&&(c-=25),(h.includes("clap")||h.includes("highlight"))&&(c-=40),K&&z==="medium-specific"){let O=K.getBoundingClientRect(),P=window.innerHeight;O.top<P*.5&&(c+=20),O.top<P*.3&&(c+=10)}let y={"og:image":100,"og:image:secure_url":95,"twitter:image":90,"twitter:image:src":85,"article:image":80,"medium-specific":85,jsonld:75,microdata:70,"meta-image":60,"itemprop-image":55,"first-main-image":40,"largest-image":30};return{url:f(B),score:c+(y[z]||0),source:z}},S=[];if(!!(window.location.hostname.includes("medium.com")||['meta[property="al:ios:app_name"][content="Medium"]','meta[name="apple-itunes-app"][content*="medium"]','meta[property="twitter:app:name:iphone"][content="Medium"]'].some(N=>document.querySelector(N))||[".meteredContent",'[data-testid="storyContent"]',".postArticle",".graf",'[data-module="ArticleClaps"]'].some(N=>document.querySelector(N))||document.body.className.includes("medium-com")||document.body.className.includes("is-withMobileMeta")||window.location.pathname.includes("/@")||window.location.search.includes("source="))){await new Promise(N=>setTimeout(N,1500));let B=["article",'[data-testid="storyContent"]',".postArticle-content",".post-content","main"],z=null;for(let N of B){let R=document.querySelector(N);if(R){z=R;break}}if(z){let N=c=>{let h=c.naturalWidth||c.width||parseInt(c.style.width)||0,y=c.naturalHeight||c.height||parseInt(c.style.height)||0;if(h<100||y<100)return!1;let O=c.src||c.getAttribute("data-src")||"";return!(O.includes("avatar")||O.includes("profile")||O.includes("author"))},R=!1,K=["figure img",".graf--figure img",".imageContainer img",".aspectRatioPlaceholder img",".progressiveMedia img",".markup--figure img"];for(let c of K){if(R)break;let h=z.querySelectorAll(c);for(let y of h){if(y.closest('.sidebar, .related, .recommendations, .more-from, .author-info, aside, nav, [class*="sidebar"], [class*="related"], [class*="recommendation"]'))continue;let P=y.src||y.getAttribute("data-src")||y.getAttribute("data-lazy-src")||y.getAttribute("data-delayed-src")||y.dataset.src;if(P&&P!==""&&!P.startsWith("data:")&&!m(P)){let q=x(P,"medium-figure-image",400,300,y);q.score=1e3,S.push(q),R=!0;break}}}if(!R){await new Promise(h=>setTimeout(h,500));let c=z.querySelectorAll("img");for(let h of c){if(h.closest('.sidebar, .related, .recommendations, .more-from, .author-info, aside, nav, [class*="sidebar"], [class*="related"], [class*="recommendation"]'))continue;let O=h.src||h.getAttribute("data-src")||h.getAttribute("data-lazy-src")||h.getAttribute("data-delayed-src")||h.dataset.src;if(O&&O!==""&&!O.startsWith("data:")&&!m(O)&&N(h)){let P=x(O,"medium-first-substantial",400,300,h);P.score=900,S.push(P),R=!0;break}}}if(!R){let c=z.querySelectorAll("img");for(let h of c){if(h.closest('.sidebar, .related, .recommendations, .more-from, .author-info, aside, nav, [class*="sidebar"], [class*="related"], [class*="recommendation"]'))continue;let O=h.src||h.getAttribute("data-src")||h.getAttribute("data-lazy-src")||h.getAttribute("data-delayed-src")||h.dataset.src;if(O&&O!==""&&!O.startsWith("data:")&&!m(O)){let P=x(O,"medium-fallback",400,300,h);P.score=800,S.push(P);break}}}}try{document.querySelectorAll("figure, .graf--figure, .imageContainer").forEach(R=>{let c=window.getComputedStyle(R).backgroundImage;if(c&&c!=="none"){let h=c.match(/url\(["']?([^"')]+)["']?\)/);h&&!m(h[1])&&S.push(x(h[1],"medium-specific",400,300))}})}catch(N){console.error("Background image extraction error:",N)}try{document.querySelectorAll("script").forEach(R=>{if(R.textContent&&(R.textContent.includes("__APOLLO_STATE__")||R.textContent.includes("window.__INITIAL_STATE__"))){let K=/(https?:\/\/[^"'\s]+\.(?:jpg|jpeg|png|webp|gif)(?:\?[^"'\s]*)?)/gi,c=R.textContent.match(K);c&&c.forEach(h=>{p(h)&&!m(h)&&S.push(x(h,"medium-specific",600,400))})}})}catch(N){console.error("Script state extraction error:",N)}}[document.querySelector("meta[property='og:image']"),document.querySelector("meta[property='og:image:secure_url']"),document.querySelector("meta[property='og:image:url']"),document.querySelector("meta[name='og:image']")].forEach((B,z)=>{let N=B?.getAttribute("content");if(N&&!m(N)){let R=["og:image","og:image:secure_url","og:image:url","og:image-name"];S.push(x(N,R[z]))}}),[document.querySelector("meta[name='twitter:image']"),document.querySelector("meta[name='twitter:image:src']"),document.querySelector("meta[property='twitter:image']")].forEach((B,z)=>{let N=B?.getAttribute("content");if(N&&!m(N)){let R=["twitter:image","twitter:image:src","twitter:image-prop"];S.push(x(N,R[z]))}});try{document.querySelectorAll('script[type="application/ld+json"]').forEach(z=>{try{let N=JSON.parse(z.textContent||""),R=K=>{let c=[];return typeof K=="string"&&K.startsWith("http")?c.push(K):Array.isArray(K)?K.forEach(h=>c.push(...R(h))):K&&typeof K=="object"&&["image","thumbnailUrl","contentUrl","url"].forEach(y=>{K[y]&&c.push(...R(K[y]))}),c};R(N).forEach(K=>{m(K)||S.push(x(K,"jsonld"))})}catch{}})}catch(B){console.error("JSON-LD extraction error:",B)}if(S.length===0)return null;S.sort((B,z)=>z.score-B.score);for(let B of S)if(B.url&&B.url.startsWith("http")&&!m(B.url))return B.url;return null}}))[0]?.result||null}catch(n){return console.error("Failed to extract article image:",n),null}};var ks={"google.com":"Google","bing.com":"Bing","yahoo.com":"Yahoo","duckduckgo.com":"DuckDuckGo","yandex.com":"Yandex","baidu.com":"Baidu","facebook.com":"Facebook","twitter.com":"Twitter","x.com":"X (Twitter)","instagram.com":"Instagram","linkedin.com":"LinkedIn","tiktok.com":"TikTok","snapchat.com":"Snapchat","pinterest.com":"Pinterest","reddit.com":"Reddit","discord.com":"Discord","telegram.org":"Telegram","whatsapp.com":"WhatsApp","youtube.com":"YouTube","netflix.com":"Netflix","twitch.tv":"Twitch","vimeo.com":"Vimeo","hulu.com":"Hulu","disneyplus.com":"Disney+","primevideo.com":"Prime Video","hbo.com":"HBO","spotify.com":"Spotify","soundcloud.com":"SoundCloud","cnn.com":"CNN","bbc.com":"BBC","bbc.co.uk":"BBC","nytimes.com":"The New York Times","washingtonpost.com":"The Washington Post","reuters.com":"Reuters","apnews.com":"AP News","theguardian.com":"The Guardian","wsj.com":"The Wall Street Journal","bloomberg.com":"Bloomberg","forbes.com":"Forbes","techcrunch.com":"TechCrunch","theverge.com":"The Verge","arstechnica.com":"Ars Technica","wired.com":"Wired","engadget.com":"Engadget","amazon.com":"Amazon","ebay.com":"eBay","etsy.com":"Etsy","shopify.com":"Shopify","alibaba.com":"Alibaba","walmart.com":"Walmart","target.com":"Target","bestbuy.com":"Best Buy","apple.com":"Apple","microsoft.com":"Microsoft","github.com":"GitHub","stackoverflow.com":"Stack Overflow","stackexchange.com":"Stack Exchange","medium.com":"Medium","dev.to":"DEV Community","atlassian.com":"Atlassian","salesforce.com":"Salesforce","adobe.com":"Adobe","figma.com":"Figma","notion.so":"Notion","slack.com":"Slack","zoom.us":"Zoom","dropbox.com":"Dropbox","googledrive.com":"Google Drive","onedrive.com":"OneDrive","coursera.org":"Coursera","udemy.com":"Udemy","edx.org":"edX","khanacademy.org":"Khan Academy","duolingo.com":"Duolingo","wikipedia.org":"Wikipedia","mozilla.org":"Mozilla","w3schools.com":"W3Schools","mdn.mozilla.org":"MDN Web Docs","developer.mozilla.org":"MDN Web Docs","npmjs.com":"npm","gmail.com":"Gmail","outlook.com":"Outlook","mail.google.com":"Gmail","docs.google.com":"Google Docs","sheets.google.com":"Google Sheets","slides.google.com":"Google Slides","office.com":"Microsoft Office","office365.com":"Microsoft 365","maps.google.com":"Google Maps","booking.com":"Booking.com","airbnb.com":"Airbnb","tripadvisor.com":"TripAdvisor","expedia.com":"Expedia","paypal.com":"PayPal","stripe.com":"Stripe","coinbase.com":"Coinbase","binance.com":"Binance","weibo.com":"微博 (Weibo)","vk.com":"VKontakte","ok.ru":"Odnoklassniki","naver.com":"Naver","kakao.com":"Kakao","line.me":"LINE"},Mo=n=>{try{let o=new URL(n).hostname.replace("www.","").toLowerCase();if(ks[o])return ks[o];for(let[f,p]of Object.entries(ks))if(o.endsWith(`.${f}`)||o===f)return p;if(o.endsWith(".github.io"))return"GitHub Pages";if(o.endsWith(".blogspot.com"))return"Blogger";if(o.endsWith(".wordpress.com"))return"WordPress";if(o.endsWith(".substack.com"))return"Substack";let a=o;if(a=a.replace(/^(m\.|mobile\.)/,""),a.includes(".")){let f=a.split("."),p=f.length>1?f[f.length-2]:f[0];a=p.charAt(0).toUpperCase()+p.slice(1),p.length<=3&&p===p.toLowerCase()&&(a=p.toUpperCase())}return a}catch{return n}};var Ms=be("AppHeader"),pv=n=>d("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",...n},d("path",{"fill-rule":"evenodd","clip-rule":"evenodd",d:"M11 2.99984V1.6665C11 1.11422 10.5523 0.666504 10 0.666504C9.44771 0.666504 9 1.11422 9 1.6665V2.99984H3.5C2.94772 2.99984 2.5 3.44755 2.5 3.99984C2.5 4.55212 2.94772 4.99984 3.5 4.99984H4.05344L4.61193 15.1644C4.69932 16.7549 6.01451 17.9998 7.60741 17.9998H12.3926C13.9855 17.9998 15.3007 16.7549 15.3881 15.1644L15.9466 4.99984H16.5C17.0523 4.99984 17.5 4.55212 17.5 3.99984C17.5 3.44755 17.0523 2.99984 16.5 2.99984H11ZM6.05645 4.99984L6.60892 15.0547C6.63805 15.5849 7.07644 15.9998 7.60741 15.9998H12.3926C12.9236 15.9998 13.362 15.5849 13.3911 15.0547L13.9435 4.99984H6.05645Z",fill:"currentColor"})),gv=n=>d("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",...n},d("path",{"fill-rule":"evenodd","clip-rule":"evenodd",d:"M8.90544 3.4001H11.0977L11.4871 4.19505C12.0056 5.25348 13.113 5.89287 14.2889 5.81264L15.1717 5.75241L16.268 7.65123L15.7744 8.38567C15.117 9.36387 15.117 10.6426 15.7744 11.6209L16.2677 12.3549L15.1712 14.2541L14.2889 14.1939C13.113 14.1137 12.0056 14.753 11.4871 15.8115L11.0982 16.6055H8.905L8.51605 15.8115C7.99761 14.753 6.89016 14.1137 5.7143 14.1939L4.83186 14.2541L3.7354 12.355L4.22877 11.6209C4.88617 10.6426 4.88617 9.36387 4.22877 8.38567L3.73512 7.65113L4.83135 5.7524L5.7143 5.81264C6.89016 5.89287 7.99761 5.25348 8.51605 4.19505L8.90544 3.4001ZM12.6059 2.38721C12.3305 1.82498 11.7679 1.6001 11.3016 1.6001H8.70156C8.23526 1.6001 7.67264 1.82498 7.39724 2.38721L6.89956 3.40325C6.70291 3.80472 6.28284 4.04725 5.83683 4.01682L4.70808 3.9398C4.08366 3.8972 3.60769 4.27185 3.37457 4.67562L2.07421 6.92792C1.8411 7.33168 1.75462 7.93121 2.10373 8.45067L2.7348 9.38969C2.98416 9.76073 2.98416 10.2458 2.7348 10.6168L2.10373 11.5559C1.75489 12.0749 1.84115 12.674 2.07416 13.0776L3.37541 15.3314C3.60842 15.735 4.08414 16.1093 4.70808 16.0667L5.83683 15.9897C6.28284 15.9593 6.70291 16.2018 6.89956 16.6033L7.39724 17.6193C7.67221 18.1807 8.23391 18.4055 8.6998 18.4055H11.3034C11.7693 18.4055 12.331 18.1807 12.6059 17.6193L13.1036 16.6033C13.3003 16.2018 13.7203 15.9593 14.1664 15.9897L15.2951 16.0667C15.9189 16.1093 16.3946 15.7351 16.6276 15.3316L17.929 13.0774C18.162 12.6738 18.2482 12.0748 17.8995 11.5559L17.2684 10.6168C17.019 10.2458 17.019 9.76073 17.2684 9.38969L17.8995 8.45067C18.2485 7.9313 18.1621 7.33188 17.929 6.92815L16.6284 4.67549C16.3953 4.27177 15.9194 3.89721 15.2951 3.9398L14.1664 4.01682C13.7203 4.04725 13.3003 3.80472 13.1036 3.40325L12.6059 2.38721ZM11.5343 10.0039C11.5343 10.8507 10.8478 11.5372 10.0009 11.5372C9.1541 11.5372 8.4676 10.8507 8.4676 10.0039C8.4676 9.15703 9.1541 8.47053 10.0009 8.47053C10.8478 8.47053 11.5343 9.15703 11.5343 10.0039ZM13.3343 10.0039C13.3343 11.8448 11.8419 13.3372 10.0009 13.3372C8.15999 13.3372 6.6676 11.8448 6.6676 10.0039C6.6676 8.16292 8.15999 6.67053 10.0009 6.67053C11.8419 6.67053 13.3343 8.16292 13.3343 10.0039Z",fill:"currentColor"})),hv=M.div`
  padding: 0 16px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  position: relative;
  height: 44px;
`,mv=M.div`
  display: flex;
  align-items: center;
  gap: 8px;
`,_v=M.img`
  width: 16px;
  height: 16px;
  border-radius: 2px;
  flex-shrink: 0;
`,yv=M.span`
  color: #e8eaed;
  font-size: 14px;
  font-weight: 500;
  line-height: 20px;
  letter-spacing: -0.00275rem;
`,vv=M.button`
  display: flex;
  justify-content: center;
  align-items: center;
  cursor: pointer;
  padding: 0;
  border-radius: 8px;
  transition: background-color 0.15s ease;
  overflow: hidden;
  width: 24px;
  height: 24px;
  border: none;
  background: none;

  flex-shrink: 0;

  color: #9899a6;

  &:hover,
  &:focus,
  &:active {
    color: #ffffff;
  }

  &:active {
    opacity: 0.75;
  }
`,xv=M.div`
  position: fixed;
  top: ${({top:n})=>n}px;
  right: ${({right:n})=>n}px;
  width: 200px;
  background-color: #252627;
  padding: 4px;
  border-radius: 12px;
  border: 0.5px solid #2d2d2f;
  box-shadow: 0px 6px 16px -6px rgba(0, 0, 0, 0.64);
  z-index: 2147483640;
  opacity: ${({isOpen:n})=>n?1:0};
  visibility: ${({isOpen:n})=>n?"visible":"hidden"};
  transform: ${({isOpen:n})=>n?"translateY(0)":"translateY(-8px)"};
  transition: all 0.15s ease;
  overflow: hidden;

  display: flex;
  flex-direction: column;
  gap: 2px;
`,xd=M.div`
  padding: 10px 12px;
  color: ${({disabled:n})=>n?"#6b6b6b":"#ffffff"};
  font-size: 14px;
  font-weight: 500;
  line-height: 20px;
  letter-spacing: 0.14px;
  cursor: ${({disabled:n})=>n?"not-allowed":"pointer"};
  transition: all 0.15s ease;
  display: flex;
  align-items: center;
  gap: 8px;
  opacity: ${({disabled:n})=>n?.5:1};
  user-select: none;
  border-radius: 8px;

  &:hover {
    background-color: ${({disabled:n})=>n?"transparent":"#2d2d2f"};
  }

  svg {
    color: #9899a6;
    opacity: ${({disabled:n})=>n?.5:1};
  }
`,bv=M.div`
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding-left: 24px;
`;function Sd({showPageTitle:n,showMenu:o=!0,onRegenerate:a}){let[f,p]=(0,Ct.useState)(!1),[m,x]=(0,Ct.useState)(!1),[S,I]=(0,Ct.useState)(!1),[k,V]=(0,Ct.useState)({top:0,right:0}),U=(0,Ct.useRef)(null),B=(0,Ct.useRef)(null),z=nr(Q=>Q.clearCurrentUrlChat),N=Gu(),[R]=dn(),K=rr(),c=ir(),h=(0,Ct.useMemo)(()=>Dn({key:"dropdown-cache",container:document.head}),[]),y=()=>{if(U.current){let Q=U.current.getBoundingClientRect(),ve=window.innerWidth;V({top:Q.bottom,right:ve-Q.right})}};(0,Ct.useEffect)(()=>{function Q(ve){let Ie=ve.target,en=U.current&&U.current.contains(Ie),De=B.current&&B.current.contains(Ie);Ms.debug("🖱️ Click outside check:",{isInsideMenuButton:en,isInsideDropdown:De,shouldCloseMenu:!en&&!De,target:Ie}),!en&&!De&&p(!1)}if(f)return document.addEventListener("mousedown",Q),()=>document.removeEventListener("mousedown",Q)},[f]);let O=()=>{let Q=!f;f||y(),p(Q)},P=Q=>{Q.preventDefault(),Q.stopPropagation(),R?.hasSummary&&(p(!1),x(!0))},q=async()=>{try{await z(),x(!1),await N()}catch(Q){Ms.error("❌ Failed to clear chat:",Q)}finally{x(!1)}},G=()=>{x(!1)},Se=Q=>{Q.preventDefault(),Q.stopPropagation(),p(!1),I(!0)},ge=()=>{I(!1)},pe=()=>{if(!f)return null;let Q=!R?.hasSummary;return(0,bd.createPortal)(d(jr,{value:h},d(xv,{ref:B,isOpen:f,top:k.top,right:k.right},d(xd,{onClick:Se},d(gv,null),"Summary Settings"),d(xd,{disabled:Q,onClick:P,onMouseDown:()=>{Ms.debug("🖱️ MenuItem mousedown event:",{disabled:Q,hasSummary:R?.hasSummary,currentUrlState:R})}},d(pv,null),"Clear Chat"))),document.body)};return d(W,null,(o||n)&&d(hv,null,d(bv,null,n&&d(mv,null,c?.favIconUrl&&d(_v,{src:c.favIconUrl,alt:""}),K&&d(yv,null,Mo(K)))),o&&d(vv,{onClick:O,ref:U},d(od,null))),o&&pe(),d(id,{isOpen:m,onClose:G,onConfirm:q}),d(yd,{isOpen:S,onClose:ge,onSave:a}))}w();C();w();C();var Ds=be("AuthService","blue"),Cd=n=>n?n.isAnonymous||!n.email:!0,_n=Mu(()=>({isAuthenticated:!1,isLoading:!0})),Sv=_n;async function Cv(){Ds.debug("Initializing auth service");try{_n.setState({isLoading:!0});let n=await kn("/auth/get-user");if(n?.user){let o=!!n.user&&!Cd(n.user);_n.setState({isAuthenticated:o})}else _n.setState({isAuthenticated:!1});Ds.debug("Auth service initialized successfully")}catch(n){Ds.error("Failed to initialize auth service:",n),_n.setState({isAuthenticated:!1})}finally{_n.setState({isLoading:!1})}}Cv();tf("/auth/state-changed",async n=>{let{user:o}=n.body;if(o){let a=!!o&&!Cd(o);_n.setState({isAuthenticated:a})}else _n.setState({isAuthenticated:!1})});var wd=()=>{let{isAuthenticated:n,isLoading:o}=Sv();return{isAuthenticated:n,isLoading:o}};w();C();w();C();var Us=be("WebsiteChecker");function Tv(n,o,a){if(!n.disabledWebsites||n.disabledWebsites.length===0)return!1;let f=a||(typeof window<"u"?window.location.href:"");if(!f)return Us.warn("No URL provided and window.location not available"),!1;try{let p=new URL(f),m=p.hostname,x=p.pathname;return n.disabledWebsites.some(S=>{if(!(m===S.domain||m.endsWith(`.${S.domain}`))||S.pathPrefix&&!x.startsWith(S.pathPrefix))return!1;let k=S.disabledFeatures.includes(o);return k&&Us.debug(`Feature ${o} is disabled for ${m}${S.pathPrefix||""}`),k})}catch(p){return Us.error("Error parsing URL:",p),!1}}function Td(n,o){return Tv(n,"summary",o)}w();C();var Bs=M.button`
  width: 240px;
  height: 40px;
  border-radius: 12px;
  border: 1px solid transparent;
  gap: 8px;
  padding: 12px 16px;
  background: ${n=>n.disabled?"#1a1a1b":"#1e1e1f"};

  font-weight: 500;
  font-size: 14px;
  line-height: 20px;
  letter-spacing: -0.5%;
  color: ${n=>n.disabled?"#6b6b6b":"#ffffff"};

  cursor: ${n=>n.disabled?"not-allowed":"pointer"};
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 60px;
  transition: all 0.15s ease;

  &:hover {
    background-color: ${n=>n.disabled?"#1a1a1b":"#252627"};
  }

  &:active {
    background-color: ${n=>n.disabled?"#1a1a1b":"#252627bf"};
  }

  &:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
`,Fs=M.div`
  width: 16px;
  height: 16px;
  border: 2px solid #3c3c3e;
  border-top: 2px solid #6b6b6b;
  border-radius: 50%;
  animation: spin 1s linear infinite;
  margin-right: 8px;

  @keyframes spin {
    0% {
      transform: rotate(0deg);
    }
    100% {
      transform: rotate(360deg);
    }
  }
`;w();C();var it=we(Oe());w();C();var Ed=M.div`
  color: var(--color-icon-text-icn-txt-prim, #ffffff);
  font-family: 'ABC Diatype', system-ui, -apple-system, sans-serif;
  font-weight: 500;
  font-size: 14px;
  line-height: 20px;
  letter-spacing: -0.008rem;
`,Id=M.div`
  color: var(--color-icon-text-icn-txt-prim, #ffffff);
  font-weight: 500;
  font-size: 18px;
  line-height: 24px;
  letter-spacing: -0.016rem;
  text-align: center;
  margin-bottom: 40px;
  max-width: 280px;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
`,Ad=M.div`
  color: var(--color-icon-text-icn-txt-prim, #9899a6);
  font-size: 14px;
  font-weight: 500;
  line-height: 20px;
  letter-spacing: -0.008rem;
`,Gs=M.div`
  color: #9899a6;
  font-size: 14px;
  text-align: center;
  padding: 20px;
  font-weight: 500;
  line-height: 20px;
  letter-spacing: -0.008rem;
`,H5=M.div`
  color: #9899a6;
  font-size: 16px;
  line-height: 1.4;
  text-align: center;
  margin-bottom: 60px;
  max-width: 280px;
  font-weight: 500;
  letter-spacing: -0.008rem;
`;var Ev=M.div`
  width: 220px;
  height: 220px;
  background-color: #2d2d2f;
  border-radius: 16px;
  margin-bottom: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  border: 1px solid #3c3c3e;
  overflow: hidden;
  position: relative;
`,Iv=M.img`
  width: 100%;
  height: 100%;
  object-fit: cover;
`,Av=M.div`
  width: 24px;
  height: 24px;
  border: 2px solid #3c3c3e;
  border-top: 2px solid #fff;
  border-radius: 50%;
  animation: spin 1s linear infinite;

  @keyframes spin {
    0% {
      transform: rotate(0deg);
    }
    100% {
      transform: rotate(360deg);
    }
  }
`;function Ld({currentUrl:n}){let[o,a]=(0,it.useState)(!1),[f,p]=(0,it.useState)(!1),[m,x]=(0,it.useState)(!1),S=(0,it.useRef)(null),I=Bu(),k=Fu(),V=Uu(),U=(0,it.useRef)(null),B=(0,it.useRef)(Du(1)),z=h=>new Promise(y=>setTimeout(y,h)),N=(0,it.useCallback)(async()=>{let h=new AbortController;U.current=h,a(!0),p(!1);let y=null;for(let O=0;O<3&&!h.signal.aborted;O++)try{if(y=await Ps(),y)break;O<2&&await z(200)}catch(P){console.error(`Page preview attempt ${O+1} failed:`,P),O<2&&await z(200)}y&&!h.signal.aborted?(await V(y,n||void 0),p(!1),a(!1),x(!0),R(!0)):h.signal.aborted||(a(!1),R(!1))},[V,n]),R=(0,it.useCallback)(async(h=!1)=>{let y=new AbortController;U.current=y,h||a(!0),p(!1);let O=B.current,P=10,q=!1;try{let G=Array.from({length:P},(pe,Q)=>O(async()=>{if(y.signal.aborted||q||(Q>0&&await z(1e3),y.signal.aborted||q))return null;try{let ve=await vd();return ve!=null&&!y.signal.aborted&&!q?(q=!0,ve):null}catch(ve){return console.error(`💥 Attempt ${Q+1} failed with error:`,ve),null}})),ge=(await Promise.allSettled(G)).find(pe=>pe.status==="fulfilled"&&pe.value!==null);ge&&!y.signal.aborted?(await V(ge.value,n||void 0),p(!1)):y.signal.aborted||I()||await K()}catch(G){console.error("Image extraction process failed with error:",G),y.signal.aborted||I()||await K()}finally{y.signal.aborted||(h||a(!1),x(!1))}},[V,n]),K=async()=>{try{let h=await Ps();h&&U.current&&!U.current.signal.aborted?(await V(h,n||void 0),p(!1)):U.current&&!U.current.signal.aborted&&p(!0)}catch(h){console.error("Page preview fallback also failed:",h),U.current&&!U.current.signal.aborted&&p(!0)}};(0,it.useEffect)(()=>{if(!n)return;let h=S.current!==n;h&&(S.current=n,U.current&&U.current.abort(),p(!1),a(!1),x(!1));let y=I(),O=k();if(y&&O){p(!1),a(!1);return}(h||!y||!O)&&N()},[n,I,k,N]),(0,it.useEffect)(()=>()=>{U.current&&U.current.abort()},[]);let c=I();return d(Ev,null,o?d(Av,null):c?d("div",{style:{position:"relative",width:"100%",height:"100%"}},d(Iv,{src:c,alt:"Article preview",onError:()=>{console.warn("🚫 Failed to load image, marking as failed:",c),p(!0)}}),m&&d("div",{style:{position:"absolute",bottom:"4px",right:"4px",width:"12px",height:"12px",backgroundColor:"rgba(74, 144, 226, 0.8)",borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center"}},d("div",{style:{width:"6px",height:"6px",backgroundColor:"white",borderRadius:"50%",animation:"pulse 1.5s ease-in-out infinite"}}))):f?d(Gs,null,"No preview available"):d(Gs,null,"Article Preview"))}w();C();var ni=we(Oe());var Od=M.div`
  background-color: #111112;
  color: #ffffff;
  height: 100vh;
  display: flex;
  flex-direction: column;
  position: relative;
`,Nd=M.div`
  padding: 16px;
  text-align: center;
  background-color: #111112;
  color: #ffffff;
  height: 100vh;
`,ri=M.div`
  flex: 1;
  padding: 0 16px; /* 16px side padding as requested */
  display: flex;
  box-sizing: border-box;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  text-align: center;
  overflow-y: auto; /* Make content scrollable */
  overflow-x: hidden;
  width: 100%;

  /* Beautiful scrollbar styling */
  &::-webkit-scrollbar {
    width: 6px;
  }

  &::-webkit-scrollbar-track {
    background: transparent;
    border-radius: 3px;
  }

  &::-webkit-scrollbar-thumb {
    background: #3c3c3e;
    border-radius: 3px;
    transition: background-color 0.2s ease;
  }

  &::-webkit-scrollbar-thumb:hover {
    background: #4a4a4c;
  }

  &::-webkit-scrollbar-thumb:active {
    background: #5a5a5c;
  }

  /* Hide scrollbar buttons */
  &::-webkit-scrollbar-button {
    display: none;
  }

  /* For Firefox */
  scrollbar-width: thin;
  scrollbar-color: #3c3c3e transparent;
`,Rd=M.div`
  flex: 1;
  overflow-y: scroll;
  overflow-x: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;

  /* Extend width slightly to allow scrollbar overlay */
  box-sizing: border-box;

  & > * {
    margin-right: -10px;
    width: calc(100% + 10px);
  }
`,kd=M.div`
  box-sizing: border-box;
  padding: 0 16px;
  max-width: 600px;

  display: ${({alignCenter:n})=>n?"flex":"block"};
  flex-direction: column;
  min-height: 100%;
`,Pd=M.div`
  flex: 1;
  position: relative;
  display: flex;
  flex-direction: column;
  width: 100%;
  overflow: hidden;

  /* Top fade effect - hidden when at top */
  &::before {
    content: '';
    position: absolute;
    top: -6px;
    left: 0;
    right: 10px;
    height: 40px;
    background: linear-gradient(
      0deg,
      rgba(17, 17, 18, 0) 0%,
      rgba(17, 17, 18, 0.9) 50.33%,
      #111112 79.93%,
      #111112 100%
    );
    pointer-events: none;
    z-index: 10;
    opacity: 1;
    transition: opacity 0.2s ease;
  }

  /* Bottom fade effect - hidden when at bottom */
  &::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    right: 10px;
    height: 40px;
    background: linear-gradient(
      180deg,
      rgba(17, 17, 18, 0) 0%,
      rgba(17, 17, 18, 0.9) 50.33%,
      #111112 79.93%,
      #111112 100%
    );
    pointer-events: none;
    z-index: 10;
    opacity: 1;
    transition: opacity 0.2s ease;
  }

  /* Hide top fade when scrolled to top */
  &.hide-top-fade::before {
    opacity: 0;
  }

  /* Hide bottom fade when scrolled to bottom */
  &.hide-bottom-fade::after {
    opacity: 0;
  }
`,Md=M.div`
  display: flex;
  align-items: center;
  margin-bottom: 16px;
  gap: 8px;
`,Dd=M.img`
  width: 20px;
  height: 20px;
  border-radius: 2px;
`,Lv=Qr`
  from {
    transform: translateY(-200%);
    opacity: 0;
  }
  to {
    transform: translateY(0);
    opacity: 1;
  }
`,Ov=Qr`
  from {
    transform: translateY(200%);
    opacity: 0;
  }
  to {
    transform: translateY(0);
    opacity: 1;
  }
`,Nv=Qr`
  from {
    transform: translateY(0);
    opacity: 1;
  }
  to {
    transform: translateY(-200%);
    opacity: 0;
  }
`,Rv=Qr`
  from {
    transform: translateY(0);
    opacity: 1;
  }
  to {
    transform: translateY(200%);
    opacity: 0;
  }
`,Ud=M.button`
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: 6px;
  gap: 10px;
  z-index: 1000;

  position: absolute;
  width: 28px;
  height: 28px;
  left: calc(50% - 28px / 2);

  background: #111112;
  border: 0.5px solid #2d2d2f;
  border-radius: 50px;
  cursor: pointer;

  &:hover {
    transform: scale(1.05);
  }

  &:active {
    transform: scale(0.95);
  }

  svg {
    width: 28px;
    height: 28px;
    flex: none;
  }
`,kv=M(Ud)`
  top: 48px;
  /* Always start with enter animation transform */
  transform: translateY(-200%);
  opacity: 0;

  animation: ${n=>n.isExiting?Nv:Lv}
    ${n=>n.isExiting?"0.3s ease-in forwards":"0.4s ease-out forwards"};
`,Pv=M(Ud)`
  bottom: 0;
  /* Always start with enter animation transform */
  transform: translateY(200%);
  opacity: 0;

  animation: ${n=>n.isExiting?Rv:Ov}
    ${n=>n.isExiting?"0.3s ease-in forwards":"0.4s ease-out forwards"};
`;function Bd({position:n,onClick:o,title:a,children:f}){let[p,m]=(0,ni.useState)(!1),[x,S]=(0,ni.useState)(null);return(0,ni.useEffect)(()=>{if(n)S(n),m(!1);else if(x){m(!0);let k=setTimeout(()=>{S(null),m(!1)},300);return()=>clearTimeout(k)}},[n,x]),x?d(x==="top"?kv:Pv,{isExiting:p,onClick:o,title:a},f):null}w();C();var Ws=M.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 20px;
`;w();C();var xn=we(Oe());w();C();var sp=we(Oe());w();C();var Fo=we(Oe(),1);function Un(){return Un=Object.assign?Object.assign.bind():function(n){for(var o=1;o<arguments.length;o++){var a=arguments[o];for(var f in a)Object.prototype.hasOwnProperty.call(a,f)&&(n[f]=a[f])}return n},Un.apply(this,arguments)}var Mv=["children","options"];var Fd=["allowFullScreen","allowTransparency","autoComplete","autoFocus","autoPlay","cellPadding","cellSpacing","charSet","classId","colSpan","contentEditable","contextMenu","crossOrigin","encType","formAction","formEncType","formMethod","formNoValidate","formTarget","frameBorder","hrefLang","inputMode","keyParams","keyType","marginHeight","marginWidth","maxLength","mediaGroup","minLength","noValidate","radioGroup","readOnly","rowSpan","spellCheck","srcDoc","srcLang","srcSet","tabIndex","useMap"].reduce((n,o)=>(n[o.toLowerCase()]=o,n),{class:"className",for:"htmlFor"}),Gd={amp:"&",apos:"'",gt:">",lt:"<",nbsp:" ",quot:"“"},Dv=["style","script","pre"],Uv=["src","href","data","formAction","srcDoc","action"],Bv=/([-A-Z0-9_:]+)(?:\s*=\s*(?:(?:"((?:\\.|[^"])*)")|(?:'((?:\\.|[^'])*)')|(?:\{((?:\\.|{[^}]*?}|[^}])*)\})))?/gi,Fv=/mailto:/i,Gv=/\n{2,}$/,Wd=/^(\s*>[\s\S]*?)(?=\n\n|$)/,Wv=/^ *> ?/gm,$v=/^(?:\[!([^\]]*)\]\n)?([\s\S]*)/,zv=/^ {2,}\n/,Vv=/^(?:( *[-*_])){3,} *(?:\n *)+\n/,$d=/^(?: {1,3})?(`{3,}|~{3,}) *(\S+)? *([^\n]*?)?\n([\s\S]*?)(?:\1\n?|$)/,zd=/^(?: {4}[^\n]+\n*)+(?:\n *)+\n?/,Yv=/^(`+)((?:\\`|(?!\1)`|[^`])+)\1/,Kv=/^(?:\n *)*\n/,qv=/\r\n?/g,Xv=/^\[\^([^\]]+)](:(.*)((\n+ {4,}.*)|(\n(?!\[\^).+))*)/,Hv=/^\[\^([^\]]+)]/,Zv=/\f/g,jv=/^---[ \t]*\n(.|\n)*\n---[ \t]*\n/,Qv=/^\s*?\[(x|\s)\]/,Vd=/^ *(#{1,6}) *([^\n]+?)(?: +#*)?(?:\n *)*(?:\n|$)/,Yd=/^ *(#{1,6}) +([^\n]+?)(?: +#*)?(?:\n *)*(?:\n|$)/,Kd=/^([^\n]+)\n *(=|-){3,} *\n/,$s=/^ *(?!<[a-z][^ >/]* ?\/>)<([a-z][^ >/]*) ?((?:[^>]*[^/])?)>\n?(\s*(?:<\1[^>]*?>[\s\S]*?<\/\1>|(?!<\1\b)[\s\S])*?)<\/\1>(?!<\/\1>)\n*/i,Jv=/&([a-z0-9]+|#[0-9]{1,6}|#x[0-9a-fA-F]{1,6});/gi,qd=/^<!--[\s\S]*?(?:-->)/,ex=/^(data|aria|x)-[a-z_][a-z\d_.-]*$/,zs=/^ *<([a-z][a-z0-9:]*)(?:\s+((?:<.*?>|[^>])*))?\/?>(?!<\/\1>)(\s*\n)?/i,tx=/^\{.*\}$/,nx=/^(https?:\/\/[^\s<]+[^<.,:;"')\]\s])/,rx=/^<([^ >]+@[^ >]+)>/,ix=/^<([^ >]+:\/[^ >]+)>/,ox=/-([a-z])?/gi,Xd=/^(\|.*)\n(?: *(\|? *[-:]+ *\|[-| :]*)\n((?:.*\|.*\n)*))?\n?/,ax=/^[^\n]+(?:  \n|\n{2,})/,sx=/^\[([^\]]*)\]:\s+<?([^\s>]+)>?\s*("([^"]*)")?/,lx=/^!\[([^\]]*)\] ?\[([^\]]*)\]/,cx=/^\[([^\]]*)\] ?\[([^\]]*)\]/,ux=/(\n|^[-*]\s|^#|^ {2,}|^-{2,}|^>\s)/,fx=/\t/g,dx=/(^ *\||\| *$)/g,px=/^ *:-+: *$/,gx=/^ *:-+ *$/,hx=/^ *-+: *$/,Go="((?:\\[.*?\\][([].*?[)\\]]|<.*?>(?:.*?<.*?>)?|`.*?`|\\\\\\1|[\\s\\S])+?)",mx=RegExp(`^([*_])\\1${Go}\\1\\1(?!\\1)`),_x=RegExp(`^([*_])${Go}\\1(?!\\1)`),yx=RegExp(`^(==)${Go}\\1`),vx=RegExp(`^(~~)${Go}\\1`),xx=/^(:[a-zA-Z0-9-_]+:)/,bx=/^\\([^0-9A-Za-z\s])/,Sx=/\\([^0-9A-Za-z\s])/g,Cx=/^[\s\S](?:(?!  \n|[0-9]\.|http)[^=*_~\-\n:<`\\\[!])*/,wx=/^\n+/,Tx=/^([ \t]*)/,Ex=/(?:^|\n)( *)$/,Xs="(?:\\d+\\.)",Hs="(?:[*+-])";function Qd(n){return"( *)("+(n===1?Xs:Hs)+") +"}var Jd=Qd(1),ep=Qd(2);function tp(n){return RegExp("^"+(n===1?Jd:ep))}var Ix=tp(1),Ax=tp(2);function np(n){return RegExp("^"+(n===1?Jd:ep)+"[^\\n]*(?:\\n(?!\\1"+(n===1?Xs:Hs)+" )[^\\n]*)*(\\n|$)","gm")}var Lx=np(1),Ox=np(2);function rp(n){let o=n===1?Xs:Hs;return RegExp("^( *)("+o+") [\\s\\S]+?(?:\\n{2,}(?! )(?!\\1"+o+" (?!"+o+" ))\\n*|\\s*\\n*$)")}var ip=rp(1),op=rp(2);function Hd(n,o){let a=o===1,f=a?ip:op,p=a?Lx:Ox,m=a?Ix:Ax;return{t:x=>m.test(x),o:hr(function(x,S){let I=Ex.exec(S.prevCapture);return I&&(S.list||!S.inline&&!S.simple)?f.exec(x=I[1]+x):null}),i:1,u(x,S,I){let k=a?+x[2]:void 0,V=x[0].replace(Gv,`
`).match(p),U=!1;return{items:V.map(function(B,z){let N=m.exec(B)[0].length,R=RegExp("^ {1,"+N+"}","gm"),K=B.replace(R,"").replace(m,""),c=z===V.length-1,h=K.indexOf(`

`)!==-1||c&&U;U=h;let y=I.inline,O=I.list,P;I.list=!0,h?(I.inline=!1,P=oi(K)+`

`):(I.inline=!0,P=oi(K));let q=S(P,I);return I.inline=y,I.list=O,q}),ordered:a,start:k}},l:(x,S,I)=>n(x.ordered?"ol":"ul",{key:I.key,start:x.type==="20"?x.start:void 0},x.items.map(function(k,V){return n("li",{key:V},S(k,I))}))}}var Nx=RegExp(`^\\[((?:\\[[^\\[\\]]*(?:\\[[^\\[\\]]*\\][^\\[\\]]*)*\\]|[^\\[\\]])*)\\]\\(\\s*<?((?:\\([^)]*\\)|[^\\s\\\\]|\\\\.)*?)>?(?:\\s+['"]([\\s\\S]*?)['"])?\\s*\\)`),Rx=/^!\[(.*?)\]\( *((?:\([^)]*\)|[^() ])*) *"?([^)"]*)?"?\)/;function oi(n){let o=n.length;for(;o>0&&n[o-1]<=" ";)o--;return n.slice(0,o)}function Uo(n,o){return n.startsWith(o)}function kx(n,o,a){if(Array.isArray(a)){for(let f=0;f<a.length;f++)if(Uo(n,a[f]))return!0;return!1}return a(n,o)}function ii(n){return n.replace(/[ÀÁÂÃÄÅàáâãäåæÆ]/g,"a").replace(/[çÇ]/g,"c").replace(/[ðÐ]/g,"d").replace(/[ÈÉÊËéèêë]/g,"e").replace(/[ÏïÎîÍíÌì]/g,"i").replace(/[Ññ]/g,"n").replace(/[øØœŒÕõÔôÓóÒò]/g,"o").replace(/[ÜüÛûÚúÙù]/g,"u").replace(/[ŸÿÝý]/g,"y").replace(/[^a-z0-9- ]/gi,"").replace(/ /gi,"-").toLowerCase()}function Px(n){return hx.test(n)?"right":px.test(n)?"center":gx.test(n)?"left":null}function Zd(n,o,a,f){let p=a.inTable;a.inTable=!0;let m=[[]],x="";function S(){if(!x)return;let I=m[m.length-1];I.push.apply(I,o(x,a)),x=""}return n.trim().split(/(`[^`]*`|\\\||\|)/).filter(Boolean).forEach((I,k,V)=>{I.trim()==="|"&&(S(),f)?k!==0&&k!==V.length-1&&m.push([]):x+=I}),S(),a.inTable=p,m}function Mx(n,o,a){a.inline=!0;let f=n[2]?n[2].replace(dx,"").split("|").map(Px):[],p=n[3]?function(x,S,I){return x.trim().split(`
`).map(function(k){return Zd(k,S,I,!0)})}(n[3],o,a):[],m=Zd(n[1],o,a,!!p.length);return a.inline=!1,p.length?{align:f,cells:p,header:m,type:"25"}:{children:m,type:"21"}}function jd(n,o){return n.align[o]==null?{}:{textAlign:n.align[o]}}function hr(n){return n.inline=1,n}function yn(n){return hr(function(o,a){return a.inline?n.exec(o):null})}function vn(n){return hr(function(o,a){return a.inline||a.simple?n.exec(o):null})}function Zt(n){return function(o,a){return a.inline||a.simple?null:n.exec(o)}}function Do(n){return hr(function(o){return n.exec(o)})}var Dx=/(javascript|vbscript|data(?!:image)):/i;function Ux(n){try{let o=decodeURIComponent(n).replace(/[^A-Za-z0-9/:]/g,"");if(Dx.test(o))return null}catch{return null}return n}function Ut(n){return n&&n.replace(Sx,"$1")}function Bo(n,o,a){let f=a.inline||!1,p=a.simple||!1;a.inline=!0,a.simple=!0;let m=n(o,a);return a.inline=f,a.simple=p,m}function Bx(n,o,a){let f=a.inline||!1,p=a.simple||!1;a.inline=!1,a.simple=!0;let m=n(o,a);return a.inline=f,a.simple=p,m}function Fx(n,o,a){let f=a.inline||!1;a.inline=!1;let p=n(o,a);return a.inline=f,p}var Vs=(n,o,a)=>({children:Bo(o,n[2],a)});function Ys(){return{}}function Ks(){return null}function Gx(...n){return n.filter(Boolean).join(" ")}function qs(n,o,a){let f=n,p=o.split(".");for(;p.length&&(f=f[p[0]],f!==void 0);)p.shift();return f||a}function Wx(n="",o={}){o.overrides=o.overrides||{},o.namedCodesToUnicode=o.namedCodesToUnicode?Un({},Gd,o.namedCodesToUnicode):Gd;let a=o.slugify||ii,f=o.sanitizer||Ux,p=o.createElement||Fo.createElement,m=[Wd,$d,zd,o.enforceAtxHeadings?Yd:Vd,Kd,Xd,ip,op],x=[...m,ax,$s,qd,zs];function S(c,h,...y){let O=qs(o.overrides,c+".props",{});return p(function(P,q){let G=qs(q,P);return G?typeof G=="function"||typeof G=="object"&&"render"in G?G:qs(q,P+".component",P):P}(c,o.overrides),Un({},h,O,{className:Gx(h?.className,O.className)||void 0}),...y)}function I(c){c=c.replace(jv,"");let h=!1;o.forceInline?h=!0:o.forceBlock||(h=ux.test(c)===!1);let y=N(z(h?c:oi(c).replace(wx,"")+`

`,{inline:h}));for(;typeof y[y.length-1]=="string"&&!y[y.length-1].trim();)y.pop();if(o.wrapper===null)return y;let O=o.wrapper||(h?"span":"div"),P;if(y.length>1||o.forceWrapper)P=y;else{if(y.length===1)return P=y[0],typeof P=="string"?S("span",{key:"outer"},P):P;P=null}return p(O,{key:"outer"},P)}function k(c,h){if(!h||!h.trim())return null;let y=h.match(Bv);return y?y.reduce(function(O,P){let q=P.indexOf("=");if(q!==-1){let G=function(Q){return Q.indexOf("-")!==-1&&Q.match(ex)===null&&(Q=Q.replace(ox,function(ve,Ie){return Ie.toUpperCase()})),Q}(P.slice(0,q)).trim(),Se=function(Q){let ve=Q[0];return(ve==='"'||ve==="'")&&Q.length>=2&&Q[Q.length-1]===ve?Q.slice(1,-1):Q}(P.slice(q+1).trim()),ge=Fd[G]||G;if(ge==="ref")return O;let pe=O[ge]=function(Q,ve,Ie,en){return ve==="style"?function(De){let ze=[],Bt="",pt=!1,Ke=!1,yr="";if(!De)return ze;for(let Ft=0;Ft<De.length;Ft++){let Ge=De[Ft];if(Ge!=='"'&&Ge!=="'"||pt||(Ke?Ge===yr&&(Ke=!1,yr=""):(Ke=!0,yr=Ge)),Ge==="("&&Bt.endsWith("url")?pt=!0:Ge===")"&&pt&&(pt=!1),Ge!==";"||Ke||pt)Bt+=Ge;else{let Et=Bt.trim();if(Et){let vr=Et.indexOf(":");if(vr>0){let Sn=Et.slice(0,vr).trim(),Cn=Et.slice(vr+1).trim();ze.push([Sn,Cn])}}Bt=""}}let Wn=Bt.trim();if(Wn){let Ft=Wn.indexOf(":");if(Ft>0){let Ge=Wn.slice(0,Ft).trim(),Et=Wn.slice(Ft+1).trim();ze.push([Ge,Et])}}return ze}(Ie).reduce(function(De,[ze,Bt]){return De[ze.replace(/(-[a-z])/g,pt=>pt[1].toUpperCase())]=en(Bt,Q,ze),De},{}):Uv.indexOf(ve)!==-1?en(Ut(Ie),Q,ve):(Ie.match(tx)&&(Ie=Ut(Ie.slice(1,Ie.length-1))),Ie==="true"||Ie!=="false"&&Ie)}(c,G,Se,f);typeof pe=="string"&&($s.test(pe)||zs.test(pe))&&(O[ge]=I(pe.trim()))}else P!=="style"&&(O[Fd[P]||P]=!0);return O},{}):null}let V=[],U={},B={0:{t:[">"],o:Zt(Wd),i:1,u(c,h,y){let[,O,P]=c[0].replace(Wv,"").match($v);return{alert:O,children:h(P,y)}},l(c,h,y){let O={key:y.key};return c.alert&&(O.className="markdown-alert-"+a(c.alert.toLowerCase(),ii),c.children.unshift({attrs:{},children:[{type:"27",text:c.alert}],noInnerParse:!0,type:"11",tag:"header"})),S("blockquote",O,h(c.children,y))}},1:{o:Do(zv),i:1,u:Ys,l:(c,h,y)=>S("br",{key:y.key})},2:{t:c=>{let h=c[0];return h==="-"||h==="*"||h==="_"},o:Zt(Vv),i:1,u:Ys,l:(c,h,y)=>S("hr",{key:y.key})},3:{t:["    "],o:Zt(zd),i:0,u:c=>({lang:void 0,text:Ut(oi(c[0].replace(/^ {4}/gm,"")))}),l:(c,h,y)=>S("pre",{key:y.key},S("code",Un({},c.attrs,{className:c.lang?"lang-"+c.lang:""}),c.text))},4:{t:["```","~~~"],o:Zt($d),i:0,u:c=>({attrs:k("code",c[3]||""),lang:c[2]||void 0,text:c[4],type:"3"})},5:{t:["`"],o:vn(Yv),i:3,u:c=>({text:Ut(c[2])}),l:(c,h,y)=>S("code",{key:y.key},c.text)},6:{t:["[^"],o:Zt(Xv),i:0,u:c=>(V.push({footnote:c[2],identifier:c[1]}),{}),l:Ks},7:{t:["[^"],o:yn(Hv),i:1,u:c=>({target:"#"+a(c[1],ii),text:c[1]}),l:(c,h,y)=>S("a",{key:y.key,href:f(c.target,"a","href")},S("sup",{key:y.key},c.text))},8:{t:["[ ]","[x]"],o:yn(Qv),i:1,u:c=>({completed:c[1].toLowerCase()==="x"}),l:(c,h,y)=>S("input",{checked:c.completed,key:y.key,readOnly:!0,type:"checkbox"})},9:{t:["#"],o:Zt(o.enforceAtxHeadings?Yd:Vd),i:1,u:(c,h,y)=>({children:Bo(h,c[2],y),id:a(c[2],ii),level:c[1].length}),l:(c,h,y)=>S("h"+c.level,{id:c.id,key:y.key},h(c.children,y))},10:{o:Zt(Kd),i:0,u:(c,h,y)=>({children:Bo(h,c[1],y),level:c[2]==="="?1:2,type:"9"})},11:{t:["<"],o:Do($s),i:1,u(c,h,y){let[,O]=c[3].match(Tx),P=RegExp("^"+O,"gm"),q=c[3].replace(P,""),G=(Se=q,x.some(Ie=>Ie.test(Se))?Fx:Bo);var Se;let ge=c[1].toLowerCase(),pe=Dv.indexOf(ge)!==-1,Q=(pe?ge:c[1]).trim(),ve={attrs:k(Q,c[2]),noInnerParse:pe,tag:Q};if(y.inAnchor=y.inAnchor||ge==="a",pe)ve.text=c[3];else{let Ie=y.inHTML;y.inHTML=!0,ve.children=G(h,q,y),y.inHTML=Ie}return y.inAnchor=!1,ve},l:(c,h,y)=>S(c.tag,Un({key:y.key},c.attrs),c.text||(c.children?h(c.children,y):""))},13:{t:["<"],o:Do(zs),i:1,u(c){let h=c[1].trim();return{attrs:k(h,c[2]||""),tag:h}},l:(c,h,y)=>S(c.tag,Un({},c.attrs,{key:y.key}))},12:{t:["<!--"],o:Do(qd),i:1,u:()=>({}),l:Ks},14:{t:["!["],o:vn(Rx),i:1,u:c=>({alt:Ut(c[1]),target:Ut(c[2]),title:Ut(c[3])}),l:(c,h,y)=>S("img",{key:y.key,alt:c.alt||void 0,title:c.title||void 0,src:f(c.target,"img","src")})},15:{t:["["],o:yn(Nx),i:3,u:(c,h,y)=>({children:Bx(h,c[1],y),target:Ut(c[2]),title:Ut(c[3])}),l:(c,h,y)=>S("a",{key:y.key,href:f(c.target,"a","href"),title:c.title},h(c.children,y))},16:{t:["<"],o:yn(ix),i:0,u:c=>({children:[{text:c[1],type:"27"}],target:c[1],type:"15"})},17:{t:(c,h)=>!h.inAnchor&&!o.disableAutoLink&&(Uo(c,"http://")||Uo(c,"https://")),o:yn(nx),i:0,u:c=>({children:[{text:c[1],type:"27"}],target:c[1],title:void 0,type:"15"})},18:{t:["<"],o:yn(rx),i:0,u(c){let h=c[1],y=c[1];return Fv.test(y)||(y="mailto:"+y),{children:[{text:h.replace("mailto:",""),type:"27"}],target:y,type:"15"}}},20:Hd(S,1),33:Hd(S,2),19:{o:Zt(Kv),i:3,u:Ys,l:()=>`
`},21:{o:hr(function(c,h){if(h.inline||h.simple||h.inHTML&&c.indexOf(`

`)===-1&&h.prevCapture.indexOf(`

`)===-1)return null;let y="";c.split(`
`).every(P=>(P+=`
`,!m.some(q=>q.test(P))&&(y+=P,!!P.trim())));let O=oi(y);return O===""?null:[y,,O]}),i:3,u:Vs,l:(c,h,y)=>S("p",{key:y.key},h(c.children,y))},22:{t:["["],o:yn(sx),i:0,u:c=>(U[c[1]]={target:c[2],title:c[4]},{}),l:Ks},23:{t:["!["],o:vn(lx),i:0,u:c=>({alt:c[1]?Ut(c[1]):void 0,ref:c[2]}),l:(c,h,y)=>U[c.ref]?S("img",{key:y.key,alt:c.alt,src:f(U[c.ref].target,"img","src"),title:U[c.ref].title}):null},24:{t:c=>c[0]==="["&&c.indexOf("](")===-1,o:yn(cx),i:0,u:(c,h,y)=>({children:h(c[1],y),fallbackChildren:c[0],ref:c[2]}),l:(c,h,y)=>U[c.ref]?S("a",{key:y.key,href:f(U[c.ref].target,"a","href"),title:U[c.ref].title},h(c.children,y)):S("span",{key:y.key},c.fallbackChildren)},25:{t:["|"],o:Zt(Xd),i:1,u:Mx,l(c,h,y){let O=c;return S("table",{key:y.key},S("thead",null,S("tr",null,O.header.map(function(P,q){return S("th",{key:q,style:jd(O,q)},h(P,y))}))),S("tbody",null,O.cells.map(function(P,q){return S("tr",{key:q},P.map(function(G,Se){return S("td",{key:Se,style:jd(O,Se)},h(G,y))}))})))}},27:{o:hr(function(c,h){let y;return Uo(c,":")&&(y=xx.exec(c)),y||Cx.exec(c)}),i:4,u(c){let h=c[0];return{text:h.indexOf("&")===-1?h:h.replace(Jv,(y,O)=>o.namedCodesToUnicode[O]||y)}},l:c=>c.text},28:{t:["**","__"],o:vn(mx),i:2,u:(c,h,y)=>({children:h(c[2],y)}),l:(c,h,y)=>S("strong",{key:y.key},h(c.children,y))},29:{t:c=>{let h=c[0];return(h==="*"||h==="_")&&c[1]!==h},o:vn(_x),i:3,u:(c,h,y)=>({children:h(c[2],y)}),l:(c,h,y)=>S("em",{key:y.key},h(c.children,y))},30:{t:["\\"],o:vn(bx),i:1,u:c=>({text:c[1],type:"27"})},31:{t:["=="],o:vn(yx),i:3,u:Vs,l:(c,h,y)=>S("mark",{key:y.key},h(c.children,y))},32:{t:["~~"],o:vn(vx),i:3,u:Vs,l:(c,h,y)=>S("del",{key:y.key},h(c.children,y))}};o.disableParsingRawHTML===!0&&(delete B[11],delete B[13]);let z=function(c){var h=Object.keys(c);function y(O,P){var q=[];if(P.prevCapture=P.prevCapture||"",O.trim())for(;O;)for(var G=0;G<h.length;){var Se=h[G],ge=c[Se];if(!ge.t||kx(O,P,ge.t)){var pe=ge.o(O,P);if(pe&&pe[0]){O=O.substring(pe[0].length);var Q=ge.u(pe,y,P);P.prevCapture+=pe[0],Q.type||(Q.type=Se),q.push(Q);break}G++}else G++}return P.prevCapture="",q}return h.sort(function(O,P){return c[O].i-c[P].i||(O<P?-1:1)}),function(O,P){return y(function(q){return q.replace(qv,`
`).replace(Zv,"").replace(fx,"    ")}(O),P)}}(B),N=(R=function(c,h){return function(y,O,P){let q=c[y.type].l;return h?h(()=>q(y,O,P),y,O,P):q(y,O,P)}}(B,o.renderRule),function c(h,y={}){if(Array.isArray(h)){let O=y.key,P=[],q=!1;for(let G=0;G<h.length;G++){y.key=G;let Se=c(h[G],y),ge=typeof Se=="string";ge&&q?P[P.length-1]+=Se:Se!==null&&P.push(Se),q=ge}return y.key=O,P}return R(h,c,y)});var R;let K=I(n);return V.length?S("div",null,K,S("footer",{key:"footer"},V.map(function(c){return S("div",{id:a(c.identifier,ii),key:c.identifier},c.identifier,N(z(c.footnote,{inline:!0})))}))):K}var ap=n=>{let{children:o="",options:a}=n,f=function(p,m){if(p==null)return{};var x,S,I={},k=Object.keys(p);for(S=0;S<k.length;S++)m.indexOf(x=k[S])>=0||(I[x]=p[x]);return I}(n,Mv);return Fo.cloneElement(Wx(o,a),f)};var $x=be("StreamingMarkdown"),zx=M.div`
  width: 100%;
  color: #ffffff; /* equivalent to text.primary in light mode */
  text-align: left;
`,Vx=M.h1`
  color: #ffffff;
  font-size: 24px; /* heading-2 */
  font-weight: 700;
  line-height: 32px;
  letter-spacing: -0.0225rem;
  margin: 0 0 16px 0;
  &:first-child {
    margin-top: 0;
  }
`,Yx=M.h2`
  color: #ffffff;
  font-size: 20px; /* heading-3 */
  font-weight: 700;
  line-height: 28px;
  letter-spacing: -0.0125rem;
  margin: 0 0 16px 0;
  &:first-child {
    margin-top: 0;
  }
`,Wo=M.h3`
  color: #ffffff;
  font-size: 18px; /* heading-4 */
  font-weight: 700;
  line-height: 24px;
  letter-spacing: -0.01125rem;
  margin: 0 0 16px 0;
  &:first-child {
    margin-top: 0;
  }
`,Kx=M(Wo)``,qx=M(Wo)``,Xx=M(Wo)``,Hx=M.p`
  color: #ffffff;
  font-size: 16px; /* body-5 */
  font-weight: 400;
  line-height: 24px;
  letter-spacing: -0.005rem;
  margin: 0 0 16px 0;
  &:first-child {
    margin-top: 0;
  }
  &:last-child {
    margin-bottom: 0;
  }
  &:is(li > p) {
    margin-top: 0;
    margin-bottom: 0;
  }
`,Zx=M.ul`
  color: #ffffff;
  font-size: 16px; /* body-5 */
  font-weight: 400;
  line-height: 24px;
  letter-spacing: -0.005rem;
  margin: 16px 0;
  padding-left: 20px;
  list-style-type: disc;

  &:first-child {
    margin-top: 0;
  }
  &:last-child {
    margin-bottom: 0;
  }
  &:is(li > ul) {
    margin-top: 0;
    margin-bottom: 0;
  }
`,jx=M.ol`
  color: #ffffff;
  font-size: 16px; /* body-5 */
  font-weight: 400;
  line-height: 24px;
  letter-spacing: -0.005rem;
  margin: 16px 0;
  padding-left: 20px;
  &:first-child {
    margin-top: 0;
  }
  &:last-child {
    margin-bottom: 0;
  }
  &:is(li > ol) {
    margin-top: 0;
    margin-bottom: 0;
  }
`,Qx=M.li`
  margin: 0;
`,Jx=M.strong`
  font-weight: bold;
`,eb=M.em`
  font-style: italic;
`,lp=(0,sp.forwardRef)(({content:n,className:o},a)=>{let f={overrides:{h1:Vx,h2:Yx,h3:Wo,h4:Kx,h5:qx,h6:Xx,p:Hx,ul:Zx,ol:jx,li:Qx,strong:Jx,em:eb}};return $x.debug("Rendering markdown",{contentLength:n.length}),d(zx,{ref:a,className:o},d(ap,{options:f},n))});w();C();var ui=we(Oe());w();C();var fp=we(cp());var jt=be("ClickToListen"),Vo=n=>n?n.replace(/(?<!\n)\n(?!\n)/g," "):"",tb=(n,o)=>{o=o.endsWith(".")?o.slice(0,-1):o;let a=Vo(n.textContent),f=Vo(o),p=a.indexOf(f);if(p===-1)return[];let m=p+f.length,x=oo(n,p,m);return Array.from(x.getClientRects())},nb=(n,o,a)=>{try{let m=(n.machine.getContext()?.queue||[]).find(U=>String(U.id)===o);if(!m)return jt.warn("Block not found in queue",{blockId:o}),null;let x=m.text,S=_s(x)||[];if(a>=S.length)return jt.warn("Sentence index out of bounds"),null;let I=0;for(let U=0;U<a;U++)I+=S[U].length;let k=S[a].length,V=I+k;return{start:I,end:V}}catch(f){return jt.error("Error calculating Orator sentence bounds",f),null}},rb=(n,o,a)=>{try{let f=oo(n,o,a),p=Array.from(f.getClientRects());if(p.length===0)return jt.warn("Range produced no rects, invalid bounds"),null;let m=p[0],x=n.getBoundingClientRect();if(o>10&&m.left<=x.left+5)for(let S=o;S<Math.min(o+20,a);S++){let I=oo(n,S,a),k=Array.from(I.getClientRects());if(k.length>0&&k[0].left>x.left+5)return[S,a]}return[o,a]}catch(f){return jt.error("Error validating range bounds",f),null}},Re={enabled:!0,blocks:[],hoveredElement:null,hoveredCursorPosition:null},wt={element:null,sentenceBounds:[]},{removeHighlights:js,highlightElement:ib}=ju("speechifyClickToPlay",{highlightColor:{sentence:{light:"rgba(255, 200, 100, 0.7)",dark:"rgba(204, 160, 80, 0.7)"},word:{light:"transparent",dark:"transparent"}}}),$o=null,zo=null,si=null,li=null,up=n=>n?(n.machine.getContext()?.queue||[]).filter(p=>{let m=p.ref;return m&&m.isConnected&&m instanceof HTMLElement}).map(p=>{let m=_s(p.text)||[];return{id:p.id,ref:p.ref,sentences:m,text:p.text}}):[],Zs=()=>{wt.element&&delete wt.element.dataset.hoverHighlightActive,wt.element=null,wt.sentenceBounds=[],js(),Re.hoveredElement&&(Re.hoveredElement.style.cursor="default",Re.hoveredElement=null)},ob=(n,o)=>{Re.hoveredCursorPosition&&(o?.controls?.seekToPosition&&o.controls.seekToPosition(Re.hoveredCursorPosition.id,Re.hoveredCursorPosition.position),n.preventDefault(),n.stopPropagation())},ab=n=>(0,fp.throttle)(o=>{if(!Re.enabled){Zs();return}Re.hoveredCursorPosition=null,Re.hoveredElement&&(Re.hoveredElement.style.cursor="default",Re.hoveredElement=null),wt.element=null,wt.sentenceBounds=[];let a=document.elementFromPoint(o.clientX,o.clientY);if(!a)return;let f=Re.blocks.find(U=>U.ref===a||U.ref.contains(a));if(!f||!f.ref)return;let p=f.ref,m=f.sentences.findIndex(U=>!!tb(p,U).find(N=>o.clientX>N.x-4&&o.clientX<N.x+N.width+4&&o.clientY>N.y-4&&o.clientY<N.y+N.height+4));if(m===-1)return;Re.hoveredCursorPosition={id:f.id,position:[m,0]},p.style.cursor="pointer",Re.hoveredElement=p,wt.element=p;let x=nb(n,f.id,m);if(!x){jt.warn("❌ Could not get Orator sentence bounds, falling back to indexOf method");let U=Vo(f.sentences[m]),B=Vo(p.textContent),z=B.indexOf(U);if(z===-1&&(z=B.indexOf(U.slice(0,-1))),z===-1){jt.warn("❌ Sentence not found in textContent, skipping highlight");return}x={start:z,end:Math.min(B.length,z+U.length)}}let{start:S,end:I}=x,k=p.textContent?.length||0;if(S<0||I<=S||S>=k){jt.warn("❌ Invalid sentence bounds, skipping highlight");return}if(js(),!rb(p,S,I)){jt.warn("❌ Could not create valid range bounds, skipping highlight");return}wt.sentenceBounds=[S,I],Re.hoveredElement?.addEventListener("mouseleave",Zs,{once:!0})},32),sb=()=>{let n=()=>{if(wt.element){let{element:o,sentenceBounds:a}=wt;wt.element.dataset.hoverHighlightActive||(wt.element.dataset.hoverHighlightActive="true"),js(),ib(o,[o],[a[0],a[1]],[a[0],a[1]],{rectOnly:!1})}$o=requestAnimationFrame(n)};n()},dp=(n,o)=>{Re.enabled&&(Re.blocks=up(o),zo=o.machine.onContextChange("queue",()=>{Re.blocks=up(o)}),si=ab(o),li=a=>{(window.getSelection()??"").toString().length>0||ob(a,o)},n.addEventListener("mousemove",si),n.addEventListener("pointerup",li,{capture:!0}),sb())},Qs=n=>{si&&(n.removeEventListener("mousemove",si),si=null),li&&(n.removeEventListener("pointerup",li,{capture:!0}),li=null),zo&&(zo(),zo=null),Zs(),$o&&(cancelAnimationFrame($o),$o=null),Re.blocks=[],Re.hoveredElement=null,Re.hoveredCursorPosition=null};w();C();var dt=we(Oe());w();C();w();C();var me=be("DOMTraverser"),Yo=class{container;options;intervalTimer=null;readyQueue=[];pendingNodes=[];yieldedNodes=new WeakSet;nodeIndex=0;isCompleted=!1;isDisposed=!1;pendingResolvers=[];constructor(o,a={}){this.container=o,this.options={nodeTypes:a.nodeTypes??["p:not(li>p)","h1","h2","h3","h4","h5","h6","li:not(li:has(>ul,ol))","li>p:is(li:has(>ul,ol)>p)"],intervalMs:a.intervalMs??200,yieldExistingNodes:a.yieldExistingNodes??!0},me.debug("DOMTraverser created for container:",{tagName:o.tagName,nodeTypes:this.options.nodeTypes,intervalMs:this.options.intervalMs,yieldExisting:this.options.yieldExistingNodes})}async*traverse(){if(this.isDisposed){me.warn("Cannot traverse: DOMTraverser has been disposed");return}me.info("Starting DOM traversal...");try{for(this.initIntervalCheck(),this.options.yieldExistingNodes&&(yield*this.yieldExistingNodes()),this.isCompleted&&this.markAllPendingNodesAsReady();!this.isDisposed&&(this.readyQueue.length>0||!this.isCompleted);){if(this.isDisposed){me.debug("Traversal stopped: DOMTraverser was disposed");break}if(this.readyQueue.length>0){let o=this.readyQueue.shift();me.debug("Yielding ready node:",{nodeType:o.nodeType,index:o.index,textPreview:o.element.textContent?.substring(0,50)}),yield o}else this.isCompleted||await this.waitForNextNode()}}finally{this.dispose()}me.info("DOM traversal completed")}complete(){if(this.isDisposed){me.warn("Cannot complete: DOMTraverser has been disposed");return}me.info("DOM traversal marked as complete"),this.isCompleted=!0,this.markAllPendingNodesAsReady(),this.resolvePendingPromises()}get disposed(){return this.isDisposed}get completed(){return this.isCompleted}get queueLength(){return this.isDisposed?0:this.readyQueue.length}get pendingNodeCount(){return this.isDisposed?0:this.pendingNodes.length}get nodeCount(){return this.nodeIndex}getStats(){return{disposed:this.isDisposed,completed:this.isCompleted,readyQueueLength:this.isDisposed?0:this.readyQueue.length,pendingNodeCount:this.isDisposed?0:this.pendingNodes.length,nodeCount:this.nodeIndex,pendingResolvers:this.pendingResolvers.length,hasIntervalTimer:this.intervalTimer!==null,hasContainer:this.container!==null}}cleanup(){this.dispose()}dispose(){if(this.isDisposed){me.debug("DOMTraverser already disposed");return}me.info("Disposing DOMTraverser resources..."),this.isDisposed=!0,this.isCompleted=!0,this.intervalTimer&&(clearInterval(this.intervalTimer),this.intervalTimer=null,me.debug("Interval timer cleared"));let o=this.readyQueue.length,a=this.pendingNodes.length,f=o+a;this.readyQueue.length=0,this.readyQueue=[],this.pendingNodes.length=0,this.pendingNodes=[],f>0&&me.debug(`Cleared ${f} nodes (${o} ready, ${a} pending)`);let p=this.pendingResolvers.length;this.resolvePendingPromisesWithCompletion(),p>0&&me.debug(`Resolved ${p} pending promises`),this.container=null,this.nodeIndex=0,this.yieldedNodes=new WeakSet,me.info("DOMTraverser disposal completed - all resources cleaned up")}initIntervalCheck(){if(this.isDisposed||!this.container){me.warn("Cannot initialize interval checker: DOMTraverser disposed or no container");return}this.intervalTimer=setInterval(()=>{this.isDisposed||this.checkForNewNodes()},this.options.intervalMs),me.debug(`Interval checker initialized with ${this.options.intervalMs}ms interval`)}checkForNewNodes(){if(this.isDisposed||this.isCompleted||!this.container){me.debug("Skipping node check: disposed, completed, or no container");return}let o=this.findTraversableNodes(this.container);o.length>0&&(me.debug(`Found ${o.length} new traversable nodes`),this.addNodesToQueue(o))}*yieldExistingNodes(){if(this.isDisposed||!this.container){me.debug("Cannot yield existing nodes: disposed or no container");return}let o=this.findTraversableNodes(this.container);for(me.debug(`Found ${o.length} existing traversable nodes`),o.length>0&&this.addNodesToQueue(o,!0);this.readyQueue.length>0;)yield this.readyQueue.shift()}findTraversableNodes(o){if(this.isDisposed)return[];let a=this.options.nodeTypes.join(", ");return Array.from(o.querySelectorAll(a)).filter(p=>!this.yieldedNodes.has(p))}isTraversableNode(o){let a=o.tagName.toLowerCase();return this.options.nodeTypes.includes(a)}addNodesToQueue(o,a=!1){if(this.isDisposed){me.debug("Cannot add nodes to queue: disposed");return}if(this.isCompleted&&!a){me.debug("Cannot add nodes to queue: completed");return}for(let f=this.pendingNodes.length-1;f>=0;f--){let p=this.pendingNodes[f];p.element.isConnected||(this.pendingNodes.splice(f,1),me.debug(`Removed disconnected pending node: ${p.nodeType} (index: ${p.index})`))}for(let f of o){if(this.isDisposed){me.debug("Stopping node queue addition: disposed");break}let p=f.textContent?.trim().replace(/^[*#]*\s?/,"").trim()??"";if(!this.yieldedNodes.has(f)&&p.length>0){this.markLastPendingNodeAsReady();let m=this.createTraversedNode(f);this.pendingNodes.push(m),me.debug(`Added node to pending queue: ${m.nodeType} (index: ${m.index})`,m.element.textContent)}}this.resolvePendingPromises()}createTraversedNode(o){return this.yieldedNodes.add(o),{element:o,nodeType:o.tagName.toLowerCase(),index:this.nodeIndex++}}waitForNextNode(){return new Promise(o=>{this.pendingResolvers.push(()=>{o()})})}resolvePendingPromises(){if(this.pendingResolvers.length===0)return;let o=[...this.pendingResolvers];this.pendingResolvers.length=0;for(let a of o)a({done:!1,value:void 0})}resolvePendingPromisesWithCompletion(){if(this.pendingResolvers.length===0)return;let o=[...this.pendingResolvers];this.pendingResolvers.length=0;for(let a of o)a({done:!0,value:void 0})}markLastPendingNodeAsReady(){if(this.pendingNodes.length>0){let o=this.pendingNodes.shift();this.readyQueue.push(o),me.debug(`Marked node as ready: ${o.nodeType} (index: ${o.index})`)}}markAllPendingNodesAsReady(){if(this.pendingNodes.length===0)return;let o=this.pendingNodes.length;for(;this.pendingNodes.length>0;){let a=this.pendingNodes.shift();this.readyQueue.push(a)}me.debug(`Marked ${o} pending nodes as ready (streaming complete)`)}};function Js(n,o){return new Yo(n,o)}w();C();w();C();w();C();function el(n){return Math.round(n*200)}w();C();function pp(n){try{return new URL(n).hostname}catch{return n}}var lb=()=>`${crypto.randomUUID()}_${Date.now()}`;async function cb(){let{voice:n,playbackSpeed:o}=await io(),a=Ku.getInstance().getCurrentTab();return{sessionId:lb(),stats:{wordsListened:0,charactersListened:0},listeningSettings:{initial:{voiceName:n.name,voiceSpeed:el(o)},current:{voiceName:n.name,voiceSpeed:el(o)}},voiceId:n.slug||n.name.toLowerCase(),contentLanguage:"und",contentType:"summary",contentSource:"sidepanel",contentName:a?.title||"Unknown",contentHostname:pp(a?.url??""),appPlatform:"desktop_extension",appVersion:F.runtime.getManifest().version}}function ub(n,o){let a=o.machine.getContext(),f=a.playbackRate,p=a.queue[a.playbackCursorIndex]?.voice.voiceId??n.listeningSettings.initial.voiceName;n.listeningSettings.current.voiceSpeed=f,n.listeningSettings.current.voiceName=p}async function fb(n){await Je("Listening Started",{app_platform:n.appPlatform,app_version:n.appVersion,voice_id:n.voiceId,session_id:n.sessionId,content_hostname:n.contentHostname,content_name:n.contentName,content_type:n.contentType,content_source:n.contentSource,voice_name_initial:n.listeningSettings.initial.voiceName,voice_speed_initial:n.listeningSettings.initial.voiceSpeed})}async function db(n){await Je("Text Listened",{app_platform:n.appPlatform,app_version:n.appVersion,voice_id:n.voiceId,session_id:n.sessionId,characters:n.stats.charactersListened,speed:n.listeningSettings.current.voiceSpeed,words:n.stats.wordsListened})}async function pb(n){await Je("Listening Finished",{app_platform:n.appPlatform,app_version:n.appVersion,voice_id:n.voiceId,session_id:n.sessionId,content_hostname:n.contentHostname,content_name:n.contentName,content_type:n.contentType,content_source:n.contentSource,content_language:n.contentLanguage,words:n.stats.wordsListened,characters:n.stats.charactersListened,voice_name_final:n.listeningSettings.current.voiceName,voice_speed_final:n.listeningSettings.current.voiceSpeed,voice_name_initial:n.listeningSettings.initial.voiceName,voice_speed_initial:n.listeningSettings.initial.voiceSpeed})}function gb(n,o){return o[1]!==n[1]||o[0]!==n[0]&&o[1]===0}function hb(n,o){if(!o)return;n.stats.wordsListened++;let a=o.wordCharIndex.end-o.wordCharIndex.start;n.stats.charactersListened+=a}function mb(n,o){return n.machine.onContextChange("currentPlaybackLocation",(a,f)=>{let p=o();if(!p||!f.currentPlaybackLocation||!a.currentPlaybackLocation)return;let m=a.currentPlaybackLocation.position,x=f.currentPlaybackLocation.position;gb(m,x)&&hb(p,a.currentPlaybackLocation)})}async function _b(n){n.current=await cb(),n.current.listeningSettings.current.voiceName&&await fb(n.current)}async function yb(n){n.current&&(await db(n.current),await pb(n.current),n.current=null)}var hp=async n=>{if(!n)return()=>{};let o={current:null},a=null,f=()=>{a&&a(),a=mb(n,()=>o.current)},p=()=>{a&&(a(),a=null)},m=(S,I)=>{let k=S!=="playing"&&I==="playing",V=S==="playing"&&(I==="paused"||I==="ended");if(k){if(o.current)return;_b(o).then(()=>{f()})}else if(V){if(!o.current)return;ub(o.current,n),yb(o).then(()=>{p()})}},x=n.machine.onStateChange(m);return()=>{x(),p(),o.current=null}};var mp=be("PlaybackQueue"),tl=null;function _p(n,{domMutationsCompleted:o,signal:a}){let f=(0,dt.useMemo)(()=>Js(n),[n]),[p,m]=(0,dt.useState)(!1),{orator:x}=ao(),S=(0,dt.useRef)(x);return(0,dt.useEffect)(()=>{o&&f.complete()},[f,o]),(0,dt.useEffect)(()=>(m(!1),()=>f.dispose()),[f]),(0,dt.useEffect)(()=>{let k=()=>f.dispose();return a.addEventListener("abort",k),()=>a.removeEventListener("abort",k)},[f,a]),(0,dt.useEffect)(()=>{let k=S.current;if(k)return()=>{k.controls.pause(),k.reset(),tl?.()}},[f]),{enqueueContent:(0,dt.useCallback)(async()=>{if(!x||p)return;x.reset(),tl?.(),m(!0);let{voice:k,playbackSpeed:V}=await io();tl=await hp(x);let U=k,B=V,z=Gr.subscribe(R=>{U=R.voice??k,B=R.playbackSpeed??V,x.controls.setSpeed(B),x.controls.setVoice(ys(U))});a.addEventListener("abort",z),x.controls.setSpeed(B);let N=f.traverse();return new Promise(R=>{let K=!1;(async()=>{for await(let h of N){if(mp.info("Traversed node",h,h.element,h.element.textContent),a.aborted){mp.info("Traversal aborted");break}let y=x.createPlayableFromElement(h.element,O=>{let P=O.textContent?.trim().replace(/^[*#]*\s?/,"")??"";return{id:String(h.index),text:P,ref:O,readyState:"not-ready",voice:ys(U)}});y.text.trim()&&(x.controls.enqueuePlayables([y]),K||(K=!0,R()))}a.removeEventListener("abort",z),z()})()})},[a,x,f,p]),contentEnqueued:p}}w();C();var Cp=we(Oe());w();C();w();C();w();C();w();C();function vb(n){var o=Object.create(null);return function(a){return o[a]===void 0&&(o[a]=n(a)),o[a]}}var yp=vb;var xb=/^((children|dangerouslySetInnerHTML|key|ref|autoFocus|defaultValue|defaultChecked|innerHTML|suppressContentEditableWarning|suppressHydrationWarning|valueLink|accept|acceptCharset|accessKey|action|allow|allowUserMedia|allowPaymentRequest|allowFullScreen|allowTransparency|alt|async|autoComplete|autoPlay|capture|cellPadding|cellSpacing|challenge|charSet|checked|cite|classID|className|cols|colSpan|content|contentEditable|contextMenu|controls|controlsList|coords|crossOrigin|data|dateTime|decoding|default|defer|dir|disabled|disablePictureInPicture|download|draggable|encType|enterKeyHint|form|formAction|formEncType|formMethod|formNoValidate|formTarget|frameBorder|headers|height|hidden|high|href|hrefLang|htmlFor|httpEquiv|id|inputMode|integrity|is|keyParams|keyType|kind|label|lang|list|loading|loop|low|marginHeight|marginWidth|max|maxLength|media|mediaGroup|method|min|minLength|multiple|muted|name|nonce|noValidate|open|optimum|pattern|placeholder|playsInline|poster|preload|profile|radioGroup|readOnly|referrerPolicy|rel|required|reversed|role|rows|rowSpan|sandbox|scope|scoped|scrolling|seamless|selected|shape|size|sizes|slot|span|spellCheck|src|srcDoc|srcLang|srcSet|start|step|style|summary|tabIndex|target|title|translate|type|useMap|value|width|wmode|wrap|about|datatype|inlist|prefix|property|resource|typeof|vocab|autoCapitalize|autoCorrect|autoSave|color|incremental|fallback|inert|itemProp|itemScope|itemType|itemID|itemRef|on|option|results|security|unselectable|accentHeight|accumulate|additive|alignmentBaseline|allowReorder|alphabetic|amplitude|arabicForm|ascent|attributeName|attributeType|autoReverse|azimuth|baseFrequency|baselineShift|baseProfile|bbox|begin|bias|by|calcMode|capHeight|clip|clipPathUnits|clipPath|clipRule|colorInterpolation|colorInterpolationFilters|colorProfile|colorRendering|contentScriptType|contentStyleType|cursor|cx|cy|d|decelerate|descent|diffuseConstant|direction|display|divisor|dominantBaseline|dur|dx|dy|edgeMode|elevation|enableBackground|end|exponent|externalResourcesRequired|fill|fillOpacity|fillRule|filter|filterRes|filterUnits|floodColor|floodOpacity|focusable|fontFamily|fontSize|fontSizeAdjust|fontStretch|fontStyle|fontVariant|fontWeight|format|from|fr|fx|fy|g1|g2|glyphName|glyphOrientationHorizontal|glyphOrientationVertical|glyphRef|gradientTransform|gradientUnits|hanging|horizAdvX|horizOriginX|ideographic|imageRendering|in|in2|intercept|k|k1|k2|k3|k4|kernelMatrix|kernelUnitLength|kerning|keyPoints|keySplines|keyTimes|lengthAdjust|letterSpacing|lightingColor|limitingConeAngle|local|markerEnd|markerMid|markerStart|markerHeight|markerUnits|markerWidth|mask|maskContentUnits|maskUnits|mathematical|mode|numOctaves|offset|opacity|operator|order|orient|orientation|origin|overflow|overlinePosition|overlineThickness|panose1|paintOrder|pathLength|patternContentUnits|patternTransform|patternUnits|pointerEvents|points|pointsAtX|pointsAtY|pointsAtZ|preserveAlpha|preserveAspectRatio|primitiveUnits|r|radius|refX|refY|renderingIntent|repeatCount|repeatDur|requiredExtensions|requiredFeatures|restart|result|rotate|rx|ry|scale|seed|shapeRendering|slope|spacing|specularConstant|specularExponent|speed|spreadMethod|startOffset|stdDeviation|stemh|stemv|stitchTiles|stopColor|stopOpacity|strikethroughPosition|strikethroughThickness|string|stroke|strokeDasharray|strokeDashoffset|strokeLinecap|strokeLinejoin|strokeMiterlimit|strokeOpacity|strokeWidth|surfaceScale|systemLanguage|tableValues|targetX|targetY|textAnchor|textDecoration|textRendering|textLength|to|transform|u1|u2|underlinePosition|underlineThickness|unicode|unicodeBidi|unicodeRange|unitsPerEm|vAlphabetic|vHanging|vIdeographic|vMathematical|values|vectorEffect|version|vertAdvY|vertOriginX|vertOriginY|viewBox|viewTarget|visibility|widths|wordSpacing|writingMode|x|xHeight|x1|x2|xChannelSelector|xlinkActuate|xlinkArcrole|xlinkHref|xlinkRole|xlinkShow|xlinkTitle|xlinkType|xmlBase|xmlns|xmlnsXlink|xmlLang|xmlSpace|y|y1|y2|yChannelSelector|z|zoomAndPan|for|class|autofocus)|(([Dd][Aa][Tt][Aa]|[Aa][Rr][Ii][Aa]|x)-.*))$/,bb=yp(function(n){return xb.test(n)||n.charCodeAt(0)===111&&n.charCodeAt(1)===110&&n.charCodeAt(2)<91}),vp=bb;w();C();function Sb(n){return`${n.join(";")};`}function Cb(n,o){return typeof n=="string"?n:o}function xp(n){return n.replace(/([a-z0-9]|(?=[A-Z]))([A-Z])/g,"$1-$2").toLowerCase()}function Bn(n){return o=>{let a=[];for(let f of n){if(Array.isArray(f)&&!o[f[0]]||typeof f=="string"&&!o[f])continue;if(!Array.isArray(f)){o[f]&&a.push(`${xp(f)}: ${o[f]}`);continue}let p=typeof f[1]=="function",m=typeof f[1]=="object";if(!(p||m))throw new TypeError(`Invalid options provided at key: ${f[0]}`);if(p&&a.push(f[1](o)),m){let x=f[1],S=x.property||xp(f[0]);x.default&&(o[f[0]]=Cb(o[f[0]],x.default)),typeof x.handler=="function"?a.push(x.handler(o)):a.push(`${S}: ${o[f[0]]}`)}}return Sb(a)}}var wb=Bn([["relative",()=>"position: relative"],"margin","padding","width","height"]),Fn=M("div",{shouldForwardProp:n=>vp(n)&&!["wrap"].includes(String(n))})`
  ${wb}
`;w();C();var bp="/* emotion-disable-server-rendering-unsafe-selector-warning-please-do-not-use-this-the-warning-exists-for-a-reason */",Tb=({column:n,separation:o})=>{let a=typeof o=="string",f=Array.isArray(o);if(!a&&!f)throw new Error("separation must be a string or string array");let p=(x,S)=>`
      > ${x} ${bp} {
        ${n?`margin-top: ${S}`:`margin-left: ${S}`};
        ${bp}
      }
    `,m=f?o:o.split(" ").filter(Boolean);if(m.length>1||f){let x=U=>U.startsWith("..."),S=m.filter(x);if(S.length>1)throw new Error("separation can only contain one rest operator");let I=m.findIndex(U=>x(U)),k=m.slice(0,I===-1?m.length:I),V=m.slice(I===-1?m.length:I+1);return[...S.map(U=>p("* + *",U.slice(3))),...V.map((U,B)=>p(`*:nth-last-child(${V.length-B})`,U)),...k.map((U,B)=>p(`*:first-child ${new Array(B+1).fill("+ *").join(" ")}`,U))].join(`
`)}return p("* + *",o)},Sp=(n,o)=>a=>o({...n,...a}),nl=Bn([["column",()=>"flex-direction: column"],["reverse",{handler:({column:n})=>`flex-direction: ${n?"column":"row"}-reverse`}],["align",{default:"center",handler:({align:n})=>`align-items: ${n}; justify-content: ${n}`}],["xAlign",{default:"center",handler:({column:n,xAlign:o})=>n?`align-items: ${o}`:`justify-content: ${o}`}],["yAlign",{default:"center",handler:({column:n,yAlign:o})=>n?`justify-content: ${o}`:`align-items: ${o}`}],["separation",Tb],["wrap",{default:"wrap",property:"flex-wrap"}]]),Eb=Sp({column:!1},nl),Ib=Sp({column:!0},nl),ci=M(Fn)`
  display: flex;
  ${nl}
`,Ab=M(Fn)`
  display: flex;
  ${Eb}
`,Lb=M(Fn)`
  display: flex;
  ${Ib}
`;w();C();var Ob=Bn([["columns",{property:"grid-template-columns"}],["rows",{property:"grid-template-rows"}],["autoColumns",{property:"grid-auto-columns"}],["autoRows",{property:"grid-auto-rows"}],["columnGap",{property:"grid-column-gap"}],["rowGap",{property:"grid-row-gap"}],["gap",{property:"grid-gap"}],["xAlign",{property:"justify-items",default:"center"}],["yAlign",{property:"align-items",default:"center"}],["align",{property:"place-items",default:"center center"}]]),Nb=M(Fn)`
  display: grid;
  ${Ob}
`;w();C();var Qt=we(Oe());var Rb=M.div`
  position: relative;
  display: inline-block;
`,kb=M.div`
  position: absolute;
  right: calc(100% + 8px); /* Position to the left of the button with 8px gap */
  top: 50%;
  transform: translateY(-50%);

  background-color: #d9d9d9;
  color: #000000;
  font-size: 0.75rem; /* 12px - body-7 */
  font-weight: 400;
  line-height: 1.33;
  letter-spacing: -0.00375rem;

  padding: 6px 12px 6px 8px; /* top/bottom 6px, left 8px, right 12px */
  border-radius: 4px;
  white-space: nowrap;

  /* Tooltip arrow pointing right (towards the button) */
  &::after {
    content: '';
    position: absolute;
    left: 100%;
    top: 50%;
    transform: translateY(-50%);
    border: 4px solid transparent;
    border-left-color: #d9d9d9;
  }

  /* Visibility and animation */
  visibility: ${({visible:n})=>n?"visible":"hidden"};
  opacity: ${({visible:n})=>n?1:0};
  transition: opacity 0.2s ease, visibility 0.2s ease;

  /* High z-index to ensure it appears above other elements */
  z-index: 1000;

  /* Prevent pointer events on the tooltip itself */
  pointer-events: none;
`;function Gn({children:n,text:o}){let[a,f]=Qt.default.useState(!1),p=Qt.default.useCallback(()=>{f(!0)},[]),m=Qt.default.useCallback(()=>{f(!1)},[]),x=Qt.default.useMemo(()=>{if((0,Qt.isValidElement)(n)){let S=n.props.onMouseEnter,I=n.props.onMouseLeave;return(0,Qt.cloneElement)(n,{onMouseEnter:k=>{p(),S?.(k)},onMouseLeave:k=>{m(),I?.(k)}})}return n},[n,p,m]);return d(Rb,null,x,d(kb,{visible:a},o))}var Pb=M(ci)`
  background: ${({disabled:n})=>n?"#747580":"#4759f7"};
  border-radius: 100px;
  cursor: ${({disabled:n})=>n?"not-allowed":"pointer"};

  &:hover {
    background: #4454e3;
    animation: none;
  }

  // change color to "Listen to email" text when hovered
  &:hover + span {
    color: ${hs.icnTxtPrimElectric};
  }

  &:active {
    background: #3d4ac4;
    animation: none;
  }

  outline: inherit;
  border: none;
  height: inherit;

  // handle keyboard navigation since we are removing outline
  &:focus-visible {
    outline: 1px solid ${hs.brdrPrimCta};
    border: 1px solid #fff;
  }
`,a4=M(ci)`
  font-size: 12px;
  font-style: normal;
  font-weight: 500;
  line-height: 12px;
  letter-spacing: 0.12px;
  color: #fff;
`,Mb=({isPlaying:n,isLoading:o,...a})=>{let f=(0,Cp.useMemo)(()=>o?"loading":n?"playing":"paused",[n,o]);return d(ci,{...a},f==="playing"&&d(ld,null),f==="loading"&&d(sd,null),f==="paused"&&d(Ns,null))};function wp({isLoading:n,isPlaying:o,isDisabled:a,onClick:f}){return d(Gn,{text:a?"Initializing...":o?"Pause":"Play"},d(Pb,{yAlign:!0,relative:!0,column:!1,onClick:m=>a?null:f(m),disabled:a},d(Mb,{size:"32",iconFill:"#fff",isLoading:n,isPlaying:o})))}function Tp({contentRoot:n,summaryCompleted:o}){let{orator:a}=ao(),f=ef(({state:k})=>k),p=(0,ui.useMemo)(()=>new AbortController,[n]),m=qu(),{enqueueContent:x,contentEnqueued:S}=_p(n,{domMutationsCompleted:o,signal:p.signal});return(0,ui.useEffect)(()=>()=>p.abort(),[p]),(0,ui.useEffect)(()=>(f==="playing"?dp(n,a):Qs(n),()=>{Qs(n)}),[f,n,a]),d("div",null,d(wp,{onClick:async()=>{f!=="playing"&&f!=="buffering"?(await m(),S||await x(),a.controls.play(),Je("extension_sidepanel_listen_btn_clicked",{action:"play"})):(a.controls.pause(),Je("extension_sidepanel_listen_btn_clicked",{action:"pause"}))},isPlaying:f==="playing",isLoading:f==="buffering",isDisabled:!a}))}w();C();var Jt=we(Oe());var _r=be("SummaryControls"),Db=M.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 12px;
  padding: 8px 0;
`,Ko=M.button`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 24px;
  height: 24px;
  border: none;
  border-radius: 6px;
  background: transparent;
  color: #9899a6;
  cursor: ${({disabled:n})=>n?"not-allowed":"pointer"};
  transition: color 0.2s ease;
  padding: 0;

  & svg {
    fill: currentColor;
  }

  &:hover:not(:disabled) {
    color: #fff;
  }

  &:active:not(:disabled) {
    color: #fff;
  }
`,Ub=M(Ko)`
  color: ${({isActive:n})=>n?"#23AE75":"#9899a6"};

  &:hover:not(:disabled) {
    color: #23ae75;
  }

  &:active:not(:disabled) {
    color: #23ae75;
  }
`,Bb=M(Ko)`
  color: ${({isActive:n})=>n?"#EB3830":"#9899a6"};

  &:hover:not(:disabled) {
    color: #eb3830;
  }

  &:active:not(:disabled) {
    color: #eb3830;
  }
`;function Ep({summaryCompleted:n,contentRoot:o,onRegenerate:a}){let[f,p]=(0,Jt.useState)(!1),[m]=dn(),x=zu(),S=m?.summaryFeedback,I=S?.isLiked===!0,k=S?.isLiked===!1,V=(0,Jt.useCallback)(async()=>{if(!(!n||!o))try{let N=o.innerHTML,R=o.innerText||o.textContent||"",K=new Blob([N],{type:"text/html"}),c=new Blob([R],{type:"text/plain"});if(navigator.clipboard&&"write"in navigator.clipboard)await navigator.clipboard.write([new ClipboardItem({"text/html":K,"text/plain":c})]);else if(navigator.clipboard&&"writeText"in navigator.clipboard)await navigator.clipboard.writeText(R);else throw new Error("Clipboard API not available");p(!0),await Je("CE_SIDEPANEL_SUMMARY_COPIED",{summaryLength:R.length,hasHtmlContent:N!==R})}catch(N){_r.error("Failed to copy summary:",N);try{let R=document.createElement("textarea");R.value=o.innerText||o.textContent||"",document.body.appendChild(R),R.select(),document.execCommand("copy"),document.body.removeChild(R),await Je("CE_SIDEPANEL_SUMMARY_COPIED",{})}catch(R){_r.error("All copy methods failed:",R)}}},[n,o]);(0,Jt.useEffect)(()=>{if(f){let N=setTimeout(()=>p(!1),2e3);return()=>clearTimeout(N)}},[f]);let U=(0,Jt.useCallback)(async()=>{try{let N=I?null:!0;await x(N),await Je("CE_SIDEPANEL_SUMMARY_UPVOTED",{summaryLength:o?.innerText?.length||0,action:N===null?"removed":"added"})}catch(N){_r.error("Failed update summary feedback:",N)}},[o,I,x]),B=(0,Jt.useCallback)(async()=>{try{let N=k?null:!1;await x(N),await Je("CE_SIDEPANEL_SUMMARY_DOWNVOTED",{summaryLength:o?.innerText?.length||0,action:N===null?"removed":"added"})}catch(N){_r.error("Failed to update summary feedback:",N)}},[o,k,x]),z=(0,Jt.useCallback)(async()=>{if(!a){_r.warn("No regenerate handler provided");return}try{await x(null),await Je("CE_SIDEPANEL_SUMMARY_REGENERATED",{previousFeedback:k?"disliked":I?"liked":"none",summaryLength:o?.innerText?.length||0}),a()}catch(N){_r.error("Failed to regenerate summary:",N)}},[a,x,k,I,o]);return d(Db,null,d(Gn,{text:f?"Copied!":"Copy"},d(Ko,{disabled:!n,onClick:V,title:n?"Copy summary":"Copy disabled - summary not completed"},f?d(dd,{size:20}):d(cd,{size:20}))),!k&&n&&d(Gn,{text:"Helpful"},d(Ub,{onClick:U,isActive:I,title:"Liked",disabled:I},d(ud,{size:20}))),!I&&n&&d(Gn,{text:"Not helpful"},d(Bb,{onClick:B,isActive:k,title:"Disliked",disabled:k},d(fd,{size:20}))),k&&n&&a&&d(Gn,{text:"Regenerate"},d(Ko,{onClick:z,title:"Regenerate summary"},d(pd,{width:20,height:20}))))}var Fb=be("SidepanelSummaryDisplay"),Gb=M.div`
  width: 100%;
  display: flex;
  align-items: flex-start;
  text-align: left;
  gap: 16px;
  min-height: 150px;
`,Wb=M.ul`
  padding: 16px;
  margin: 0;
  width: 100%;
`,$b=M.li`
  color: #ffffff;
  font-size: 0.875rem; /* body-6 */
  font-weight: 400;
  line-height: 1.43; /* 20px line-height (20/14 = 1.43) */
  letter-spacing: -0.004375rem;
  margin: 0 0 8px 0;
  &:first-child {
    margin-top: 0;
  }
  &:last-child {
    margin-bottom: 0;
  }
`,zb=M.div`
  position: sticky;
  top: 10px;
  bottom: 0;
  width: 24px;
  min-height: 100px;
  z-index: 100;
  backdrop-filter: blur(10px);
  flex-shrink: 0;
  justify-items: center;
`,Vb=M.div`
  padding: 8px 0 24px;
  width: 100%;
`;function Ip({summary:n,onRegenerate:o}){let a=(0,xn.useRef)(null),f=(0,xn.useRef)(null),[p,m]=(0,xn.useState)(null),x=Array.isArray(n)||n.status==="completed";return(0,xn.useEffect)(()=>{x&&Fb.info("Traversed node"," ------- - -- - - -Summary completed!!!")},[x]),(0,xn.useEffect)(()=>{m(f.current??a.current)}),d(Gb,null,d(Vb,null,Array.isArray(n)?d(Wb,{ref:a},n.map((S,I)=>d($b,{key:I},S.replace(/^[-*]/,"").trim()))):d(lp,{content:n.summary,ref:f})),d(zb,null,p&&d(Tp,{contentRoot:p,summaryCompleted:x}),d(Ep,{summaryCompleted:x,contentRoot:p,onRegenerate:o})))}w();C();var Ap=M.div`
  height: 16px;
  border-radius: 2px;
  background: #1e1e1f;
  width: 100%;
  position: relative;
  overflow: hidden;
`,Lp=M.div`
  @keyframes shimmer {
    100% {
      transform: translateX(150%);
    }
  }

  animation: shimmer 2s infinite;
  position: absolute;
  left: 0;
  top: 0;
  height: 100%;
  width: 80%;
  background: linear-gradient(90deg, #1e1e1f 0%, #282829 50%, #1e1e1f 100%);
  pointer-events: none;
  transform: translateX(-150%);
`,Yb=M.div`
  display: flex;
  padding: 8px 0 24px 0;
  flex-direction: column;
  align-items: flex-start;
  gap: 12px;
  align-self: stretch;

  > div:nth-child(1) {
    width: 100%; /* Full width excluding padding */
  }
  > div:nth-child(2) {
    width: 85%;
  }
  > div:nth-child(3) {
    width: 92%;
  }
  > div:nth-child(4) {
    width: 78%;
  }
`,Kb=M.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
`;function Op(){return d(Kb,null,d(Yb,null,d(Ap,null,d(Lp,null)),d(Ap,null,d(Lp,null))))}function Np({onSummarizeClick:n,onSummarizeRegenerate:o}){let{isLoading:a,isAuthenticated:f}=wd(),[p]=dn(),m=rr(),x=ir(),S=Vu(),I=!!(S&&Td(S,m||void 0));return a?d(ri,null,d(Fs,null)):f?!p||p.hasContent===!1&&m?.startsWith("chrome://")||I?d(ri,null,d(Ws,null,d(Rs,null),d("p",null,"No readable text found to summarize"))):p.isLoadingSummary?d(Op,null):p.summaryData?d(Ip,{summary:p.summaryData.summary,onRegenerate:o}):d(ri,null,d(Ld,{currentUrl:m,key:m}),d(Md,null,x?.favIconUrl&&d(Dd,{src:x.favIconUrl,alt:""}),d(Ed,null,Mo(m??""))),x?.title&&d(Id,null,x.title),p.hasContent===void 0&&d(Bs,{disabled:!0,isExtracting:!0},d(Fs,null),"Summarize Page"),p.hasContent===!0&&d(Bs,{onClick:n},d(gd,null),"Summarize Page")):d(ri,null,d(Ws,null,d(Rs,null),d("p",null,"Only authorized users can listen to summaries")))}w();C();var Rp=we(Oe());var qb=M.div`
  padding: 20px 16px 32px; /* 16px side padding to match design requirement */
  position: relative;
  flex-shrink: 0; /* Prevent the input from shrinking */
`,Xb=M.div`
  position: relative;
`,Hb=M.input`
  width: 100%;
  padding: 16px 50px 16px 20px;
  background-color: #2d2d2f;
  color: #ffffff;
  border: 1px solid ${({hasText:n})=>n?"#ffffff":"#3c3c3e"};
  border-radius: 25px;
  font-size: 16px;
  outline: none;
  box-sizing: border-box;
  transition: border-color 0.15s ease;

  &:hover {
    border-color: ${({hasText:n})=>n?"#ffffff":"#5a5a5c"};
  }

  &:focus {
    border-color: #ffffff;
  }

  &::placeholder {
    color: #9899a6;
  }
`,Zb=M.button`
  position: absolute;
  right: 8px;
  top: 50%;
  transform: translateY(-50%);
  width: 32px;
  height: 32px;
  background-color: ${({hasText:n})=>n?"#4285f4":"#747580"};
  border: none;
  border-radius: 50%;
  color: #ffffff;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 14px;
  font-weight: bold;
  transition: all 0.15s ease;

  &:hover {
    background-color: ${({hasText:n})=>n?"#2b6ce8":"#9899a6"};
  }

  &:active {
    background-color: ${({hasText:n})=>n?"#1c5bd1":"#6b6b72"};
  }

  &:disabled {
    background-color: #4a4a4c;
    cursor: not-allowed;
    opacity: 0.5;
  }
`;function kp({onSubmit:n,placeholder:o="Ask anything"}){let[a,f]=(0,Rp.useState)(""),p=a.trim().length>0,m=k=>{k.trim()&&(n(k.trim()),f(""))};return d(qb,null,d(Xb,null,d(Hb,{type:"text",placeholder:o,value:a,onChange:k=>{f(k.target.value)},onKeyDown:k=>{k.key==="Enter"&&m(a)},hasText:p,disabled:!0}),d(Zb,{onClick:()=>{m(a)},hasText:p,disabled:!p},"↑")))}var Ee=be("TabInfoApp"),jb=Dn({key:"sidepanel-emotion",prepend:!0});function Qb({enableFollowupChat:n=!1}){let o=rr(),[a]=dn(),f=ir(),p=Wu(),m=$u(),x=Yu(),S=nr(c=>c.clearCurrentUrlChat),I=Xu(),[k,V]=(0,Tt.useState)("top"),U=(0,Tt.useCallback)(c=>{let h=c.target,{scrollTop:y,scrollHeight:O,clientHeight:P}=h,q=y<=5,G=y+P>=O-5;V(q?"top":G?"bottom":null)},[]);(0,Tt.useEffect)(()=>{let c=document.getElementById("scrollable-content");if(c)return c.addEventListener("scroll",U),U({target:c}),()=>{c.removeEventListener("scroll",U)}},[U,a?.hasSummary]);let B=(0,Tt.useCallback)(()=>{Qu()},[]);(0,Tt.useEffect)(()=>{},[o]);let z=(0,Tt.useCallback)(async()=>{let c=o;if(!c){Ee.error("No target URL available for summarization");return}if(!f?.tabId){Ee.error("No tab ID available for content extraction");return}try{await m(!0,c);let h=new AbortController;x(c,h),Ee.debug("📤 Sending content extraction request to background...");let y=await kn("/content/extract-content",{tabId:f.tabId});if(Ee.info("✅ Received extracted content:",{contentLength:y?.text?.length||0,hasContent:!!y?.text}),!y?.text){Ee.error("❌ No content extracted from page"),await m(!1,c);return}if(h.signal.aborted){Ee.info("🚫 Summary generation cancelled before creating chat for URL:",c),await m(!1,c);return}let O=Zf(),P=Hf(O),{chatId:q}=await ms.createChat(y.text).catch(()=>({chatId:null}));if(q)await ms.generateSummary(q,P,G=>{if(h.signal.aborted){Ee.info("🚫 Summary generation cancelled, ignoring data chunk for URL:",c);return}Ee.debug("🔍 Summary data chunk:",{data:G,targetUrl:c}),G&&(m(!1,c),p({summary:G,status:"in-progress"},c,O))},G=>{Ee.error("❌ Failed to generate summary:",G)},G=>{if(h.signal.aborted){Ee.info("🚫 Summary generation cancelled, ignoring completion for URL:",c);return}Ee.debug("🔍 Summary generated:",{content:G,targetUrl:c}),m(!1,c),p({summary:G,status:"completed"},c,O)},h.signal);else{if(h.signal.aborted){Ee.info("🚫 Summary generation cancelled before fallback summarization for URL:",c),await m(!1,c);return}Ee.debug("🧠 Sending summarization request to background...");let G=await kn("/summarization/summarize-content",{content:y.text,model:"gemini-2.0-flash"});if(Ee.info("✅ Received summarization result:",{keypointsCount:G?.keypoints?.length||0,model:G?.model}),!G?.keypoints){Ee.error("❌ No keypoints received from summarization"),await m(!1,c);return}if(h.signal.aborted){Ee.info("🚫 Summary generation cancelled, ignoring fallback result for URL:",c),await m(!1,c);return}await p(G.keypoints,c,O),await m(!1,c)}Ee.info("✅ Successfully summarized and stored content for URL:",c)}catch(h){h instanceof Error&&h.name==="AbortError"||Ee.error("❌ Failed to extract content or summarize:",h),await m(!1,c)}},[o,a,f,m,p]),N=(0,Tt.useCallback)(async()=>{await Je("extension_sidepanel_summarize_btn_clicked",{source:"sidepanel"}),await z()},[z]),R=(0,Tt.useCallback)(async()=>{await S(),await z()},[S,z]);(0,Tt.useEffect)(()=>{let c=async()=>{Ee.info("🤖 [TABINFOAPP] Received summarization event from TabManager");try{if(a?.hasSummary){Ee.info("🤖 [TABINFOAPP] Summary already exists, skipping");return}Ee.info("🤖 [TABINFOAPP] Starting summarization..."),await z()}catch(h){Ee.error("🤖 [TABINFOAPP] Error handling summarization event:",h)}};return window.addEventListener("speechify-start-summarization",c),()=>{window.removeEventListener("speechify-start-summarization",c)}},[a?.hasSummary,z]);let K=c=>{};return o?d(Od,null,d(Sd,{showPageTitle:!!(a?.isLoadingSummary||a?.summaryData),showMenu:!!(a?.isLoadingSummary||a?.summaryData),onRegenerate:R,key:o}),d(Bd,{position:I,onClick:B,title:"Click to re-enable autoscroll"},d("svg",{width:"28",height:"28",viewBox:"0 0 28 28",fill:"none"},d("mask",{id:"path-1-inside-1_4845_84939",fill:"white"},d("path",{d:"M0 14C0 6.26801 6.26801 0 14 0C21.732 0 28 6.26801 28 14C28 21.732 21.732 28 14 28C6.26801 28 0 21.732 0 14Z"})),d("path",{d:"M0 14C0 6.26801 6.26801 0 14 0C21.732 0 28 6.26801 28 14C28 21.732 21.732 28 14 28C6.26801 28 0 21.732 0 14Z",fill:"#111112"}),d("path",{d:"M14 28V27.5C6.54416 27.5 0.5 21.4558 0.5 14H0H-0.5C-0.5 22.0081 5.99187 28.5 14 28.5V28ZM28 14H27.5C27.5 21.4558 21.4558 27.5 14 27.5V28V28.5C22.0081 28.5 28.5 22.0081 28.5 14H28ZM14 0V0.5C21.4558 0.5 27.5 6.54416 27.5 14H28H28.5C28.5 5.99187 22.0081 -0.5 14 -0.5V0ZM14 0V-0.5C5.99187 -0.5 -0.5 5.99187 -0.5 14H0H0.5C0.5 6.54416 6.54416 0.5 14 0.5V0Z",fill:"#2D2D2F",mask:"url(#path-1-inside-1_4845_84939)"}),d("path",{fillRule:"evenodd",clipRule:"evenodd",d:I==="top"?"M8.76773 13.2339C8.45531 12.9215 8.45531 12.415 8.76773 12.1026L13.4345 7.43574C13.7469 7.12332 14.2535 7.12332 14.5659 7.43574L19.2327 12.1026C19.5452 12.415 19.5452 12.9215 19.2327 13.2339C18.9203 13.5464 18.4138 13.5464 18.1014 13.2339L14.8014 9.93394L14.8014 20.0013C14.8014 20.4431 14.4432 20.8013 14.0014 20.8013C13.5595 20.8013 13.2014 20.4431 13.2014 20.0013V9.93168L9.89908 13.2339C9.58666 13.5464 9.08013 13.5464 8.76773 13.2339Z":"M19.2323 14.7661C19.5447 15.0785 19.5447 15.585 19.2323 15.8974L14.5655 20.5643C14.2531 20.8767 13.7465 20.8767 13.4341 20.5643L8.76727 15.8974C8.45485 15.585 8.45485 15.0785 8.76727 14.7661C9.07969 14.4536 9.58622 14.4536 9.89864 14.7661L13.1986 18.0661L13.1986 7.99873C13.1986 7.5569 13.5568 7.19873 13.9986 7.19873C14.4405 7.19873 14.7986 7.5569 14.7986 7.99873V18.0683L18.1009 14.7661C18.4134 14.4536 18.9199 14.4536 19.2323 14.7661Z",fill:"white"}))),d(Pd,{className:`${k==="top"?"hide-top-fade":""} ${k==="bottom"?"hide-bottom-fade":""}`.trim()},d(Rd,{id:"scrollable-content",className:"smoothScrollbar"},d(kd,{alignCenter:!a?.summaryData},d(Np,{onSummarizeClick:N,onSummarizeRegenerate:R,key:o})))),n&&d(kp,{onSubmit:K})):d(Nd,null,d(Ad,null,"Loading tab information..."))}function Pp(){return d(jr,{value:jb},d(Qb,null))}typeof window<"u"&&typeof F>"u"&&(globalThis.browser=chrome);var Mp=()=>d("div",{style:{fontFamily:"system-ui, -apple-system, sans-serif"}},d(Pp,null));w();C();var bn=be("SidepanelOrchestration"),Dp={"tab-info":()=>import("./init-PQ2C4AVH.js")},qo=new Map;function Jb(n){if(!Dp[n])throw new Error(`Unable to find init function for sidepanel feature: "${n}"`);return Dp[n]}async function e3(n,o,a,f,p={}){try{bn.debug(`Initializing sidepanel feature: ${n}`,{lifecycle:a,event:f});let m=Jb(n),{default:x}=await m(),S=new AbortController,I=await x(o,a,f,p,S.signal);if(I&&typeof I=="function"){let k=async()=>{S.abort(),await I()};qo.set(n,k)}bn.debug(`Successfully initialized sidepanel feature: ${n}`)}catch(m){throw bn.error(`Failed to initialize sidepanel feature: ${n}`,m),m}}async function t3(n){let o=qo.get(n);if(o)try{await o(),qo.delete(n),bn.debug(`Cleaned up sidepanel feature: ${n}`)}catch(a){bn.error(`Failed to cleanup sidepanel feature: ${n}`,a)}}async function n3(){let n=Array.from(qo.keys()).map(t3);await Promise.all(n)}async function Up(){try{bn.debug("Initializing sidepanel orchestration");let n=[{feature:"tab-info",config:{enabled:!0,disabledWebsites:[{domain:"docs.google.com",disabledFeatures:["summary"]}]}}];for(let{feature:o,config:a}of n)await e3(o,a,"init",{name:"sidepanel-init",source:"orchestration"},{});return bn.debug("Sidepanel orchestration initialization complete"),n3}catch(n){throw bn.error("Failed to initialize sidepanel orchestration",n),n}}typeof window<"u"&&typeof F>"u"&&(globalThis.browser=chrome);async function r3(){let n=document.createElement("link");n.rel="stylesheet",n.href=F.runtime.getURL("css/speechify.css"),document.head.appendChild(n)}async function i3(){let n=document.createElement("div");n.style.fontFamily="ABCDiatype",n.style.visibility="hidden",n.style.position="absolute",n.innerHTML="asd",document.body.appendChild(n),setTimeout(()=>n?.remove(),0)}var Bp=async()=>{await r3(),await i3(),await Hu();let n=await Up(),o=document.getElementById("speechify-sidepanel-root");if(!o){console.error("Side panel root element not found");return}o.innerHTML="",Pu(d(Mp,null),o),window.__sidepanelCleanup=()=>{n()}};document.readyState==="loading"?document.addEventListener("DOMContentLoaded",Bp):Bp();
/*! Bundled license information:

react-is/cjs/react-is.production.min.js:
  (** @license React v16.13.1
   * react-is.production.min.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

lodash/lodash.js:
  (**
   * @license
   * Lodash <https://lodash.com/>
   * Copyright OpenJS Foundation and other contributors <https://openjsf.org/>
   * Released under MIT license <https://lodash.com/license>
   * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
   * Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
   *)
*/
//# sourceMappingURL=main.js.map
