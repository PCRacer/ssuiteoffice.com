import{a}from"./chunk-IDIA6O63.js";import"./chunk-IV62XIZ7.js";import"./chunk-V2L5DJQO.js";import"./chunk-7DWBZSFS.js";export{a as default};
//# sourceMappingURL=TabManager-WIIBU2N4.js.map
