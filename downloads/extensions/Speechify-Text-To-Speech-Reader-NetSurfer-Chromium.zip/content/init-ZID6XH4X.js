import{a as mt}from"./chunk-H2Q7MKM3.js";import{a as Y}from"./chunk-3F57R3AM.js";import{a as ct,c as dt}from"./chunk-L466EF2O.js";import{a as st,b as Yt,c as ce}from"./chunk-F6QDPILS.js";import{a as _}from"./chunk-533YBOH2.js";import{a as rt}from"./chunk-BKGCVLI3.js";import{c as at,d as ke,e as lt}from"./chunk-5VQR6ERF.js";import{a as it}from"./chunk-7XGTX76V.js";import{c as Ze}from"./chunk-3UDU62CH.js";import"./chunk-BTWOJWRN.js";import{a as se}from"./chunk-MBHSJ34F.js";import{a as Ke}from"./chunk-56NWWOIX.js";import"./chunk-EF43U47C.js";import"./chunk-GWCIFOLA.js";import"./chunk-NK4CKTAC.js";import{j as T,q as y}from"./chunk-KO4WPNRU.js";import"./chunk-F5622KQ7.js";import"./chunk-WC6QURV6.js";import"./chunk-TIGAXALM.js";import{a as Qe}from"./chunk-ZQRXZJGY.js";import"./chunk-6S4AP2UG.js";import{d as ie}from"./chunk-O3LC63CS.js";import{a as re}from"./chunk-AG3QEKLJ.js";import{Dd as ot,Fd as nt,Ia as Ue,Oa as Ge,Ta as $,Xa as Je,ac as we,bd as He,c as Re,dc as Se,e as L,ea as ze,fc as ve,gb as F,gc as ae,hc as le,i as Ve,jc as N,k as Fe,la as We,pa as je,w as ye,wb as Xe,x as Ce,yd as et,zd as tt}from"./chunk-RISKGE32.js";import{V as _e,ca as oe,ja as ne}from"./chunk-6O6MLDWR.js";import{a as xe,b as a,c as qe,g as Ye,k as m}from"./chunk-F4AZU7R4.js";import{a as te,b as O,d as $e,f as q,g as P}from"./chunk-GQY3J744.js";import{d as E,f as x,g as c,i as e,j as f,k as G,m as Oe,n as d}from"./chunk-CLPINNGF.js";d();c();Oe();d();c();q();d();c();d();c();var de=t=>e(re,{viewBox:"0 0 13 13",xmlns:"http://www.w3.org/2000/svg",...t,fill:"currentColor"},e("path",{d:"M1.23438 5.95361C1.43327 5.95361 1.59831 5.89014 1.72949 5.76318C1.86491 5.632 1.93262 5.46484 1.93262 5.26172V4.86182L1.79932 3.07178L3.12598 4.46191L4.80176 6.15674C4.93294 6.29215 5.09798 6.35986 5.29688 6.35986C5.5127 6.35986 5.68831 6.29215 5.82373 6.15674C5.96338 6.02132 6.0332 5.84782 6.0332 5.63623C6.0332 5.5389 6.01416 5.44792 5.97607 5.36328C5.94222 5.27865 5.89144 5.20247 5.82373 5.13477L4.13525 3.44629L2.73877 2.12598L4.54785 2.25293H4.99219C5.19531 2.25293 5.36247 2.18945 5.49365 2.0625C5.62484 1.93132 5.69043 1.76416 5.69043 1.56104C5.69043 1.35791 5.62484 1.19076 5.49365 1.05957C5.36247 0.928385 5.19531 0.862793 4.99219 0.862793H1.66602C1.30632 0.862793 1.02702 0.96224 0.828125 1.16113C0.629232 1.36003 0.529785 1.63721 0.529785 1.99268V5.26172C0.529785 5.46061 0.597493 5.62565 0.73291 5.75684C0.868327 5.88802 1.03548 5.95361 1.23438 5.95361ZM7.67725 12.479H11.0034C11.3631 12.479 11.6424 12.3796 11.8413 12.1807C12.0402 11.9818 12.1396 11.7025 12.1396 11.3428V8.07373C12.1396 7.87484 12.0719 7.7098 11.9365 7.57861C11.8053 7.44743 11.6382 7.38184 11.4351 7.38184C11.2362 7.38184 11.069 7.44743 10.9336 7.57861C10.8024 7.7098 10.7368 7.87484 10.7368 8.07373V8.47363L10.8701 10.27L9.54346 8.87354L7.86768 7.18506C7.73649 7.04541 7.57145 6.97559 7.37256 6.97559C7.15674 6.97559 6.979 7.04329 6.83936 7.17871C6.70394 7.31413 6.63623 7.48975 6.63623 7.70557C6.63623 7.8029 6.65316 7.89388 6.68701 7.97852C6.7251 8.05892 6.77799 8.13509 6.8457 8.20703L8.53418 9.88916L9.93066 11.2158L8.12158 11.0825H7.67725C7.47835 11.0825 7.31331 11.1481 7.18213 11.2793C7.05094 11.4105 6.98535 11.5755 6.98535 11.7744C6.98535 11.9775 7.05094 12.1447 7.18213 12.2759C7.31331 12.4113 7.47835 12.479 7.67725 12.479Z"}));d();c();var me=t=>e(re,{viewBox:"0 0 12 13",xmlns:"http://www.w3.org/2000/svg",...t},e("path",{d:"M1.18213 6.13135H4.51465C4.84049 6.13135 5.09229 6.04248 5.27002 5.86475C5.45199 5.68278 5.54297 5.42887 5.54297 5.10303V1.7959C5.54297 1.62663 5.48584 1.48486 5.37158 1.37061C5.25732 1.25212 5.11133 1.19287 4.93359 1.19287C4.76009 1.19287 4.61621 1.25 4.50195 1.36426C4.3877 1.47852 4.33057 1.6224 4.33057 1.7959V2.25928L4.45752 4.24609L2.97217 2.67822L1.18848 0.881836C1.07422 0.767578 0.932454 0.710449 0.763184 0.710449C0.576986 0.710449 0.422526 0.767578 0.299805 0.881836C0.177083 0.996094 0.115723 1.14632 0.115723 1.33252C0.115723 1.41715 0.130534 1.49756 0.160156 1.57373C0.19401 1.6499 0.238444 1.71761 0.293457 1.77686L2.08984 3.56055L3.65771 5.0459L1.66455 4.92529H1.18213C1.00863 4.92529 0.86263 4.98242 0.744141 5.09668C0.629883 5.20671 0.570638 5.35059 0.566406 5.52832C0.566406 5.70605 0.623535 5.85205 0.737793 5.96631C0.856283 6.07633 1.00439 6.13135 1.18213 6.13135ZM7.02832 12.2251C7.20182 12.2251 7.3457 12.1659 7.45996 12.0474C7.57422 11.9331 7.63135 11.7892 7.63135 11.6157V11.0889L7.49805 9.10205L8.98975 10.6699L10.8052 12.5044C10.9194 12.6187 11.0612 12.6758 11.2305 12.6758C11.4167 12.6758 11.5711 12.6187 11.6938 12.5044C11.8166 12.3901 11.8779 12.2399 11.8779 12.0537C11.8779 11.9691 11.861 11.8887 11.8271 11.8125C11.7975 11.7363 11.7531 11.6686 11.6938 11.6094L9.86572 9.7876L8.3042 8.30225L10.2974 8.42285H10.8369C11.0104 8.42285 11.1543 8.36784 11.2686 8.25781C11.387 8.14355 11.4463 7.99756 11.4463 7.81982C11.4463 7.64632 11.387 7.50244 11.2686 7.38818C11.1543 7.27393 11.0104 7.2168 10.8369 7.2168H7.44727C7.11719 7.2168 6.86117 7.30778 6.6792 7.48975C6.50146 7.66748 6.4126 7.91927 6.4126 8.24512V11.6157C6.4126 11.785 6.46973 11.9289 6.58398 12.0474C6.70247 12.1659 6.85059 12.2251 7.02832 12.2251Z"}));var ut=m($)`
  padding: 16px 16px 20px 16px;
  background: ${a.bgPrimW100};
  border-radius: 10px;
  font-family: ABCDiatype;
`,Jt=m($)`
  width: 100%;
  justify-content: space-between;
  align-items: center;
  gap: 32px;
`,pt=m.div`
  padding: 16px 16px 20px 16px;
  background: ${a.bgPrimW100};
  border-radius: 10px;
  font-family: ABCDiatype;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  position: relative;
  max-width: 75vw;
  height: 100%;
  max-height: 50vh;
  color: ${a.icnTxtPrim};
  h1 {
    margin-bottom: 1rem;
    font-weight: bold;
    font-size: 1.5rem;
  }

  > * {
    width: 100%;
  }
`,gt=({isMinimized:t,onClick:o,onClose:i})=>e(Jt,null,e("div",null,e(F,{fontSize:"14px"},"Debugging Tools")),e($,{style:{gap:"8px"}},e(T,{background:"transparent",onClick:o},t?e(de,null):e(me,null)),e(T,{background:"transparent",onClick:i,padding:"2px"},e(Y,null))));d();c();d();c();q();var ue="speechify-marked-active",Qt=()=>{try{let t=document.styleSheets[0];t.insertRule(`.${ue} { background: rgba(255, 0, 0, 0.2); }`,t.cssRules.length)}catch{}},Xt=t=>{t.classList.add(ue)},Zt=()=>{document.querySelectorAll(`.${ue}`).forEach(t=>t.classList.remove(ue))};Qt();function Ee({enabled:t}){let{activeElement:o}=it();return O(()=>{Zt(),t&&o instanceof HTMLElement&&Xt(o)},[o,t]),null}d();c();q();var ft=E(P());var J="speechify-marked-parser",Kt=()=>{try{let t=new CSSStyleSheet;t.insertRule(`.${J} { background: rgba(0, 100, 100, 0.2) !important; }`,t.cssRules.length),document.adoptedStyleSheets=[...document.adoptedStyleSheets,t]}catch{}};Kt();function bt({enabled:t}){let[o,i]=(0,ft.useState)("hybrid");O(()=>(t?N.getParsedElements({useHybridParsingMode:o==="hybrid",invalidateCache:!0,shouldParseShadowRoot:!1,startingNodeElement:document.body}).then(s=>s.forEach(l=>l.classList?.add(J))):document.querySelectorAll(`.${J}`).forEach(l=>l.classList?.remove(J)),()=>{document.querySelectorAll(`.${J}`).forEach(l=>l.classList?.remove(J))}),[t,o]);let r=()=>{let s=Xe(),l=JSON.stringify(s.map(u=>({tagName:u.tagName,content:u.textContent})));navigator.clipboard.writeText(l)};return t?e("div",null,e(y,{onClick:r},"Copy Parsed Elements as JSON"),e("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",marginTop:"10px"}},e(F,null,"Hybrid Parsing Mode"),e(se,{checked:o==="hybrid",onChange:s=>i(s?"hybrid":"standard")}))):null}d();c();Oe();q();var Ht=m($)`
  background: ${a.bgPrimW100};
  max-width: 620px;
  border-radius: 10px;
  gap: 16px;
  font-family: ABCDiatype;
  line-height: 1.3;
  padding: ${({expanded:t})=>t?"16px":"8px"};
`,xt=()=>{if(document.querySelector("#speechify-view-div"))return document.querySelector("#speechify-view-div");let t=document.createElement("div");return t.id="speechify-view-div",t.style.zIndex="9999999999",document.body.appendChild(t),t},eo=async t=>{let o=await Ue(t),i=xt();o.forEach(r=>{let{text:s,ref:l}=t.converter(r),u=l.ref;if(ze(u))return;let p=u instanceof Element?u.getBoundingClientRect():je(u),n=document.createElement("div");n.style.position="absolute",n.style.display="block",n.style.top=`${p.top+window.scrollY}px`,n.style.left=`${p.left+window.scrollX-48}px`,n.style.zIndex="9999999999",G(e(to,{text:s}),n),i.appendChild(n)})},ht=()=>{let t=xt();if(!t)return;Array.from(t.children).forEach(i=>G(()=>null,i))},to=({text:t})=>{let[o,i]=te(!0);return e(Ht,{expanded:!o},e(T,{background:"transparent",onClick:()=>i(!o)},o?e(de,null):e(me,null)),!o&&e(F,null,t))};function Pe({enabled:t}){let o=Ge.useCurrentContent();return O(()=>{if(o)return t&&eo(o),t||ht(),ht},[o,t]),null}d();c();var Te=E(P());var pe=Re("cluster_data",{getInitialState:async()=>({})}),oo=async(t,o,i)=>{let r={clusters:o,readable:i,...ae()};try{let l={...await pe.getAll(),[t]:r};await pe.setAll(l)}catch(s){console.error(s)}},yt=async()=>{let t=await pe.getAll(),o=new Blob([JSON.stringify(t)],{type:"application/json"}),i=URL.createObjectURL(o),r=document.createElement("a");r.href=i,r.download="dataset.json",r.click(),URL.revokeObjectURL(i)},Ct=async()=>{await pe.setAll({})},M=oe(()=>({clusters:[],readableNodes:[],readable:!1}));function no(t,o,i,r){let{x:s,y:l,width:u,height:p}=ve(t,r),n=document.createElement("div");Object.assign(n.style,{position:"absolute",zIndex:"999999",isolate:"isolate",left:`${s}px`,top:`${l}px`,width:`${u}px`,height:`${p}px`,border:"2px solid black",backgroundColor:o?"rgba(28, 236, 28, 0.2)":"rgba(105, 104, 104, 0.2)"}),n.classList.add("speechify-cluster");let b=document.createElement("form");b.classList.add("cluster-form"),Object.assign(b.style,{background:"white",padding:"8px",margin:"8px",width:"auto",display:"none",color:"black",zIndex:"999999999"});let v=document.createElement("label");v.textContent="Critical";let g=document.createElement("input");g.type="checkbox",g.checked=o,Object.assign(g.style,{appearance:"checkbox"}),g.onchange=()=>{M.setState(S=>({clusters:S.clusters.map(C=>C.cluster===t?{...C,critical:!C.critical}:C)}))};let w=document.createElement("label");w.textContent="Type";let h=document.createElement("select");["ad","article","article_paragraph","avatar","button_group","button_individual","calendar","carousel","code_block","comment","comment_group","cookie_text","email","faq","showcase","showcase_item","hero","featured","filters","forum_post","heading","media","metadata","navigation","navigation_item","navigation_tabs","product_card","product_description","review","search","search_results","sidebar","social_post","social_share","table","other"].forEach(S=>{let C=document.createElement("option");C.value=S,C.textContent=S,h.appendChild(C)}),h.value=i,h.onchange=S=>{M.setState(C=>({clusters:C.clusters.map(D=>D.cluster===t?{...D,type:S.target.value}:D)}))};let k=()=>{t.forEach(S=>{r[S].node.style.outline="2px dashed red"})},B=()=>{t.forEach(S=>{r[S].node.style.outline=""})};b.append(w,h,v,g),n.appendChild(b),n.onmouseenter=S=>{let{clientX:C,clientY:D}=S;document.elementsFromPoint(C,D).find(R=>{if(R.classList.contains("speechify-cluster")){let K=R.getBoundingClientRect(),H=n.getBoundingClientRect();return K.width*K.height<H.width*H.height}return!1})||(b.style.display="flex",n.style.zIndex="999999999",k())},n.onmousemove=S=>{let{clientX:C,clientY:D}=S;document.elementsFromPoint(C,D).find(R=>{if(R.classList.contains("speechify-cluster")){let K=R.getBoundingClientRect(),H=n.getBoundingClientRect();return K.width*K.height<H.width*H.height}return!1})&&(B(),n.style.zIndex="99999",b.style.display="none")},n.onmouseleave=()=>{b.style.display="none",n.style.zIndex="999999",B()},document.body.appendChild(n)}function ro(){document.querySelectorAll(".speechify-cluster").forEach(t=>t.remove())}function io(){let t=document.createElement("button");return t.id="add-to-dataset",t.innerText="Save to Dataset",Object.assign(t.style,{background:"#3A72E0",color:"white",border:"none",cursor:"pointer",outline:"none",padding:"8px"}),t}function so(){let t=document.createElement("button");return t.id="add-fold-to-dataset",t.innerText="Save clusters in viewport",Object.assign(t.style,{background:"#3A72E0",color:"white",border:"none",cursor:"pointer",outline:"none",padding:"8px"}),t}function ao(){let t=document.createElement("button");return t.id="refresh-dataset",t.innerText="Refresh Clusters",Object.assign(t.style,{background:"#231F20",color:"white",border:"none",cursor:"pointer",outline:"none",padding:"8px"}),t}function lo(t,o){let i=document.createElement("div");i.id="speechify-page-toolbar",i.className="speechify-toolbar",Object.assign(i.style,{position:"fixed",bottom:"32px",right:"64px",display:"flex",alignItems:"center",gap:"8px",zIndex:"99999999",background:"white",padding:"8px",borderRadius:"4px",boxShadow:"rgba(0, 0, 0, 0.24) 0px 3px 8px",color:"black"});let r=ao();r.onclick=t;let s=io();s.onclick=o(!1);let l=so();l.onclick=o(!0);let u=document.createElement("label");u.textContent="Readable?";let p=document.createElement("input");return p.type="checkbox",p.checked=M.getState().readable,p.style.appearance="checkbox",p.onchange=n=>{M.setState(()=>({readable:n.target.checked}))},i.append(u,p,r,s,l),i}function co(t,o){return o.filter(i=>{let{x:r,y:s,width:l,height:u}=ve(i.cluster,t),p=window.scrollX,n=window.scrollY,b=window.innerWidth,v=window.innerHeight,g=l*u,w=Math.min(r+l,p+b)-Math.max(r,p),h=Math.min(s+u,n+v)-Math.max(s,n);return Math.max(0,w)*Math.max(0,h)/g>=.7})}function Be({enabled:t}){(0,Te.useEffect)(()=>{(async()=>{if(t){let r=await N.getIsPageReadable(),s=N.getAllReadableNodes(!0),l=Array.from(N.getAllClusters(s,!0)),u=le(s,l),p=await Se({...ae(),clusters:l.map(g=>({features:u.extract(g)}))});M.setState({readableNodes:s,clusters:l.map((g,w)=>{let h=p[w].label;return{cluster:g,critical:h,type:"article"}}),readable:r});let v=lo(async g=>{let w=g.target;M.setState({readableNodes:[],clusters:[]}),w.innerText="Refreshing...",setTimeout(async()=>{let h=await N.getIsPageReadable(),k=N.getAllReadableNodes(!0),B=N.getAllClusters(k,!0),S=le(k,B),C=await Se({...ae(),clusters:B.map(D=>({features:S.extract(D)}))});M.setState({readableNodes:k,clusters:B.map((D,U)=>{let I=C[U].label;return{cluster:D,critical:I,type:"article"}}),readable:h}),w.innerText="Refresh Clusters"},250)},g=>async w=>{let h=w.target,{clusters:k,readableNodes:B,readable:S}=M.getState(),C=g?co(B,k):k,D=le(B,C.map(I=>I.cluster)),U=C.map(({cluster:I,critical:R,type:Z})=>({critical:R,type:Z,features:D.extract(I)}));console.groupCollapsed("Saving to dataset"),console.log("viewport",{width:window.innerWidth,height:window.innerHeight}),console.log("readable",M.getState().readable);for(let I=0;I<C.length;I++){let R=C[I].cluster.map(Z=>B[Z].node);console.group(`Cluster ${I}`),console.log("clusterNodes:",R),console.log("clusterData",U[I]),console.groupEnd()}console.groupEnd(),await oo(window.location.href,U,S),h.innerText="Saved!",setTimeout(()=>{h.innerText=g?"Save clusters in viewport":"Save to Dataset"},1e3)});document.body.appendChild(v)}else M.setState({readableNodes:[],clusters:[]}),document.getElementById("speechify-page-toolbar")?.remove()})()},[t]);let[o,i]=M(r=>[r.clusters,r.readableNodes]);return(0,Te.useEffect)(()=>(o.forEach(r=>{no(r.cluster,r.critical,r.type,i)}),ro),[o,i]),null}var mo={"Display Current View":{enabled:!1,render:Pe},"Mark Active Element":{enabled:!1,render:Ee},"Mark parsed elements":{enabled:!1,render:bt},"Readability Dataset Mode":{enabled:!1,render:Be}},ge=oe(t=>({actions:mo,updateAction:(o,i)=>{t(r=>({...r,actions:{...r.actions,[o]:{...r.actions[o],enabled:i.enabled}}}))}}));d();c();d();c();var St=E(P()),vt=E(P());d();c();var Q=E(P());var uo=m.div`
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  background: ${a.bgDimmer};
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 999999999;
`,po=m.div`
  padding: 16px 16px 20px 16px;
  background: ${a.bgPrimWB};
  border-radius: 10px;
  font-family: ABCDiatype;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  position: relative;
  width: 50vw;
  height: 50vh;
  color: ${a.icnTxtPrim};
  h1 {
    margin-bottom: 1rem;
    font-weight: bold;
    font-size: 1.5rem;
  }

  pre {
    width: 80%;
    align-self: center;
    height: 100%;
    overflow: scroll;
    margin: 1rem;
    background: ${a.bgPrimWB};
    border-radius: 10px;
    font-size: 0.8rem;
  }

  .url {
    color: ${a.icnTxtCrit};
    font-weight: bold;
    padding: 0.25rem;
    border-radius: 0.25rem;
  }
`;function wt({root:t}){let[o,i]=(0,Q.useState)(null),r=(0,Q.useCallback)(()=>{t.remove()},[t]);return(0,Q.useEffect)(()=>{i(Ke())},[]),e(uo,null,e(po,null,e(T,{background:"transparent",onClick:r,style:{position:"absolute",top:"1rem",right:"1rem"}},e(Y,null)),e("h3",null,"(Remote) Page Config for this site: ",e("span",{className:"url"},window.location.host)),o?e("pre",null,e("code",null,JSON.stringify(o,null,2))):null))}var go=m(y)`
  margin: 1rem 0 0;
  text-align: center;
  background: ${a.sfPrimCta};
  color: white;
`,fo="speechify-page-config-debugger-modal";function kt(){let t=(0,St.useCallback)(()=>{let o=document.createElement("div");o.id=fo,(0,vt.render)(e(wt,{root:o}),o),document.body.appendChild(o)},[]);return e(go,{onClick:t,xAlign:"center",color:a.icnTxtPrim},"View Page Config")}d();c();var W=E(P());q();var bo=m(y)`
  margin-bottom: 0.5rem 0;
  background: ${a.icnTxtAlert};
  text-align: center;
  &:disabled {
    cursor: not-allowed;
  }
`;function Et(){let[t,o]=(0,W.useState)(null),i=(0,W.useMemo)(()=>t?t.resource.wordsLeft>0:!1,[t]),r=(0,W.useCallback)(async()=>{let l=await Fe();o(l)},[o]);O(()=>{r()},[r]);let s=(0,W.useCallback)(async()=>{if(!i)return;let l=t?.resource.wordsLeft??0;await L("/debugger/exhaust-premium-words",{wordsLeft:l}),await r()},[i]);return e(bo,{onClick:s,disabled:!i,xAlign:"center"},i?"Exhaust Premium Words":"Cannot Exhaust Premium Words")}d();c();var V=E(P());d();c();var z=m.div`
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  background: ${a.bgDimmer};
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 999999999;
`;var Pt=m(y)`
  margin-bottom: 0.5rem;
  background: ${a.icnTxtAlert};
  text-align: center;
  &:disabled {
    cursor: not-allowed;
  }
`,ho=m.div`
  color: ${a.icnTxtPrim};
  background-color: ${a.bgPrimWB};
  border-radius: 6px;
  padding: 0.5rem;
  position: relative;
  h3 {
    margin-top: 0;
    margin-bottom: 0;
  }

  table {
    border-collapse: collapse;
    width: 100%;
  }

  th,
  td {
    border: 1px solid #ccc;
    padding: 8px;
    font-family: 'Courier New', monospace;
    font-size: 12px;
  }

  th {
    background-color: #f2f2f2;
  }

  td {
    text-align: left;
  }
`;function Tt(){let[t,o]=(0,V.useState)([]),[i,r]=(0,V.useState)(!1),[s,l]=(0,V.useState)(null),u=(0,V.useCallback)(async()=>{let n=await Promise.all(at.map(async v=>{let g=await nt(v),w=await lt(v);return{hintId:v,displayCount:g?.displayCount||0,dismissedByUser:g?.dismissedByUser||!1,enabled:w}}));o(n);let b=await L("/auth/get-user");b&&l(Number.parseInt(b.user.createdAt))},[]);(0,V.useEffect)(()=>{u()},[]);let p=(0,V.useCallback)(async n=>{await tt.set(n,b=>({...b,displayCount:0,dismissedByUser:!1,lastDisplayedAt:null})),u(),window.confirm("Listening hint state has been resetted, do you want to refresh the page?")&&window.location.reload()},[]);return e(f,null,e(Pt,{onClick:()=>r(!0)},e("span",null,"Open Listening Hint Debugger")),i&&e(z,null,e(ho,null,e(T,{background:"black",onClick:()=>r(!1),style:{position:"absolute",top:"1rem",right:"1rem"}},e(ce,null)),e("h3",null,"Listening Hints Debugger"),e("hr",null),s!==null&&e("p",null,e("strong",null,"User Created At:")," ",new Date(s).toLocaleDateString(),e("br",null),e("strong",null,"Is created after ",ke.toLocaleDateString()," ","threshold:")," ",s??ke.getTime()<=0?"✅ yes":"❌ no"),e("table",null,e("thead",null,e("tr",null,e("td",null,"Listening Hint ID"),e("td",null,"enabled"),e("td",null,"displayCount"),e("td",null,"dismissedByUser"),e("td",null))),e("tbody",null,t.map(n=>e("tr",{key:n.hintId},e("td",null,n.hintId),e("td",null,n.enabled?"true":"false"),e("td",null,n.displayCount),e("td",null,n.dismissedByUser?"true":"false"),e("td",null,e(Pt,{onClick:()=>p(n.hintId)},"Reset")))))))))}d();c();var ee=E(P());q();var xo=m(y)`
  margin: 0.5rem 0;
  text-align: center;
  &:disabled {
    cursor: not-allowed;
  }
`;function Bt(){let[t,o]=(0,ee.useState)(null),i=(0,ee.useCallback)(async()=>{let s=await Ve();o(s&&s.uid&&!He(s))},[o]);O(()=>{i()},[i]);let r=(0,ee.useCallback)(async()=>{await L("/auth/log-out"),await L("/debugger/clear-storage"),window.confirm("Successfully logged out and cleared storage. Do you want to refresh the page?")&&window.location.reload(),o(!1)},[i]);return e(xo,{onClick:r,disabled:!t,xAlign:"center"},t?"Log out and clear storage":"Sign in first to log out!")}d();c();var Le=E(P());var Dt=m(y)`
  margin-bottom: 1rem;
  background: #fff;
  color: #000;
  text-align: center;
  &:disabled {
    cursor: not-allowed;
  }
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0.5rem 0;
`,wo=m.div`
  color: ${a.icnTxtPrim};
  background-color: ${a.bgPrimWB};
  border-radius: 6px;
  padding: 0.5rem;
  width: 600px;
  max-width: 90vw;
  max-height: 80vh;
  overflow-y: auto;

  h3 {
    margin-top: 0;
    margin-bottom: 0;
  }

  position: relative;
`,So=m.div`
  margin: 1rem 0;
  display: flex;
  flex-direction: column;
  gap: 12px;
`,fe=m.div`
  display: flex;
  align-items: center;
  gap: 10px;
`,be=m.label`
  min-width: 120px;
  font-size: 14px;
`,vo=m.input`
  padding: 8px;
  border-radius: 4px;
  border: 1px solid #ccc;
  flex: 1;
`,It=m.select`
  padding: 8px;
  border-radius: 4px;
  border: 1px solid #ccc;
  flex: 1;
`,ko=m.div`
  display: flex;
  flex-wrap: wrap;
  gap: 15px;
`,De=m.div`
  display: flex;
  align-items: center;
`,Ie=m.input`
  margin-right: 8px;
`,Eo=m.pre`
  background: #f5f5f5;
  color: #000;
  padding: 10px;
  border-radius: 4px;
  overflow: auto;
  max-height: 200px;
  font-size: 12px;
  border: 1px solid #ddd;
`,he={"introduce-ai-autoplay":{component:dt,isComponent:!0,openPillPlayer:!0},"introduce-ai-button":{component:ct,isComponent:!0},"no-client-voices":{component:Ze,isComponent:!1,openPillPlayer:!0},"individual-post-button-hint":{component:rt,isComponent:!0}};function Lt({onMinimizeClick:t}){let[o,i]=(0,Le.useState)(!1),[r,s]=(0,Le.useState)({allowPointerActions:!0,component:!1,duration:0,id:"individual-post-button-hint",priority:101,showOnMobile:!1,timeSensitive:!0}),l=Object.values(Je).filter(n=>he[n]),u=(n,b)=>{if(s(v=>({...v,[n]:b})),n==="id"){let g=he[b]?.isComponent??!0;s(w=>({...w,component:g}))}},p=async()=>{try{let{id:n}=r,b=he[n]?.component,v=he[n]?.openPillPlayer;if(!b){alert(`No component found for notification ID: ${n}`);return}v&&(_e()||ne("browser-action",{animate:!1},"pill-player")),i(!1),t(),await ot({...r,render:()=>e(b,null)})}catch(n){console.error("Error queuing notification:",n)}};return e(f,null,e(Dt,{onClick:()=>i(!0)},e("span",null,"Notifications")),o&&e(z,null,e(wo,null,e(T,{background:"black",onClick:()=>i(!1),style:{position:"absolute",top:"1rem",right:"1rem"}},e(ie,null)),e("h3",null,"Notification Debugger"),e("hr",null),e(So,null,e(fe,null,e(be,null,"Notification:"),e(It,{value:r.id,onChange:n=>u("id",n.target.value)},l.map(n=>e("option",{key:n,value:n},n)))),e(fe,null,e(be,null,"Duration (ms):"),e(vo,{type:"number",value:r.duration,onChange:n=>u("duration",parseInt(n.target.value,10)||0)})),e(fe,null,e(be,null,"Priority:"),e(It,{value:r.priority,onChange:n=>u("priority",n.target.value)},Object.entries(et).map(([n,b])=>e("option",{key:n,value:b},n)))),e(fe,null,e(be,null,"Options:"),e(ko,null,e(De,null,e(Ie,{type:"checkbox",checked:r.component,onChange:n=>u("component",n.target.checked),id:"component-checkbox"}),e("label",{htmlFor:"component-checkbox"},"Component")),e(De,null,e(Ie,{type:"checkbox",checked:r.showOnMobile,onChange:n=>u("showOnMobile",n.target.checked),id:"mobile-checkbox"}),e("label",{htmlFor:"mobile-checkbox"},"Show on Mobile")),e(De,null,e(Ie,{type:"checkbox",checked:r.timeSensitive,onChange:n=>u("timeSensitive",n.target.checked),id:"time-sensitive-checkbox"}),e("label",{htmlFor:"time-sensitive-checkbox"},"Time Sensitive"))))),e(Eo,null,JSON.stringify(r,null,2)),e(Dt,{onClick:p,style:{marginTop:"16px"}},e("span",null,"Queue Notification")))))}d();c();var j=E(P());var At=m(y)`
  margin: 0.5rem 0;
  background: ${a.bgSuccess};
  text-align: center;
  &:disabled {
    cursor: not-allowed;
  }
  display: flex;
  align-items: center;
  justify-content: center;
`,Po=m.div`
  color: ${a.icnTxtPrim};
  background-color: ${a.bgPrimWB};
  border-radius: 6px;
  padding: 0.5rem;

  h3 {
    margin-top: 0;
    margin-bottom: 0;
  }

  table {
    border-collapse: collapse;
    width: 100%;
  }

  th,
  td {
    border: 1px solid #ccc;
    padding: 8px;
    font-family: 'Courier New', monospace;
    font-size: 12px;
  }

  th {
    background-color: #f2f2f2;
  }

  td {
    text-align: left;
  }
  position: relative;
`,To=t=>{try{let o=new Date(t);return`${o.toLocaleDateString()} ${o.toLocaleTimeString()}`}catch{return"Error: Invalid timestamp"}},Nt=t=>{let o=Math.floor(t/1e3)%60,i=Math.floor(t/(1e3*60))%60,r=Math.floor(t/(1e3*60*60))%24,s=Math.floor(t/(1e3*60*60*24)),l="";return s>0&&(l+=`${s}d `),r>0&&(l+=`${r}h `),i>0&&(l+=`${i}m `),o>0&&(l+=`${o}s`),l.trim()};function Mt(){let[t,o]=(0,j.useState)(),i=mt(()=>{}),[r,s]=(0,j.useState)(!1);(0,j.useEffect)(()=>{(async()=>{let p=await L("/debugger/get-shortcut-prompt-data");o(p)})()},[]);let l=(0,j.useMemo)(()=>{if(!t)return;let{displayStrategy:p="auto",shortcutUsedTimestamp:n=0,...b}=t,v=Date.now(),g=i[p]||0,w=n??0+g-v;return{...b,displayStrategy:p,shortcutUsedTimestamp:To(n),"displayStrategyDuration (helper)":g?`${g} (${Nt(g)})`:"-","time to next prompt (helper)":w>0?Nt(w):"(now)"}},[t,i]);return e(f,null,e(At,{onClick:()=>s(!0)},e("span",null,"Open Shortcut Prompt Debugger")),r&&e(z,null,e(Po,null,e(T,{background:"black",onClick:()=>s(!1),style:{position:"absolute",top:"1rem",right:"1rem"}},e(ie,null)),e("h3",null,"Shortcut Prompt Debugger"),e("hr",null),e(At,{onClick:async()=>{await L("/debugger/force-enable-shortcut-prompt",{}),window.confirm("Successfully enabled shortcut prompt, want to refresh?")&&window.location.reload()},style:{display:"flex",flexDirection:"column"}},e("span",null,"Force Enable Show Shortcut Prompt")),e("table",null,e("thead",null,e("tr",null,e("td",null,"Field"),e("td",null,"Value"))),e("tbody",null,l?Object.entries(l).map(([p,n])=>e("tr",{key:p},e("td",null,p),e("td",null,`${n}`))):e("tr",null,e("td",{colSpan:2},e("span",null,"Loading..."),e("br",null),e("span",{style:{fontSize:"1rem",fontStyle:"italic"}},"If this gets stuck, consider using play shortcut at least once."))))))))}d();c();var Ot=E(P());var Bo=m(y)`
  margin-bottom: 0.5rem 0 0 0;
  text-align: center;
  &:disabled {
    cursor: not-allowed;
  }
`;function Rt(){let t=(0,Ot.useCallback)(async()=>{N.printDebugInformation()},[]);return e(Bo,{onClick:t,xAlign:"center"},"Spatial Parsing - Print Debug Info in console")}d();c();var $t=E(P());var Do=m(y)`
  margin: 0.5rem 0;
  text-align: center;
  &:disabled {
    cursor: not-allowed;
  }
`;function Vt(){let t=(0,$t.useCallback)(async()=>{yt().then(()=>{Ct()}).catch(o=>console.error(o))},[]);return e(Do,{onClick:t,xAlign:"center"},"Export Readability Data")}d();c();var Ut=E(P()),Gt=E(P());d();c();var A=E(P());d();c();var X=E(P());var Ft=E(Yt());function Io(t){return(o,...i)=>o.key==="Enter"&&t(o,...i)}var Lo=m.div`
  ${({isForRedesignedVoiceSelection:t})=>t?`
      display: flex;
      align-items: center;
      > div {
        flex: 1;
      }
      border-bottom: 1px solid ${a.brdrSec2060};
      background-color: ${a.bgPrimWB};
`:""}

  > div {
    display: flex;
    flex-direction: column;
    position: relative;
  }

  input {
    box-sizing: border-box;
    background: url('${x.runtime.getURL("/images/search-icon.svg")}') no-repeat scroll 9px 9px;
    background-size: 16px;

    ${({color:t,isForRedesignedVoiceSelection:o})=>o?`
        background-position: 16px center;
        background-color: ${a.bgPrimWB};

        padding-left: 40px;
        padding-top: 12px;
        padding-bottom: 12px;

        color: ${t??a.icnTxtPrim};

        border: none;
      `:`
        background-color: ${a.bgPrimW100};
        padding: 8px;
        padding-left: 30px;
        color: ${t??a.icnTxtPrim};
        border: 1px solid ${a.brdrSec2060};
        border-radius: 4px;
      `}
    outline: none;
    width: 100%;
    font-size: 12px;
    line-height: 16px;

    &::placeholder {
      font-size: 12px;
      line-height: 16px;
      color: ${a.icnTxtSec};
    }
  }

  @media (max-width: 500px) {
    input {
      font-size: 16px;
      background-color: #e4eaf1;
      color: #1c2c40;
      line-height: 20px;
      border: none;
      border-radius: 8px;
      padding: 8px 40px;

      &::placeholder {
        font-size: 16px;
        line-height: 20px;
        color: #587393;
      }
    }
  }

  > div > div:empty {
    display: none;
  }

  > div > div {
    position: absolute;
    left: 0;
    right: 0;
    top: calc(100% - 5px);
    background: ${a.bgPrimWB};
    z-index: 5000;
    border: none;
    border-top: none;
    max-height: 400px;
    overflow-y: auto;
    box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.05);
    border-radius: 0px 0px 5px 5px;

    max-height: ${({suggestionsMaxHeight:t})=>t};
    overflow-y: auto;

    &::-webkit-scrollbar {
      width: 8px;
    }

    &::-webkit-scrollbar-track {
      border-radius: 4px;
      background-color: ${a.bgPrimW100};
    }

    &::-webkit-scrollbar-thumb {
      border-radius: 4px;
      background-color: ${a.icnTxtQuat};
    }

    &::-webkit-scrollbar-button {
      display: none;
    }

    > ul {
      list-style-type: none;
      padding: 0;
      margin: 0;
    }

    > ul > li {
      padding: 0;
      > button {
        background: ${a.bgPrimWB};
        color: ${a.icnTxtPrim};

        padding: 12px 28px;
        border: none;
        margin: none;
        outline: none;

        text-align: left;
        cursor: pointer;
        width: 100%;
      }

      &:hover > button,
      &:focus > button,
      &.react-autosuggest__suggestion--highlighted > button {
        background: ${a.bgPrimW100};
      }
    }
  }
`,Ao=m(ce)`
  margin-top: 0px;
  margin-right: 0.75rem;
`,_t=({suggestions:t,value:o,placeholder:i,onChange:r,onBlur:s,onFocus:l=()=>{},suggestionsMaxHeight:u,color:p,isForRedesignedVoiceSelection:n,...b})=>{let[v,g]=(0,X.useState)([]),w=(0,X.useMemo)(()=>new st(t,[]),[t]);return(0,X.useEffect)(()=>{o===""&&Array.isArray(t)&&g(t)},[o,t]),e(Lo,{color:p,suggestionsMaxHeight:u,isForRedesignedVoiceSelection:n},e(Ft.default,{suggestions:v,renderSuggestion:h=>e("button",{type:"button",onClick:k=>We(r(h))(k),onKeyDown:Io(()=>r(h))},h),inputProps:{value:o,onChange:(h,{newValue:k,method:B})=>!["down","up"].includes(B)&&typeof r=="function"&&r(k),onBlur:(h,k)=>typeof s=="function"&&s(k?.highlightedSuggestion??""),onFocus:l,placeholder:i,...b},shouldRenderSuggestions:h=>t.indexOf(h)===-1,getSuggestionValue:h=>h,onSuggestionsClearRequested:()=>g([]),onSuggestionsFetchRequested:({value:h,reason:k})=>k!=="suggestions-revealed"&&g(w.search(h).sort((B,S)=>B.toLowerCase().localeCompare(S.toLowerCase())))}),n&&o.length>=1&&e(Ao,{onClick:()=>r("")}))};function jt({root:t}){let o=(0,A.useCallback)(()=>{t.remove()},[t]),[i,r]=(0,A.useState)("");return e(z,null,e(pt,null,e(T,{background:"transparent",onClick:o,style:{position:"absolute",top:"1rem",right:"1rem"}},e(Y,null)),e("h1",null,"View and Edit Feature Flag"),e(_t,{placeholder:"Search for feature flag",suggestions:Object.values(ye),value:i,onChange:s=>r(s),suggestionsMaxHeight:"250px",color:"#587393",style:{width:"100%",marginBottom:"1rem"},onBlur:s=>s}),e("div",{className:_`
            display: grid;
            grid-template-columns: 2fr minmax(0, 3fr);

            gap: 1rem;
            width: 100%;
            > * {
              font-weight: bold;
              font-size: 1.1rem;
              color: ${a.icnTxtPrimElectric};
            }
          `},e("div",null,"AB Test Name"),e("div",null,"Variant")),e(No,{searchQuery:i})))}var No=({searchQuery:t})=>{let[o,i]=(0,A.useState)(null),r=(0,A.useMemo)(()=>{if(!o)return{};let s=new Set(Object.values(ye));return Object.fromEntries(Object.entries(o).filter(([l])=>s.has(l)?t.length===0?!0:l.includes(t):!1))},[o,t]);return(0,A.useEffect)(()=>{(async()=>{let{features:s}=await L("/feature-flags/get");Object.keys(s).forEach(l=>{xe.featureFlagOverrides&&we(l)&&(s[l]=xe.featureFlagOverrides[l])}),i(s)})()},[]),o===null?e("div",{className:_`
          width: 100%;
          display: flex;
          justify-content: center;
          align-items: center;
          height: 2rem;
        `},e(Qe,null)):e("div",{className:_`
        height: 100%;
        overflow-y: auto;
        width: 100%;
        min-width: min(1000px, 100%);
        display: grid;
        grid-template-columns: 2fr 3fr;
        gap: 1rem;
        align-items: flex-start;
        > * {
          word-break: break-word;
        }
      `},Object.entries(r).map(([s,l])=>e(Mo,{key:s,k:s,v:l})))},zt="80px",Wt="8px",Mo=({k:t,v:o})=>{let[i,r]=(0,A.useState)(o),s=(0,A.useMemo)(()=>we(t),[t]),l=(0,A.useMemo)(()=>o!==i,[o,i]),u=(0,A.useCallback)(async n=>{await L("/debugger/set-feature-flag",{featureFlagName:t,variant:n}),window.confirm("Successfully set feature flag. Do you want to refresh the page?")&&window.location.reload()},[]),p=n=>{o!==n&&(r(n),u(n))};return t in Ce?e(f,null,e("div",{className:_`
            display: flex;
            align-items: center;

            label {
              align-self: flex-start;
              font-size: 0.8rem;
              color: ${a.icnTxtPrim};
              margin-left: 0.5rem;
              font-weight: bold;
              padding: 0.1rem 0.2rem;
              background: ${a.sfCrit};
              border-radius: 0.5rem;
            }
          `},e("span",null,t),s&&e("label",null,"overriden")),e("div",{className:_`
            width: calc(100% - ${zt});
          `},e("select",{disabled:s,title:`${t}-variant-select`,name:"variant",value:i,onChange:n=>p(n.target.value),className:_`
              width: 100%;
              color: ${a.icnTxtPrim};
              background: ${a.bgPrimWB};
              border-radius: 0.5rem !important;
              border-color: #f2f3ff80 !important;
              border-width: 2px !important;
              border-style: solid !important;
              background-image: none !important; // linkedin does weird thing on label
            `},Ce[t].map(n=>e("option",{key:n,value:n},n))))):e(f,null,e("div",null,t),e("div",{className:_`
          width: 100%;
          display: flex;
          justify-content: space-between;
          input {
            flex: 1;
            width: 100%;
            border-radius: 0.5rem !important;
            border-color: #f2f3ff80 !important;
            border-width: 2px !important;
            border-style: solid !important;
            background: ${a.bgPrimWB} !important;
            color: ${a.icnTxtPrim};
          }
          button {
            width: calc(${zt} - ${Wt} * 2);
            margin: 0 ${Wt};
            text-align: center;
            display: flex;
            justify-content: center;
            align-items: center;
          }
          button:disabled {
            opacity: 0.5;
          }
        `},e("input",{value:i,onChange:n=>r(n.target.value)}),e(y,{disabled:!l,onClick:()=>u(i)},"Save")))};var Oo=m(y)`
  margin: 0;
  text-align: center;
  &:disabled {
    cursor: not-allowed;
  }
  background: ${a.sfCrit};
`,Ro="speechify-debugger-modal";function qt(){let t=(0,Ut.useCallback)(()=>{let o=document.createElement("div");o.id=Ro,(0,Gt.render)(e(jt,{root:o}),o),document.body.appendChild(o)},[]);return e(Oo,{onClick:t,xAlign:"center",color:a.icnTxtPrim},"View and Edit Feature Flags")}var $o=m($)`
  flex-direction: column;
  padding: 16px 0px;
  margin-bottom: 16px;
`;function Ae({onMinimizeClick:t}){let{actions:o,updateAction:i}=ge(r=>({actions:r.actions,updateAction:r.updateAction}));return e($o,null,Object.entries(o).map(([r,{enabled:s}])=>e($,{key:r,style:{gap:"8px",justifyContent:"space-between",marginTop:"8px"}},e(F,{fontSize:"14px"},r),e(se,{checked:s,onChange:()=>i(r,{enabled:!s})}))),e(kt,null),e(Lt,{onMinimizeClick:t}),e(qt,null),e(Bt,null),e(Rt,null),e(Vt,null),e(Et,null),e(Mt,null),e(Tt,null))}function Ne({root:t}){let{actions:o}=ge(p=>({actions:p.actions})),[i,r]=te(!0),s=()=>r(!i),l=()=>ne("destroy",{},"debugger"),u=$e(()=>qe({key:"debugger-emotion-cache",container:t}),[t]);return e(Ye,{value:u},e(ut,{column:!0},!i&&e(f,null,Object.entries(o).map(([,{enabled:p,render:n}])=>n({enabled:p})),e(Ae,{onMinimizeClick:s})),e(gt,{isMinimized:i,onClick:s,onClose:l})))}var Me;function Vo(){if(!Me){let o=document.createElement("div");o.id="speechify-debugger",o.style.cssText="position: fixed; bottom: 32px; left: 32px; z-index: 999999999",document.body.appendChild(o),Me=o.attachShadow({mode:"open"})}let t=document.createElement("div");return t.id="speechify-debugger-root",Me.appendChild(t),G(e(Ne,{root:t}),t),()=>{G(()=>null,t)}}export{Vo as default};
//# sourceMappingURL=init-ZID6XH4X.js.map
