import{a as Ci,b as bi,c as xi}from"./chunk-L466EF2O.js";import{a as Wo,d as Pi}from"./chunk-7FGM3MKG.js";import{a as Ti}from"./chunk-Q4YKR5OJ.js";import{a as Si,b as Ei}from"./chunk-YORI6CWH.js";import{a as pi,b as fi,c as pt,d as $,e as gi,f as hi}from"./chunk-Z35E3KWV.js";import"./chunk-F6QDPILS.js";import"./chunk-CXWBUGW7.js";import{b as yi}from"./chunk-GBP5AYAV.js";import{a as di}from"./chunk-7XGTX76V.js";import"./chunk-FD2XQWPC.js";import{a as Ie,c as je}from"./chunk-3UDU62CH.js";import{a as ai}from"./chunk-FKJPRJ46.js";import"./chunk-5PO6RROQ.js";import{E as eo,a as oi,l as ei,s as ni}from"./chunk-43GP4A7N.js";import"./chunk-MBHSJ34F.js";import{a as No}from"./chunk-DMUXVFIA.js";import{a as ti}from"./chunk-Z3E43XMU.js";import{b as ii,c as ri}from"./chunk-BN5XPDNR.js";import{a as _o}from"./chunk-YYPSUSZQ.js";import"./chunk-56NWWOIX.js";import"./chunk-EF43U47C.js";import{A as Ve,B as Ge,C as oo,D as Ye,E as ze,F as mt,G as Ke,H as Xe,I as Mo,J as qe,K as Ze,L as to,M as E,a as we,b as Re,c as Ae,d as Oe,e as st,f as Be,g as Le,h as wo,i as Me,j as Ne,k as Ro,l as Ao,m as _e,n as Oo,o as lt,p as ut,q as ke,t as Bo,u as Lo,v as De,w as Fe,x as Ue,y as We,z as $e}from"./chunk-GWCIFOLA.js";import{c as ve}from"./chunk-NK4CKTAC.js";import{a as oe,b as te,d as ne,e as Ce,f as be,g as xe,o as Te,p as at,q as H}from"./chunk-KO4WPNRU.js";import{a as Se,c as Ee}from"./chunk-F5622KQ7.js";import"./chunk-WC6QURV6.js";import"./chunk-TIGAXALM.js";import{a as ie}from"./chunk-ZQRXZJGY.js";import"./chunk-6S4AP2UG.js";import{a as ae,b as se,d as go,f as le,i as ue,k as me,l as ce,m as de,n as pe,o as fe,p as ge,q as he,s as ye,t as nt,u as Pe}from"./chunk-O3LC63CS.js";import{a as Ht}from"./chunk-AG3QEKLJ.js";import"./chunk-C4ZBMBCR.js";import{B as Yt,Ba as Zt,Cd as no,Db as Je,Dd as X,Ea as rt,Fc as ct,Fd as Uo,G as zt,L as et,Na as Io,Oa as I,Oc as w,Pc as O,Qb as Qe,Sb as He,Ta as z,Va as b,Wa as P,Xb as si,Xc as dt,Yb as li,Z as Kt,bc as ui,bd as Do,cd as ci,d as Ut,e as Wt,fa as tn,fd as ro,gb as Q,i as $t,kc as io,la as it,lc as ho,mb as re,mc as yo,qc as mi,rc as ko,ud as Fo,xa as J,ya as qt}from"./chunk-RISKGE32.js";import{R as Vt,S as tt,T as Gt,ca as Xt,ja as po}from"./chunk-6O6MLDWR.js";import{a as ot,b as Y,c as jt,g as Jt,i as Qt,j as fo,k as p,l as ee,m as K}from"./chunk-F4AZU7R4.js";import{g as v}from"./chunk-GQY3J744.js";import{d as T,f as h,g as a,i as o,j as f,k as Ho,m as on,n as s}from"./chunk-CLPINNGF.js";s();a();on();s();a();var x=T(v());s();a();var V=T(v()),en=["click","contextmenu","dblclick","mousedown","mouseenter","mouseleave","mousemove","mouseout","mouseover","mouseup","wheel"];function ft(t=en){let[e,i]=(0,V.useState)(null),n=(0,V.useRef)(t);n.current=t;let r=(0,V.useCallback)(l=>{l.target?.className?.includes?.("react-switch-")||(l.stopPropagation(),l.stopImmediatePropagation())},[]);return(0,V.useEffect)(()=>{if(e)return n.current.forEach(l=>e.addEventListener(l,r)),()=>n.current.forEach(l=>e.removeEventListener(l,r))},[e,r]),i}s();a();var rn=(t,e,i)=>{t.style.top=`${Math.min(Math.max(e.clientY-i,0),window.innerHeight-t.clientHeight)}px`},nn=(t,e,i)=>{t.style.bottom=`${Math.min(Math.max(window.innerHeight-t.offsetHeight-e.clientY+i,0),window.innerHeight-t.clientHeight)}px`};var an=(t,e,i)=>{t.style.right=`${Math.min(Math.max(window.innerWidth-t.offsetWidth-e.clientX+i,0),window.innerWidth-t.clientWidth)}px`};function vi(t,{onDrag:e}={}){let i=0,n=0,r,l=!1;function u(m){let y={x:m.clientX,y:m.clientY},C=Math.sqrt((r.x-y.x)**2+(r.y-y.y)**2);!l&&C<16||(m.preventDefault(),l=!0,t.style.top?rn(t,m,n):t.style.bottom&&nn(t,m,n),an(t,m,i),typeof e=="function"&&e(t.getBoundingClientRect()))}function d(m){l&&(l=!1,m.stopPropagation(),t.removeEventListener("click",d,!0))}function g(m){return m.preventDefault(),document.removeEventListener("mouseup",g),document.removeEventListener("mousemove",u),!1}function c(m){m.target.tagName==="INPUT"||m.which!==1||(n=m.clientY-t.getBoundingClientRect().top,i=m.clientX-t.getBoundingClientRect().left,r={x:m.clientX,y:m.clientY},document.addEventListener("mousemove",u),document.addEventListener("mouseup",g),t.addEventListener("click",d,!0))}t.addEventListener("mousedown",c)}s();a();var wi=T(v());var sn=({enabled:t,onClick:e})=>o(Oe,{enabled:t,onClick:e},t?o(ae,null):o(se,null),o("span",null,t?"On":"Off"));function ln({showOnRight:t,triggerSource:e}){let{isEnabled:i,toggle:n}=bi(),{current:r,NotificationBoard:l}=ro({componentOnly:!0});(0,wi.useEffect)(()=>{let g=async()=>{await no("introduce-ai-autoplay"),await X({allowPointerActions:!0,component:!0,duration:0,id:"introduce-ai-autoplay",priority:101,showOnMobile:!1,timeSensitive:!0,render:()=>o(xi,null)}),w("extension_usage_new_user_eduction_prompt_shown",{prompt:"introduce-ai-autoplay"})};e==="introduce-ai-autoplay"&&g()},[e]);let u=async()=>{(await Uo("introduce-ai-button")).displayCount===0===!0&&await X({allowPointerActions:!0,component:!0,duration:0,id:"introduce-ai-button",priority:101,showOnMobile:!1,timeSensitive:!0,render:()=>o(Ci,null)})};return o(f,null,o(E,{visible:!0,showOnRight:t,text:"Autoplay responses"},o(sn,{enabled:i,onClick:()=>{i&&u(),n()}})),o(un,{showOnRight:t,showPointer:!0,visible:r?.id==="introduce-ai-autoplay"},o(Bo,null,o(l,null))))}var un=p(Lo)`
  overflow: visible;
  top: 0;

  ${({showPointer:t})=>t?`
      &::before {
        content: '';
        position: absolute;
        top: 12px;
        right: -5px;
        width: 12px;
        height: 12px;
        background: #1e1e1e;
        transform: rotate(45deg);
        box-shadow: 0px 0px 0px 0px rgba(106, 120, 252, 0.5),
                    0px 0px 2px 0px rgba(106, 120, 252, 0.49),
                    0px 0px 3px 0px rgba(106, 120, 252, 0.43),
                    0px 0px 4px 0px rgba(106, 120, 252, 0.25),
                    0px 0px 4px 0px rgba(106, 120, 252, 0.07),
                    0px 0px 5px 0px rgba(106, 120, 252, 0.01);
      }
      
      
      &::after {
        content: '';
        position: absolute;
        top: 7px;
        right: 1px;
        width: 32px;
        height: 27px;
        background: #1e1e1e;
      }
    `:""}
`,Ri=ln;s();a();var yt=T(v());var mn=["playing","buffering"],Ai=({isPDF:t})=>{let e=I.useTime(),i=I.usePlayingState(),n=(0,yt.useMemo)(()=>mn.includes(i),[i]),r=(0,yt.useMemo)(()=>{if(e.isLoading===!0)return{isLoading:!0};let g=e.totalEstimatedDuration,c=e.currentTime,m=Math.max(0,g-c),y=m===0&&!n?g:m,C=Math.floor(y/3600),R=Math.floor(y%3600/60),N=t?"":Gt("short")(y);return{isLoading:!1,hours:C,minutes:R,durationText:N}},[n,e]);if(r.isLoading===!0)return o(Oo,{style:{height:"0px"}});let{hours:l,minutes:u,durationText:d}=r;return l===0?o(Oo,{style:{height:d?"20px":"0"}},o(ut,{"aria-label":b("DURATION IN MINS"),"data-testid":P.DURATION_MINS,className:"left"},d?d.split(":")[0]:""," "),d?o(_e,null,":"):null,o(ut,{"aria-label":b("DURATION IN SECS"),"data-testid":P.DURATION_SECS,className:"right"},d?d.split(":")[1]:""," ")):o(Oo,{style:{height:d?"20px":"0"}},o(Q,{bold:!0,fontSize:"12px",lineHeight:"20px",fixedWidthNumbers:!0},l,o(lt,{"aria-label":b("DURATION IN HOURS"),"data-testid":P.DURATION_HOURS},"h"),u<10?"0":"",u,o(lt,{"aria-label":b("DURATION IN MINS"),"data-testid":P.DURATION_MINS},"m")))};s();a();function $o(){let t=window.location.hostname,e=window.location.pathname;_o()&&Qe.toggleFeatureOnDomain("pill-player",!1),w("extension_pill_player_dismissed",{type:"domain",domain:t,pathname:e})}s();a();var Co=T(v());s();a();var Li=T(v());s();a();var ao=T(v());s();a();var Pt=p.div`
  cursor: pointer;
  position: absolute;
  right: 10px;
  top: 10px;

  svg {
    fill: #afb9c8;
  }
`,Ct=p.div`
  background-color: #111112;
  border-radius: 12px;
  color: #fff;
  display: flex;
  flex-direction: column;
  font-family: ABCDiatype, sans-serif;
  min-width: 460px;
  padding: ${({padding:t})=>t};
  position: relative;
  box-shadow: 0px 12px 48px -16px rgba(0, 0, 0, 0.24);
`,Oi=p.div`
  align-items: center;
  background-color: rgba(5, 7, 11, 0.5);
  display: flex;
  height: 100vh;
  justify-content: center;
  left: 0;
  position: fixed;
  top: 0;
  width: 100vw;
  z-index: 2147483645;
`,Vo=p.div`
  background: #fff;
  border-radius: 12px;
  height: 240px;
  overflow: hidden;
  width: 306px;
  z-index: 1;
`,Bi=p(ii)`
  border-radius: 12px;
  width: 100%;
`,Go=p.p`
  font-size: 16px;
  font-weight: 500;
  line-height: 24px;
  margin: 12px 0 0px 0;
  text-align: ${({alignItems:t})=>t};
`,Yo=p.h3`
  font-size: 24px;
  font-weight: 700;
  line-height: 28px;
  max-width: 440px;
  margin: 0 0 0 0;
  overflow: hidden;
  text-align: left;
  text-overflow: ellipsis;
  white-space: nowrap;
`;var dn=4e3,zo=t=>{let e=(0,ao.useRef)(null),[i,n]=(0,ao.useState)();return(0,ao.useEffect)(()=>()=>clearTimeout(i)),o(Bi,{ref:e,onEnded:()=>{n(window.setTimeout(()=>e.current?.play(),dn))},...t})};var Mi=({hostIcon:t,handleSubmit:e})=>{let i=(0,Li.useMemo)(()=>io(),[]);return o(wo,{aligned:"center"},o(Yo,null,"Player Hidden"),o(Ro,null,t&&o("img",{alt:i,src:t}),o(Ao,null,i)),o(Go,{alignItems:"center"},"To bring the player back, click on the extension",o("br",null),"icon in your browser’s toolbar."),o(Vo,null,o(zo,{src:"turn-on-extension-animation.webm",autoPlay:!0,muted:!0})),o(Mo,null,o(Ne,{type:"submit",onClick:e,width:"160px","data-testid":P.GOT_IT},"Got it")))};s();a();var Z=T(v());s();a();var pn=()=>o("svg",{width:"12",height:"10",viewBox:"0 0 12 10",fill:"none",xmlns:"http://www.w3.org/2000/svg",style:{position:"absolute",top:2,left:1}},o("path",{d:"M4.85337 8.81371C4.5067 9.16038 3.9467 9.16038 3.60004 8.81371L0.408926 5.6226C0.0622591 5.27593 0.0622591 4.71593 0.408926 4.36927C0.755592 4.0226 1.31559 4.0226 1.66226 4.36927L4.22226 6.92927L10.3378 0.813711C10.6845 0.467044 11.2445 0.467044 11.5911 0.813711C11.9378 1.16038 11.9378 1.72038 11.5911 2.06704L4.85337 8.81371Z",fill:"black"})),fn=p.div`
  display: flex;
  align-items: center;
  gap: 8px;
`,gn=p.span`
  position: relative;
  box-sizing: border-box;

  width: 16px;
  height: 16px;
  border-radius: 4px;

  border: 1.5px solid ${({checked:t})=>t?"#ffffff":"#747580"};
  background: ${({checked:t})=>t?"#ffffff":"unset"};

  &:hover {
    background: ${({checked:t})=>t?"#ffffff":"#3c3c3e"};
    border: 1.5px solid #ffffff;
  }
`,hn=p.input`
  opacity: 0.01;
  margin: 0;
  width: 16px;
  height: 16px;
  position: relative;
  top: -1.5px;
  left: -1.5px;
`,Ni=({label:t,style:e,...i})=>o(fn,{style:e},o(gn,{checked:i.checked},i.checked&&o(pn,null),o(hn,{type:"checkbox",...i})),t&&o("label",{htmlFor:i.id},t));var _i=({hostIcon:t,onDismiss:e,showConfirmation:i})=>{let[n,r]=(0,Z.useState)(!1),[l,u]=(0,Z.useState)(!1),d=(0,Z.useMemo)(()=>io(),[]);(0,Z.useEffect)(()=>{(async()=>{let y=await $t();ci(y)&&u(!0)})()},[]);let g=()=>{e()};return o(f,null,o(Me,null,o(wo,{aligned:"left"},o(Yo,null,"Hide Speechify Player on"),o(Ro,null,t&&o("img",{alt:d,src:t}),o(Ao,null,d)),o(Go,{alignItems:"left"},"To further personalize and customize",o("br",null),"your listening experience, including",o("br",null),"playback and highlighting options, go to",o("br",null),"settings.",o(Ni,{id:"dont-show-modal-again",checked:n,onChange:m=>r(m.target.checked),label:"Don't show this again",style:{marginTop:"32px"}}))),o(Vo,null,o(zo,{src:"turn-off-extension-animation.webm",autoPlay:!0,muted:!0}))),o(Xe,null,o(H,{type:"button",className:"settings",onClick:()=>{po("show-settings-modal"),e()},width:"187px","aria-label":b("GO_TO_SETTINGS"),"data-testid":P.GO_TO_SETTINGS,style:{visibility:l?"visible":"hidden"}},o(ei,null),"Settings"),o(Mo,null,o(H,{type:"button",onClick:g,width:"95px","aria-label":b("CANCEL_TURNOFF"),"data-testid":P.CANCEL_TURNOFF},"Cancel"),o(H,{type:"submit",onClick:()=>i(n),width:"194px","aria-label":b("HIDE_PLAYER"),"data-testid":P.HIDE_PLAYER},"Hide Player"))))};s();a();var Po=Xt(Je({isModalShown:!1},t=>({showModal:()=>t({isModalShown:!0}),hideModal:()=>t({isModalShown:!1})})));var ki=()=>{let t=Po(c=>c.isModalShown),[e,i]=(0,Co.useState)(null),[n,r]=(0,Co.useState)(!1),l=Po(c=>c.hideModal);(0,Co.useEffect)(()=>{(async()=>{let m=io(),{icon:y}=await Wt("/helpers/get-domain-icon",{domain:m});y&&i(y)})()},[]);let u=()=>{n&&$o(),r(!1),l()},d=c=>{c?.target===c?.currentTarget&&u()};Fo(document.querySelector("#speechify-pill-player"),u);let g=c=>{r(!0),Kt(c)};return t?o(Oi,{onClick:d},n?o(Ct,{padding:"32px 28px 32px 28px"},o(Pt,{onClick:u},o(go,{fill:"#AFB9C8",width:32,height:32})),o(Mi,{handleSubmit:u,hostIcon:e})):o(Ct,{padding:"65px 82px 50px 82px"},o(Pt,{"aria-label":b("TURNOFF_SPEECHIFY_WINDOW_CLOSE_BUTTON"),"data-testid":P.TURNOFF_SPEECHIFY_WINDOW_CLOSE_BUTTON,onClick:l},o(go,{width:32,height:32})),o(_i,{hostIcon:e,onDismiss:l,showConfirmation:g}))):null};s();a();var Ko=T(v());var Fi=T(tn());var Di=t=>{let e=t.getBoundingClientRect().top,i=window.innerHeight/2;return e<i?"up":"down"};function Ui(){let[t,e]=(0,Ko.useState)("up"),{activeElement:i,activeScrollElement:n}=di(),r=yo()?SVGGElement:HTMLElement;return(0,Ko.useEffect)(()=>{if(i instanceof r&&n){let l=n,u=(0,Fi.default)(()=>{i.isConnected&&e(Di(i))},200);return i.isConnected&&e(Di(i)),l.addEventListener("scroll",u,{capture:!0}),()=>{l.removeEventListener("scroll",u,{capture:!0})}}},[i,n]),t}s();a();var B=T(v());function Wi({checkIsMouseOut:t,onMouseOut:e}){let i=(0,B.useRef)(t);i.current=t;let n=(0,B.useRef)(e);n.current=e;let[r,l]=(0,B.useState)(!0),[u,d]=(0,B.useState)(!1);(0,B.useEffect)(()=>{if(!r)return;let m=window.setTimeout(()=>d(!1),250);return()=>clearTimeout(m)},[r]),(0,B.useEffect)(()=>{u||n.current()},[u]);let g=(0,B.useCallback)(()=>{i.current()&&l(!0)},[]),c=(0,B.useCallback)(()=>{d(!0),l(!1)},[]);return{isMouseOver:u,handleMouseOver:c,handleMouseOut:g,setIsMouseOut:l}}s();a();s();a();var $i=({removeNotification:t,onRefresh:e})=>o(re,{removeNotification:t},o(z,{column:!0,xAlign:!0,separation:"12px"},o(z,{yAlign:"start",separation:"12px"},o(bn,null,o(be,{color:"#FA0F19"})),o(Cn,null,"The player didn’t load correctly. Please refresh it.")),o(Pn,{onClick:()=>{t(),e?.()}},"Refresh"))),Pn=p(H)`
  font-family: var(--font-family)
  font-style: normal;
  font-weight: 500;
  font-size: 14px;
  line-height: 20px;

  display: flex;
  align-items: center;
  text-align: center;
  letter-spacing: 0.01em;

  width: 100%;
  justify-content: center;
`,Cn=p(Q)`
  font-family: var(--font-family)
  font-style: normal;
  font-size: 14px;
  line-height: 20px;
  letter-spacing: 0.01em;
`,bn=p("div")`
  width: 20px;
  height: 20px;
`;var Vi=T(v());function Gi(){let t=I.usePlayingState();(0,Vi.useEffect)(()=>{if(t!=="errored"&&no("player-error"),!["stopped","paused"].includes(t))return()=>{I.getPlayingState()==="errored"&&X({id:"player-error",priority:100,duration:0,showOnMobile:!0,timeSensitive:!0,render:({dismiss:e})=>o($i,{removeNotification:e})})}},[t])}s();a();var D=T(v()),Xo=ot.speechifyWebApp.baseUrl;function Yi(t,e){let{docTitle:i}=Wo(),[n,r]=(0,D.useState)(0),l=No();(0,D.useEffect)(()=>{if(!e||t)return;let m=h.runtime.connect();m.onMessage.addListener(r),m.postMessage({domain:"com.speechify.pdf",fnName:"getPdfSize",payload:{href:document.location.href}})},[e]);let u=(0,D.useMemo)(()=>document.location.href.startsWith("file://")||n>25*1e3*1e3,[n]),d=(0,D.useMemo)(()=>!(ho()||mi()||t||e&&u),[t,e,u]),g=(0,D.useMemo)(()=>{if(u)return Xo;let m=new URLSearchParams(window.location.search).get("url")??document.location.href;return`${Xo}/importFile?type=pdf&url=${encodeURIComponent(m)}`},[u]),c=(0,D.useCallback)(()=>{if(ho()&&i){K(`${Xo}?importService=google-drive&importFilename=${i}`);return}if(!d){K(ee("?importModal=true",ot.speechifyWebApp.baseUrl));return}l&&!Do(l)?(w("extension_pdf_import_click",{href:document.location.href}),K(g)):K(Xo)},[d,l,i]);return{canSaveToMobile:d,saveToMobile:c}}s();a();var nr=T(v());s();a();var A=T(v());function qo(){let[t,e]=(0,A.useState)(!1),[i,n]=(0,A.useState)(!1),r=(0,A.useRef)(!1),{current:l}=ro(),{shortcuts:u}=eo(),d=(0,A.useMemo)(()=>{let c=u["open-screenshot-mode"]?.shortcut,y=(i?`No Text Detected.
Try Capture & Listen.`:"Capture & Listen").split(`
`).map((C,R)=>o(A.Fragment,{key:R},R>0&&o("br",null),C));return o("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center"}},o("div",null,y),c&&o(to,{keys:c}))},[i,u]),g=(0,A.useCallback)(()=>{e(!1)},[]);return(0,A.useEffect)(()=>{let c;return l?.id==="pill_player-ocr-recommendation"?(n(!0),r.current||(r.current=!0,e(!0),c=setTimeout(()=>{g()},3e3))):n(!1),()=>{c&&clearTimeout(c)}},[l]),{closeTooltip:g,forceShowTooltip:t,noTextDetected:i,tooltipContent:d}}s();a();s();a();var or=T(v());s();a();var bt=T(v());var xn=100,Sn=100,En=50,Ki=50,Xi=50;function qi({className:t,counterClockwise:e,dashRatio:i,pathRadius:n,strokeWidth:r,xOffset:l=0,yOffset:u=0}){return o("path",{className:t,d:Tn({pathRadius:n,counterClockwise:e,positionX:Ki+l,positionY:Xi+u}),fillOpacity:0,strokeWidth:r,style:Object.assign({},vn({pathRadius:n,dashRatio:i,counterClockwise:e}))})}function Tn({pathRadius:t,counterClockwise:e,positionX:i=Ki,positionY:n=Xi}){let r=t,l=e?1:0;return`
      M ${i},${n}
      m 0,-${r}
      a ${r},${r} ${l} 1 1 0,${2*r}
      a ${r},${r} ${l} 1 1 0,-${2*r}
    `}function vn({counterClockwise:t,dashRatio:e,pathRadius:i}){let n=Math.PI*2*i,r=(1-e)*n;return{strokeDasharray:`${n}px ${n}px`,strokeDashoffset:`${t?-r:r}px`}}var In=p.div`
  width: ${({size:t})=>t??"24px"};
  height: ${({size:t})=>t??"24px"};
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  position: relative;
`,wn=p.svg`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  vertical-align: middle;
  display: flex;
  align-items: center;

  .CircularProgressBarPath {
    stroke: #4759f7;

    &.AiCircularProgressBarPath {
      stroke: url(#aiProgressGradient);
    }
  }

  .CircularProgressBarTrail {
    stroke: #2d2d2f;
  }
  .CircularProgressBarBackground {
    fill: #4759f7;

    &.AiCircularProgressBarBackground {
      fill: url(#aiProgressGradient);
    }
  }

  &:hover {
    .CircularProgressBarPath {
      stroke: #4454e3;

      &.AiCircularProgressBarPath {
        stroke: url(#aiProgressGradientHover);
      }
    }
    .CircularProgressBarBackground {
      fill: #4454e3;

      &.AiCircularProgressBarBackground {
        fill: url(#aiProgressGradientHover);
      }
    }
  }

  &:active {
    .CircularProgressBarPath {
      stroke: #3d4ac4;

      &.AiCircularProgressBarPath {
        stroke: url(#aiProgressGradientActive);
      }
    }
    .CircularProgressBarBackground {
      fill: #3d4ac4;

      &.AiCircularProgressBarBackground {
        fill: url(#aiProgressGradientActive);
      }
    }
  }
`,Rn=p(qi)`
  stroke-linecap: round;
`,An=p(qi)`
  transition: stroke-dashoffset 0.5s ease 0s;
`,On=t=>{let{circleRatio:e=1,counterClockwise:i=!1,maxValue:n=100,minValue:r=0,strokeWidth:l=24,value:u=0,size:d="24px",variant:g="speechify"}=t,c=(0,bt.useMemo)(()=>En-l/2,[l]),m=(0,bt.useMemo)(()=>(Math.min(Math.max(u,r),n)-r)/(n-r),[u,r,n]);return o(In,{size:d},o(wn,{viewBox:`0 0 ${xn} ${Sn}`,"data-test-id":"CircularProgressbar"},o("defs",null,o("linearGradient",{id:"aiProgressGradient",x1:"0%",y1:"0%",x2:"100%",y2:"0%"},o("stop",{offset:"0%",stopColor:"#EA6AFF"}),o("stop",{offset:"100%",stopColor:"#6B78FC"})),o("linearGradient",{id:"aiProgressGradientHover",x1:"0%",y1:"0%",x2:"100%",y2:"0%"},o("stop",{offset:"0%",stopColor:"#E055F5"}),o("stop",{offset:"100%",stopColor:"#5F6DEF"})),o("linearGradient",{id:"aiProgressGradientActive",x1:"0%",y1:"0%",x2:"100%",y2:"0%"},o("stop",{offset:"0%",stopColor:"#D640EB"}),o("stop",{offset:"100%",stopColor:"#5362E2"}))),o(Rn,{counterClockwise:i,dashRatio:e,pathRadius:c,strokeWidth:l,className:"CircularProgressBarTrail"}),o(An,{counterClockwise:i,dashRatio:m*e,pathRadius:c,strokeWidth:l,className:["CircularProgressBarPath",g==="ai"?"AiCircularProgressBarPath":""].filter(Boolean).join(" ")})))},Zi=On;s();a();s();a();var ji=t=>o("svg",{"aria-label":b("PILL_PLAYER_REPEAT_ICON"),"data-testid":P.PILL_PLAYER_REPEAT_ICON,width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg",...t},o("g",{id:"icons/20"},o("path",{id:"Union","fill-rule":"evenodd","clip-rule":"evenodd",d:"M12.3391 5.13296C11.4074 3.72588 9.81131 2.79995 8.00001 2.79995C5.12813 2.79995 2.80001 5.12807 2.80001 7.99995C2.80001 10.8718 5.12813 13.1999 8.00001 13.1999C10.6694 13.2 12.87 11.1879 13.1661 8.5981C13.2162 8.15913 13.6128 7.84396 14.0518 7.89415C14.4907 7.94434 14.8059 8.34088 14.7557 8.77985C14.3683 12.1684 11.492 14.7999 8.00001 14.7999C4.24447 14.7999 1.20001 11.7555 1.20001 7.99995C1.20001 4.24441 4.24447 1.19995 8.00001 1.19995C10.2023 1.19995 12.159 2.24698 13.4011 3.86822V2.83237C13.4011 2.39054 13.7593 2.03237 14.2011 2.03237C14.6429 2.03237 15.0011 2.39054 15.0011 2.83237V5.93296C15.0011 6.37479 14.6429 6.73296 14.2011 6.73296L11.1005 6.73296C10.6587 6.73296 10.3005 6.37479 10.3005 5.93296C10.3005 5.49113 10.6587 5.13296 11.1005 5.13296L12.3391 5.13296Z",fill:"white"})));var Ji=(t,e,i,n)=>t==="playing"?Ee:n&&e&&i?he:n&&!e?ie:t==="errored"?xe:t==="ended"?ji:Se,Qi=(t,e,i,n)=>t==="playing"?"pause":n&&e&&i?"stop":n&&!e?"loading":t==="errored"?"alert":t==="ended"?"repeat":"play";s();a();s();a();var xt=()=>Y.sfPrimCta,Hi=p(z)`
  // Reset button styles
  outline: none;
  border: none;

  background-color: ${({background:t,secondary:e})=>e?"transparent":t??xt()};
  padding: ${({padding:t})=>t??"8px 16px"};
  cursor: pointer;
  border-radius: ${({borderRadius:t})=>t??"8px"};
  box-shadow: rgba(109, 117, 141, 0.2) 0 0 2px;
  color: ${({color:t,secondary:e,background:i})=>e?i??xt():t??Y.icnTxtPrim};
  ${({secondary:t,background:e})=>t&&`border: 2px solid ${e??xt()}`};

  // For a tag
  text-decoration: none;
  box-sizing: border-box;
`.withComponent("button");var St=p(Hi)`
  border-radius: 20px;

  margin: 0;
  padding: 8px 12px;

  font-size: 12px;
  height: 40px; // Fixed height necessary for animations
  width: 100%;
`;St.defaultProps={xAlign:!0,yAlign:!0};var Et=()=>Y.sfPrimCta,Bn=()=>fo`
 0% {
   transform: scale(.95);
   box-shadow: 0 0 0 0 ${Et()}80;
 }
 70% {
   transform: scale(1);
   box-shadow: 0 0 0 12px ${Et()}00;
 }
 100% {
   transform: scale(.95);
   box-shadow: 0 0 0 0 ${Et()}00;
 }
`,Ln=()=>Qt`
  animation: ${Bn()} 1.5s infinite;
`,Mn=p(St)`
  ${({expanded:t,simple:e,minimal:i,pill:n,isPlayIconActive:r})=>t?"margin-right: 12px;":e?"width: 28px !important; height: 28px; border-radius: 50%;":i?"width: 36px !important; height: 36px; border-radius: 50%;":n?"width: 32px !important; height: 32px; border-radius: 50%;"+(r?"> svg { transform: translateX(1px); }":""):"width: 48px !important; height: 48px; border-radius: 50%;"};

  > span {
    white-space: nowrap;
  }

  svg {
    transition: 0.2s min-width;
    min-width: ${({expanded:t})=>t?"18px":"28px"};
    color: ${({centerWhite:t})=>t?Y.icnTxtPrim:Y.icnTxtPrimInv};
  }

  ${({glow:t})=>t&&Ln};

  &:hover {
    scale: ${({minimal:t})=>t?"1.11":""};
  }
`,Nn=p.div`
  position: absolute;
  width: 36px;
  height: 36px;
`,tr=({children:t,expanded:e,glow:i,minimal:n,onClick:r,onMouseEnter:l,onMouseLeave:u,pill:d,progress:g=0,simple:c,state:m,playingHasStarted:y,variant:C="speechify",...R})=>{let[N,G]=(0,or.useState)(!1),uo=Ji(m,d,N,R.isLoading),bo=Qi(m,d,N,R.isLoading)==="play",mo=b(m==="playing"?"PAUSE_BUTTON":"PLAY_BUTTON"),S=m==="playing"?P.PAUSE_BUTTON:P.PLAY_BUTTON;return o(f,null,o(Mn,{"aria-label":mo,"data-testid":S,expanded:e,glow:i&&e,minimal:n,onClick:it(r),onMouseEnter:()=>{G(!0),l?.()},onMouseLeave:()=>{G(!1),u?.()},onTouchEnd:it(r),pill:d,simple:c,isPlayIconActive:bo,...R},d&&y&&o(Nn,null,o(Zi,{maxValue:100,minValue:0,size:"36px",strokeWidth:8,value:g*100,variant:C})),o(uo,{size:c?"16px":n||d?"20px":"24px"}),t),R.isLoading&&!N&&o(ti,{variant:C}))};var _n="#4759F7",kn="#4454E3",Dn="#3D4AC4",er="linear-gradient(180deg, #EA6AFF 0%, #6B78FC 100%)",Fn="linear-gradient(180deg, #E055F5 0%, #5F6DEF 100%)",Un="linear-gradient(180deg, #D640EB 0%, #5362E2 100%)",Wn="transparent",$n="#2D2D2F",ir="#3C3C3E",Vn="#FFFFFF",Gn="#FFFFFF",Yn="#FFFFFF",zn="#FFFFFF",Kn="#FFFFFF",Xn="#C7C7C7",qn="#4759F7",Zn="#747580",jn="#5E5F68",Jn="#747580",rr=p(tr)`
  > svg {
    ${({playingHasStarted:t})=>t&&`fill: ${Vn};`}
    ${({isLoading:t,disabled:e})=>(t||e)&&`fill: ${zn};`}
    max-height: ${({state:t})=>t==="playing"?"16px":"18px"};
  }

  background: ${({variant:t})=>t==="ai"?er:_n};

  ${({playingHasStarted:t})=>t&&`background: ${Wn};`}
  ${({disabled:t})=>t&&`background: ${Jn}; cursor: default;`}
  ${({isLoading:t,variant:e})=>t&&`background: ${e==="ai"?er:qn};`}

  &:hover {
    background: ${({playingHasStarted:t,variant:e})=>t?$n:e==="ai"?Fn:kn};

    ${({isLoading:t,disabled:e})=>(t||e)&&`background: ${Zn};`}

    & > svg {
      ${({playingHasStarted:t})=>t&&`fill: ${Gn};`}
      ${({isLoading:t,disabled:e})=>(t||e)&&`fill: ${Kn};`}
    }
  }

  &:active {
    background: ${({variant:t})=>t==="ai"?Un:Dn};

    ${({playingHasStarted:t})=>t&&`background: ${ir};`}

    ${({isLoading:t,disabled:e})=>(t||e)&&`background: ${jn};`}

     & > svg {
      ${({playingHasStarted:t})=>t&&`fill: ${Yn};`}
      ${({isLoading:t,disabled:e})=>(t||e)&&`fill: ${Xn};`}
    }

    .CircularProgressBarTrail {
      stroke: ${ir};
    }
  }
`;var Qn=Ie()==="mac";function ar({isDisabled:t,isPDF:e,onClick:i,saveToMobile:n,showSettingsOnRight:r}){let{noTextDetected:l,tooltipContent:u}=qo(),{docTitle:d}=Wo(),{shortcuts:g}=eo(),c=I.useTime(),m=I.useProgress(),y=I.usePlayingState(),C=I.useCurrentContent()?.metadata.source,{pause:R,play:N,stop:G}=Io,uo=(0,nr.useMemo)(()=>{let So=g["play-pause-new"]?.shortcut||g["play-pause"]?.shortcut,_;switch(y){case"playing":_="Pause";break;case"buffering":_="Stop";break;default:_="Play"}return o(f,null,_," ",So&&o(to,{keys:So}))},[Qn,e,y,g]),mo=te(e?n:()=>(i(),y==="playing"?R():y==="buffering"?G():N())),S=y==="playing"||y==="paused"&&m>0,jo=y==="playing"||y==="buffering",xo=c.isLoading===!1&&c.totalEstimatedDuration>0;return o(E,{showOnRight:r,text:l?u:uo,isPlayButton:!0},o(rr,{centerWhite:!0,duration:c.isLoading===!0?0:c.totalEstimatedDuration,onClick:mo,pill:!0,progress:m,state:y,isLoading:y==="buffering",disabled:!xo&&(t||!d&&c.isLoading||l&&!jo),playingHasStarted:S,variant:C==="Keypoints"?"ai":"speechify"}))}s();a();var M=T(v());function Tt({children:t,expanded:e,isCollapsed:i,isMouseOver:n,isPDF:r,shouldShowUpsell:l}){let[u,d]=(0,M.useState)(!1),g=(0,M.useRef)(null),c=(0,M.useMemo)(()=>r?"pdf":i?"collapsed":e?l?"upsell":"expanded":"compact",[i,r,e,l]),m=(0,M.useMemo)(()=>(n?Re:we)[c]-Ae,[n,c]),y=(0,M.useCallback)(C=>{ko()&&C.target.closest("button")&&C.preventDefault()},[]);return(0,M.useEffect)(()=>{if(g.current!==null&&m>g.current){d(!0);let C=setTimeout(()=>{d(!1)},150);return()=>{clearTimeout(C)}}g.current=m},[m]),o(De,{className:u?"animating":"",relative:!0,onMouseDown:y,playerContainerHeight:m},t)}s();a();var gr=T(v());s();a();var Hn="#343537",vt="#3C3C3E",It=`
  &:hover {
    background-color: ${Hn};
  }

  &:active {
    background-color: ${vt};
  }
`,oa=p.button`
  background: unset;
  border-radius: 50%;
  border: unset;
  cursor: pointer;
  height: 32px;
  outline: unset;
  padding: 0;
  text-align: center;
  vertical-align: middle;
  width: 32px;

  & > svg {
    height: 96% !important;
    left: 50%;
    position: absolute;
    top: 50%;
    transform: translate(-50%, -50%);
    width: 96% !important;
  }

  & > img {
    height: 80% !important;
    left: 50%;
    position: absolute;
    top: 50%;
    transform: translate(-50%, -50%);
    width: 80% !important;
  }

  ${It}

  ${({active:t})=>t&&`background-color: ${vt};`}
`,U=({onClick:t,...e})=>o(oa,{onClick:oe(t),...e}),wt=p(at)`
  background: unset;
  border: unset;
  border-radius: 50%;
  box-shadow: none;
  cursor: pointer;
  min-height: 16px;
  min-width: 16px;
  outline: unset;
  height: 16px;
  width: 16px;
  padding: 0;

  & > svg {
    height: 16px;
    width: 16px;
  }

  ${It}
`,sr=p(U)`
  opacity: ${({disabled:t})=>t?.5:1};

  & > svg {
    height: 20px !important;
    left: 50%;
    position: absolute;
    top: 50%;
    transform: translate(-50%, -50%);
    width: 20px !important;
  }
`,lr=p(U)`
  & > svg {
    height: 20px !important;
    left: 50%;
    position: absolute;
    top: 50%;
    transform: translate(-50%, -50%);
    width: 20px !important;
  }
`,ur=p(U)`
  & > svg {
    height: 20px !important;
    left: 50%;
    position: absolute;
    top: 50%;
    transform: translate(-50%, -50%);
    width: 20px !important;
  }
`,mr=p(U)`
  & > svg {
    height: 20px !important;
    left: 50%;
    position: absolute;
    top: 50%;
    transform: translate(-50%, -50%);
    width: 20px !important;
  }
`,cr=p(Te)`
  width: 32px;
  height: 32px;

  & > svg {
    height: 20px !important;
    left: 50%;
    position: absolute;
    top: 50%;
    transform: translate(-50%, -50%);
    width: 20px !important;
  }

  ${It}
`,dr=p(U)`
  & > svg {
    height: 24px !important;
    left: 50%;
    position: absolute;
    top: 50%;
    transform: translate(-50%, -50%);
    width: 24px !important;
  }
`,pr=p.button`
  display: flex;
  background: #2d2d2f;
  border: unset;
  border-radius: 50%;
  cursor: pointer;
  outline: unset;
  padding: 0;

  & > svg path {
    fill: #9899a6;
    height: 20px !important;
    width: 20px !important;
  }

  &:hover {
    background: #2d2d2f;
    & > svg path {
      fill: #ffffff;
    }
  }
`,fr=p(at)`
  width: 48px;
  height: 48px;
  background: unset;

  &:hover {
    & > svg {
      opacity: 0.75;
    }
  }

  &:active {
    background-color: ${vt};
  }

  & > svg {
    height: 20px;
    width: 20px;
    fill: #fff;
  }
`;function hr({isPDF:t,canSaveToMobile:e,showSettingsOnRight:i}){let{shortcuts:n}=eo(),{saveToMobileStatus:r}=Ce("Pill Player"),l=(0,gr.useMemo)(()=>{if(!e||r==="saving")return"";let u=n["save-to-library"]?.shortcut;return r==="saved"?o(f,null,"View in Library",o(Pe,{style:{marginLeft:"6px",marginBottom:"2px"}})):r==="failed"?"Error saving to library":o(f,null,"Save to Library ",u&&o(to,{keys:u}))},[r,e,n]);return o(E,{showOnRight:i,text:l},o(cr,{"aria-label":b("SAVE_TO_LIBRARY"),"data-testid":P.SAVE_TO_LIBRARY,boxShadow:"none",disabled:!e,color:"#F1F4F9",logEventOnClick:()=>{O("bookmark"),ne("SHOULD_SHOW_BOOKMARK_FEATURE_HINT",!1)},source:t?"PDF":"Pill Player",style:e?{}:{cursor:"default",opacity:.5}}))}s();a();var yr=T(v());function Rt({disabled:t,showTooltipOnRight:e}){let{closeTooltip:i,tooltipContent:n}=qo(),r=(0,yr.useCallback)(()=>{O("screenshot"),i(),!t&&ai("pill-player")},[t]);return o(E,{disabled:!!t,showOnRight:e,text:n},o(sr,{"aria-label":b("OCR_ICON"),"data-testid":P.OCR_ICON,disabled:!!t,onClick:r},o(ce,null)))}s();a();s();a();var so=T(v());var Pr=()=>{let t=(0,so.useRef)(),[e,i]=(0,so.useState)(!1);return(0,so.useEffect)(()=>{let n=zt.on("speedUpdate",({isAutoIncrease:r})=>{r&&(i(!0),t.current=window.setTimeout(()=>{i(!1)},3e3))});return()=>{n(),t.current&&clearTimeout(t.current)}},[]),{showSpeedRampAnimation:e}};s();a();var ta=()=>o("div",{style:{width:"14px",height:"17px",position:"relative"}},o("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 14 17",width:"14",height:"17",preserveAspectRatio:"xMidYMid meet",style:{width:"100%",height:"100%"}},o("defs",null,o("radialGradient",{id:"speedRampGradient",spreadMethod:"pad",gradientUnits:"userSpaceOnUse",cx:"-4.809000015258789",cy:"-0.949999988079071",r:"10.190258807587085",fx:"-4.809000015258789",fy:"-0.949999988079071"},o("stop",{offset:"0%",stopColor:"rgb(234,106,255)"}),o("stop",{offset:"50%",stopColor:"rgb(171,113,253)"}),o("stop",{offset:"100%",stopColor:"rgb(107,120,252)"}))),o("g",{className:"arrow-1"},o("path",{fill:"url(#speedRampGradient)",d:"M-0.7070000171661377,-2.7070000171661377 C-0.3160000145435333,-3.0980000495910645 0.3160000145435333,-3.0980000495910645 0.7070000171661377,-2.7070000171661377 C0.7070000171661377,-2.7070000171661377 4.706999778747559,1.2929999828338623 4.706999778747559,1.2929999828338623 C5.0980000495910645,1.684000015258789 5.0980000495910645,2.315999984741211 4.706999778747559,2.7070000171661377 C4.315999984741211,3.0980000495910645 3.684000015258789,3.0980000495910645 3.2929999828338623,2.7070000171661377 C3.2929999828338623,2.7070000171661377 0,-0.5860000252723694 0,-0.5860000252723694 C0,-0.5860000252723694 -3.2929999828338623,2.7070000171661377 -3.2929999828338623,2.7070000171661377 C-3.684000015258789,3.0980000495910645 -4.315999984741211,3.0980000495910645 -4.706999778747559,2.7070000171661377 C-5.0980000495910645,2.315999984741211 -5.0980000495910645,1.684000015258789 -4.706999778747559,1.2929999828338623 C-4.706999778747559,1.2929999828338623 -0.7070000171661377,-2.7070000171661377 -0.7070000171661377,-2.7070000171661377z"})),o("g",{className:"arrow-2"},o("path",{fill:"url(#speedRampGradient)",d:"M-0.7070000171661377,-2.7070000171661377 C-0.3160000145435333,-3.0980000495910645 0.3160000145435333,-3.0980000495910645 0.7070000171661377,-2.7070000171661377 C0.7070000171661377,-2.7070000171661377 4.706999778747559,1.2929999828338623 4.706999778747559,1.2929999828338623 C5.0980000495910645,1.684000015258789 5.0980000495910645,2.315999984741211 4.706999778747559,2.7070000171661377 C4.315999984741211,3.0980000495910645 3.684000015258789,3.0980000495910645 3.2929999828338623,2.7070000171661377 C3.2929999828338623,2.7070000171661377 0,-0.5860000252723694 0,-0.5860000252723694 C0,-0.5860000252723694 -3.2929999828338623,2.7070000171661377 -3.2929999828338623,2.7070000171661377 C-3.684000015258789,3.0980000495910645 -4.315999984741211,3.0980000495910645 -4.706999778747559,2.7070000171661377 C-5.0980000495910645,2.315999984741211 -5.0980000495910645,1.684000015258789 -4.706999778747559,1.2929999828338623 C-4.706999778747559,1.2929999828338623 -0.7070000171661377,-2.7070000171661377 -0.7070000171661377,-2.7070000171661377z"}))),o("style",null,`
          .arrow-1 {
            transform: translate(7px, 4.992px);
            opacity: 0;
            animation: fadeInUp 1.017s cubic-bezier(0.34, 1, 0.14, 1) forwards;
            will-change: transform, opacity;
          }
          
          .arrow-2 {
            transform: translate(7px, 11.008px);
            opacity: 0;
            animation: fadeInUpDelayed 1.017s cubic-bezier(0.34, 1, 0.14, 1) forwards ;
            will-change: transform, opacity;
          }
          
          @keyframes fadeInUp {
            0% {
              opacity: 0;
              transform: translate(7px, 14.492px);
            }
            24.6% {
              opacity: 0;
              transform: translate(7px, 14.492px);
            }
            41% {
              opacity: 1;
              transform: translate(7px, 4.992px);
            }
            100% {
              opacity: 1;
              transform: translate(7px, 4.992px);
            }
          }
          
          @keyframes fadeInUpDelayed {
            0% {
              opacity: 0;
              transform: translate(7px, 14.492px);
            }
            16.4% {
              opacity: 0;
              transform: translate(7px, 14.492px);
            }
            57.4% {
              opacity: 1;
              transform: translate(7px, 11.008px);
            }
            100% {
              opacity: 1;
              transform: translate(7px, 11.008px);
            }
          }
        `)),Cr=ta;var br=({showOnRight:t,route:e,toggleRoute:i})=>{let{autoSpeedUp:n}=J(),r=qt(),{showSpeedRampAnimation:l}=Pr(),u=()=>{w("extension_usage_speed_controller_opened",{source:"pill_player"}),i("/speed")};return o(E,{showOnRight:t,text:"Set Speed"},o(U,{"aria-label":b("PLAYBACK_SPEED_MENU_BUTTON"),"data-testid":P.PLAYBACK_SPEED_MENU_BUTTON,active:e==="/speed",onClick:u},o(Q,{bold:!0,fontSize:"14px",lineHeight:"20px"},(r??1).toFixed(1),"×")),n&&o(Ke,null,l?o(Cr,null):o(ge,null)))};s();a();var Zo=T(v());var ea=Ut("PillPlayerSummarizeButton"),ia=p(E)`
  & [aria-roledescription='tooltip'] {
    right: 58px;
  }
`,xr=(0,Zo.forwardRef)(function({isDisabled:e=!1,onClick:i,showOnRight:n=!1},r){let l=I.useTime(),u=ui("ceSidepanelSummaries"),d=No(),g=!d||Do(d),c=(0,Zo.useCallback)(async()=>{w("extension_sidepanel_summarize_btn_clicked",{source:"pill_player"}),O("summarize");try{await Si(),await Ei()}catch(m){ea.error("🔴 [PILL-PLAYER] Failed to open side panel or request summarization:",m)}i?.()},[i]);return g||e||l.isLoading||u.isLoading||u.variant==="control"?null:o(We,{ref:r},o(ia,{visible:!0,showOnRight:n,text:"Summarize",disableRelative:!0},o(fr,{"aria-label":b("SUMMARIZE_BUTTON"),"data-testid":P.SUMMARIZE_BUTTON,onClick:c},o(Ti,null))))});s();a();s();a();function At(){return o(Ht,{width:"18",height:"20",viewBox:"0 0 18 20",fill:"currentColor",xmlns:"http://www.w3.org/2000/svg"},o("path",{d:"M11.0049 0.461452C11.0049 0.0159997 11.5435 -0.207084 11.8585 0.107898L15.0656 3.31501C15.2608 3.51027 15.2608 3.82685 15.0656 4.02211L11.8585 7.22922C11.5435 7.5442 11.0049 7.32112 11.0049 6.87567V4.31028C8.8951 3.58012 6.45125 4.06198 4.75705 5.75618C3.58074 6.93248 2.98925 8.46796 2.98143 10.005C2.97862 10.5573 2.52864 11.0027 1.97636 10.9999C1.42408 10.9971 0.978651 10.5471 0.981459 9.99487C0.99185 7.95088 1.78005 5.90475 3.34283 4.34197C5.42221 2.26259 8.35342 1.55518 11.0049 2.22499V0.461452Z"}),o("path",{d:"M6.99465 17.7754V19.5384C6.99465 19.9839 6.45608 20.207 6.1411 19.892L2.93399 16.6849C2.73873 16.4896 2.73873 16.173 2.93399 15.9778L6.1411 12.7707C6.45608 12.4557 6.99465 12.6788 6.99465 13.1242V15.6898C9.10524 16.4217 11.5508 15.9402 13.2459 14.2451C14.4225 13.0685 15.014 11.5325 15.0216 9.99506C15.0243 9.44278 15.4742 8.99726 16.0264 8.99996C16.5787 9.00266 17.0242 9.45256 17.0215 10.0048C17.0115 12.0494 16.2233 14.0961 14.6602 15.6593C12.5799 17.7396 9.64704 18.4467 6.99465 17.7754Z"}))}var ra="background: linear-gradient(0, #111112 0%, #2F220E 40%, #5A4015 100%);",na="background: linear-gradient(0, #111112 0%, #2D0606 40%, #690E0E 100%);",aa=fo`
  from {
    transform: translateY(100%);
  }
  to {
    transform: translateY(0);
  }
`,sa=fo`
  from {
    visibility: hidden;
    opacity: 0;
  }
  to {
    visibility: visible;
    opacity: 1;
  }
`,la=p.button`
  animation: ${sa} 0s linear 300ms forwards, ${aa} 0.2s ease-in-out 300ms forwards;
  border-radius: 100px 100px 0 0;
  border: none;
  cursor: pointer;
  display: block;
  height: 78px;
  margin-bottom: -20px;
  opacity: 0;
  outline: none;
  padding: 0px;
  position: absolute;
  top: -58px;
  visibility: hidden;
  width: 48px;

  > div {
    color: ${({unsupported:t})=>t?" #FF463C":"#FBB13B"};
    margin-top: -20px;
    transition: opacity 0.2s ease-in-out;

    > span {
      font-size: 11px;
      font-weight: 700;
    }
  }

  &:hover {
    > div {
      opacity: 0.8;
    }
  }

  ${({unsupported:t})=>t?na:ra}
`;function Ot({isInScreenshotMode:t}){let{updateAvailable:e,isLoading:i}=li();return i||!e||t?null:o(la,{unsupported:e.critical,onClick:()=>{w("extension_update_clicked",{version:e.version,critical:e.critical}),si()}},o("div",null,o(At,null),o("span",null,"Update")))}s();a();var Sr=({hasClientVoices:t,route:e,showOnRight:i,toggleRoute:n,isPremium:r})=>{let{voice:l}=J(),u=I.usePlayingState(),d=()=>{w("extension_usage_voice_opened",{source:"pill_player"}),n("/voices")},g=()=>t?l&&l.avatarImage?o(ri,{alt:"Selected Voice",flag:l.avatarImage,variant:"circle"}):o(qe,null):o(Ze,null);return o(E,{showOnRight:i,text:!t&&!r?"No Free Voices":"Change Voice"},o(U,{"aria-label":b("VOICE_MENU_BUTTON"),"data-testid":P.VOICE_MENU_BUTTON,active:e==="/voices",onClick:d,disabled:u==="buffering"},g()))};var Er=["/featureprompt","/pillreport","/speed","/voices"];function ua({animate:t,isPDF:e,noSaveToMobile:i,hideSummaryButton:n,root:r,triggerSource:l}){let[u,d]=(0,x.useState)(!1),[g,c]=(0,x.useState)(!0),[m,y]=(0,x.useState)(!1),[C,R]=(0,x.useState)(!1),[N,G]=(0,x.useState)(!1),uo=ft(),{canSaveToMobile:bo,saveToMobile:mo}=Yi(i,e),{route:S,hidePlayerPill:jo}=He(fi,["route","hidePlayerPill"]),xo=(0,x.useRef)(null),So=(0,x.useCallback)(()=>m?!1:!Er.some(L=>S.startsWith(L)),[S,m]),{isMouseOver:_,handleMouseOver:wr,handleMouseOut:Rr,setIsMouseOut:Bt}=Wi({checkIsMouseOut:So,onMouseOut:()=>{$("/")}});Gi();let co=(0,x.useMemo)(()=>new Audio,[]),{autoScroll:Ar,autoScrollTemporary:Or,autoSpeedUp:Br,screenshotMode:Lr,dontShowHideModal:Mr,hasSeenSettingsModal:Nr}=J(),Lt=Zt(),{autoScroll:_r}=ni(),{current:kr,NotificationBoard:Dr}=ro(),j=oi(),{isDraggable:Mt}=Lr??{isDraggable:!1,helpMode:!1},Fr=_r===!1,F=(0,x.useMemo)(()=>u&&!_&&!m,[u,_,m]),Eo=(0,x.useMemo)(()=>_||m,[_,m]),Nt=Fr||Or||!Ar,{seekNext:Ur,seekPrevious:Wr,pause:_t}=Io,W=I.usePlayingState(),To=Ui(),$r=ct(),Vr=l!=="init"&&t,Gr=(0,x.useMemo)(()=>jt({key:"player-emotion-cache",container:r}),[r]),vo=(0,x.useMemo)(()=>!j||j.status==="expired"||!dt(j),[j]),Yr=hi(S),Jo=(0,x.useMemo)(()=>gi(S),[S]);(0,x.useEffect)(()=>{vo&&(async()=>{let Ft=await Yt();if(c(Ft),!Ft){if(await no("no-client-voices"),(await Uo("no-client-voices")).dismissedByUser)return;await X({duration:0,id:"no-client-voices",priority:151,showOnMobile:!1,timeSensitive:!0,render:()=>o(je,null)}),d(!0),w("extension_no_client_voices_notification_shown",{action:"open"})}})()},[vo]),(0,x.useEffect)(()=>{if(!e)return rt(1e4).then(()=>{let{orator:L}=I.getState();L||d(!0)}),()=>{co.pause()}},[e]),(0,x.useEffect)(()=>{(W==="playing"||W==="buffering"||W==="errored")&&(co.pause(),d(!0))},[W]),(0,x.useEffect)(()=>{if(W==="playing"&&(yo()||ko())){if(S==="/featureprompt/skipsentences"||Lt)return;$("/featureprompt/skipsentences")}},[Lt,S,W]),(0,x.useEffect)(()=>{vi(r,{onDrag:zr})},[r]);let Qo=(0,x.useCallback)(L=>$(L===S?"/":L),[S]),zr=(0,x.useCallback)(L=>R(L.left<window.innerWidth/2),[]);(0,x.useLayoutEffect)(()=>{u&&(r.style.bottom="15%")},[u]);let Kr=(0,x.useCallback)(()=>{Bt(!0),G(!0),rt(3e3).then(()=>{G(!1)})},[]),Xr=()=>S.startsWith("/voices")?{audioPlayer:co,hasClientVoices:g,route:S}:S.startsWith("/pillreport")?{onReport:Kr}:{},kt=()=>{Er.some(L=>S.startsWith(L))&&Bt(!0),$("/")};Fo(r,kt);let qr=()=>{if(O("close"),!_o())return _t(),co.pause(),po("browser-action",{animate:!1},"pill-player");Mr?$o():Po.getState().showModal(),_t(),co.pause()},Zr=(0,x.useCallback)(()=>{d(!0)},[]),jr=(0,x.useCallback)(()=>{Wr(),S==="/featureprompt/skipsentences"&&$("/")},[S]),Jr=(0,x.useCallback)(()=>{Ur(),S==="/featureprompt/skipsentences"&&$("/")},[S]),Qr=(0,x.useCallback)(()=>{O("upgrade_icon"),ve("pill_player_upsell")},[]),Dt=!Nt&&To==="down"&&W==="playing",Hr=ct();return jo?null:o(Jt,{value:Gr},o(ki,null),o(Ot,{isInScreenshotMode:Mt}),o($e,{animate:!!Vr},!Nt&&To==="up"&&W==="playing"&&o(E,{visible:!0,showOnRight:C,text:"Scroll to Listening",isAbsolute:!0,isTop:!0},o(st,{"aria-label":b("REENABLE_AUTOSCROLL_BUTTON"),"data-testid":P.REENABLE_AUTOSCROLL_BUTTON,onClick:()=>et(!0),visible:!0,direction:To,hasIsland:!!xo.current},o(nt,null))),!n&&!yo()&&o(xr,{isDisabled:!g,ref:xo,showOnRight:C}),o(Fe,{onMouseOver:wr,onMouseOut:Rr},o(Ue,null,o(Ye,null,o(Lo,{showOnRight:C,visible:!!kr},o(Bo,null,o(Dr,null))),o(Le,{isCollapsed:F,ref:uo,route:S,showPointer:S.startsWith("/featureprompt"),showOnRight:C,visible:!!Jo},o(Be,null,o(ke,{alignLeft:S.startsWith("/featureprompt"),onClose:kt,onSearch:S==="/voices"?()=>$("/voices/search"):void 0,title:Yr.name??""}),Jo&&o(Jo,{...Xr()}))),o(Tt,{isPDF:!!e,isMouseOver:Eo,shouldShowUpsell:vo,expanded:u,isCollapsed:F},o(Ge,null,o(Ai,{isPDF:!!e}),o(ar,{...!g&&{isDisabled:!0},isPDF:e,onClick:Zr,saveToMobile:mo,showSettingsOnRight:C}),u&&!e&&o(z,{yAlign:!0,style:{position:"relative"}},o(E,{disableRelative:!0,showOnRight:C,text:"Skip Backward"},o(wt,{"aria-label":b("SKIP_SENTENCE_BACKWARD"),"data-testid":P.SKIP_SENTENCE_BACKWARD,onClick:jr},o(me,null))),o(E,{disableRelative:!0,showOnRight:C,text:"Skip Forward"},o(wt,{"aria-label":b("SKIP_SENTENCE_FORWARD"),"data-testid":P.SKIP_SENTENCE_FORWARD,onClick:Jr},o(le,null)))),o(mt,null)),o(oo,{visible:u&&!e,style:Br?{overflow:"visible"}:{}},o(Sr,{hasClientVoices:g,route:S,showOnRight:C,toggleRoute:Qo,isPremium:!!j&&dt(j)}),o(br,{route:S,toggleRoute:Qo,showOnRight:C})),!e&&!F&&o(Rt,{disabled:Mt,showTooltipOnRight:C}),!F&&o(hr,{showSettingsOnRight:C,isPDF:e,canSaveToMobile:bo}),o(oo,{visible:u&&!e&&!F},o(E,{showOnRight:C,text:N?"Site has been reported":"Get Help",forceShow:!!N},o(mr,{"aria-label":b("REPORT_A_PROBLEM"),"data-testid":P.REPORT_A_PROBLEM,active:S==="/pillreport",onClick:()=>{O("report"),Qo("/pillreport")}},o(ue,null)))),(u&&!F||Eo)&&o(mt,null),o(Ve,{className:"pill-player-bottom-section"},!e&&!F&&o(oo,{visible:u||Eo},o(E,{showOnRight:C,text:"Open Library"},o(dr,{"aria-label":b("VIEW_LIBRARY"),"data-testid":P.VIEW_LIBRARY,onClick:()=>{O("library"),K("https://app.speechify.com")}},o(fe,null))),o(E,{showOnRight:C,text:"Settings"},o(lr,{"aria-label":b("PILL_PLAYER_SETTINGS"),"data-testid":P.PILL_PLAYER_SETTINGS,onClick:()=>{O("settings"),w("extension_usage_settings_clicked",{source:"pill_player"}),po("show-settings-modal")}},Nr?o(pe,null):o(de,null)))),o(oo,{visible:u&&vo&&!F},o(E,{showOnRight:C,text:"Upgrade to Premium"},o(ur,{"aria-label":b("PILL_PLAYER_UPGRADE_TO_PREMIUM_BUTTON"),"data-testid":P.PILL_PLAYER_UPGRADE_TO_PREMIUM_BUTTON,onClick:Qr},o(ye,null)))),o(oo,{className:"dismiss",visible:Eo&&!F},o(pr,{"aria-label":b("PILL_PLAYER_TURN_OFF_SPEECHIFY_BUTTON"),"data-testid":P.PILL_PLAYER_TURN_OFF_SPEECHIFY_BUTTON,onClick:qr},o(go,null)))))))),o(ze,{showScrollDown:Dt,showAutoToggle:Hr,onMouseEnter:()=>_&&y(!0),onMouseLeave:()=>setTimeout(()=>y(!1),250)},Dt&&o(E,{visible:!0,showOnRight:C,text:"Scroll to Listening"},o(st,{"aria-label":b("REENABLE_AUTOSCROLL_BUTTON"),"data-testid":P.REENABLE_AUTOSCROLL_BUTTON,onClick:()=>{et(!0),y(!1)},visible:!0,direction:To},o(nt,null))),$r&&o(Ri,{route:S,showOnRight:C,triggerSource:l}))))}var Tr=ua;var lo,ma=342,ca=`position: fixed; z-index: 2147483645; top:calc(50% - ${ma/2}px); right: 18px; height: fit-content; font-size: initial;`,vr,da=async(t={},e,i,n,r)=>{let{hidePlayerPill:l,isPDF:u,noSaveToMobile:d,hideSummaryButton:g}=t;if(r?.aborted)return;if(e==="init"&&l)return Ir();if(!lo){let y=document.createElement("div");y.id=Vt,y.style.cssText="position: absolute; bottom: 0; right: 0;",document.body.appendChild(y),lo=y.attachShadow({mode:"open"})}pt();let c=document.createElement("div");c.id=tt,c.style.cssText=ca;let m=ho()&&!!Pi().docTitle;return Ho(o(Tr,{animate:i.animate!==!1,isPDF:u||m,noSaveToMobile:d,hideSummaryButton:g,root:c,triggerSource:e}),c),clearTimeout(vr),vr=window.setTimeout(()=>{r?.aborted||lo.appendChild(c)},100),pi(),yi("Chrome Extension"),Ir()};function Ir(){return()=>{if(pt(),!lo)return;let t=lo.querySelector(`#${tt}`);t&&(Ho(null,t),lo.removeChild(t))}}var cp=da;export{cp as default,Ir as destroyPillPlayer};
//# sourceMappingURL=init-EABZESUJ.js.map
