import{a}from"./chunk-UQFDLVII.js";import"./chunk-TYN6FJD3.js";import"./chunk-SSSSNVF5.js";import"./chunk-YYPSUSZQ.js";import"./chunk-56NWWOIX.js";import"./chunk-EF43U47C.js";import"./chunk-RISKGE32.js";import"./chunk-6O6MLDWR.js";import"./chunk-F4AZU7R4.js";import"./chunk-GQY3J744.js";import"./chunk-CLPINNGF.js";export{a as resetExtensionLifecycle};
//# sourceMappingURL=main.js.map
