import{a as P}from"./chunk-DM55HIHZ.js";import{a as y}from"./chunk-F5622KQ7.js";import"./chunk-AG3QEKLJ.js";import{Cd as b,Dd as S,Fd as v,Oc as N,Ta as r,Ya as g,_b as h,cc as w,e as x,gb as l}from"./chunk-RISKGE32.js";import"./chunk-6O6MLDWR.js";import{b as o,k as e}from"./chunk-F4AZU7R4.js";import{g as O}from"./chunk-GQY3J744.js";import{d as E,g as m,i as t,n as c}from"./chunk-CLPINNGF.js";c();m();c();m();var u=E(O()),A=e(r)`
  pointer-events: auto;
  font-family: 'ABCDiatype';
  font-style: normal;
  letter-spacing: 0.01em;
  box-sizing: border-box;
  padding: 16px;
  font-style: normal;
  width: 360px;
  background: ${o.bgPrimWB};
  border: 1px solid ${o.brdrPrim10100};
  border-radius: 12px;
  position: absolute;
  z-index: 20000;
  top: 20px;
  right: 30px;
`,L=e(l)`
  font-weight: 700;
  font-size: 16px;
  line-height: 24px;
  display: flex;
  align-items: center;
`,k=e(l)`
  color: ${o.brdrPrimInv8010};
  font-style: normal;
  font-weight: 400;
  font-size: 14px;
  line-height: 20px;
`,F=e(l)`
  color: ${o.icnTxtSec};
  font-style: normal;
  font-weight: 400;
  font-size: 12px;
  line-height: 16px;
  cursor: pointer;
`,M=e(g)`
  position: absolute;
  top: 12px;
  right: 12px;
  cursor: pointer;
  fill: ${o.icnTxtSec};
`,$=e(r)`
  flex-shrink: 0;
  justify-content: center;
  align-items: center;
  width: 32px;
  height: 32px;
  background: ${o.hgltSec};
  border-radius: 50%;
`,H=e(r)`
  align-items: center;
  justify-content: space-between;
  padding: 8px 12px;
  width: 250px;
  border-radius: 4px;
  background: ${o.bgPrimW100};
  margin-top: 16px;
`,Y=e(l)`
  color: ${o.brdrPrimInv8010};
  font-style: normal;
  font-weight: 400;
  font-size: 12px;
  line-height: 16px;
  display: flex;
  align-items: center;
  letter-spacing: 0.01em;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  text-overflow: ellipsis;
`,z=e(r)`
  flex-shrink: 0;
  justify-content: center;
  align-items: center;
  width: 24px;
  height: 24px;
  border-radius: 50%;
  background: ${o.sfPrimCta};
  cursor: pointer;
`,C=({historyItem:n,onRemind:f,onPlay:T,removeNotification:s})=>{let a=(0,u.useMemo)(()=>`${Math.ceil((1-n.leavePosition)*n.duration/60)}`,[n]),p=(0,u.useMemo)(()=>`https://www.google.com/s2/favicons?domain=${new URL(n.url).hostname}`,[n]);return t(A,null,t(r,{separation:"16px"},t($,null,t(P,{color:o.icnTxtPrimElectric,width:"24px",height:"13px"})),t(r,{column:!0,separation:"4px"},t(L,null,"Listen to where you left"),t(r,{column:!0,separation:"8px"},t(k,null,"You haven’t finished this article. Spend ",a," minutes to wrap it up!"),t(H,{separation:"8px"},t(r,{yAlign:!0,separation:"8px"},t("img",{src:p,alt:""}),t(Y,null,n.title)),t(z,{onClick:T},t(y,{size:"14px",color:o.icnTxtPrimInv}))),t(F,{onClick:f},"Remind me later")))),t(M,{onClick:s}))};var D=12*60*60*1e3,W=36*60*60*1e3,G=.2,V=.7,j=48*60*60*1e3;async function B(){let n=new Date().getTime(),f=await v("listen-history-item");if(n-(f?.lastDisplayedAt??0)<j)return;let s=(await x("/listen-history/get-history-list")).find(i=>n-i.updatedAt>=D&&n-i.updatedAt<=W&&i.leavePosition>=G&&i.leavePosition<=V&&i.url!==window.location.href);if(!s)return;let a=await h("ListeningHistoryNotification");if(w("ListeningHistoryNotification",a),a!=="notification")return;S({id:"listen-history-item",timeSensitive:!1,priority:151,duration:0,global:!0,allowPointerActions:!0,showOnMobile:!1,render:({dismiss:i})=>t(C,{historyItem:s,onRemind:p,onPlay:d,removeNotification:i})});let p=()=>{I()},d=async()=>{let i=s.url;N("extension_listen_history_click_notification",{url:i,title:s.title,duration:s.duration,readingProgress:s.leavePosition}),I(),await x("/listen-history/navigate-history-item",{url:i}),window.open(i,"_blank")};return I}function I(){b("listen-history-item")}export{B as default,I as destroyHistoryNotification};
//# sourceMappingURL=init-UOYAVNDE.js.map
