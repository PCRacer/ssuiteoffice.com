import{Ga as w,Na as R,Oa as y,Ta as c,Va as M,Wa as D,hb as V}from"./chunk-RISKGE32.js";import{T as P}from"./chunk-6O6MLDWR.js";import{b as h,k as S}from"./chunk-F4AZU7R4.js";import{a as B,f as _,g as $}from"./chunk-GQY3J744.js";import{d as F,g as f,i as e,n as k}from"./chunk-CLPINNGF.js";k();f();_();k();f();var l=F($());k();f();var G=({strokeLineCap:o,...t})=>e("path",{d:"M 1,1 L 99,1","fill-opacity":"0","stroke-width":"0.5",stroke:h.brdrSec2060,"stroke-linecap":o??"square",...t}),x=({percent:o,strokeColor:t,strokeLineCap:r,...s})=>e("svg",{viewBox:"0 0 100 2",preserveAspectRatio:"none","aria-label":M("SEEKBAR"),"data-testid":D.SEEKBAR,style:{width:"100%",cursor:"pointer",height:"16px"},...s},e("defs",null,e("linearGradient",{id:"grad1",x1:"56",y1:"4",x2:"55.4314",y2:"-3.95987",gradientUnits:"userSpaceOnUse"},e("stop",{"stop-color":"#EA6AFF"}),e("stop",{offset:"1","stop-color":"#6B78FC"}))),e(G,{strokeLineCap:r}),e(G,{stroke:t,strokeLineCap:r,style:{strokeDashoffset:"0.2px",strokeDasharray:`${Math.max(o-.2,0)}px, 100px`}}));var L=S(c)`
  position: absolute;
  left: 0;
  right: 0;

  &:hover .seek-handle {
    display: flex;
  }
`,K=S(c)`
  width: 100%;
  margin-bottom: 10px;
  justify-content: space-between;
  padding: 0 8px;
`,A=h.sfPrimCta,T=S("div")`
  display: none;
  width: 10px;
  height: 10px;
  background: ${({background:o})=>o??A};
  border-radius: 50%;
  pointer-events: none;

  position: absolute;
  top: 16px;
  transform: translateY(-50%);
  ${({isDragging:o})=>o&&"display: flex !important;"}
`,q=S(c)`
  &:hover .seek-handle {
    display: flex;
  }
`,v=({ariaElement:o,time:t,isRemainTime:r=!1,color:s})=>e(V,{color:s,"aria-label":M(o),fixedWidthNumbers:!0,fontSize:"14px",style:{whiteSpace:"nowrap",fontWeight:500}},r?"-":"",P("short")(t)),I=({customStyle:o,currentTime:t,duration:r,onChange:s,onMouseUp:E,...m})=>{let p=(0,l.useRef)(null),g=Math.max(r-t,0),[a,C]=(0,l.useState)(!1),n=Math.min(t/Math.max(r,1)*100,100),u=(0,l.useCallback)(i=>{let d=p.current?.base?.getBoundingClientRect();return d?Math.max(0,(i.clientX-d.x)/d.width*r):0},[p,r]),b=(0,l.useCallback)(i=>{m.disabledSeek||(i.stopPropagation(),s(u(i)),C(!0))},[a,u,s]);return(0,l.useEffect)(()=>{if(!a)return;let i=d=>s(u(d));return window.addEventListener("mousemove",i),()=>window.removeEventListener("mousemove",i)},[a,u,s]),(0,l.useEffect)(()=>{if(!a)return;let i=d=>{C(!1),typeof E=="function"&&E(u(d)),window.removeEventListener("mouseup",i)};return window.addEventListener("mouseup",i),()=>window.removeEventListener("mouseup",i)},[a,u,s]),o?.position?o?.position==="top"?e(L,{yAlign:!0,relative:!0,...m,style:{top:0}},e(x,{ref:p,percent:n,strokeColor:A,onMouseDown:b}),e(T,{style:{left:`${n}%`,width:"10px",top:"8px"},className:"seek-handle",isDragging:a,background:o?.seekHandleColor})):e(L,{yAlign:!0,relative:!0,...m,style:{bottom:0}},o.withTimeLabel&&e(K,{relative:!0,align:!0},e(v,{ariaElement:"CURRENT_TIME",time:t}),e(v,{ariaElement:"REMAIN_TIME",time:g,isRemainTime:!0})),e(L,{yAlign:!0,relative:!0,...m,style:{bottom:0}},e(x,{ref:p,percent:n,strokeColor:A,onMouseDown:b}),e(T,{className:"seek-handle",style:{left:`${n}%`,top:"8px"},isDragging:a,background:o?.seekHandleColor}))):e(c,{separation:"6px",yAlign:!0,...m},e(v,{color:o?.timeLabelColor,ariaElement:"CURRENT_TIME",time:t}),e(q,{yAlign:!0,relative:!0},e(x,{ref:p,percent:n,strokeColor:o?.seekbarColor??"#4759F7",strokeLineCap:"round",onMouseDown:b,style:{width:"100%",cursor:"pointer",padding:"8px 0",height:"16px"}}),e(T,{style:{left:`${n>0?`${n<100?n:"98.5"}%`:"6px"}`},className:"seek-handle",isDragging:a,background:o?.seekHandleColor})),e(v,{color:o?.timeLabelColor,ariaElement:"REMAIN_TIME",time:g,isRemainTime:!0}))};var pe=({customStyle:o={},duration:t,seek:r,...s})=>{let E=y.useProgress(),m=y.useTime(),[p,g]=B(null),a=m.isLoading?Math.floor((E??0)*t):m.currentTime;return e(I,{customStyle:o,currentTime:p??a,duration:t,onChange:async n=>{n<=t&&g(Math.round(n))},onMouseUp:n=>{if(r(n/t),w(y.getPlayingState()))g(null);else{let u=R.registerHook("PLAYBACK_STATE_CHANGED",async({state:b})=>{w(b)&&(g(null),u())})}},...s})};export{pe as a};
//# sourceMappingURL=chunk-GM73DFVY.js.map
