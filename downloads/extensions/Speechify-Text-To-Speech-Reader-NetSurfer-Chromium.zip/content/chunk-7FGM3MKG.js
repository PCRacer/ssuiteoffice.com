import{ca as l}from"./chunk-6O6MLDWR.js";import{g as e,n as o}from"./chunk-CLPINNGF.js";o();e();var t=l(()=>({docTitle:null,docUrl:null})),i=()=>t.setState({docTitle:null,docUrl:null}),g=t.setState,u=t.getState;export{t as a,i as b,g as c,u as d};
//# sourceMappingURL=chunk-7FGM3MKG.js.map
