import{Cd as p,Dd as O,Ed as m,Na as b,Oa as W,Wa as E,Ya as Y,cd as S,e as _,f as G,g as F,h as U,i as y}from"./chunk-RISKGE32.js";import{fa as w,ja as L}from"./chunk-6O6MLDWR.js";import{a as v,b as g,k as n,l as I}from"./chunk-F4AZU7R4.js";import{g as B}from"./chunk-GQY3J744.js";import{d as P,f as c,g as r,i as t,n as s}from"./chunk-CLPINNGF.js";s();r();s();r();var f=P(B()),le=(e,o)=>o?e?"toast-out 0.3s ease-out forwards":"toast-in 0.3s ease-out forwards":"none",ce=n.div`
  background: ${g.bgPrimW90};
  padding: 12px 8px 12px 12px;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  position: fixed;
  top: 16px;
  left: 50%;
  transform: translateX(-50%);
  z-index: 1000;
  box-shadow: 0px 6px 16px -6px rgba(0, 0, 0, 0.64);
  will-change: transform;
  opacity: 0;
  transform: translateX(-50%) translateY(-20px);
  animation: ${({isClosing:e,isVisible:o})=>le(e,o)};

  @keyframes toast-in {
    0% {
      opacity: 0;
      transform: translateX(-50%) translateY(-20px);
    }
    100% {
      opacity: 1;
      transform: translateX(-50%) translateY(0);
    }
  }

  @keyframes toast-out {
    0% {
      opacity: 1;
      transform: translateX(-50%) translateY(0);
    }
    100% {
      opacity: 0;
      transform: translateX(-50%) translateY(-20px);
    }
  }
`,de=n.span`
  font-family: ABCDiatype, sans-serif;
  color: ${g.icnTxtWhite};
  font-size: 14px;
  font-weight: 500;
  line-height: 20px;
  text-align: center;
  letter-spacing: -0.07px;
`,pe=n.button`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 24px;
  height: 24px;
  padding: 0;
  background: none;
  border: none;
  cursor: pointer;
`,fe=()=>t("svg",{xmlns:"http://www.w3.org/2000/svg",width:"24",height:"24",viewBox:"0 0 24 24",fill:"none"},t("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M5.44974 8.96232C6.05988 8.07071 6.589 7.62984 7.38119 7.87474C7.86056 8.02294 8.05734 8.63488 7.86056 9.40272C7.51457 10.7528 7.38119 11.5278 7.38119 12.4502C8.59809 9.89955 10.8476 6.50955 11.8226 5.36934C12.4964 4.58124 13.4623 4.68175 13.826 4.85753C14.4168 5.14316 14.448 5.76249 14.2441 6.35479C12.8332 10.4525 12.784 12.6411 12.6108 14.7673C13.4877 12.4092 14.5538 10.1911 15.8412 8.62891C16.3836 7.87964 17.3344 7.64444 17.9349 7.88784C18.5354 8.13124 18.6722 8.71357 18.5354 9.44332C18.1784 11.3463 18.0013 12.2382 18.0013 12.9754C18.6534 12.4767 19.1726 12.0553 20.3597 11.959C21.5468 11.8627 24 12.3353 24 12.3353C24 12.3353 22.5838 12.5759 21.8357 12.7593C20.3023 13.1354 19.7667 13.5752 18.7741 15.029C18.4856 15.4514 18.0013 15.7758 17.4557 15.7345C16.9101 15.6933 16.5437 15.35 16.3836 14.8865C16.1612 14.2422 16.095 13.2785 16.3836 11.1929C14.9694 13.3446 14.2441 16.2675 13.275 18.2058C13.0273 18.7014 12.6041 19.2661 12.0307 19.2661C11.4572 19.2661 10.7136 19.0437 10.617 17.3399C10.3697 12.9754 11.1942 9.50233 11.1942 9.50233C9.58829 12.0486 9.07541 13.5329 8.5168 14.3069C7.95818 15.0808 7.41614 15.7511 6.7568 15.7345C6.09747 15.718 5.71375 14.9809 5.63031 14.3069C5.54688 13.6329 5.52287 12.772 5.76656 11.1929C5.13224 11.8272 4.57449 12.2568 3.57562 12.5258C2.57674 12.7948 1.38397 12.6236 0 12.3353C1.38397 12.3353 3.71298 11.5003 5.44974 8.96232Z",fill:"white"})),j=({removeNotification:e})=>{let[o,l]=(0,f.useState)(!1),[d,i]=(0,f.useState)(!1);return(0,f.useEffect)(()=>{let a=setTimeout(()=>{i(!0)},500),x=setTimeout(()=>{l(!0),setTimeout(e,300)},5500);return()=>{clearTimeout(a),clearTimeout(x)}},[e]),t(ce,{isClosing:o,isVisible:d},t(fe,null),t(de,null,"You've successfully logged into Speechify."),t(pe,{onClick:()=>{l(!0),setTimeout(e,300)}},t(Y,{fill:g.icnTxtTert})))};s();r();var ne=P(B());s();r();var T=G(async()=>_("/helpers/get-current-tab-id"));s();r();var z="speechify-global-notifications",C=e=>{let l=document.getElementById(z)?.shadowRoot;if(l){let d=l.querySelectorAll(".scrollable");for(let i of d)if(e.composedPath().some(x=>x===i))return}e.preventDefault()},A=()=>{let e=document.getElementById(z);e&&e.shadowRoot?(window.addEventListener("wheel",C,{passive:!1}),window.addEventListener("touchmove",C,{passive:!1})):setTimeout(A,100)},R=e=>{let o=window.open(e,"_blank","noopener noreferrer");o&&(o.opener=null)},D=()=>{window.removeEventListener("wheel",C),window.removeEventListener("touchmove",C)};s();r();var V=n.div`
  align-items: center;
  background-color: rgba(5, 7, 11, 0.5);
  display: flex;
  height: 100vh;
  justify-content: center;
  left: 0;
  position: fixed;
  top: 0;
  width: 100vw;
  z-index: 2147483645;
`,$=n.div`
  align-items: center;
  background: #111112;
  border-radius: 12px;
  display: inline-flex;
  flex-direction: column;
  flex-shrink: 0;
  height: 436px;
  justify-content: center;
  padding: 20px 88px;
  position: relative;
`,X=n.div`
  position: absolute;
  top: 0;
  right: 0;
  padding: 16px;
  cursor: pointer;
`,q=n.div`
  width: 380px;
  display: flex;
  flex-direction: column;
  align-items: center;
`,K=n.div`
  align-items: center;
  background: #4759f7;
  border-radius: 13px;
  display: flex;
  gap: 10px;
  justify-content: center;
  padding: 4px;
  margin-bottom: 24px;
`,Z=n.div`
  align-self: stretch;
  color: #fff;
  font-size: 36px;
  font-style: normal;
  font-weight: 500;
  letter-spacing: -0.72px;
  line-height: 44px;
  margin-bottom: 8px;
  text-align: center;
`,J=n.div`
  align-self: stretch;
  color: #fff;
  font-size: 16px;
  font-style: normal;
  font-weight: 500;
  letter-spacing: -0.08px;
  line-height: 24px;
  margin-bottom: 24px;
  text-align: center;
`,Q=n.div`
  align-items: center;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  gap: 16px;
`,H=n.button`
  align-items: center;
  align-self: stretch;
  background: #fff;
  border-radius: 12px;
  border: none;
  color: #000;
  cursor: pointer;
  display: flex;
  font-size: 16px;
  font-style: normal;
  font-weight: 700;
  gap: 0px;
  height: 48px;
  justify-content: center;
  letter-spacing: -0.08px;
  line-height: 24px;
  padding: 12px 36px;
`,ee=n.div`
  align-items: center;
  align-self: stretch;
  color: #fff;
  display: flex;
  font-size: 14px;
  font-style: normal;
  font-weight: 400;
  gap: 4px;
  justify-content: center;
  letter-spacing: -0.07px;
  line-height: 20px;
`,te=n.div`
  align-items: center;
  border-radius: 10px;
  color: #8894fe;
  cursor: pointer;
  display: flex;
  font-size: 14px;
  font-style: normal;
  font-weight: 400;
  gap: 0px;
  justify-content: center;
  letter-spacing: -0.07px;
  line-height: 20px;
  padding: 0px;
`;function N({close:e}){(0,ne.useEffect)(()=>(A(),window.addEventListener("keydown",o),()=>{D(),window.removeEventListener("keydown",o)}),[]);let o=a=>{a.key==="Escape"&&i()},l=async()=>{let a=await T();R(I(`auth/ce/?mode=sign-in&extensionId=${c.runtime.id}&tabId=${a}`,v.onboardingUrl)),i()},d=async()=>{let a=await T();R(I(`auth/ce/?extensionId=${c.runtime.id}&tabId=${a}`,v.onboardingUrl)),i()},i=()=>{e()};return t(V,{onClick:a=>{a.target===a.currentTarget&&i()}},t($,null,t(X,{onClick:i},t("svg",{xmlns:"http://www.w3.org/2000/svg",width:"20",height:"20",viewBox:"0 0 20 20",fill:"none"},t("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M4.87361 3.45952C4.48309 3.06899 3.84992 3.06899 3.4594 3.45952C3.06887 3.85004 3.06887 4.48321 3.4594 4.87373L8.58562 9.99996L3.4594 15.1262C3.06887 15.5167 3.06887 16.1499 3.4594 16.5404C3.84992 16.9309 4.48309 16.9309 4.87361 16.5404L9.99984 11.4142L15.1261 16.5404C15.5166 16.9309 16.1498 16.9309 16.5403 16.5404C16.9308 16.1499 16.9308 15.5167 16.5403 15.1262L11.4141 9.99996L16.5403 4.87373C16.9308 4.48321 16.9308 3.85004 16.5403 3.45952C16.1498 3.06899 15.5166 3.06899 15.1261 3.45952L9.99984 8.58575L4.87361 3.45952Z",fill:"white"}))),t(q,null,t(K,null,t("svg",{xmlns:"http://www.w3.org/2000/svg",width:"60",height:"60",viewBox:"0 0 60 60",fill:"none"},t("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M13.6244 22.4053C15.1497 20.1763 16.4725 19.0741 18.453 19.6864C19.6514 20.0569 20.1433 21.5867 19.6514 23.5063C18.7864 26.8816 18.453 28.819 18.453 31.1249C21.4952 24.7484 27.1191 16.2734 29.5564 13.4229C31.2411 11.4526 33.6559 11.7039 34.5649 12.1433C36.042 12.8574 36.12 14.4057 35.6102 15.8865C32.0829 26.1308 31.9601 31.6022 31.527 36.9177C33.7191 31.0225 36.3844 25.4772 39.603 21.5718C40.9591 19.6986 43.3359 19.1106 44.8371 19.7191C46.3384 20.3276 46.6806 21.7834 46.3384 23.6078C45.4461 28.3653 45.0033 30.5951 45.0033 32.4381C46.6335 31.1912 47.9316 30.1378 50.8993 29.897C53.8669 29.6562 60 30.8377 60 30.8377C60 30.8377 56.4594 31.4393 54.5894 31.8979C50.7556 32.838 49.4168 33.9374 46.9351 37.572C46.214 38.6281 45.0033 39.439 43.6392 39.3358C42.2751 39.2327 41.3593 38.3746 40.9591 37.2157C40.4029 35.605 40.2376 33.1957 40.9591 27.9818C37.4234 33.3611 35.6102 40.6682 33.1876 45.5139C32.5682 46.7529 31.5103 48.1647 30.0767 48.1647C28.643 48.1647 26.7839 47.6087 26.5425 43.3492C25.9243 32.4381 27.9855 23.7553 27.9855 23.7553C23.9707 30.1211 22.6885 33.8317 21.292 35.7667C19.8955 37.7016 18.5404 39.3772 16.892 39.3358C15.2437 39.2945 14.2844 37.4517 14.0758 35.7667C13.8672 34.0816 13.8072 31.9296 14.4164 27.9818C12.8306 29.5676 11.4362 30.6416 8.93904 31.3141C6.44186 31.9866 3.45993 31.5586 0 30.8377C3.45993 30.8377 9.28245 28.7503 13.6244 22.4053Z",fill:"white"}))),t(Z,null,"Welcome to Speechify"),t(J,null,"Listen anywhere with natural",t("br",null),"AI voices and more"),t(Q,null,t(H,{"data-testid":E.SIGNUP_SIGNIN_PROMPT,onClick:d},"Create Account"),t(ee,null,"Already have an account?",t(te,{"data-testid":E.LOGIN_SIGNIN_PROMPT,onClick:l},"Log in"))))))}async function ue(){let e=await ge();return()=>e()}var oe=null,M="",ie=!1,st=F({events:["check"]}),se=async e=>{e?p("force-login"):ie&&!e&&(h(),L("destroy",{},"paragraph-player"),L("destroy",{},"sentence-player")),ie=e},ge=async()=>{M=location.href;let e=await b.registerHook("BEFORE_PLAY",async()=>{h()});w("browser-action",async()=>{h()},"force-login"),w("toggle-force-login",async()=>{h()},"force-login"),document.addEventListener("visibilitychange",re);let o=U.on("userupdate",async i=>{se(!!S(i))}),l=i=>{i.type==="show-auth-success-notification"&&Ce()};c.runtime.onMessage.addListener(l);let d=new MutationObserver(he);return d.observe(document,{subtree:!0,childList:!0}),()=>{document.removeEventListener("visibilitychange",re),d.disconnect(),e(),o(),c.runtime.onMessage.removeListener(l)}},h=async()=>{let{currentContent:e}=W.getState();await ae()?p("force-login"):(b.pause(),(m()?.current?.id!=="force-login"||oe!==e?.metadata.source)&&(me(),oe=e?.metadata.source??null))},me=async()=>{p("force-login"),p("checklist"),p("salience"),p(),m()?.current?.id!=="force-login"&&O({id:"force-login",priority:151,duration:0,showOnMobile:!1,timeSensitive:!0,wrapperPadding:"0",global:!0,allowPointerActions:!1,render:({dismiss:e})=>t(N,{close:e})})},Ce=async()=>{m()?.current?.id!=="auth-success"&&O({id:"auth-success",priority:151,duration:0,showOnMobile:!1,timeSensitive:!0,wrapperPadding:"0",global:!0,render:({dismiss:e})=>t(j,{removeNotification:e})})},ae=async()=>{let e=await y();return S(e)},re=async()=>{y.invalidateCache();let e=await ae();se(!!e)},he=async()=>{M!==location.href&&p("force-login"),M=location.href};export{ue as a,st as b};
//# sourceMappingURL=chunk-6S4AP2UG.js.map
