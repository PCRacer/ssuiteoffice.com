import{a as o}from"./chunk-56NWWOIX.js";import{g as r,n as c}from"./chunk-CLPINNGF.js";c();r();var f=()=>{let t=o();return i(t)},i=t=>{let s=t["pill-player"]||{},{lifecycles:e=[]}=s;return e.includes("init")||e.includes("readable")};export{f as a};
//# sourceMappingURL=chunk-YYPSUSZQ.js.map
