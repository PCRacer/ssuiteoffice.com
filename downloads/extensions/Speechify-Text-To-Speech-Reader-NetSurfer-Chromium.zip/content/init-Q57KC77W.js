import{a as pt}from"./chunk-GM73DFVY.js";import{a as dt}from"./chunk-SSSSNVF5.js";import{A as at,B as st,F as lt,b as Ge,c as Ve,d as Ze,e as Je,f as He,g as et,h as J,i as tt,j as ot,k as nt,w as H,x as rt,y as ee,z as $}from"./chunk-43GP4A7N.js";import"./chunk-MBHSJ34F.js";import"./chunk-DMUXVFIA.js";import"./chunk-Z3E43XMU.js";import"./chunk-BN5XPDNR.js";import"./chunk-YYPSUSZQ.js";import{a as it}from"./chunk-56NWWOIX.js";import"./chunk-EF43U47C.js";import"./chunk-GWCIFOLA.js";import"./chunk-NK4CKTAC.js";import{q as Z}from"./chunk-KO4WPNRU.js";import"./chunk-F5622KQ7.js";import"./chunk-WC6QURV6.js";import{a as Xe}from"./chunk-TIGAXALM.js";import"./chunk-ZQRXZJGY.js";import"./chunk-6S4AP2UG.js";import"./chunk-O3LC63CS.js";import"./chunk-AG3QEKLJ.js";import{Ea as q,Ha as Ne,Ia as j,Ja as Oe,Na as X,Oa as D,Oc as x,Qa as We,Ra as Ye,Sa as Qe,Ta as _,b as Pe,e as Re,ed as ct,g as Le,gb as je,kc as fe,qa as Fe,ua as me,wa as Ke}from"./chunk-RISKGE32.js";import{T as Ie,V as _e,ea as $e,fa as ze,ha as Ue,ja as T}from"./chunk-6O6MLDWR.js";import{b as k,c as G,g as V,h as qe,k as n}from"./chunk-F4AZU7R4.js";import{g as O}from"./chunk-GQY3J744.js";import{d as N,g as y,i as t,j as E,k as I,m as Ae,n as h}from"./chunk-CLPINNGF.js";h();y();Ae();h();y();var mt=N(O());Ae();var Ot=n.div`
  align-items: center;
  background-color: #111112;
  border-radius: 6px;
  bottom: 40px;
  color: #fff;
  cursor: pointer;
  display: flex;
  font-family: 'ABCDiatype';
  font-size: 14px;
  gap: 6px;
  line-height: 20px;
  padding: 8px 12px;
  position: absolute;
  right: 20px;
  z-index: 9999;
  pointer-events: auto;

  .esc-key-button {
    align-items: center;
    background-color: #f1f4f9;
    border: 1px solid #afb9c8;
    border-radius: 4px;
    box-shadow: 0px 1px 0px 0px rgba(175, 185, 200, 1);
    color: #1e1e1e;
    display: flex;
    font-size: 14px;
    font-weight: 400;
    height: 24px;
    justify-content: center;
    line-height: 20px;
    text-align: center;
  }
`;function ft({onKeyPress:e,root:o}){let r=(0,mt.useMemo)(()=>G({key:"keypoint-emotion-cache",container:o}),[o]);return t(V,{value:r},t(Ot,{role:"button",onClick:e},t("div",{className:"esc-key-button"}," Click"),"to Exit Key Takeaways player"))}var ut=e=>{let o=document.querySelector("#speechify-keypoint-mode");if(!o){let a=document.createElement("div");a.id="speechify-keypoint-mode",a.style.cssText="position: fixed; top: 0; right: 0; width: 100%; min-height: 100%; z-index: 2147483640; display: none !important;",document.body.appendChild(a),a.attachShadow({mode:"open"}),o=a}o.style.display="block",o.style.pointerEvents="none";let r=o?.shadowRoot;if(!r)return $e(new Error("No shadow root found for speechify selection player, cannot mount."));let i=document.createElement("div");i.id="speechify-keypoint-player",r.appendChild(i),I(t(ft,{root:i,onKeyPress:()=>{e&&(X.pause(),e.options?.autoplay&&(e.options.autoplay=!1),We(e,!0)),ue()}}),i)},ue=()=>{let e=document.querySelector("#speechify-keypoint-mode"),o=e?.shadowRoot;if(!o||!e)return;e.style.display="none",e.style.pointerEvents="auto";let r=o.getElementById("speechify-selection-player");r&&(I(null,r),r.remove())};h();y();var c=N(O());h();y();var gt={textColor:"#1E1E1E",csatIconFill:"#587393",csatTextColor:"#587393",closeBtnFill:"#587393",closeBtnHover:"#dee5eb",jumpIconFill:"#6B78FC",csatSeparatorColor:"#e4eaf1",speechifyLogoColor:"#2137FC",tooltip:{background:"#111112",text:"#FCFEFE"},closeBtnDropdown:{text:"#1e1e1e",background:"#fff",backgroundHover:"#e4eaf1"},listenBtn:{static:"#6B78FC",hover:"#9BA3FF",active:"#6870CC",textColor:"#fff"},modal:{background:"#fff",border:"1px solid #e4eaf1",text:"#1e1e1e",btnText:"#fff",btnDisabled:"#E4EAF1",btnDisabledText:"#8791A0",btnBg:"#2137FC",btnSimpleText:"#587393",radioBg:"#e4eaf1",radioFill:"#fff",radioBorder:"#2137fc",textAreaBorder:"#c9ced4",textAreaBg:"#fff"},background:"radial-gradient(43.11% 51.96% at 30.5% 59.96%, rgba(45, 214, 92, 0.02) 0%, rgba(53, 143, 78, 0.00) 100%), radial-gradient(61.75% 102.86% at 76.75% 70.46%, rgba(226, 41, 197, 0.03) 0%, rgba(205, 62, 182, 0.00) 100%), radial-gradient(96.95% 118.17% at 73% 26.15%, rgba(48, 138, 221, 0.05) 0%, rgba(29, 41, 53, 0.00) 100%), linear-gradient(155deg, rgba(145, 205, 255, 0.04) 0%, rgba(145, 205, 255, 0.00) 102.86%), #FFF",border:"1px solid #e4eaf1"},yt={textColor:k.icnTxtPrim,csatIconFill:"#AFB9C8",csatTextColor:"#AFB9C8",closeBtnFill:"#AFB9C8",closeBtnHover:"#505050",jumpIconFill:"#6B78FC",csatSeparatorColor:"#373737",speechifyLogoColor:"#FFFFFF",tooltip:{background:"#F1F4F9",text:"#1e1e1e"},modal:{background:"#1e1e1e",border:"1px solid #373737",text:"#fff",btnText:"#111112",btnDisabled:"#373737",btnDisabledText:"#8791A0",btnSimpleText:"#AFB9C8",btnBg:"#5F9BF0",radioBg:"#373737",radioFill:"#fff",radioBorder:"#6B78FC",textAreaBorder:"#646464",textAreaBg:"#1E1E1E"},closeBtnDropdown:{text:"#fff",background:"#1e1e1e",backgroundHover:"#373737"},listenBtn:{static:"#6B78FC",hover:"#7DAFDC",active:"#73A0C8",textColor:"#fff"},background:"radial-gradient(43.11% 51.96% at 30.5% 59.96%, rgba(45, 214, 92, 0.08) 0%, rgba(53, 143, 78, 0.00) 100%), radial-gradient(61.75% 102.86% at 76.75% 70.46%, rgba(226, 41, 197, 0.12) 0%, rgba(205, 62, 182, 0.00) 100%), radial-gradient(96.95% 118.17% at 73% 26.15%, rgba(48, 138, 221, 0.20) 0%, rgba(29, 41, 53, 0.00) 100%), linear-gradient(155deg, rgba(145, 205, 255, 0.12) 0%, rgba(145, 205, 255, 0.00) 102.86%), #111112",border:"none"};h();y();var te=N(O());function ge(){let[e,o]=(0,te.useState)(null);return(0,te.useEffect)(()=>((async()=>{let r=await $();o(r)})(),ee.listen(r=>{o(r)})),[]),e}h();y();var ht=N(O());var $t=n(_)`
  background: ${e=>e.theme.listenBtn.static};
  border-radius: 100px;
  cursor: pointer;

  &:hover {
    background: ${e=>e.theme.listenBtn.hover};
    animation: none;
  }

  // change color to "Listen to email" text when hovered
  &:hover + span {
    color: ${k.icnTxtPrimElectric};
  }

  &:active {
    background: ${e=>e.theme.listenBtn.active};
    animation: none;
  }

  &:active + span {
    color: #6870cc;
  }

  outline: inherit;
  border: none;
  height: inherit;

  // handle keyboard navigation since we are removing outline
  &:focus-visible {
    outline: 1px solid ${k.brdrPrimCta};
    border: 1px solid #fff;
  }
`,nn=n(_)`
  font-size: 12px;
  font-family: ABCDiatype, sans-serif;
  font-style: normal;
  font-weight: 500;
  line-height: 12px;
  letter-spacing: 0.12px;
  color: ${e=>e.theme.listenBtn.textColor};
`,zt=({isPlaying:e,isLoading:o,...r})=>{let i=(0,ht.useMemo)(()=>o?"loading":e?"playing":"paused",[e,o]);return t(_,{...r},i==="playing"&&t(Ze,null),i==="loading"&&t(Ge,null),i==="paused"&&t(Ve,null))};function Ut({isLoading:e,isPlaying:o,playPage:r,theme:i}){return t($t,{yAlign:!0,relative:!0,column:!1,onClick:a=>r(a)},t(zt,{size:"32",iconFill:i.listenBtn.textColor,isLoading:e,isPlaying:o}))}var xt=Ut;h();y();var ye=N(O());var Wt=n.div`
  z-index: 100000;
  align-items: center;
  background-color: rgba(5, 7, 11, 0.5);
  display: flex;
  height: 100vh;
  justify-content: center;
  left: 0;
  position: fixed;
  top: 0;
  width: 100vw;
`,Yt=n.div`
  border: ${e=>e.theme.modal.border};
  background: ${e=>e.theme.modal.background};
  border-radius: 12px;
  color: ${e=>e.theme.modal.text};
  display: flex;
  flex-direction: column;
  font-family: ABCDiatype, sans-serif;
  min-width: 380px;
  padding: 20px 40px;
  position: relative;
`,Qt=n.div`
  cursor: pointer;
  position: absolute;
  right: 10px;
  top: 10px;
`,qt=n.h3`
  color: ${e=>e.theme.modal.text};
  text-align: center;
  font-family: 'ABCDiatype', sans-serif;
  font-size: 18px;
  font-style: normal;
  font-weight: 700;
  line-height: 24px;
`,jt=n.form`
  display: flex;
  flex-direction: column;
  gap: 16px;
`,Xt=n.div`
  align-items: center;
  display: flex;

  & label {
    height: 100%;
    cursor: pointer;
    font-size: 14px;
    font-style: normal;
    font-weight: 400;
    line-height: 20px;
    letter-spacing: 0.14px;
  }
`,Gt=n.input`
  appearance: none;
  background-color: ${e=>e.theme.modal.radioBg};
  border: 6px solid transparent;
  border-radius: 50%;
  width: 20px;
  height: 20px;
  cursor: pointer;
  position: relative;
  transition: border-color 0.3s;
  margin-right: 8px;

  &:checked {
    border-color: ${e=>e.theme.modal.radioBorder};

    &::before {
      content: '';
      display: block;
      width: 8px;
      height: 8px;
      background-color: ${e=>e.theme.modal.radioFill};
      border-radius: 50%;
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
    }
  }
`,Vt=n.div`
  display: flex;
  gap: 24px;
  justify-content: center;
  margin-top: 8px;

  & > button {
    font-family: ABCDiatype, sans-serif;
    font-size: 14px;
    padding: 8px 36px 6px 36px;
  }
`,Zt=n.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
`,Jt=n.textarea`
  border-radius: 6px;
  border: 1px solid ${e=>e.theme.modal.textAreaBorder};
  background: ${e=>e.theme.modal.textAreaBg};
  color: ${e=>e.theme.modal.text};
  min-height: 100px;
  padding: 10px;
  resize: none;
  font-family: ABCDiatype, sans-serif;
  font-size: 14px;
  font-weight: 400;
  line-height: 20px;
  letter-spacing: 0.14px;
`,Ht=[{label:"Summary is too lengthy",id:"too-long"},{label:"Summary misses important details",id:"miss-important-details"},{label:"Prefer reading full article",id:"prefer-reading-all"},{label:"Prefer a different summary style",id:"prefer-different-style"},{label:"It interferes with content on the page",id:"interferes-with-content"},{label:"Add a custom reason",id:"custom-response",collectCustomResponse:!0}],eo=({show:e,variant:o,onDismiss:r,onSubmit:i,theme:a})=>{let[d,u]=(0,ye.useState)(),[s,m]=(0,ye.useState)(""),f=async l=>{l.preventDefault(),d&&await x("extension_embedded_summary_feedback",{channel:o,response:s||d.label}),i()},g=l=>{u(l)};return e?t(Wt,null,t(Yt,null,t(Qt,{onClick:r},t(J,{fill:"#587393"})),t(qt,null,o==="csat"?"Tell us what you didn’t like about summary":"Why you want to turn off summarization?"),t(jt,{onSubmit:f},Ht.map(l=>t(Xt,{key:l.id},t(Gt,{checked:d&&d.id===l.id,id:l.id,name:"modal-key-points",onChange:()=>g(l),type:"radio",value:l.id}),t("label",{htmlFor:l.id},l.label))),(!d||!d.collectCustomResponse)&&t(Vt,null,t(Z,{type:"button",onClick:r,style:{color:a.modal.btnSimpleText,border:"none",boxShadow:"none"},secondary:!0},"Cancel"),t(Z,{type:"submit",disabled:!d,style:{display:"flex",cursor:d?"pointer":"not-allowed",alignItems:"center",color:d?a.modal.btnText:a.modal.btnDisabledText,background:d?a.modal.btnBg:a.modal.btnDisabled}},"Confirm")),d&&d.collectCustomResponse&&t(Zt,null,t(Jt,{onChange:l=>m(l.target.value),placeholder:"Tell us what you don’t like about summarization"}),t(Z,{type:"submit",disabled:!s,style:{display:"flex",alignItems:"center",justifyContent:"center",color:s?a.modal.btnText:a.modal.btnDisabledText,background:s?a.modal.btnBg:a.modal.btnDisabled,width:"100%",textAlign:"center"}},"Submit Feedback"))))):null},Et=eo;var io=n.div`
  border: 0.5px solid #3c3c3e;
  background: #1e1e1f;
  margin-top: 1rem;
  margin-bottom: 1rem;
  max-height: 700px;
  width: 100%;
  padding: 0;
  border-radius: 16px;
  display: flex;
  flex-direction: column;
`,ro=n.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 16px 8px 16px;
`,ao=n.div`
  display: flex;
  align-items: center;
  gap: 8px;
`,so=n.span`
  font-family: 'ABC Diatype';
  font-size: 16px;
  font-style: normal;
  font-weight: 500;
  line-height: 24px; /* 150% */
  letter-spacing: 0.16px;
  color: #ffffff;
`,lo=n.div`
  display: flex;
  gap: 8px;
  align-items: center;
`,Ct=n.div`
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;

  & .tooltip {
    display: none;
  }

  &:hover .tooltip {
    display: flex;
  }

  &:active .tooltip {
    display: flex;
  }
`,co=n(Je)`
  cursor: pointer;

  &:hover {
    opacity: 0.75;
  }

  &:active {
    opacity: 0.5;
  }
`,po=n.div`
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;

  & svg > path {
    fill: #9899a6;
  }

  &:hover svg {
    opacity: 0.75;
  }

  &:active svg {
    opacity: 0.5;
  }
`,mo=n.h3`
  font-family: ABCDiatype, sans-serif;
  font-size: 16px;
  font-style: normal;
  font-weight: 500;
  line-height: 24px; /* 150% */
  letter-spacing: 0.16px;
  color: #ffffff;
  margin: 0;
`,fo=n.span`
  font-family: ABCDiatype;
  font-size: 12px;
  font-style: normal;
  font-weight: 400;
  line-height: 16px; /* 133.333% */
  letter-spacing: 0.12px;
  color: #747580;
`,oe=n.div`
  height: 16px;
  border-radius: 2px;
  background: #262940;
  width: 100%;
  position: relative;
  overflow: hidden;
`,ne=n.div`
  @keyframes shimmer {
    100% {
      transform: translateX(150%);
    }
  }

  animation: shimmer 2s infinite;
  position: absolute;
  left: 0;
  top: 0;
  height: 100%;
  width: 80%;
  background: linear-gradient(to right, transparent, #2a2f57, transparent);
  pointer-events: none;
  transform: translateX(-150%);
`,uo=n.div`
  display: flex;
  padding: 12px 16px 24px 16px;
  flex-direction: column;
  align-items: flex-start;
  gap: 12px;
  align-self: stretch;

  > div:nth-child(odd) {
    width: 60%;
  }
  > div:nth-child(even) {
    width: 70%;
  }
`,go=n.div`
  padding: 12px 3px 0px 16px;
  position: relative;
`,yo=n.ul`
  margin: 0;
  text-align: left;
  padding: 0px 19px 24px 0px;
  overflow-x: hidden;
  overflow-y: scroll;
  will-change: max-height;
  max-height: ${({expanded:e})=>e?"240px":"72px"};

  // Animation definitions
  @keyframes expand {
    from {
      max-height: 72px;
    }
    to {
      max-height: 240px;
    }
  }

  @keyframes collapse {
    from {
      max-height: 240px;
    }
    to {
      max-height: 72px;
    }
  }

  animation: ${({expanded:e})=>e&&"expand 350ms ease-in-out forwards"};

  &::-webkit-scrollbar {
    width: 6px;
    height: 48px;
  }

  &::-webkit-scrollbar-track {
    border-radius: 1--px;
    background-color: 'transparent';
  }

  &::-webkit-scrollbar-thumb {
    border-radius: 4px;
    background-color: #3c3c3e;
  }

  &::-webkit-scrollbar-button {
    display: none;
  }
`,ho=n.span`
  display: inline;
  font-family: ABCDiatype, sans-serif;
  font-size: 16px;
  font-style: normal;
  font-weight: 400;
  line-height: 24px;
  position: relative;
  color: #ffffff;
  -webkit-font-smoothing: antialiased;
  margin-right: 4px;
`,xo=n.div`
  display: flex;
  justify-content: center;
  padding: 12px 16px 16px;
`,bo=n.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
`,Eo=n.div`
  display: flex;
  align-items: center;
  gap: 12px;
`,Co=n.li`
  line-height: 24px;
  color: ${e=>e.theme.textColor};
  text-align: left;
`,ie=n.span`
  cursor: pointer;
  position: relative;
  & svg > path {
    fill: #9899a6;
  }

  &:hover svg#regenerate {
    opacity: 0.75;
  }

  &:active svg#regenerate {
    opacity: 0.5;
  }

  &:hover svg#copy {
    opacity: 0.75;
  }

  &:active svg#copy {
    opacity: 0.5;
  }

  ${({chooseResponse:e})=>e==="good"&&`
    svg#like > path {
      fill: #23ae75;
    }
  `}

  &:hover svg#like > path {
    fill: #23ae75;
  }

  &:active svg#like > path {
    fill: #23ae75;
    opacity: 0.75;
  }

  ${({chooseResponse:e})=>e==="bad"&&`
    svg#dislike > path {
      fill: #eb3830;
    }
  `}

  &:hover svg#dislike > path {
    fill: #eb3830;
  }

  &:active svg#dislike > path {
    fill: #eb3830;
    opacity: 0.75;
  }

  & .tooltip {
    display: none;
  }

  &:hover .tooltip {
    display: flex;
  }

  &:active .tooltip {
    display: flex;
  }

  height: 20px;
  width: 20px;
`,vo=n.div`
  width: 2px;
  height: 10px;
  min-width: 2px;
  border-radius: 30px;
  background: #3c3c3e;
`,qn=n.span`
  position: relative;
  opacity: ${({visible:e})=>e?1:0};
  ${({visible:e})=>!e&&"pointer-events: none;"}
  transition: opacity 0.25s ease-in-out;
`,jn=n.div`
  background: ${e=>e.theme.tooltip.background};
  border-radius: 4px;
  color: ${e=>e.theme.tooltip.text};
  font-family: ABCDiatype, sans-serif;
  font-size: 14px;
  ${({showOnRight:e=!1})=>e?"left: 30px;":"right: 30px"};
  line-height: 16px;
  padding: 4px 8px;
  position: absolute;
  top: 0;
  width: max-content;
`,wo=n.button`
  color: white;
  background: transparent;
  border: none;
  font-size: 14px;
  font-family: ABCDiatype, sans-serif;
  font-weight: 500;
  line-height: 20px; /* 142.857% */
  display: flex;
  align-items: center;
  gap: 6px;
  justify-content: center;
  outline: none;
  margin-right: auto;
  cursor: pointer;
  padding: 0;
  > svg {
    fill: white;
    width: 12px;
    height: 12px;
    padding: 2px;
  }

  &:hover {
    opacity: 0.75;
  }

  &:active {
    opacity: 0.5;
  }
`,So=n.div`
  width: calc(100% - 38px);
  background: linear-gradient(
    180deg,
    rgba(30, 30, 31, 0) 0%,
    rgba(30, 30, 31, 0.9) 80%,
    rgba(30, 30, 31, 0.99) 95%,
    #1e1e1f 100%
  );
  position: absolute;
  bottom: 0;
  height: 32px;
  z-index: 1;
`,ko=n(_)`
  position: absolute;
  z-index: 2000;
  bottom: 34px;
  right: 0px;
  transform: translateX(calc(50% - 12px));
  font-family: 'ABCDiatype';
  font-style: normal;
  border-radius: 6px;
  padding: 6px 8px;
  box-shadow: 0px 4px 12px -4px rgba(0, 0, 0, 0.16);
  color: ${k.icnTxtPrimInv};
  background-color: #e9eaf0;

  ::before {
    content: '';
    display: block;
    width: 0;
    height: 0;
    position: absolute;
    left: calc(50% - 4px);
    top: 100%;
    border-style: solid;
    border-width: 4px;
    border-color: #e9eaf0 transparent transparent transparent;
  }

  ::after {
    content: '';
    display: block;
    position: absolute;
    width: 0;
    height: 0;
    left: calc(50% - 3px);
    top: 100%;
    border-style: solid;
    border-width: 3px;
    border-color: #e9eaf0 transparent transparent transparent;
  }
`,To=n(je)`
  font-weight: 400;
  font-size: 12px;
  line-height: 16px;
  letter-spacing: 0.01em;
  width: max-content;
  color: ${k.icnTxtPrimInv};
`;function Do(e){let o=ge(),r=(0,c.useMemo)(()=>fe(),[window.location.hostname]);return!!(e||o?.enabled_by_default&&!o?.disabled_websites.includes(r)||o?.enabled_websites.includes(r))}function Mo({root:e,skipEnabledCheck:o}){let{seekTo:r}=X,[i,a]=(0,c.useState)([]),[d,u]=(0,c.useState)(!1),[s,m]=(0,c.useState)(!1),[f,g]=(0,c.useState)({show:!1,variant:"csat"}),l=Do(o),[C,F]=(0,c.useState)(null),[B,U]=(0,c.useState)(0),[A,v]=(0,c.useState)(l),[W,w]=(0,c.useState)(l),[le,he]=(0,c.useState)(!0),[St,xe]=(0,c.useState)(!1),[Y,be]=(0,c.useState)(),ce=(0,c.useRef)(null),Ee=ct(e),de=(0,c.useMemo)(()=>Ee?yt:gt,[Ee]),kt=(0,c.useMemo)(()=>G({key:"keypoints-emotion-cache",container:e}),[e]),Tt=(0,c.useMemo)(()=>fe(),[window.location.hostname]),{state:Ce,play:Dt,pause:Mt,isActive:K,queueAndPlayContent:Bt}=Ne(C),At=!!(K&&Ce==="buffering"),ve=!!(K&&Ce==="playing"),we=()=>{v(!0)},Se=p=>{v(!1),he(!0),w(!0),a(p.sentences)},ke=()=>{v(!1),w(!1),he(!1),a([])};(0,c.useLayoutEffect)(()=>(b.on("loading",we),b.on("success",Se),b.on("no-content-available",ke),()=>{b.off("success",Se),b.off("loading",we),b.off("no-content-available",ke)}),[b]);let Q=D.useCurrentContent(),Te=(0,c.useRef)(Q);(0,c.useEffect)(()=>{le||!l||Q!==Te.current&&(Te.current=Q)},[le,l,Q]),(0,c.useEffect)(()=>{K||u(!1)},[K]),(0,c.useEffect)(()=>{(async()=>{let p={getContent:await Ye(async()=>({content:Array.from(ce.current?.querySelectorAll("li")??[]),chunksBefore:0,chunksAfter:0})),converter:S=>({text:dt(S),ref:{ref:S,highlightInfo:{scrollElement:ce.current??void 0,startOffset:0,isKeypoint:!0}}}),metadata:{source:"Keypoints"},options:{autoplay:!0,sideEffects:!1}};Oe(p).then(S=>{U(S)}),F(p)})()},[i]);let De=(0,c.useRef)(l);(0,c.useEffect)(()=>{l!==De.current&&(De.current=l,w(l))},[l]);let Pt=async p=>{if(d||u(!0),p.preventDefault&&p.stopPropagation&&(p.preventDefault(),p.stopPropagation()),x("extension_embedded_summary_listen_btn_clicked"),s||m(!0),_e()||T("browser-action",{animate:!1},"pill-player"),ve)return Mt();if(K)return Dt();let S=D.getState().currentContent;S&&ut(S),Bt()},pe=()=>{switch(f.variant){case"csat":g(p=>({...p,show:!1}));break}},Rt=async()=>{switch(f.variant){case"csat":pe();break;case"dismiss":await at("enabled_by_default",!0),w(!1),pe();break}},Me=p=>{p==="upvote"?(be("good"),x("extension_embedded_summary_upvoted")):(be("bad"),x("extension_embedded_summary_downvoted"))},Lt=()=>{lt("/aiSummary"),x("extension_usage_settings_clicked",{source:"keypoints_extraction"}),T("show-settings-modal")},It=()=>{v(!0),a([]),x("extension_embedded_summary_regenerate_btn_clicked",{website:window.location.hostname}),T("summarize-once-embedded-summary",{},"embedded-summaries")},_t=()=>{x("extension_embedded_summary_copy_btn_clicked",{website:window.location.hostname});let p=i.join(`
`);navigator.clipboard.writeText(p),xe(!0),setTimeout(()=>{xe(!1)},5e3)},Ft=()=>{T("destroy",{},"embedded-summaries")},Kt=()=>{x("extension_embedded_summary_closed",{option:"current-page"}),st(Tt),w(!1),Ft()},Nt=()=>{m(p=>!p),x("extension_embedded_summary_read_more_btn_clicked",{website:window.location.hostname})},L=({text:p})=>t(ko,{className:"tooltip"},t(To,null,p)),Be=i.length>3;if(!(!le||!W))return t(V,{value:kt},t(qe,{theme:de},t(Et,{theme:de,show:f.show,variant:f.variant,onDismiss:pe,onSubmit:Rt}),t(io,{id:"speechify-keypoints-extractor-body"},t(ro,null,t(ao,null,A&&!i.length?t(nt,null):t(xt,{theme:de,playPage:Pt,isLoading:At,isPlaying:ve}),A&&!i.length&&t(so,null,"Summarizing Text..."),!A&&(d?t(pt,{style:{marginLeft:"8px",marginRight:"16px"},customStyle:{timeLabelColor:"#ffffff",seekbarColor:"url(#grad1)",seekHandleColor:"linear-gradient(315deg, #EA6AFF 0%, #6B78FC 100%)"},duration:B,seek:r}):t(mo,null,"Listen to Speechify Summary ",t(fo,null,"·")," ",Ie("long")(B)))),t(lo,null,t(Ct,null,t(co,{onClick:Lt}),t(L,{text:"Customize summary"})),t(Ct,null,t(po,null,t(J,{onClick:Kt,fill:"#9899A6"}),t(L,{text:"Turn off for this site"}))))),A&&!i.length?t(uo,null,t(oe,null,t(ne,null)),t(oe,null,t(ne,null)),t(oe,null,t(ne,null)),t(oe,null,t(ne,null))):t(E,null,t(go,null,t(yo,{ref:ce,expanded:s},i.map(p=>t(Co,{key:p},t(ho,null,p)))),t(So,null)),t(xo,null,(s||!Be)&&t(E,null,t(bo,null,t(Eo,null,t(ie,null,t(He,{id:"regenerate",onClick:It}),t(L,{text:"Regenerate"})),t(ie,null,t(et,{id:"copy",onClick:_t}),t(L,{text:St?"Copied":"Copy"})),t(vo,null),Y!=="bad"&&t(ie,{chooseResponse:Y},t(tt,{id:"like",onClick:()=>Me("upvote")}),t(L,{text:"Good response"})),Y!=="good"&&t(ie,{style:{marginTop:"2px"},chooseResponse:Y},t(ot,{id:"dislike",onClick:()=>Me("downvote")}),t(L,{text:"Bad response"}))))),Be&&!s&&t(wo,{onClick:Nt},"Read More",t(Xe,{direction:s?"up":"down",disableAnimation:!0})))))))}var vt=Mo;h();y();var re=e=>{};var R=Pe(1),M=null,se="speechify-keypoints-extractor",Bo="speechify-keypoints-extractor-root",Ao="speechify-keypoints-extractor-body",b=Le({events:["loading","success","no-content-available"]}),Po=async()=>{let{currentContent:e}=D.getState(),o=e;if(e!==M&&M?.metadata.source==="PillPlayer"&&(o=M),!o)return document.body;let r=new Range,i=await j(o);if(!i.length)return document.body;r.setStart(i[0],0),r.setEnd(i[i.length-1],0);let a=r.commonAncestorContainer??document.body;return a.querySelector("h1")??a.childNodes[0]};async function Ro(e,o){if(e?.awaitedElement&&await Promise.race([me(e?.awaitedElement??""),q(500)]),await Promise.race([me("#speechify-embedded-player"),q(1e3)]),document.querySelector(`#${se}`)&&document.querySelector(`#${Ao}`))return;let r=await Po(),i=e?.inlinePlayerContentSelector?e?.inlinePlayerContentSelector:e?.inlinePlayerSelector,a=i?i.indexOf("::prepend")!==-1:!1,d=i?i.indexOf("::before")!==-1:!1,u=document.querySelector("#speechify-embedded-player"),s=(a?i?.replace("::prepend",""):d?i?.replace("::before",""):i)??"",m=s.length>0?Fe(s)??r:r,f;if(m){let g=document.createElement("div");g.id=se,g.style.position="relative",g.style.cssText=e?.inlinePlayerStyle??"width: 100%; max-width: 1200px; margin: 0 auto;";let l=g.attachShadow({mode:"open"}),C=m.parentNode;u?C.insertBefore(g,u):a?C.prepend(g):C.insertBefore(g,d?m.previousElementSibling:m.nextElementSibling),f=document.createElement("div"),f.id=Bo,l.appendChild(f),e?.inlinePlayerContentStyle&&(f.style.cssText=e.inlinePlayerContentStyle),I(t(vt,{root:f,skipEnabledCheck:o}),f)}return()=>{f&&I(null,f)}}var z=null,Lo=["google.com","github.com","huggingface.com","speechify.com"],Io=e=>{let o=new URL(e);return o.pathname==="/"||o.pathname==="/home"||o.pathname==="/home/"},wt=e=>e.map(o=>{let r=((o instanceof Node?o.textContent:o.text)??"").trim();if(o instanceof HTMLElement&&o.tagName){let i=o.tagName.toLowerCase();return`<${i}>${r}</${i}>`}return r}).filter(o=>!!o.trim()).join(`
`),ae=async(e,o,r,i,a)=>{let d=window.location.hostname.replace(/^www\./,"");o&&(!a&&(!e.enabled_by_default&&!e.enabled_websites.includes(d)||e.disabled_websites.includes(d)||document.querySelector(`#${se}`)&&e.enabled_websites.includes(d))||Lo.some(u=>window.location.href.includes(u))||Io(window.location.href)||(z&&(z(),M=null),z=await Ro(r,a)??null,M!==o&&(b.emit("loading",null),re("Attempting to break content down by sentences and perform keypoint extraction"),M=o,re("Applying highlights to content"),await Promise.race([new Promise(u=>i.addEventListener("abort",u,{once:!0})),new Promise(async(u,s)=>{let m=await rt(),f=await j(o),g=wt(f);if(g===""){let C=()=>{},F=await Promise.race([new Promise(B=>i.addEventListener("abort",B,{once:!0})),q(5e3),new Promise(B=>{let U=new MutationObserver(v=>{v.forEach(async W=>{if(W.type==="childList"||W.type==="characterData"){let w=wt(await j(o));w&&B(w)}})});C=()=>U.disconnect();let A=f.find(v=>v instanceof HTMLElement)?.parentElement??document.querySelector(r?.awaitedElement);A?U.observe(A??document.querySelector(r?.awaitedElement)??document.body,{childList:!0,characterData:!0,subtree:!0}):B("")})]);C(),F&&typeof F=="string"&&(g=F)}if(g==="")return M=null,b.emit("no-content-available",null),s(new Error("No sentences found to summarize"));let{keypoints:l}=await Re("/summarization/summarize-content",{model:m,content:g});if(!l?.length)return s(new Error("No important sentences found"));R.clearQueue(),b.emit("success",{sentences:l}),re("Finished applying highlights to content"),u(),x("extension_embedded_summary_generated",{website:window.location.hostname})})]).catch(u=>{let s=new Error("Failed to perform keypoint extraction",{cause:u});M=null,T("embedded-summary-error",{},"embedded-summaries"),R.pendingCount||(x("extension_embedded_summary_failed_to_generate",{website:window.location.hostname}),T("destroy",{},"embedded-summaries")),console.error(s)}))))},_o=async()=>{let e=new AbortController,o=it()["embedded-player"]?.config.config,r=async()=>{let{currentContent:s}=D.getState(),m=await $();m.enabled_by_default=!0,s&&R(()=>ae(m,s,o,e.signal,!0))};if(ze("summarize-once-embedded-summary",r,"embedded-summaries"),!await H())return()=>z?.();let i=await $();Ke().then(()=>{let{currentContent:s}=D.getState();s&&R(()=>ae(i,s,o,e.signal))});let a=ee.listen(async s=>{let{currentContent:m}=D.getState();await H(s)&&m&&R(()=>ae(s,m,o,e.signal))}),d=await Qe("PLAYABLE_CONTENT_UPDATED",async({changed:s})=>{if(!await H())return;let m=["Keypoints","Selection Player","Screenshot"];s.metadata.source==="Selection Player"&&ue(),s&&!m.includes(s.metadata.source)&&(R(()=>ae(i,s,o,e.signal,!0)),d())}),u=b.once("success",()=>{R.clearQueue(),d()});return()=>{Ue("summarize-once-embedded-summary",r),u(),e.abort(),a(),d(),document.querySelector(`#${se}`)?.remove(),document.querySelector("#speechify-keypoint-mode")?.remove(),z?.()}},xi=_o;export{b as KeypointExtractionStateEmitter,xi as default};
//# sourceMappingURL=init-Q57KC77W.js.map
