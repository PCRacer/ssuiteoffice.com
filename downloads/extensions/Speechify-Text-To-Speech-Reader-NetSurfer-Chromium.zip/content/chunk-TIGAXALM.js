import{a as v}from"./chunk-AG3QEKLJ.js";import{Oc as S,Ta as h}from"./chunk-RISKGE32.js";import{b as x,j as C,k as l}from"./chunk-F4AZU7R4.js";import{g as k}from"./chunk-GQY3J744.js";import{d as $,f as d,g,i as t,n as u}from"./chunk-CLPINNGF.js";u();g();var M=({angle:o,translateVar:e})=>C`
  0%,
  100% {
    transform: translate(0, 0) rotate(${o}deg);
  }

  50% {
    transform: translate(${e}) rotate(${o}deg);
  }
`,L=l.svg`
  height: ${({height:o})=>o??"20px"};
  width: ${({width:o})=>o??"16px"};
  animation: ${M} 1s ease-in-out infinite;
`,A=({direction:o,height:e,width:n,disableAnimation:r=!1})=>{let i={right:0,down:90,left:180,up:270}[o]??0,s={right:"5px, 0",down:"0, 5px",left:"-5px, 0",up:"0, -5px"}[o];return t(L,{direction:o,height:e,width:n,xmlns:"http://www.w3.org/2000/SvgStyle",viewBox:"0 0 18 19",angle:i,translateVar:r?"0, 0":s},t("path",{fillRule:"evenodd",d:"M17.469 10.782l-6.689 7.086c-1.573 1.647-4.013-.907-2.439-2.554l3.856-3.955H1.652c-2.203 0-2.203-3.626 0-3.626h10.78L8.342 3.45c-1.574-1.648.866-4.202 2.44-2.472l6.688 7.004c.708.659.708 2.142 0 2.801z"}))},P=A;var Y=({direction:o,animate:e=!1,animationDistance:n="5px",style:r,...i})=>{let s={down:0,left:90,up:180,right:270}[o]??0,p={right:`${n}, 0`,down:`0, ${n}`,left:`-${n}, 0`,up:`0, -${n}`}[o];return t(e?L:v,{width:"15",height:"9",viewBox:"0 0 15 9",fill:"currentColor",xmlns:"http://www.w3.org/2000/svg",style:{transform:`rotate(${s}deg)`,...r},angle:s,translateVar:p,...i},t("path",{d:"M7.33008 8.43115C7.5376 8.43115 7.74512 8.34814 7.88623 8.19043L14.311 1.60791C14.4521 1.4668 14.5352 1.28418 14.5352 1.07666C14.5352 0.64502 14.2114 0.312988 13.7798 0.312988C13.5723 0.312988 13.3813 0.395996 13.2402 0.528809L7.33008 6.57178L1.41162 0.528809C1.27881 0.395996 1.08789 0.312988 0.87207 0.312988C0.44043 0.312988 0.116699 0.64502 0.116699 1.07666C0.116699 1.28418 0.199707 1.4668 0.34082 1.61621L6.76562 8.19043C6.92334 8.34814 7.11426 8.43115 7.33008 8.43115Z"}))};u();g();var a=$(k());var B=l(h)`
  font-family: var(--font-family);
  color: rgb(109, 109, 109);
  font-weight: 500;
  font-size: 16px;
  width: 178px;
  position: absolute;
  z-index: 5000;
  left: 3px;
  bottom: 100%;
  background-color: #1e1e1e;
  padding: 6px 8px;
  background: #1e1e1e;
  border-radius: 6px;
  box-shadow: 0px 2px 4px 0px rgba(0, 0, 0, 0.08);
  > span {
    font-size: 12px;
    font-style: normal;
    font-weight: 400;
    line-height: 16px; /* 133.333% */
    letter-spacing: 0.12px;
    color: #ffffff;
  }
`.withComponent("div"),G=l.div`
  position: absolute;
  left: 8px;
  bottom: -8px;
`,N=l.div`
  position: absolute;
  right: -8px;
  top: -8px;
  cursor: pointer;
`,R=l.div`
  position: relative;
`,z=l(h)`
  font-family: var(--font-family);
  color: rgb(109, 109, 109);
  font-weight: 500;
  font-size: 16px;
  ${({direction:o})=>o==="up"||o==="down"?"width: 240px;":""}

  position: absolute;
  z-index: 5000;

  ${({direction:o})=>o==="down"&&`
  transform: translateX(-50%);
  margin-bottom: 8px;
  left: 50%;
  bottom: 100%;
  `}

  ${({direction:o})=>o==="up"&&`
  transform: translateX(-50%);
  margin-top: 8px;
  left: 50%;
  top: 100%;
  `}

  ${({direction:o})=>o==="left"&&`
  left: 100%;
  top: 0;
  bottom: 0;
  margin-left: 8px;
  `};

  ${({direction:o})=>o==="right"&&`
  right: 100%;
  top: 0;
  bottom: 0;
  margin-right: 8px;
  `};

  > svg {
    ${({direction:o})=>o==="left"||o==="right"?"width: 35px;":""}

    > path {
      fill: rgb(109, 109, 109);
    }
  }

  > span {
    ${({direction:o})=>o==="left"||o==="right"?"width: max-content;":""}
    position: relative;
    color: #112d6d;
    display: flex;
    border-radius: 6px;
    border: 1px solid rgba(58, 98, 254, 0.12);
    box-sizing: border-box;
    font-size: 14px;
    cursor: pointer;
    background-color: #ffffff;
    padding: 5px;
    align-items: center;
    sup {
      position: absolute;
      top: -7.5px;
      right: -7.5px;
    }
  }
`,V=l.sup`
  font-size: 13px;
  margin-left: 4px;
`,W=({children:o,direction:e,...n})=>{let r=(0,a.useMemo)(()=>({left:"row",right:"row-reverse",up:"column",down:"column-reverse"})[e]??"row",[e]);return t(z,{xAlign:!0,yAlign:!0,separation:"4px",direction:e,...n,style:{flexDirection:r,...n?.style??{}}},t(P,{direction:e}),t("span",null,o,t(V,null,t("svg",{width:"12",height:"12",viewBox:"0 0 12 12",fill:"none",xmlns:"http://www.w3.org/2000/svg"},t("path",{d:"M6 11C8.76142 11 11 8.76142 11 6C11 3.23858 8.76142 1 6 1C3.23858 1 1 3.23858 1 6C1 8.76142 3.23858 11 6 11Z",fill:"white",stroke:"#E7ECFF",strokeLinecap:"round",strokeLinejoin:"round"}),t("path",{d:"M7.5 4.5L4.5 7.5",stroke:"#3A62FE",strokeLinecap:"round",strokeLinejoin:"round"}),t("path",{d:"M4.5 4.5L7.5 7.5",stroke:"#3A62FE",strokeLinecap:"round",strokeLinejoin:"round"})))))},I=({text:o,direction:e,display:n,children:r,tooltipStyle:i,...s})=>t(R,{...s},r,n&&t(W,{direction:e,style:i},o)),F=({text:o,direction:e,display:n,children:r,...i})=>t(R,{...i},r,n&&t(B,{xAlign:!0,yAlign:!0,separation:"4px",direction:e,...i,style:{...i?.style??{}}},t(G,null,t("svg",{xmlns:"http://www.w3.org/2000/svg",width:"6",height:"6",viewBox:"0 0 6 6",fill:"none"},t("path",{d:"M0 3L2.82843 0.171573L5.65685 3L2.82843 5.82843L0 3Z",fill:"#1E1E1E"}))),t("span",null,o,t(N,{onClick:i?.onClick},t("svg",{xmlns:"http://www.w3.org/2000/svg",width:"16",height:"16",viewBox:"0 0 16 16",fill:"none"},t("rect",{width:"16",height:"16",rx:"8",fill:"#2D2D2F"}),t("path",{"fill-rule":"evenodd","clip-rule":"evenodd",d:"M10.3884 4.38837C10.6813 4.09548 11.1562 4.09548 11.4491 4.38837C11.742 4.68127 11.742 5.15614 11.4491 5.44903L8.97942 7.91867L11.4491 10.3884C11.742 10.6813 11.742 11.1561 11.4491 11.449C11.1563 11.7419 10.6814 11.7419 10.3885 11.449L7.91876 8.97933L5.44903 11.449C5.15613 11.7419 4.68126 11.7419 4.38837 11.449C4.09548 11.1561 4.09548 10.6813 4.38837 10.3884L6.85809 7.91867L4.38843 5.44903C4.09553 5.15614 4.09553 4.68127 4.38842 4.38837C4.68132 4.09548 5.15619 4.09548 5.44908 4.38837L7.91876 6.85802L10.3884 4.38837Z",fill:"white"})))))),fo=({id:o,display:e,variant:n="simple",onToolTipDismiss:r,...i})=>{let[s,p]=(0,a.useState)(!1),m=(0,a.useRef)(null);(0,a.useEffect)(()=>{(async()=>{let{oneTimeTooltips:b}=await new Promise(c=>d.storage.sync.get(["oneTimeTooltips"],c));p(!b?.[o]),d.storage.onChanged.addListener(async(c,w)=>{if(w!=="sync"||!c.oneTimeTooltips)return;let{oneTimeTooltips:y}=await new Promise(E=>d.storage.sync.get(["oneTimeTooltips"],E));p(!y?.[o])})})()},[]);let T=async f=>{if(r?.(),f.preventDefault(),f.stopPropagation(),!s)return;let c=m.current?.base?.contains(f.target)?"extension_listen_nudge_dismissed":"extension_listened_while_nudge_shown";S(c,{source:o}),p(!1);let{oneTimeTooltips:w}=await new Promise(y=>d.storage.sync.get(["oneTimeTooltips"],y));d.storage.sync.set({oneTimeTooltips:{...w,[o]:!0}})};return n==="simple"?t(I,{id:o,ref:m,display:e??s,onClick:T,...i}):n==="gmailStyle"?t(F,{id:o,ref:m,display:e??s,onClick:T,...i}):null},O=l.div`
  position: absolute;
  ${({display:o})=>o?"opacity: 1":"opacity: 0"};
  transition: 0.26s opacity;
  filter: drop-shadow(0px 1px 2px rgba(0, 0, 0, 0.1));
`,Z=l.div`
  position: absolute;
  ${({direction:o})=>["up","down"].includes(o)?`top:${o==="up"?" 0":"100%"}; left: 50%;`:`left:${o==="left"?" 0":"100%"}; top: 50%;`}
  transform: translate(-50%, -50%);
  z-index: 100;
`,j=l(h)`
  padding: 4px 8px;
  border-radius: 3px;
  min-height: 24px;
  min-width: 100px;
  background: ${({background:o})=>o};
`,go=({direction:o,display:e,children:n,tooltipStyle:r,background:i,style:s,...p})=>t(O,{style:s,...p,display:e},e&&t(j,{xAlign:!0,yAlign:!0,style:r,background:i},t(Z,{direction:o},t("svg",{width:"8",height:"8",viewBox:"0 0 6 6",fill:"none",xmlns:"http://www.w3.org/2000/svg"},t("path",{d:"M0 3L2.82843 0.171573L5.65685 3L2.82843 5.82843L0 3Z",fill:i}))),n));function X(){let[o,e]=(0,a.useState)(!1),n=(0,a.useRef)(),r=(0,a.useCallback)(()=>{n.current=window.setTimeout(()=>{e(!0)},300)},[]),i=(0,a.useCallback)(()=>{clearTimeout(n.current),e(!1)},[]);return{showTooltip:o,onMouseEnter:r,onMouseLeave:i}}var uo=l.div`
  position: relative;
  display: inline-block;
  pointer-events: auto;

  span {
    visibility: hidden;
    width: 133px;
    background-color: ${x.bgPrimW100};
    font-family: 'ABCDiatype';
    color: #d9d9d9;
    font-size: 12px;
    padding: 8px;
    border-radius: 3px;
    position: absolute;
    opacity: 1;
    z-index: 1;
    ${({down:o})=>o?"top: 150%":"bottom: 150%"};
    left: 154%;
    margin-left: -87px;

    &:after {
      content: '';
      position: absolute;
      ${({down:o})=>o?"bottom: 100%":"top: 100%"};
      left: 50%;
      margin-left: -5px;
      border-width: 5px;
      border-style: solid;
      ${({down:o})=>o?`border-color: transparent transparent ${x.brdrPrim10100} transparent`:`border-color: ${x.brdrPrim10100} transparent transparent transparent;`};
    }
  }

  :hover span {
    visibility: visible;
  }
`;function xo(o){return({children:e,...n})=>{let{showTooltip:r,onMouseLeave:i,onMouseEnter:s}=X();return t(o,{...n,showTooltip:r,onMouseLeave:i,onMouseEnter:s},typeof e=="function"?e(r):e)}}export{Y as a,fo as b,go as c,X as d,xo as e};
//# sourceMappingURL=chunk-TIGAXALM.js.map
