import{h,i as u,q as y}from"./chunk-KO4WPNRU.js";import{d as m}from"./chunk-TIGAXALM.js";import{a as b}from"./chunk-AG3QEKLJ.js";import{Ta as p,Ya as c}from"./chunk-RISKGE32.js";import{b as r,j as a,k as t}from"./chunk-F4AZU7R4.js";import{g as S}from"./chunk-GQY3J744.js";import{d as T,g as l,i,n as s}from"./chunk-CLPINNGF.js";s();l();var G={collapsed:178,pdf:102,compact:158,upsell:400,expanded:364},Z={collapsed:400,pdf:148,compact:272,upsell:436,expanded:400},q=20;s();l();var x=T(S());s();l();var P=e=>i(b,{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",...e},i("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M14 9C14 11.7614 11.7614 14 9 14C6.23858 14 4 11.7614 4 9C4 6.23858 6.23858 4 9 4C11.7614 4 14 6.23858 14 9ZM13.1927 14.606C12.0241 15.4814 10.5726 16 9 16C5.13401 16 2 12.866 2 9C2 5.13401 5.13401 2 9 2C12.866 2 16 5.13401 16 9C16 10.5721 15.4818 12.0231 14.6068 13.1916L17.7914 16.3762C18.1819 16.7668 18.1819 17.3999 17.7914 17.7904C17.4009 18.181 16.7677 18.181 16.3772 17.7904L13.1927 14.606Z",fill:"#AFB9C8"}));var Y=a`
  0% {
    opacity: 0;
    transform: translateX(60px);
    visibility: hidden;
  }
  1% {
    visibility: visible;
  }
  100% {
    opacity: 1;
    transform: translateX(0);
    visibility: visible;
  }`,I=a`
  from {
    transform: translateY(-200%);
  }
  to {
    transform: translateY(0);
  }`,W=a`
  from {
    transform: translateY(200%);
  }
  to {
    transform: translateY(0);
  }`,C=a`
  from {
    opacity: 0.6;
    transform: translateX(40px);
  }
  to {
    opacity: 1;
    transform: translateX(0);
  }`,z=a`
  0% {
    transform: translate(-50%, -50%) translateX(-3px);
  }
  100% {
    transform: translate(-50%, -50%) translateX(0px);
  }
`,O=()=>a`
 0% {
   background: ${r.bgPrimInvBW};
 }
 33% {
  background: ${r.sfActElectricBlue};
 }
 66% {
  background: ${r.sfActElectricBlue};
 }
 100% {
  background: ${r.bgPrimInvBW};
 }
`,k=t.button`
  background: #1e1e1f;
  border-radius: 50%;
  border: none;
  box-shadow: 0px 0px 0px 0px rgba(106, 120, 252, 0.5), 0px 0px 2px 0px rgba(106, 120, 252, 0.49),
    0px 0px 3px 0px rgba(106, 120, 252, 0.43), 0px 0px 4px 0px rgba(106, 120, 252, 0.25),
    0px 0px 4px 0px rgba(106, 120, 252, 0.07), 0px 0px 5px 0px rgba(106, 120, 252, 0.01);
  cursor: pointer;
  display: grid;
  height: 40px;
  left: 0;
  outline: none;
  place-items: center;
  position: relative;
  width: 40px;

  & > svg {
    height: 24px;
    width: 24px;
  }
`,ue=t(k)`
  background-color: ${({backgroundColor:e="#171515"})=>e};
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  width: 40px;
  height: 40px;

  & > svg {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    height: 24px;
    width: 24px;
    transition: opacity 0.3s ease;
  }

  & > svg.off-icon {
    opacity: ${({enabled:e})=>e?0:1};
  }

  & > svg.on-icon {
    opacity: ${({enabled:e})=>e?1:0};
    animation: ${({enabled:e})=>e?z:void 0} 0.3s ease-in-out 1;
  }
`,me=t("div")`
  display: flex;
  padding: 8px;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  gap: 4px;
  cursor: pointer;
  border-radius: 9999px;
  background: #1e1e1f;

  /* pill_glow_dark */
  box-shadow: 0px 0px 5px 0px rgba(106, 120, 252, 0.01), 0px 0px 4px 0px rgba(106, 120, 252, 0.07),
    0px 0px 4px 0px rgba(106, 120, 252, 0.25), 0px 0px 3px 0px rgba(106, 120, 252, 0.43),
    0px 0px 2px 0px rgba(106, 120, 252, 0.49), 0px 0px 0px 0px rgba(106, 120, 252, 0.5);

  & > svg {
    height: 24px;
    width: 24px;
  }

  & > span {
    font-family: 'ABCDiatype';
    font-size: 12px;
    font-style: normal;
    font-weight: 500;
    line-height: 16px; /* 133.333% */
    letter-spacing: 0.12px;
    color: ${({enabled:e})=>e?"#23AE75":"#9899A6"};
  }

  &:hover {
    background: ${({enabled:e})=>e?"#252627":"#1E1E1F"};
    & > span {
      opacity: 0.75;
    }
    & > svg {
      opacity: 0.75;
    }
  }

  &:active {
    background: ${({enabled:e})=>e?"#343537":"#1E1E1F"};
    & > span {
      opacity: 0.5;
    }
    & > svg {
      opacity: 0.5;
    }
  }
`,ye=t(k)`
  animation: 0.05s
    ${({visible:e=!1,direction:o="down"})=>e?o==="up"?W:I:void 0}
    0.35s ease-out;
  width: 40px;
  height: 40px;
  animation-fill-mode: forwards;

  transform: ${({visible:e=!1,direction:o="down",hasIsland:n=!1})=>e?o==="up"?`translateY(${n?"300%":"200%"})`:"translateY(-200%)":void 0};

  &:hover {
    svg {
      opacity: 0.75;
    }
  }

  &:active {
    svg {
      opacity: 0.5;
    }
  }

  & > svg {
    height: 20px;
    width: 20px;
    ${({direction:e="down"})=>e==="up"?"transform:rotateZ(180deg)":""}
  }
`,ve=t.div`
  font-family: ABCDiatype, sans-serif;
  height: 100%;
  min-width: 240px;
  padding: 0;
  width: 100%;
`,we=t(p)`
  animation: ${({visible:e=!1})=>e?C:void 0} 0.2s ease-out;
  background: #1e1e1e;
  border-radius: 12px;
  box-shadow: 0px 0px 0px 0px rgba(106, 120, 252, 0.5), 0px 0px 2px 0px rgba(106, 120, 252, 0.49),
    0px 0px 3px 0px rgba(106, 120, 252, 0.43), 0px 0px 4px 0px rgba(106, 120, 252, 0.25),
    0px 0px 4px 0px rgba(106, 120, 252, 0.07), 0px 0px 5px 0px rgba(106, 120, 252, 0.01);
  cursor: default;
  ${({showOnRight:e=!1})=>e?"left: 60px;":"right: 60px;"}
  ${({route:e,showPointer:o})=>!e?.startsWith("/voices")&&!o&&"overflow: hidden;"}
  position: absolute;
  top: ${({route:e})=>e?.startsWith("/pillreport")?"80px":e?.startsWith("/featureprompt/skipsentences")?"10px":"20px"};
  visibility: ${({visible:e=!1})=>e?"visible":"hidden"};

  ${({showPointer:e,showOnRight:o})=>e?`
      &::after {
        content: '';
        position: absolute;
        top: 50%;
        ${o?`
              left: -8px;
              border-right: 8px solid #1e1e1e;
            `:`
              right: -8px;
              border-left: 8px solid #1e1e1e;
            `}
        transform: translateY(-50%);
        border-top: 6px solid transparent;
        border-bottom: 6px solid transparent;
      }
    `:""}
`,Pe=t.div`
  display: flex;
  flex-direction: column;
  gap: 15px;
  align-items: ${({aligned:e})=>e};
`,Ce=t.div`
  display: flex;
  flex-direction: row;
  gap: 50px;
  align-items: center;
`,ke=t(y)`
  width: 160px;
  height: 48px;
  align-items: center;
  justify-content: center;
  font-family: 'ABCDiatype';
  font-weight: 700;
  font-size: 16px;
  margin-top: 18px;
`,$e=t.div`
  align-items: center;
  border-radius: 8px;

  display: flex;
  gap: 8px;

  img {
    border-radius: 2px;
    height: 20px;
    overflow: hidden;
    width: 20px;
  }

  svg {
    fill: #afb9c8;
    width: 20px;
    height: 20px;
  }
`,Ae=t.div`
  font-size: 18px;
  font-style: normal;
  font-weight: 700;
  letter-spacing: 0.14px;
  line-height: 24px;
  font-family: 'ABCDiatype';
`,Ee=t.div`
  align-items: center;
  display: flex;
  padding: 0;
  margin: -2px 0 0 0;
`,Be=t.div`
  align-items: center;
  display: flex;
  flex-direction: row;
  font-family: ABCDiatype;
  font-size: 12px;
  font-weight: 700;
  font-variant-numeric: tabular-nums;
  justify-content: center;
  height: 20px;
  line-height: 20px;
  text-align: center;
  width: 48px;
`,De=t.span`
  color: #8791a0;
  font-weight: 500;
`,Le=t.div`
  align-items: center;
  display: flex;
  justify-content: center;

  &.left {
    text-align: right;
  }

  &.right {
    text-align: left;
  }
`,Re=({alignLeft:e,onClose:o,onSearch:n,title:d})=>i(H,null,n&&i(N,{onClick:n},i(P,{fill:r.icnTxtSec})),i(F,{alignLeft:e},d),i(_,{alignLeft:e},i(j,{"data-testId":"Close Side Panel",onClick:o},i(c,{fill:r.icnTxtSec})))),j=t.button`
  background: unset;
  border: unset;
  color: #fff;
  cursor: pointer;
  display: flex;
  outline: unset;
  padding: 0;

  > svg {
    width: 24px !important;
    height: 24px !important;
    margin-top: 4px;
  }
`,N=t.button`
  background: unset;
  border: unset;
  cursor: pointer;
  display: flex;
  outline: unset;
  align-items: flex-start;
  gap: 0px;
  padding: 0px;
  margin-top: 0px;
`,_=t.div`
  position: absolute;
  right: ${({alignLeft:e})=>e?"4px":"16px"};
  top: 8px;
`,F=t.div`
  align-items: center;
  color: #fff;
  display: flex;
  flex: 1 0 0;
  font-size: 16px;
  font-style: normal;
  font-weight: 700;
  gap: 6px;
  justify-content: ${({alignLeft:e})=>e?"flex-start":"center"};
  letter-spacing: 0.16px;
  line-height: 24px;
  text-align: ${({alignLeft:e})=>e?"left":"center"};
`,H=t.div`
  align-items: center;
  align-self: stretch;
  border-top-left-radius: 12px;
  border-top-right-radius: 12px;
  display: flex;
  padding: 12px 16px;
  position: relative;
`,Te={AbsoluteCloseIcon:t(c)`
    cursor: pointer;
    fill: #9899a6;
    position: absolute;
    right: 12px;
    top: 6px;

    &:hover {
      fill: #fff;
    }
  `,Container:t.div`
    align-items: flex-start;
    align-self: stretch;
    border-radius: 10px;
    display: flex;
    flex-direction: column;
    gap: 24px;
  `,Header:t.div`
    display: flex;
    align-items: center;
    gap: 8px;
  `,HeaderLogo:t.div`
    display: flex;
    width: 115.63px;
    height: 20px;
    padding-right: 0.09px;
    justify-content: center;
    align-items: flex-end;
    gap: 4.36px;
  `,Body:t.div`
    align-items: flex-start;
    align-self: stretch;
    color: #fff;
    display: flex;
    flex-direction: column;
    font-size: 16px;
    font-style: normal;
    font-weight: 400;
    gap: 8px;
    letter-spacing: -0.08px;
    line-height: 24px;
    width: 230px;
  `,Footer:t.div`
    display: flex;
    align-items: center;
    align-self: stretch;
    justify-content: flex-end;
    gap: 4px;
    color: #747580;
    font-size: 14px;
    font-weight: 400;
    font-style: normal;
    line-height: 20px;
    letter-spacing: -0.07px;
  `,Key:t.div`
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    width: 26px;
    height: 16px;
    padding: 2px;
    gap: 0;
    background: #2d2d2f;
    border-radius: 4px;
    color: #e9eaf0;
    font-size: 12px;
    font-weight: 400;
    font-style: normal;
    line-height: 16px;
    letter-spacing: 0.12px;
    text-align: center;
  `,DownloadButton:t.button`
    align-items: center;
    align-self: stretch;
    background: #2d2d2f;
    border-radius: 10px;
    border: none;
    color: #fff;
    cursor: pointer;
    display: flex;
    font-family: ABCDiatype, sans-serif;
    font-size: 14px;
    font-style: normal;
    font-weight: 500;
    gap: 6px;
    justify-content: center;
    letter-spacing: -0.07px;
    line-height: 20px;
    padding: 8px 16px 8px 20px;

    &:hover {
      background: #343537;
    }

    &:active {
      background: #3c3c3e;
    }
  `,DownloadButtonIcon:t.div`
    align-items: flex-start;
    display: flex;
    gap: 0px;
    height: 20px;
    padding: 0px;
  `,UpsellButton:t.button`
    align-items: center;
    display: flex;
    gap: 8px;
    justify-content: center;
    padding: 8px 20px 8px 16px;
    width: 100%;

    color: #000;
    font-family: ABCDiatype, sans-serif;
    font-size: 14px;
    font-style: normal;
    font-weight: 700;
    line-height: 20px;
    letter-spacing: 0.14px;

    background: linear-gradient(0deg, rgba(0, 0, 0, 0.4) 0%, rgba(0, 0, 0, 0.4) 100%),
      radial-gradient(
        113.68% 113.68% at 84.82% -14.29%,
        rgba(255, 230, 0, 0.8) 0%,
        rgba(255, 149, 0, 0) 100%
      ),
      radial-gradient(
        97.58% 151.79% at -6.25% 114.29%,
        rgba(255, 26, 150, 0.4) 0%,
        rgba(250, 0, 255, 0.03) 84.18%,
        rgba(250, 0, 255, 0) 100%
      ),
      linear-gradient(283deg, #ffa82f 0.25%, #ff795b 100%);
    background-blend-mode: overlay, normal, normal, normal;
    border: none;
    border-radius: 10px;
    cursor: pointer;

    svg {
      fill: #000;
      width: 20px;
      height: 20px;

      path {
        fill: #000;
      }
    }

    &:hover {
      opacity: 0.75;
      background: linear-gradient(0deg, rgba(0, 0, 0, 0.4) 0%, rgba(0, 0, 0, 0.4) 100%),
        radial-gradient(
          113.68% 113.68% at 84.82% -14.29%,
          rgba(255, 230, 0, 0.8) 0%,
          rgba(255, 149, 0, 0) 100%
        ),
        radial-gradient(
          97.58% 151.79% at -6.25% 114.29%,
          rgba(255, 26, 150, 0.4) 0%,
          rgba(250, 0, 255, 0.03) 84.18%,
          rgba(250, 0, 255, 0) 100%
        ),
        linear-gradient(283deg, #ffa82f 0.25%, #ff795b 100%);
    }

    &:active {
      opacity: 0.5;
      background: linear-gradient(0deg, rgba(0, 0, 0, 0.4) 0%, rgba(0, 0, 0, 0.4) 100%),
        radial-gradient(
          113.68% 113.68% at 84.82% -14.29%,
          rgba(255, 230, 0, 0.8) 0%,
          rgba(255, 149, 0, 0) 100%
        ),
        radial-gradient(
          97.58% 151.79% at -6.25% 114.29%,
          rgba(255, 26, 150, 0.4) 0%,
          rgba(250, 0, 255, 0.03) 84.18%,
          rgba(250, 0, 255, 0) 100%
        ),
        linear-gradient(283deg, #ffa82f 0.25%, #ff795b 100%);
    }
  `},Se=t.div`
  font-family: ABCDiatype, sans-serif;
  height: 100%;
  min-width: 230px;
  padding: 0;
  width: 100%;
`,Ye=t(p)`
  animation: ${({visible:e=!1})=>e?C:void 0} 0.2s ease-out;
  background: #1e1e1e;
  border-radius: 12px;
  box-shadow: 0px 0px 0px 0px rgba(106, 120, 252, 0.5), 0px 0px 2px 0px rgba(106, 120, 252, 0.49),
    0px 0px 3px 0px rgba(106, 120, 252, 0.43), 0px 0px 4px 0px rgba(106, 120, 252, 0.25),
    0px 0px 4px 0px rgba(106, 120, 252, 0.07), 0px 0px 5px 0px rgba(106, 120, 252, 0.01);

  box-shadow: 0px 4px 6px 0px rgba(0, 0, 0, 0.32);

  color: #fff;
  cursor: default;
  ${({showOnRight:e=!1})=>e?"left: 60px;":"right: 60px"};
  overflow: hidden;
  position: absolute;
  top: -12px;
  visibility: ${({visible:e=!1})=>e?"visible":"hidden"};
`,M=t.div`
  background: #1e1e1e;
  border-radius: 8px;
  color: #fff;
  font-family: ABCDiatype;
  font-size: 12px;
  font-weight: 400;
  ${({showOnRight:e=!1})=>e?"left: 50px;":"right: 50px"};
  letter-spacing: 0.12px;
  line-height: 16px;
  border: 0.75px solid #2d2d2f;
  padding: 8px;
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  width: max-content;
  z-index: 1;

  // tooltip tip
  &:before {
    content: ' ';
    position: absolute;
    ${({showOnRight:e=!1})=>e?"left: -6px":"right: -6px"};
    top: 50%;
    transform: translateY(-50%);
    width: 6px;
    height: 10px;
    background: #2d2d2f;
    clip-path: ${({showOnRight:e=!1})=>e?"polygon(0 50%, 100% 0, 100% 100%)":"polygon(0 0, 0 100%, 100% 50%)"};
  }

  // tooltip tip inner
  &:after {
    content: ' ';
    position: absolute;
    ${({showOnRight:e=!1})=>e?"left: -5px":"right: -5px"};
    top: 50%;
    transform: translateY(-50%);
    width: 5px;
    height: 9px;
    background: #1e1e1e;
    clip-path: ${({showOnRight:e=!1})=>e?"polygon(0 50%, 100% 0, 100% 100%)":"polygon(0 0, 0 100%, 100% 50%)"};
  }
`,V=t.div`
  position: ${({disableRelative:e,isAbsolute:o})=>o?"absolute":e?"static":"relative"};
  opacity: ${({visible:e})=>e?1:0};
  ${({visible:e})=>!e&&"pointer-events: none;"}
  transition: opacity 0.15s ease-in-out;
  display: flex;
  align-items: center;
  ${({isPlayButton:e})=>e&&"height: 36px;"}
  ${({isTop:e})=>e?"top: -48px;":"bottom: 0;"}
  z-index: 9998;
`,Ie=t(p)`
  align-items: center;
  color: ${r.icnTxtPrim};
  cursor: default;
  display: flex;
  flex-direction: column;
  gap: 4px;
  height: ${({playerContainerHeight:e})=>`${e}px`};
  transition: height 0.15s ease-in-out;

  .pill-player-bottom-section {
    opacity: 1;
    transition: opacity 0.05s ease-in-out forwards;
    will-change: opacity;
  }

  &.animating {
    .pill-player-bottom-section {
      opacity: 0;
    }
  }
`,We=t(p)`
  z-index: 9999;
  padding-bottom: 8px;
  position: relative;
  cursor: move;
`,U=t(p)`
  z-index: 9999;
  background-color: #1e1e1f;
  padding: 12px 0 8px;
  border-radius: 100px;
  position: relative;
  cursor: move;
  box-shadow: 0px 0px 0px 0px rgba(106, 120, 252, 0.5), 0px 0px 2px 0px rgba(106, 120, 252, 0.49),
    0px 0px 3px 0px rgba(106, 120, 252, 0.43), 0px 0px 4px 0px rgba(106, 120, 252, 0.25),
    0px 0px 4px 0px rgba(106, 120, 252, 0.07), 0px 0px 5px 0px rgba(106, 120, 252, 0.01);
`,ze=t(U)`
  width: 48px;
  justify-content: center;
  padding: 0;
  cursor: initial;
`,Oe=t.div`
  align-items: center;
  animation: ${({animate:e=!1})=>e?Y:void 0} 0.08s ease-out 0.08s
    forwards;
  display: flex;
  flex-direction: column;
  gap: 8px;
  visibility: hidden;
  visibility: ${({animate:e=!1})=>e?"hidden":"visible"};
  position: relative;
`,je=t.div`
  align-items: center;
  display: flex;
  flex-direction: column;
  gap: 4px;
`,Ne=t.div`
  align-items: center;
  display: flex;
  flex-direction: column;
  gap: 4px;
`,_e=t.div`
  display: ${({visible:e})=>e?"flex":"none"};
  flex-direction: column;
  gap: 4px;
  max-height: ${({visible:e})=>e?"120px":"0px"};
  transition: max-height 0.2s ease-in-out;

  &.dismiss {
    bottom: 6px;
    position: absolute;
  }
`,Fe=t.div`
  position: relative;
`,He=t.div`
  display: flex;
  flex-direction: column;
  position: absolute;
  bottom: 0;
  align-items: center;
  gap: 8px;
  bottom: ${({showScrollDown:e,showAutoToggle:o})=>e&&o?"-108px":e&&!o?"-40px":!e&&o?"-60px":"0px"};
`,Me=t.div`
  background-color: #2d2d2f;
  display: block;
  height: 2px;
  max-height: 2px;
  border-radius: 2px;
  width: 60%;
`,Ve=t.div`
  height: 14px;
  position: absolute;
  right: -4px;
  top: -4px;
  width: 12px;
`,Ue=t.div`
  display: flex;
  gap: 50px;
  justify-content: space-between;
  margin-top: 32px;
  align-items: center;
  height: 48px;

  button {
    border: 1px solid #1e1e1e;
    background-color: #1e1e1e;
    border-radius: 8px;
    color: #ffffff;
    font-family: ABCDiatype, sans-serif;
    height: 48px;
    align-items: center;
    justify-content: center;
    font-family: 'ABCDiatype';
    font-weight: 700;
    font-size: 16px;

    &:hover {
      background-color: #2e2e2e;
      border-color: #2e2e2e;
      color: #ffffff;
    }

    &:active {
      background-color: #383838;
      border-color: #383838;
      color: #ffffff;
    }

    &.settings {
      padding: 8px 28px 8px 24px;
    }

    &[type='submit'] {
      background-color: #6b78fc;
      border-color: #6b78fc;
      color: #ffffff;

      &:hover {
        background-color: #9ba3ff;
        border-color: #9ba3ff;
      }

      &:active {
        background-color: #6870cc;
        border-color: #6870cc;
      }
    }
  }

  svg {
    fill: #ffffff;
    height: 20px;
    width: 20px;
    margin-right: 8px;
  }

  .right-aligned {
    margin-left: auto;
    display: flex;
    gap: 12px;
  }
`,Xe=t.div`
  display: flex;
  gap: 16px;

  button {
    border: 1px solid #1e1e1e;
    background-color: #1e1e1e;
    border-radius: 8px;
    color: #ffffff;
    font-family: ABCDiatype, sans-serif;
    height: 48px;
    align-items: center;
    justify-content: center;
    font-family: 'ABCDiatype';
    font-weight: 700;
    font-size: 16px;

    &:hover {
      background-color: #2e2e2e;
      border-color: #2e2e2e;
      color: #ffffff;
    }

    &:active {
      background-color: #383838;
      border-color: #383838;
      color: #ffffff;
    }

    &[type='submit'] {
      background-color: #6b78fc;
      border-color: #6b78fc;
      color: #ffffff;

      &:hover {
        background-color: #9ba3ff;
        border-color: #9ba3ff;
      }

      &:active {
        background-color: #6870cc;
        border-color: #6870cc;
      }
    }
  }

  svg {
    fill: #ffffff;
    height: 20px;
    width: 20px;
    margin-right: 8px;
  }

  .right-aligned {
    margin-left: auto;
    display: flex;
    gap: 12px;
  }
`,Ke=t(h)`
  fill: #fff;
  max-width: 18px !important;
  max-height: 18px !important;
`,Ge=t(u)`
  fill: #fff;
  max-width: 18px !important;
  max-height: 18px !important;
`,X=t(p)`
  display: inline-flex;
  gap: 2px;
  margin-left: 6px;
`,K=t.kbd`
  font-family: system-ui;
  display: inline-flex;
  justify-content: center;
  align-items: center;
  height: 20px;
  min-width: 20px;
  padding: 0px 5px;
  box-sizing: border-box;
  background: #3c3c3e;
  border-radius: 2px;
`,Ze=({keys:e})=>{let o=(0,x.useMemo)(()=>e.split("+"),[e]);return i(X,null,o.map(n=>i(K,{key:n},n)))},qe=t.span`
  width: 6px;
  height: 6px;
  border-radius: 100%;

  background: ${r.sfActElectricBlue};
  animation: ${O} 1.2s infinite;

  &:nth-of-type(2) {
    animation-delay: -0.8s;
  }

  &:nth-of-type(3) {
    animation-delay: -1.6s;
  }
`;var Je=({children:e,disabled:o,text:n,showOnRight:d=!1,visible:$=!0,forceShow:A=!1,...E})=>{let{onMouseLeave:B,onMouseEnter:D,showTooltip:L}=m(),[f,g]=(0,x.useState)(!1),R=()=>g(!0);return(0,x.useEffect)(()=>{f&&setTimeout(()=>{g(!1)},500)},[f]),i(V,{onClick:R,onMouseLeave:B,onMouseEnter:D,...E,visible:$},(L&&!f||A)&&!o&&n&&i(M,{"aria-roledescription":"tooltip",showOnRight:d},n),e)};export{G as a,Z as b,q as c,me as d,ye as e,ve as f,we as g,Pe as h,Ce as i,ke as j,$e as k,Ae as l,Ee as m,Be as n,De as o,Le as p,Re as q,F as r,Te as s,Se as t,Ye as u,Ie as v,We as w,U as x,ze as y,Oe as z,je as A,Ne as B,_e as C,Fe as D,He as E,Me as F,Ve as G,Ue as H,Xe as I,Ke as J,Ge as K,Ze as L,Je as M};
//# sourceMappingURL=chunk-GWCIFOLA.js.map
