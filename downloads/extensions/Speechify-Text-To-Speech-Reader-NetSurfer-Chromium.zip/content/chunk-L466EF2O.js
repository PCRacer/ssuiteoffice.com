import{a as E}from"./chunk-O3LC63CS.js";import{Ac as k,Bc as _,Cc as U,Cd as m,Dd as K,Na as C,Oc as S,Pc as c,Qb as l,Rb as N,Ta as O,Wa as p,Ya as T,id as R,jd as w,kd as F,ld as b,nd as v,od as D,pd as L,wc as I,yc as P,zc as B}from"./chunk-RISKGE32.js";import{k as r}from"./chunk-F4AZU7R4.js";import{g as X}from"./chunk-GQY3J744.js";import{d as W,g as u,i as t,n as f}from"./chunk-CLPINNGF.js";f();u();function g(){let s=()=>{m("introduce-ai-button")};return t(F,{width:198},t(R,{onClick:s,"aria-label":"Close"},t(w,null)),t(L,null,"Listen to Responses"),t(v,null,"Play and Pause any response in your chat by clicking the button."),t(D,null,t(b,{onClick:s},"OK, Got it")))}f();u();var i=W(X());var h=[{check:I,enum:"chatgpt"},{check:P,enum:"claude"},{check:_,enum:"deepseek"},{check:B,enum:"gemini"},{check:U,enum:"grok"},{check:k,enum:"perplexity"}];function V(){let s=N.useConfig(),e="individual-posts-player",n="autoplayResponses",o=(0,i.useMemo)(()=>h.find(a=>a.check()),[]),d=(0,i.useMemo)(()=>o?l.playButtons.get(e,o.enum,n):!1,[o,s]),x=(0,i.useCallback)(()=>{if(!o)return;let A=!l.playButtons.get(e,o.enum,n);c("auto-play",A.toString()),l.playButtons.set(e,o.enum,n,A)},[o]),y=(0,i.useCallback)(()=>{o&&(c("auto-play","false"),l.playButtons.set(e,o.enum,n,!1))},[o]),z=(0,i.useCallback)(()=>{c("auto-play","false"),h.forEach(({enum:a})=>{l.playButtons.set(e,a,n,!1)})},[]),M=(0,i.useCallback)(()=>{o&&(c("auto-play","true"),l.playButtons.set(e,o.enum,n,!0))},[o]),j=(0,i.useCallback)(()=>{c("auto-play","true"),h.forEach(({enum:a})=>{l.playButtons.set(e,a,n,!0)})},[]);return{isEnabled:d,toggle:x,turnOff:y,turnOffAll:z,turnOn:M,turnOnAll:j}}f();u();var J=r(T)`
  cursor: pointer;
  fill: #9899a6;
  position: absolute;
  right: 8px;
  top: 2px;

  &:hover {
    fill: #fff;
  }
`,Q=r.div`
  color: #fff;
  font-size: 14px;
  font-style: normal;
  font-weight: 400;
  letter-spacing: 0.14px;
  line-height: 20px;
`,Z=r.div`
  align-items: flex-start;
  align-self: stretch;
  border-radius: 10px;
  display: flex;
  flex-direction: column;
  gap: 12px;
`,$=r.div`
  align-items: center;
  background: #4759f7;
  border-radius: 10px;
  color: #fff;
  cursor: pointer;
  display: flex;
  flex: 1 0 0;
  font-size: 14px;
  font-style: normal;
  font-weight: 700;
  gap: 0px;
  justify-content: center;
  letter-spacing: 0.14px;
  line-height: 20px;
  padding: 8px 16px 8px 8px;
  white-space: nowrap;

  > svg {
    fill: #fff;
    margin-right: 8px;

    path {
      fill: #fff;
    }
  }
`,H=r.div`
  align-items: flex-start;
  align-self: stretch;
  display: flex;
  gap: 16px;
`,tt=r.div`
  align-items: center;
  border-radius: 10px;
  color: #9899a6;
  cursor: pointer;
  display: flex;
  font-size: 14px;
  font-style: normal;
  font-weight: 500;
  gap: 0px;
  justify-content: center;
  letter-spacing: 0.14px;
  line-height: 20px;
  padding: 8px 0px;
  white-space: nowrap;
`,ot=r.div`
  color: #fff;
  font-size: 16px;
  font-style: normal;
  font-weight: 700;
  letter-spacing: 0.16px;
  line-height: 24px;
`;function nt(){let{turnOffAll:s,turnOnAll:e}=V(),n=y=>{m("introduce-ai-autoplay"),S("extension_usage_new_user_education_prompt_interacted",{prompt:"introduce-ai-autoplay",action:y})},o=()=>{n("close")},d=async()=>{s(),await K({component:!0,duration:0,id:"introduce-ai-button",priority:101,showOnMobile:!1,timeSensitive:!0,render:()=>t(g,null)}),n("keep-off")};return t(O,{xAlign:!0,column:!0,separation:"8px"},t(Z,null,t(ot,null,"Autoplay Responses"),t(Q,null,"Speechify can automatically read out chat responses as soon as they’re generated."),t(H,null,t($,{onClick:()=>{e(),setTimeout(()=>{C.play(),n("turn-on")},500)},"data-testid":p.TURN_ON_AUTOPLAY},t(E,null),"Turn On Autoplay"),t(tt,{onClick:d,"data-testid":p.KEEP_OFF_AUTOPLAY},"Keep off"))),t(J,{onClick:o,"data-testid":p.CLOSE_AUTOPLAY}))}export{g as a,V as b,nt as c};
//# sourceMappingURL=chunk-L466EF2O.js.map
