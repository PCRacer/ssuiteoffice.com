import{a as bt,b as be,e as de,f as j,g as _t,i as At}from"./chunk-5VQR6ERF.js";import{a as Ot}from"./chunk-7XGTX76V.js";import{a as at}from"./chunk-5PO6RROQ.js";import{a as ot}from"./chunk-Z3E43XMU.js";import{a as nt}from"./chunk-BN5XPDNR.js";import{c as it}from"./chunk-EF43U47C.js";import"./chunk-O3LC63CS.js";import"./chunk-AG3QEKLJ.js";import"./chunk-C4ZBMBCR.js";import{$a as Ke,Aa as We,Ac as gt,Bc as yt,Cc as Pt,Cd as Tt,Db as rt,Dc as Rt,Dd as xt,Ea as Ye,Fd as St,Ga as Ue,Gc as Et,Ic as vt,Na as W,Oa as V,Oc as It,Sa as qe,Ta as se,Uc as wt,Va as Te,Wa as xe,Za as ce,_a as je,_b as Oe,bb as Je,gb as Se,mb as Qe,mc as D,nb as et,oc as lt,qb as tt,sa as Be,sc as st,tc as ct,uc as dt,vc as ft,wc as ut,xc as mt,yc as ht,zc as pt}from"./chunk-RISKGE32.js";import{F as Fe,ba as Kt,ca as Ge,ea as Ie,fa as $e,ha as ze,p as Ve}from"./chunk-6O6MLDWR.js";import{b as le,c as we,g as Ze,j as Xe,k as z}from"./chunk-F4AZU7R4.js";import{b as $,f as jt,g as Jt}from"./chunk-GQY3J744.js";import{d as Me,g,i as n,k as ke,m as Xt,n as y}from"./chunk-CLPINNGF.js";y();g();y();g();var ee=Me(Kt());Xt();y();g();var _e=e=>{let t=Math.min(...e.map(d=>d.x)),o=Math.min(...e.map(d=>d.y)),f=Math.max(...e.map(d=>d.x+d.width)),s=Math.max(...e.map(d=>d.y+d.height)),c=f-t,p=s-o;return new DOMRect(t,o,c,p)},K=({rect:e,horizontalPadding:t,verticalPadding:o})=>new DOMRect(e.x-t,e.y-o,e.width+2*t,e.height+2*o);y();g();var O=Me(Jt());jt();y();g();var Nt=e=>n("svg",{"aria-label":"Speechify Inline player Play button","data-testid":"Paragraph/Hover Player Play Button",width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",xmlns:"http://www.w3.org/2000/svg",...e},n("g",{clipPath:"url(#clip0_19693_61227)"},n("circle",{cx:"12",cy:"12",r:"12",fill:"#4759F7"}),n("path",{d:"M16.5 11.134C17.1667 11.5189 17.1667 12.4811 16.5 12.866L10.5 16.3301C9.83333 16.715 9 16.2339 9 15.4641L9 8.53592C9 7.76611 9.83333 7.28499 10.5 7.66989L16.5 11.134Z",fill:"white"})),n("defs",null,n("clipPath",{id:"clip0_19693_61227"},n("rect",{width:"24",height:"24",fill:"white"})))),Ct=e=>n("svg",{"aria-label":"Speechify Inline player Pause button","data-testid":"Paragraph/Hover Player Pause Button",width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",xmlns:"http://www.w3.org/2000/svg",...e},n("g",{clipPath:"url(#clip0_20845_46272)"},n("circle",{cx:"12",cy:"12",r:"12",fill:"#4759F7"}),n("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M8.8 7C8.35817 7 8 7.35817 8 7.8V16.2C8 16.6418 8.35817 17 8.8 17H10.2C10.6418 17 11 16.6418 11 16.2V7.8C11 7.35817 10.6418 7 10.2 7H8.8ZM13.8 7C13.3582 7 13 7.35817 13 7.8V16.2C13 16.6418 13.3582 17 13.8 17H15.2C15.6418 17 16 16.6418 16 16.2V7.8C16 7.35817 15.6418 7 15.2 7H13.8Z",fill:"white"})),n("defs",null,n("clipPath",{id:"clip0_20845_46272"},n("rect",{width:"24",height:"24",fill:"white"}))));y();g();var Lt="speechify-hover-player-icon";var{usePlayingState:er,useCurrentContent:tr,useOrator:rr}=V;var Ht=2147483640,or=z.button`
  position: absolute;
  cursor: pointer;
  background: transparent;
  border: none;
  outline: none;
  margin: 0;
  padding: 0;
  pointer-events: all;

  @keyframes fadeOut {
    from {
      opacity: 1;
    }
    to {
      opacity: 0;
    }
  }

  @keyframes fadeIn {
    from {
      opacity: 0;
    }
    to {
      opacity: 1;
    }
  }

  @keyframes loading {
    from {
      transform: rotate(0deg);
    }
    to {
      transform: rotate(360deg);
    }
  }

  .fadeOut {
    animation-name: fadeOut;
    animation-duration: ${200}ms;
    animation-timing-function: ease-out;
    animation-fill-mode: forwards;
  }

  .fadeIn {
    animation-name: fadeIn;
    animation-timing-function: ease-out;
    animation-duration: ${100}ms;
    animation-fill-mode: forwards;
  }

  .icon {
    cursor: pointer;
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 50%;
    position: absolute;
    color: ${le.icnTxtPrim};
    background: #4759f7;
    &:hover {
      background: #4454e3;
    }

    > .play-pause-icon-svg {
      cursor: pointer;
      width: 100%;
      height: 100%;
    }

    .circularProgress {
      position: absolute;
      width: calc(100% + 2px + 1.75px); /* Increased by stroke width */
      height: calc(100% + 2px + 1.75px); /* Increased by stroke width */
      top: calc(-1px - 0.875px); /* Offset decreased by half stroke width */
      left: calc(-1px - 0.875px); /* Offset decreased by half stroke width */
      animation-name: loading;
      animation-duration: 1s;
      animation-iteration-count: infinite;
      animation-timing-function: linear;
    }
  }
`,nr=Xe`
  from {
    width: 0;
  }
  to {
    width: 100%;
  }
`,ir=z.div`
  position: absolute;
  height: 3px;
  background: linear-gradient(90deg, #4759f7 52.5%, rgba(107, 120, 252, 0) 93.6%);
  border-radius: 4px 0 0 4px;
  opacity: 1;

  top: 0;
  left: 0;
  animation-fill-mode: forwards;
  animation: ${nr} ${100}ms ease-out;
  width: 100%;
`,ar=z(ot)`
  height: ${({size:e})=>e};
  left: -${4}px;
  top: -${4}px;
  width: ${({size:e})=>e};
  g circle {
    stroke-width: 3;
  }
`,Ae=e=>[e.ariaLabel,...Array.from(e.children).map(t=>Ae(t))].join(""),lr=(e,t)=>e?e===t.element||"isConnected"in e&&!e.isConnected&&Ae(e)===Ae(t.element):!1,sr=(e,t)=>{let o=(0,O.useCallback)(f=>setTimeout(()=>{t(s=>s.filter(c=>f.instanceId!==c.instanceId))},200),[]);$(()=>{let f=e.filter(s=>!s.destroyingTimeout&&s.hoverPlayerState==="Initial").map(s=>s.instanceId);f.length>0&&t(s=>s.map(c=>f.includes(c.instanceId)?{...c,destroyingTimeout:o(c)}:c))},[e,o])};function kt({hoveredParagraph:e,emotionCache:t,wasLifecycleAudioLoadedTriggered:o,onPlaybackStarted:f}){let s=We(),c=er(),p=tr(),d=rr(),{activeElement:R}=Ot(),[l,P]=(0,O.useState)(),[E,w]=(0,O.useState)([]);sr(E,w),$(()=>{c!=="paused"&&c!=="stopped"&&f()},[c]);let k=(0,O.useCallback)(a=>{P(u=>u&&a(u)),w(u=>{let T=!1,H=u.map(m=>{let x=a(m);return T=T||x!==m,x});return T?H:u})},[]),_=(0,O.useCallback)((a,u)=>k(T=>T.instanceId!==a?T:u(T)),[]);$(()=>{!e&&l&&(P(void 0),w(a=>[l,...a]))},[e,l]),$(()=>{e&&(e.reactKey!==l?.hoveredParagraph.reactKey?(l&&w(a=>[l,...a].filter(u=>u.hoveredParagraph.reactKey!==e.reactKey)),P({instanceId:it(),hoveredParagraph:e,hoverPlayerState:"Initial",destroyingTimeout:void 0,buttonRef:(0,O.createRef)()})):e!==l.hoveredParagraph&&P(a=>a&&{...a,hoveredParagraph:e}))},[e,l]),$(()=>{c==="buffering"||c==="seeking"||k(a=>a.hoverPlayerState!=="BufferingInProgress"?a:{...a,hoverPlayerState:"Initial"})},[c,k,l,E]);let q=(0,O.useCallback)(async()=>{if(l){if(f(),_(l.instanceId,a=>({...a,hoverPlayerState:"BufferingStarting"})),await at(),D()){if(!d||!p)return;tt(d,l.hoveredParagraph.element,p)}else{if(!l.hoveredParagraph.id)return;W.seekToPosition(l.hoveredParagraph.id,[0,0]),Ue(V.getPlayingState())||W.play()}It("extension_hover_player_button_clicked",{isClonedVoice:s}),wt({triggeredFrom:"HoverPlayer"}),await Ye(500),_(l.instanceId,a=>({...a,hoverPlayerState:"BufferingInProgress"}))}},[l,P,p]),A={x:window.scrollX,y:window.scrollY};return n(Ze,{value:t},[l,...E].map(a=>{if(!a)return null;let u=a===l,{getPlayerIconRect:T,getUnderlineRect:H}=a.hoveredParagraph,m=c==="buffering"||c==="seeking",x=E.some(he=>he.hoverPlayerState!=="Initial"),N=a.hoverPlayerState!=="Initial"||m&&u&&!x,C=T(),U=H();if(!C)return null;let Z=lr(R,a.hoveredParagraph),X=Z&&(c==="playing"||c==="buffering"||c==="seeking")&&!N;return n(O.default.Fragment,{key:a.hoveredParagraph.reactKey},u&&!o&&!N&&n("div",{style:{position:"absolute",top:(U?.top??0)+A.y,left:(U?.x??0)+A.x,width:U?.width??0,zIndex:Ht}},n(ir,null)),n("div",{"aria-label":Te("HOVER_PLAYER"),"data-testid":u?xe.HOVER_PLAYER:void 0,style:{position:"absolute",left:`${C.left+A.x-4}px`,top:`${C.top+A.y}px`,width:`${C.width+2*4}px`,height:`${C.height+2*4}px`,zIndex:Ht}},n(or,{"aria-label":Te("HOVER_PLAYER_BUTTON"),"data-testid":u?xe.HOVER_PLAYER_BUTTON:void 0,onClick:()=>{u&&(X?W.pause():Z?W.play():q())},ref:a.buttonRef,style:{position:"absolute",left:"0px",top:"0px",width:"100%",height:"100%"}},n("div",{id:u?Lt:void 0,style:{width:`${C.width}px`,height:`${C.height}px`,left:`${4}px`,top:0},className:["icon",u||N?"fadeIn":"fadeOut"].join(" ")},X?n(Ct,{className:"play-pause-icon-svg"}):n(Nt,{className:"play-pause-icon-svg"}),N&&n(ar,{size:`${C.width+2*4}px`})))))}))}y();g();y();g();var cr=/^\s*$/,Vt=e=>e.nodeType===Node.TEXT_NODE&&!cr.test(e.textContent??""),Ft=e=>{if(!e)return null;if(Vt(e))return e;for(let t of Array.from(e.childNodes)){if(Vt(t))return t;let o=Ft(t);if(o!==null)return o}return null};function*Gt(e){if(e.nodeType===Node.TEXT_NODE){let t=e.textContent?.trim().split(" ")??"";for(let o of t)yield{node:e,word:o}}else for(let t=0;t<e.childNodes.length;t++)yield*Gt(e.childNodes[t])}var Ne=(e,t)=>{if(!e||!Ft(e))return null;let o=document.createRange(),f=Gt(e),s=null,c="",p=0,d=1;for(;d<=t;){let R=f.next();if(R.done)return d<t&&o.setEnd(s,Math.min(p+c.length,s?.textContent?.length??0)),null;let{node:l,word:P}=R.value;if(!(!l||!P)){if(s!==l&&(p=0),d===1&&o.setStart(l,p),d===t){let E=(l.textContent?.indexOf(P,p)??0)+P.length;o.setEnd(l,Math.min(E,l.textContent?.length??0))}p+=P.length+1,c=P,s=l,d++}}return o};var Y=Ge(rt({hoveredParagraph:null,shouldShowHint:!1},e=>({updateHoveredParagraph:t=>e(o=>({...o,hoveredParagraph:t})),updateShouldShowHint:t=>e(o=>({...o,shouldShowHint:t}))}))),fe=({wasLifecycleAudioLoadedTriggered:e,id:t,element:o,ref:f,index:s})=>{if(!o)return null;let c=Ne(o,1),p=Ne(o,3),d=()=>(c??o).getBoundingClientRect(),R=()=>(p??o).getBoundingClientRect();if(D()){let m=o.firstElementChild??o;R=()=>m.getBoundingClientRect();let x=null;d=()=>{let N=m?.getBoundingClientRect();return N.height>0&&N.width>0&&(x=N),x}}let l=window.getComputedStyle(o),P=parseFloat(l.fontSize||"16")||16,E=Math.max(P,20),w=R(),k=new DOMRect(w.x-16,w.y,w.width+16,w.height),_=()=>{let m=d();if(!m)return null;let x=(m.height-E)/2;return new DOMRect(k.x-E,m.top+x,E,E)},q=()=>{let m=d();return m?new DOMRect(m.x,m.top+m.height,w.width+4,w.height):null},A=_();if(!A)return null;let a=K({rect:A,horizontalPadding:4,verticalPadding:4}),u=_e([w,k,a]);e&&(u=_e([u,o.getBoundingClientRect()]));let T=K({rect:u,horizontalPadding:4,verticalPadding:0}),H=p?.toString();return{element:o,getUnderlineRect:q,elementFontSize:P,firstThreeWords:H,getFirstThreeWordsRect:R,hoverAreaRect:T,hoverPlayerSize:E,getPlayerIconRect:_,id:t,ref:f,index:s,get reactKey(){return`${t}-${H}-${s}`}}};var Wt="speechify-hover-player-shadow-root",Yt="speechify-hover-player-container",J=null,M=null,Ut=we({key:"hover-player-emotion-cache"}),Ce=()=>{},hr="h1 h2 h3 h4 h5 h6 select textarea button label audio video dialog embed menu nav noframes noscript object script style svg aside footer #footer pre summary form input iframe img map meta link title track area base basefont col colgroup head html param source table tbody td tfoot th thead tr",pr="span a li ol ul h1 h2 h3 h4 h5 h6 select textarea button label audio video dialog embed menu nav noframes noscript object script style svg aside footer #footer pre summary form input iframe img map meta link title track area base basefont col colgroup head html param source table tbody td tfoot th thead tr",gr=e=>e.nodeType===Node.ELEMENT_NODE;async function yr(){return(await Oe("ceHoverPlayerIgnoredTags")||hr).split(" ").map(t=>t.toLowerCase())}async function Pr(){return(await Oe("ceHoverPlayerTopLevelIgnoredTags")||pr).split(" ").map(t=>t.toLowerCase())}function $t(e,t){return e.clientX>t.x&&e.clientX<t.x+t.width&&e.clientY>t.y&&e.clientY<t.y+t.height}function Rr(){let t=document.getElementById("speechify-hint-tooltip-shadow-root")?.shadowRoot?.getElementById("speechify-hint-tooltip");if(t)return t.getBoundingClientRect()}function Er(e){let t=(0,ee.default)(e,50),o=et(`${je} > svg`,(0,ee.default)(e,500)),f=document.querySelector(ce());return f.addEventListener("scroll",t,{passive:!0}),()=>{o(),f.removeEventListener("scroll",t)}}var Q=!1,vr=()=>{let e=async()=>{Q=!0,ze("audio-loading",e)};$e("audio-loading",e,"hover-player")};vr();async function ue(e){["boot","init"].includes(e)||(Q=!0);let t=[];if(J=document.querySelector(`#${Wt}`)?.shadowRoot??null,!J){let r=document.createElement("div");r.id=Wt,document.body.appendChild(r),J=r.attachShadow({mode:"open"})}M=J.querySelector(`#${Yt}`),M||(M=document.createElement("div"),M.id=Yt,Ut=we({key:"hover-player-emotion-cache",container:M}),J.appendChild(M));let{updateHoveredParagraph:o,updateShouldShowHint:f}=Y.getState(),s=await de("hover-player-hints"),c=await Pr(),p=await yr(),d=r=>!(!r||!gr(r)||c.includes(r.tagName.toLowerCase())||r.querySelector(p.join(","))!==null||(r.textContent?.trim().split(/\s+/).length??0)<=10||r.closest("a, button, form"));f(s);let R=()=>{f(!1),_t("hover-player-hints")},l=r=>{if(!M){Ie(new Error("hover-player renderTooltip is called with no container"),{type:"hover-player"});return}if(!Y.getState().shouldShowHint||!r||!r.firstThreeWords){j("hover-player-hints");return}let i=r.getPlayerIconRect();i&&At({key:r?.reactKey??"hover-player-hint-null",hintId:"hover-player-hints",anchorElement:null,text:"Hover over the first three words of any paragraph and click the “Play” button to start listening",xOffset:i.x+bt*-1+be*-1+be/2*-1+i.width/2,yOffset:i.y-14,closable:!0,maxWidth:"350px",onClose:R})},P=r=>{if(!M){Ie(new Error("hover-player renderHoverPlayer is called with no container"),{type:"hover-player"});return}ke(n(kt,{hoveredParagraph:r,emotionCache:Ut,wasLifecycleAudioLoadedTriggered:Q,onPlaybackStarted:()=>R()}),M)},E=()=>{P(null)},w=r=>{s&&r&&o(r)},k=async()=>{if(!t||t.length===0)return;Ce();let r=(0,ee.default)(i=>{let S=t.map(({element:h,id:I,ref:b,index:B})=>fe({wasLifecycleAudioLoadedTriggered:Q,element:h,id:I,ref:b,index:B})).filter(h=>!!h).find(({hoverAreaRect:h})=>$t(i,h));if(Y.getState().shouldShowHint){if(!S)return;let h=Rr(),I=h&&K({rect:h,horizontalPadding:10,verticalPadding:10});if(I&&$t(i,I))return}o(S??null)},16);window.addEventListener("mousemove",r),Ce=()=>{window.removeEventListener("mousemove",r)},t?.length>0&&s&&w(fe({wasLifecycleAudioLoadedTriggered:Q,element:t[0].element,ref:t[0].ref,index:0}))},_=async r=>{let i=[];if(D())i=Ke().map(Je).flat().map((h,I)=>({element:h,index:I}));else{let S=r?.options?.sideEffects??!1,{orator:h}=V.getState();if(S)return;h&&(i=h.machine.getContext().queue.map((b,B)=>({element:b.ref.ref,id:b.id,ref:b.ref,index:B})).filter(({element:b})=>d(b)))}Ve(i,t)||(t=i,k())},q=await qe("PLAYABLE_CONTENT_UPDATED",async({changed:r})=>{r&&r.metadata.source!=="Selection Player"&&_(r)}),{currentContent:A,orator:a}=V.getState();A&&_(A);let u=null;a&&(u=a.machine.onContextChange("queue",()=>{let{currentContent:r}=V.getState();r&&_(r)}));function T(r,i=20,S=4){if(!r)return!0;let I=document.createTreeWalker(r,NodeFilter.SHOW_TEXT,{acceptNode:ie=>ie.nodeValue?.trim()?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_REJECT}).nextNode();if(!I)return!0;let b=I.nodeValue,B=b.trim().split(/\s+/).slice(0,S).join(" ");if(!B)return!0;let ye=b.indexOf(B);if(ye===-1)return!0;let Pe=document.createRange();Pe.setStart(I,ye),Pe.setEnd(I,ye+B.length);let v=Pe.getBoundingClientRect();if(v.bottom<=0||v.top>=window.innerHeight||v.right<=0||v.left>=window.innerWidth)return!0;let He=[{x:v.left+v.width*.25,y:v.top+v.height*.5},{x:v.left+v.width*.5,y:v.top+v.height*.5},{x:v.left+v.width*.75,y:v.top+v.height*.5}],De=0;for(let ie of He){let Re=document.elementFromPoint(ie.x,ie.y),Ee=!1,ae=Re;for(;ae&&!Ee;){if(ae===r){Ee=!0;break}ae=ae.parentElement}let ve=Re?window.getComputedStyle(Re):null,Zt=ve?.pointerEvents==="none"||ve?.visibility==="hidden"||parseFloat(ve?.opacity||"1")<.1;!Ee&&!Zt&&De++}return De/He.length*100>=i}function H(r){if(!r?.element)return!1;try{let i=r.element,S=i.getBoundingClientRect(),h=r.ref?.highlightInfo?.scrollElement??(ce()?document.querySelector(ce()):null);if(h){let I=h.getBoundingClientRect();return S.top>=I.top&&S.bottom<=I.bottom}return!T(i,20)}catch(i){return console.error("Error in isElementVisible Hover Player:",i),!1}}let m=null,x=!1,N=Y.subscribe((r,i)=>{i?.hoveredParagraph!==r?.hoveredParagraph&&(r?.hoveredParagraph&&H(r.hoveredParagraph)?(m=r?.hoveredParagraph?.getFirstThreeWordsRect()??null,P(r.hoveredParagraph),l(r.hoveredParagraph)):(E(),j("hover-player-hints")),r?.hoveredParagraph?.element!==i?.hoveredParagraph?.element&&(i?.hoveredParagraph?.element&&(pe.unobserve(i?.hoveredParagraph?.element),ge.unobserve(i?.hoveredParagraph?.element)),r?.hoveredParagraph?.element&&(pe.observe(r?.hoveredParagraph?.element),ge.observe(r?.hoveredParagraph?.element))))}),C=(0,ee.default)(()=>{x=!1;let{hoveredParagraph:r}=Y.getState();r&&(m=r.getFirstThreeWordsRect(),H(r)||(E(),j("hover-player-hints")))},100),U=()=>{x=!0,C()};window.addEventListener("scroll",U);let Z=()=>{};D()&&(Z=Er(()=>{let{currentContent:r}=V.getState();r&&_(r)}));let me=()=>{let{hoveredParagraph:r}=Y.getState();if(!r)return;let i=r.getFirstThreeWordsRect();if(!i||!(i.x!==m?.x||i.y!==m?.y||i.width!==m?.width||i.height!==m?.height))return;let h=fe({wasLifecycleAudioLoadedTriggered:!1,element:r.element,id:r.id,ref:r.ref,index:r.index});o(h),m=i},X=!1,he=r=>{X=r[0].isIntersecting},pe=new ResizeObserver(me),ge=new IntersectionObserver(he),ne,Le=()=>{!x&&X&&me(),ne=requestAnimationFrame(Le)};return ne=requestAnimationFrame(Le),()=>{R(),ne&&cancelAnimationFrame(ne),window.removeEventListener("scroll",U),pe.disconnect(),ge.disconnect(),Z(),q(),N(),Ce(),u&&u(),j("hover-player-hints"),E()}}y();g();var Ir=z(se)`
  border-radius: 8px;
  margin-top: 1.5rem;
  position: relative;
`,zt=({removeNotification:e})=>n(Qe,{removeNotification:e},n(se,{column:!0,separation:"12px"},n(Ir,null,n(nt,{alt:"hover player demo",src:"hoverPlayer/notification.png",style:{marginLeft:"-21px",height:"64px",width:"252px"}})),n(se,{column:!0,yAlign:!0,separation:"4px"},n(Se,{semiBold:!0,fontSize:"16px"},"One click play"),n(Se,{fontSize:"14px",color:le.icnTxtSec,lineHeight:"20px"},"Hover over the first three words of any paragraph to start listening from there."))));var wr=()=>!(ut()||ht()||yt()||mt()||pt()||Pt()||ct()||st()||dt()||lt()||Et()||gt()||ft()||vt()||Rt());var oe={"paragraph-player":!1,"hover-player":!1},te=()=>Object.values(oe).filter(Boolean).length,Tr=e=>te()===1&&oe[e],re=[],qt=e=>{Tr(e)&&(re.forEach(t=>t()),re=[]),oe[e]=!1};async function xr(e,t,o){let f=o.name;if(f==="paragraph-player"&&D()&&e?.playButtons?.googledocs?.paragraphPlayer===!1||f==="hover-player"&&!wr())return;if(te()>0)return oe[f]=!0,()=>qt(f);oe[f]=!0;let s=await ue(t);if(te()===0){s();return}re.push(s),re.push(Be(async()=>{s(),s=await ue(t),te()===0&&s()}));let c=await de("hover-player-hints",!0);if(te()!==0)return c||re.push(W.registerHook("PLAYBACK_STATE_CHANGED",async({state:p})=>{if(p==="playing"&&(Tt("still-listening"),!Fe())){let d=await St("hover-player");if(d){let{dismissedByUser:R,displayCount:l}=d;if(R||l>0)return}xt({id:"hover-player",priority:100,showOnMobile:!1,timeSensitive:!0,render:({dismiss:R})=>n(zt,{removeNotification:R})})}})),()=>qt(f)}export{xr as default};
//# sourceMappingURL=init-6MMRQ76X.js.map
