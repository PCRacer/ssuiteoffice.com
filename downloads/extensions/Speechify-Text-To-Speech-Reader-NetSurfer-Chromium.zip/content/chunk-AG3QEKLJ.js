import{k as e}from"./chunk-F4AZU7R4.js";import{g as t,n as $}from"./chunk-CLPINNGF.js";$();t();var l=e.svg`
  width: ${({width:o,size:r})=>o??r??"20px"};
  height: ${({height:o,size:r})=>o??r??"20px"};
  ${({color:o})=>o&&`color: ${o}`};
  fill: ${({fill:o})=>o??"currentColor"};
  ${({style:o})=>o&&`style: ${o}`};

  ${({onClick:o})=>o&&"cursor: pointer;"}
`;export{l as a};
//# sourceMappingURL=chunk-AG3QEKLJ.js.map
