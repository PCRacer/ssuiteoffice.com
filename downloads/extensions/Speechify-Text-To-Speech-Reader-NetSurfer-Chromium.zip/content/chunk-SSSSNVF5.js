import{g as e,n}from"./chunk-CLPINNGF.js";n();e();function m(t){return(t instanceof Node?t.textContent:t.text)??""}export{m as a};
//# sourceMappingURL=chunk-SSSSNVF5.js.map
