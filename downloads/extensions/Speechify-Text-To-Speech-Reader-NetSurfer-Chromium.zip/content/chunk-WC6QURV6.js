import{Ta as n}from"./chunk-RISKGE32.js";import{k as t}from"./chunk-F4AZU7R4.js";import{g as r,i as e,n as p}from"./chunk-CLPINNGF.js";p();r();var x=t(n)`
  padding: 11px 8px;
  width: 280px;
  box-sizing: border-box;
  background: ${({background:o})=>o??"#B4BBFE"};
  justify-content: center;
  align-items: center;
  border-radius: 8px;
  font-size: 14px;
  color: ${({color:o})=>o??"#1C2C40"};
  font-weight: 500;
  box-shadow: 0px 10px 20px rgba(0, 0, 0, 0.04), 0px 2px 6px rgba(0, 0, 0, 0.04),
    0px 0px 1px rgba(0, 0, 0, 0.04);
`,i=o=>e(x,{...o}),B=o=>e(x,{background:"#E6E8FF",color:"#0317CE",...o});export{i as a,B as b};
//# sourceMappingURL=chunk-WC6QURV6.js.map
