import{a}from"./chunk-C4ZBMBCR.js";import{Ea as t,Oa as o}from"./chunk-RISKGE32.js";import{g as e,n as r}from"./chunk-CLPINNGF.js";r();e();var s=async()=>{o.getState().currentContent?.metadata.source==="Selection Player"&&(a(),await t(200))};export{s as a};
//# sourceMappingURL=chunk-5PO6RROQ.js.map
