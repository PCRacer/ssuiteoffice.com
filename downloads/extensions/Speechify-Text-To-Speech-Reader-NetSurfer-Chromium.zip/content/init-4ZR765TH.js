import{a as f1}from"./chunk-BN5XPDNR.js";import{a as b,b as d1,d as c1}from"./chunk-NK4CKTAC.js";import{a as y}from"./chunk-AG3QEKLJ.js";import{Va as R}from"./chunk-RISKGE32.js";import{fa as H,ha as e1,ja as V}from"./chunk-6O6MLDWR.js";import{c as s1,g as a1,k as n}from"./chunk-F4AZU7R4.js";import{g as k}from"./chunk-GQY3J744.js";import{d as E,f as m,g as r,i as e,k as r1,m as te,n as s}from"./chunk-CLPINNGF.js";s();r();te();s();r();var p=E(k());s();r();var U=t=>{let a=document.getElementById(b)?.shadowRoot;if(a){let o=a.querySelectorAll(".scrollable");for(let l of o)if(t.composedPath().some(x=>x===l))return}t.preventDefault()},t1=()=>{let t=document.getElementById(b);t&&t.shadowRoot?(window.addEventListener("wheel",U,{passive:!1}),window.addEventListener("touchmove",U,{passive:!1})):setTimeout(t1,100)},p1=()=>{window.removeEventListener("wheel",U),window.removeEventListener("touchmove",U)};s();r();var N=E(k());s();r();function Z(t){return e(y,{xmlns:"http://www.w3.org/2000/svg",width:"32",height:"32",viewBox:"0 0 32 32",fill:"none",...t},e("path",{d:"M22.4157 10.5333C22.4157 9.87059 21.8784 9.33334 21.2157 9.33334C20.5529 9.33334 20.0157 9.87059 20.0157 10.5333L20.0157 21.2C20.0157 21.8628 20.5529 22.4 21.2157 22.4C21.8784 22.4 22.4157 21.8628 22.4157 21.2V10.5333Z",fill:"currentColor"}),e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M16.0551 21.5375L15.5039 19.8841H10.8042C10.7465 19.8841 10.6898 19.8795 10.6345 19.8707L10.0789 21.5375C9.89263 22.0964 9.28856 22.3984 8.72969 22.2121C8.17081 22.0258 7.86878 21.4218 8.05507 20.8629L11.4226 10.7602C11.9494 9.17997 14.1846 9.17997 14.7114 10.7602L18.0789 20.8629C18.2652 21.4218 17.9632 22.0258 17.4043 22.2121C16.8454 22.3984 16.2414 22.0964 16.0551 21.5375ZM13.067 12.5733L14.7928 17.7508H11.3412L13.067 12.5733Z",fill:"currentColor"}),e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M1.52195 10.3248C1.74811 7.02314 1.8612 5.37231 3.633 3.60486C5.4048 1.83741 7.04331 1.72921 10.3203 1.51283C11.9586 1.40465 13.8529 1.33334 16 1.33334C18.1471 1.33334 20.0414 1.40465 21.6798 1.51283C24.9568 1.72921 26.5953 1.83741 28.3671 3.60486C30.1389 5.37231 30.252 7.02314 30.4781 10.3248C30.5914 11.9781 30.6667 13.8761 30.6667 16C30.6667 18.0013 30.5998 19.802 30.4974 21.3865C30.2732 24.8528 30.1611 26.5859 28.3901 28.3613C26.619 30.1368 24.8738 30.254 21.3833 30.4884C19.7833 30.5959 17.9785 30.6667 16 30.6667C14.0216 30.6667 12.2168 30.5959 10.6167 30.4884C7.12628 30.254 5.38106 30.1368 3.61002 28.3613C1.83899 26.5859 1.7269 24.8528 1.50272 21.3865C1.40025 19.802 1.33337 18.0013 1.33337 16C1.33337 13.8761 1.4087 11.9781 1.52195 10.3248ZM21.2046 27.8278C19.6601 27.9315 17.9151 28 16 28C14.085 28 12.34 27.9315 10.7954 27.8278C7.1318 27.5817 6.45304 27.4355 5.49798 26.4781C4.54152 25.5192 4.39885 24.8483 4.16383 21.2144C4.06494 19.6852 4.00004 17.9419 4.00004 16C4.00004 13.9391 4.07313 12.102 4.18238 10.507C4.4175 7.07464 4.54988 6.45684 5.5163 5.49279C6.48434 4.52713 7.09428 4.39832 10.496 4.1737C12.0763 4.06935 13.912 4 16 4C18.088 4 19.9237 4.06935 21.5041 4.1737C24.9058 4.39832 25.5157 4.52713 26.4838 5.49279C27.4502 6.45684 27.5826 7.07464 27.8177 10.507C27.927 12.102 28 13.9391 28 16C28 17.9419 27.9351 19.6852 27.8362 21.2144C27.6012 24.8483 27.4586 25.5192 26.5021 26.4781C25.547 27.4355 24.8683 27.5817 21.2046 27.8278Z",fill:"currentColor"}))}function W(t){return e(y,{xmlns:"http://www.w3.org/2000/svg",width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",...t},e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M4.87361 3.45952C4.48309 3.06899 3.84992 3.06899 3.4594 3.45952C3.06887 3.85004 3.06887 4.48321 3.4594 4.87373L8.58562 9.99996L3.4594 15.1262C3.06887 15.5167 3.06887 16.1499 3.4594 16.5404C3.84992 16.9309 4.48309 16.9309 4.87361 16.5404L9.99984 11.4142L15.1261 16.5404C15.5166 16.9309 16.1498 16.9309 16.5403 16.5404C16.9308 16.1499 16.9308 15.5167 16.5403 15.1262L11.4141 9.99996L16.5403 4.87373C16.9308 4.48321 16.9308 3.85004 16.5403 3.45952C16.1498 3.06899 15.5166 3.06899 15.1261 3.45952L9.99984 8.58575L4.87361 3.45952Z",fill:"currentColor"}))}var u1=t=>e(y,{xmlns:"http://www.w3.org/2000/svg",width:20,height:20,viewBox:"0 0 20 20",fill:"none",...t},e("path",{d:"M12.6365 9.41073L10.7257 11.3215L10.7257 2.49999C10.7257 2.03975 10.3526 1.66666 9.8924 1.66666C9.43216 1.66666 9.05906 2.03975 9.05906 2.49999L9.05906 11.3215L7.14832 9.41073C6.82288 9.0853 6.29524 9.0853 5.96981 9.41073C5.64437 9.73617 5.64437 10.2638 5.96981 10.5892L9.30314 13.9226C9.62858 14.248 10.1562 14.248 10.4816 13.9226L13.815 10.5892C14.1404 10.2638 14.1404 9.73617 13.815 9.41073C13.4895 9.0853 12.9619 9.0853 12.6365 9.41073Z",fill:"currentColor"}),e("path",{d:"M17.3924 12.5C17.3924 12.0398 17.0193 11.6667 16.5591 11.6667C16.0988 11.6667 15.7257 12.0398 15.7257 12.5V15.3676C15.7257 15.7636 15.4556 16.0826 15.1044 16.15C11.5097 16.8389 8.2751 16.8389 4.68044 16.15C4.32919 16.0826 4.05906 15.7636 4.05906 15.3676L4.05906 12.5C4.05906 12.0398 3.68597 11.6667 3.22573 11.6667C2.76549 11.6667 2.3924 12.0398 2.3924 12.5V15.3676C2.3924 16.5245 3.19289 17.5619 4.36673 17.7868C8.16864 18.5155 11.6162 18.5155 15.4181 17.7868C16.5919 17.5619 17.3924 16.5245 17.3924 15.3676V12.5Z",fill:"currentColor"}));function Y(t){return e(y,{xmlns:"http://www.w3.org/2000/svg",width:"32",height:"32",viewBox:"0 0 32 32",fill:"none",...t},e("g",{clipPath:"url(#clip0_350_53513)"},e("path",{d:"M22.6667 4C23.403 4 24 3.40305 24 2.66667C24 1.93029 23.403 1.33333 22.6667 1.33333H17.3333C16.597 1.33333 16 1.93029 16 2.66667C16 3.40305 16.597 4 17.3333 4H22.6667Z",fill:"currentColor"}),e("path",{d:"M4 16C3.26362 16 2.66667 16.597 2.66667 17.3333C2.66667 18.0697 3.26362 18.6667 4 18.6667H12C12.7364 18.6667 13.3333 18.0697 13.3333 17.3333C13.3333 16.597 12.7364 16 12 16H4Z",fill:"currentColor"}),e("path",{d:"M1.33333 21.3333C0.596954 21.3333 0 21.9303 0 22.6667C0 23.403 0.596954 24 1.33333 24H9.33333C10.0697 24 10.6667 23.403 10.6667 22.6667C10.6667 21.9303 10.0697 21.3333 9.33333 21.3333H1.33333Z",fill:"currentColor"}),e("path",{d:"M4 28C4 27.2636 4.59695 26.6667 5.33333 26.6667H13.3333C14.0697 26.6667 14.6667 27.2636 14.6667 28C14.6667 28.7364 14.0697 29.3333 13.3333 29.3333H5.33333C4.59695 29.3333 4 28.7364 4 28Z",fill:"currentColor"}),e("path",{d:"M19.8372 11.1296C20.5736 11.1296 21.1706 11.7266 21.1706 12.463V17.244L23.4467 19.5202C23.9674 20.0409 23.9674 20.8851 23.4467 21.4058C22.926 21.9265 22.0818 21.9265 21.5611 21.4058L18.8944 18.7391C18.6444 18.4891 18.5039 18.1499 18.5039 17.7963V12.463C18.5039 11.7266 19.1009 11.1296 19.8372 11.1296Z",fill:"currentColor"}),e("path",{d:"M12.2813 12.0843C13.9636 9.61604 16.7933 8 20 8C25.1547 8 29.3333 12.1787 29.3333 17.3333C29.3333 22.0919 25.771 26.0204 21.1684 26.5944C20.7862 26.642 20.3963 26.6667 20 26.6667C19.2636 26.6667 18.6667 27.2636 18.6667 28C18.6667 28.7364 19.2636 29.3333 20 29.3333C20.5069 29.3333 21.007 29.3018 21.4984 29.2406C27.4192 28.5022 32 23.4537 32 17.3333C32 10.7059 26.6274 5.33333 20 5.33333C15.8743 5.33333 12.2355 7.41657 10.0778 10.5824C9.66308 11.1909 9.82017 12.0204 10.4287 12.4351C11.0371 12.8498 11.8666 12.6927 12.2813 12.0843Z",fill:"currentColor"})),e("defs",null,e("clipPath",{id:"clip0_350_53513"},e("rect",{width:"32",height:"32",fill:"white"}))))}function F(t){return e(y,{xmlns:"http://www.w3.org/2000/svg",width:"32",height:"32",viewBox:"0 0 32 32",fill:"none",...t},e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M14.6912 7.42368L6.15745 16.5322C4.9279 17.8446 4.75062 19.7726 5.60847 21.262C5.56342 21.2968 5.52008 21.3348 5.47878 21.3761C3.75563 23.0992 3.30279 25.3448 3.96661 27.2618C4.62817 29.1723 6.35905 30.629 8.67955 30.8497C10.1068 30.9854 11.4997 30.4739 12.7383 29.8225C13.9513 29.1847 15.1938 28.3134 16.3714 27.4878L16.4789 27.4124C17.7219 26.5411 18.9061 25.7174 20.0715 25.1047C21.2396 24.4906 22.2686 24.1553 23.1877 24.1553C24.6371 24.1553 25.6726 24.9671 26.2368 26.0313C26.849 27.1861 26.7418 28.2729 26.4037 28.7347C25.9687 29.3289 26.0978 30.1632 26.6919 30.5982C27.2861 31.0332 28.1204 30.9041 28.5554 30.31C29.7115 28.7308 29.4862 26.4674 28.5928 24.7822C27.6514 23.0065 25.7938 21.4886 23.1877 21.4886C21.6476 21.4886 20.1696 22.0404 18.8305 22.7444C17.4887 23.4499 16.1655 24.3755 14.9482 25.2288L14.9197 25.2488C13.68 26.1178 12.5574 26.9047 11.4971 27.4623C10.4173 28.0302 9.58642 28.2572 8.93201 28.195C7.64317 28.0724 6.80377 27.3056 6.48648 26.3893C6.17145 25.4795 6.33118 24.2949 7.36438 23.2617C7.37445 23.2517 7.38433 23.2415 7.39401 23.2312C8.92739 24.5912 11.2628 24.5755 12.7787 23.1571L21.8757 14.6449C25.3039 14.3689 28 11.4993 28 8C28 4.3181 25.0152 1.33333 21.3333 1.33333C17.8455 1.33333 14.9834 4.01161 14.6912 7.42368ZM17.3642 7.50027L21.833 11.9691C23.8063 11.7232 25.3333 10.0399 25.3333 8C25.3333 5.79086 23.5424 4 21.3333 4C19.2934 4 17.6101 5.52698 17.3642 7.50027ZM8.10348 18.3554L16.0095 9.91684L19.4011 13.3084L10.9567 21.2099C10.4316 21.7013 9.61144 21.6876 9.10293 21.1791L8.13367 20.2099C7.62493 19.7011 7.61157 18.8805 8.10348 18.3554Z",fill:"currentColor"}))}function C1(t){return e(y,{xmlns:"http://www.w3.org/2000/svg",width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",...t},e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M13.6241 3.4594C13.2336 3.06887 12.6005 3.06887 12.2099 3.4594L6.37639 9.29293C5.98586 9.68346 5.98586 10.3166 6.37639 10.7071L12.2099 16.5407C12.6005 16.9312 13.2336 16.9312 13.6241 16.5407C14.0147 16.1502 14.0147 15.517 13.6241 15.1265L8.49771 10L13.6241 4.87361C14.0147 4.48309 14.0147 3.84992 13.6241 3.4594Z",fill:"currentColor"}))}var m1=t=>e(y,{xmlns:"http://www.w3.org/2000/svg",width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",...t},e("path",{d:"M3.33335 9.99999C3.33335 6.31809 6.31812 3.33332 10 3.33332C13.6819 3.33332 16.6667 6.31809 16.6667 9.99999C16.6667 10.4602 17.0398 10.8333 17.5 10.8333C17.9603 10.8333 18.3334 10.4602 18.3334 9.99999C18.3334 5.39762 14.6024 1.66666 10 1.66666C5.39765 1.66666 1.66669 5.39762 1.66669 9.99999C1.66669 14.6024 5.39765 18.3333 10 18.3333C10.4603 18.3333 10.8334 17.9602 10.8334 17.5C10.8334 17.0398 10.4603 16.6667 10 16.6667C6.31812 16.6667 3.33335 13.6819 3.33335 9.99999Z",fill:"currentColor"}),e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M12.8751 18.5978C12.7052 19.0872 13.0686 19.5981 13.5867 19.5981C13.9179 19.5981 14.2102 19.3818 14.307 19.065L14.6895 17.8136H17.2865L17.6673 19.0632C17.7641 19.381 18.0573 19.5981 18.3896 19.5981C18.9091 19.5981 19.2734 19.0856 19.1027 18.595L17.1258 12.9123C16.9859 12.5103 16.6069 12.2409 16.1813 12.2409H15.7936C15.3677 12.2409 14.9886 12.5106 14.8489 12.9129L12.8751 18.5978ZM16.0356 13.7093H15.9439L15.0416 16.6613H16.9353L16.0356 13.7093Z",fill:"currentColor"}),e("path",{d:"M14.841 9.5815C15.1428 9.77885 15.1428 10.2211 14.841 10.4185L11.6822 12.4839C11.3496 12.7013 10.9086 12.4627 10.9086 12.0654V7.93457C10.9086 7.53724 11.3496 7.29865 11.6822 7.51609L14.841 9.5815Z",fill:"currentColor"}),e("path",{d:"M10.5602 10.4185C10.862 10.2211 10.862 9.77885 10.5602 9.5815L7.40137 7.51609C7.06882 7.29865 6.62774 7.53724 6.62774 7.93457L6.62774 12.0654C6.62774 12.4627 7.06882 12.7013 7.40137 12.4839L10.5602 10.4185Z",fill:"currentColor"})),h1=t=>e(y,{xmlns:"http://www.w3.org/2000/svg",width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",...t},e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M10 1.65201C5.85786 1.65201 2.5 5.00987 2.5 9.15201V11.6659C2.5 13.5068 3.99238 15 5.83333 15H6.66667C7.1269 15 7.5 14.6269 7.5 14.1667V9.16666C7.5 8.70642 7.1269 8.33332 6.66667 8.33332H5.83333C5.2312 8.33332 4.66636 8.49298 4.17883 8.77226C4.37447 5.72759 6.90592 3.31867 10 3.31867C13.0941 3.31867 15.6255 5.72759 15.8212 8.77226C15.3336 8.49298 14.7688 8.33332 14.1667 8.33332H13.3333C12.8731 8.33332 12.5 8.70642 12.5 9.16666V14.1667C12.5 14.6269 12.8731 15 13.3333 15H14.1667C14.7738 15 15.343 14.8377 15.8333 14.554V15.8293C15.8333 16.2895 15.4602 16.6626 15 16.6626H10C9.53976 16.6626 9.16667 17.0357 9.16667 17.496C9.16667 17.9562 9.53976 18.3293 10 18.3293H15C16.3807 18.3293 17.5 17.21 17.5 15.8293V9.15201C17.5 5.00987 14.1421 1.65201 10 1.65201ZM15.8333 11.6667C15.8329 10.7465 15.0869 9.99999 14.1667 9.99999V13.3333C15.0871 13.3333 15.8333 12.5871 15.8333 11.6667ZM4.16667 11.6667C4.16667 12.5871 4.91286 13.3333 5.83333 13.3333V9.99999C4.91311 9.99999 4.16708 10.7465 4.16667 11.6667Z",fill:"currentColor"})),x1=t=>e(y,{xmlns:"http://www.w3.org/2000/svg",width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",...t},e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M12.5 2.00388C12.5 0.866286 11.3855 0.0630036 10.3063 0.422743L6.97293 1.53385C6.29236 1.76071 5.83331 2.39761 5.83331 3.11499V9.62689C5.34302 9.34327 4.77379 9.18095 4.16665 9.18095C2.3257 9.18095 0.833313 10.6733 0.833313 12.5143C0.833313 14.3552 2.3257 15.8476 4.16665 15.8476C6.0076 15.8476 7.49998 14.3552 7.49998 12.5143V5.61499L11.3604 4.3282C12.0409 4.10134 12.5 3.46445 12.5 2.74706V2.00388ZM7.49998 3.11499L10.8333 2.00388V2.74706L7.49998 3.85817V3.11499ZM4.16665 10.8476C5.08712 10.8476 5.83331 11.5938 5.83331 12.5143C5.83331 13.4348 5.08712 14.1809 4.16665 14.1809C3.24617 14.1809 2.49998 13.4348 2.49998 12.5143C2.49998 11.5938 3.24617 10.8476 4.16665 10.8476Z",fill:"currentColor"}),e("path",{d:"M9.99998 8.34762C10.4602 8.34762 10.8333 8.72071 10.8333 9.18095V17.5143C10.8333 17.9745 10.4602 18.3476 9.99998 18.3476C9.53974 18.3476 9.16665 17.9745 9.16665 17.5143V9.18095C9.16665 8.72071 9.53974 8.34762 9.99998 8.34762Z",fill:"currentColor"}),e("path",{d:"M15.8333 9.18095C15.8333 8.72071 15.4602 8.34762 15 8.34762C14.5397 8.34762 14.1666 8.72071 14.1666 9.18095V17.5143C14.1666 17.9745 14.5397 18.3476 15 18.3476C15.4602 18.3476 15.8333 17.9745 15.8333 17.5143V9.18095Z",fill:"currentColor"}),e("path",{d:"M12.5 10.8476C12.9602 10.8476 13.3333 11.2207 13.3333 11.6809V15.0143C13.3333 15.4745 12.9602 15.8476 12.5 15.8476C12.0397 15.8476 11.6666 15.4745 11.6666 15.0143V11.6809C11.6666 11.2207 12.0397 10.8476 12.5 10.8476Z",fill:"currentColor"}),e("path",{d:"M18.3333 11.6809C18.3333 11.2207 17.9602 10.8476 17.5 10.8476C17.0397 10.8476 16.6666 11.2207 16.6666 11.6809V15.0143C16.6666 15.4745 17.0397 15.8476 17.5 15.8476C17.9602 15.8476 18.3333 15.4745 18.3333 15.0143V11.6809Z",fill:"currentColor"}));s();r();var z=n.div`
  align-items: flex-start;
  display: flex;
  cursor: pointer;
  gap: 0px;
  padding: 16px;
  position: absolute;
  right: 0;
  z-index: 50;
`,g1=n.div`
  align-items: center;
  background-color: ${({showOverlay:t})=>t?"rgba(5, 7, 11, 0.5)":"transparent"};
  display: flex;
  height: 100vh;
  justify-content: center;
  left: 0;
  position: fixed;
  top: 0;
  width: 100vw;
  z-index: 2147483645;
`;s();r();var w1=n.div`
  align-items: flex-start;
  background-color: #111112;
  border-radius: 12px;
  color: #fff;
  display: flex;
  flex-direction: column;
  font-family: ABCDiatype, sans-serif;
  overflow: hidden;
  position: relative;
  width: 420px;
  z-index: 2147483647;
`,v1=n.div`
  align-self: stretch;
  background: linear-gradient(273deg, #384be7 -15.85%, #101036 124.01%);
  box-shadow: 0px 13.793px 20.69px 0px rgba(33, 55, 252, 0.1);
  height: 164px;
  overflow: hidden;
`,y1=n.div`
  align-items: center;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  gap: 32px;
  padding: 32px;
`,L1=n.div`
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  gap: 20px;
  width: 300px;
`,S1=n.div`
  align-self: stretch;
  font-size: 24px;
  font-style: normal;
  font-weight: 700;
  line-height: 32px;
`,M1=n.div`
  align-items: flex-start;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  gap: 12px;
`,P1=n.div`
  font-size: 14px;
  font-style: normal;
  font-weight: 700;
  letter-spacing: 0.14px;
  line-height: 20px;
`,V1=n.div`
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  gap: 12px;
`,b1=n.div`
  align-items: center;
  align-self: stretch;
  display: flex;
  gap: 12px;
`,I1=n.div`
  font-size: 14px;
  font-style: normal;
  font-weight: 500;
  letter-spacing: 0.14px;
  line-height: 20px;
`,T1=n.div`
  align-items: center;
  align-self: stretch;
  background: #4759f7;
  border-radius: 16px;
  cursor: pointer;
  display: flex;
  font-family: ABCDiatype, sans-serif;
  font-size: 18px;
  font-style: normal;
  font-weight: 700;
  gap: 0px;
  justify-content: center;
  line-height: 24px;
  padding: 16px 40px;

  &:focus {
    background: #3d4ac4;
  }

  &:hover {
    background: #4454e3;
  }
`;var n1={increased_listening_speeds:{animation:"increasespeed",title:"Upgrade to Increase Your Listening Speed",benefitsTitle:"Get all reading superpowers from day one:"},premium_voices:{animation:"premiumvoices",title:"Upgrade to Listen with Premium Voices",benefitsTitle:"Get all reading superpowers from day one:"}},oe=[{icon:e(F,{style:{width:"20px",height:"20px"}}),title:"Listen with 200+ AI voices",excludedVariants:["premium_voices"]},{icon:e(Y,{style:{width:"20px",height:"20px"}}),title:"Up to 4.5x listening speed",excludedVariants:["increased_listening_speeds"]},{icon:e(Z,{style:{width:"20px",height:"20px"}}),title:"Summarize your documents",excludedVariants:[]},{icon:e(m1,{style:{width:"20px",height:"20px"}}),title:"Skip headers, footers, and more",excludedVariants:[]},{icon:e(x1,{style:{width:"20px",height:"20px"}}),title:"Turn anything into audio",excludedVariants:[]},{icon:e(u1,{style:{width:"20px",height:"20px"}}),title:"Download files to listen offline",excludedVariants:[]},{icon:e(h1,{style:{width:"20px",height:"20px"}}),title:"Rely on fast 24/7 support",excludedVariants:[]}];function A1({onCloseClick:t,onUpgradeClick:u,variant:a}){let o=(0,N.useRef)(null);return(0,N.useEffect)(()=>{o.current&&o.current.play()},[a]),e(w1,null,e(z,{onClick:t},e(W,null)),e(v1,null,e("video",{ref:o,src:m.runtime.getURL(`images/paywall/animations/${n1[a]?.animation}.mp4`),autoPlay:!0,loop:!0,muted:!0,playsInline:!0,style:{marginTop:"-10px",width:"100%"}})),e(y1,null,e(L1,null,e(S1,null,n1[a]?.title),e(M1,null,e(P1,null,n1[a]?.benefitsTitle),e(V1,null,oe.filter(l=>!l.excludedVariants.includes(a)).map((l,C)=>e(b1,{key:`benefit-${C}`},l.icon,e(I1,null,l.title)))))),e(T1,{"aria-label":R("PAYWALL_BUTTON"),onClick:u},"Try for Free")))}s();r();var f=E(k());s();r();var E1=E(k()),ie=()=>{let u=(0,E1.useRef)((()=>{let o=new Date,l=o.getDay(),C=o.getDate()-l+(l===0?-6:1),c=new Date(o.setDate(C));return c.setHours(0,0,0,0),c})());return()=>{let c=(new Date().getTime()-u.current.getTime())/1e3,M=16197/(7*24*60*60),h=3659+c*M;return h=Math.min(19856,Math.max(3659,Math.round(h))),h.toLocaleString("en-US",{minimumFractionDigits:0,maximumFractionDigits:0})}},k1=ie;s();r();var $=E(k()),D1=({item:t,isMiddleCard:u,isTransitioning:a})=>{let o=(0,$.useRef)(null);return(0,$.useEffect)(()=>{o.current&&(u&&!a?o.current.play():(o.current.pause(),o.current.currentTime=0))},[u,a]),e("div",{style:{position:"relative",width:"260px",height:"120px",borderRadius:"19.2px",background:"linear-gradient(93deg, #384BE7 2.89%, #101036 252.14%)",overflow:"hidden"}},e("video",{ref:o,src:m.runtime.getURL(`images/paywall/animations/${t.animation}.mp4`),style:{width:"260px",height:"120px"},muted:!0,playsInline:!0,loop:!1,controls:!1}))};s();r();var O1=n.div`
  align-items: flex-start;
  background-color: #111112;
  border-radius: 20px;
  color: #fff;
  display: flex;
  font-family: ABCDiatype, sans-serif;
  overflow: hidden;
  position: relative;
  width: 925px;
  z-index: 2147483647;
`,G1=n.div`
  align-items: flex-start;
  display: flex;
  cursor: pointer;
  gap: 0px;
  padding: 16px;
  position: absolute;
`,_1=n.div`
  align-items: center;
  display: flex;
  flex-direction: column;
  flex-shrink: 0;
  gap: 32px;
  padding: 98px 60px 90px 60px;
`,R1=n.div`
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  gap: 12px;
  max-width: 400px;
  width: 340px;
`,U1=n.div`
  font-size: 36px;
  font-weight: 700;
  line-height: 44px;
`,Z1=n.div`
  font-size: 16px;
  font-weight: 500;
  line-height: 24px;
`,W1=n.div`
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  gap: 20px;
  max-width: 400px;
  width: 340px;
`,Y1=n.div`
  align-items: flex-start;
  align-self: stretch;
  display: flex;
  gap: 12px;

  svg {
    margin-top: 6px;
  }
`,F1=n.div`
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  flex: 1 0 0;
`,z1=n.div`
  align-self: stretch;
  font-size: 16px;
  font-style: normal;
  font-weight: 700;
  letter-spacing: 0.16px;
  line-height: 24px;
`,N1=n.div`
  align-self: stretch;
  color: #9899a6;
  font-size: 14px;
  font-style: normal;
  font-weight: 400;
  letter-spacing: 0.14px;
  line-height: 20px;
`,$1=n.div`
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  gap: 12px;
  max-width: 400px;
  width: 340px;
`,j1=n.button`
  align-items: center;
  align-self: stretch;
  background: #4759f7;
  border-radius: 12px;
  border-width: 0px;
  color: #fff;
  cursor: pointer;
  display: flex;
  font-family: ABCDiatype, sans-serif;
  font-size: 16px;
  font-style: normal;
  font-weight: 700;
  gap: 0px;
  justify-content: center;
  letter-spacing: 0.16px;
  line-height: 24px;
  padding: 12px 104px;

  &:focus {
    background: #3d4ac4;
  }

  &:hover {
    background: #4454e3;
  }
`,q1=n.div`
  align-items: center;
  align-self: stretch;
  display: flex;
  gap: 8px;
  justify-content: center;
`,J1=n.div`
  font-size: 14px;
  font-style: normal;
  font-weight: 500;
  letter-spacing: 0.14px;
  line-height: 20px;
`,K1=n.div`
  align-items: center;
  background: #1e1e1f;
  display: flex;
  flex-direction: column;
  flex: 1 0 0;
  gap: 20px;
  height: 624px;
  justify-content: center;
  padding: 16px 0px;
`;var D={baseOffset:150,topCardScale:1.2,secondCardScale:1.1,lastCardScale:1.1,defaultScale:1,secondCardOffset:-155,lastCardOffset:155,visibilityThreshold:3,animationDuration:500,intervalDuration:4e3},le=[{icon:F,title:"200+ highest quality voices",description:"Including official Speechify celebrity partners"},{icon:Y,title:"Up to 4.5x listening speed",description:"To help you become a speed reader"},{icon:Z,title:"Advanced AI",description:"Enhance your learning with AI powers"}],S=[{animation:"unlimitedfiles",title:"Unlimited Files"},{animation:"support",title:"Support"},{animation:"premiumvoices",title:"Premium Voices"},{animation:"increasespeed",title:"Speed"},{animation:"skip",title:"Skip"},{animation:"askai",title:"Ask AI"},{animation:"clonevoice",title:"Clone Voice"},{animation:"downloadmp3",title:"Download MP3"},{animation:"fileformats",title:"File Formats"},{animation:"imageonlypdfs",title:"Scan"}];function X1({isSettingsUpsell:t,onCloseClick:u,onPreviousClick:a,onUpgradeClick:o}){let l=k1(),[C,c]=(0,f.useState)(2),[x,M]=(0,f.useState)(!1),[P,h]=(0,f.useState)(!1),[I,O]=(0,f.useState)(!1),[q,G]=(0,f.useState)(2),g=(0,f.useRef)(null),T=(0,f.useCallback)(()=>{g.current&&clearInterval(g.current),g.current=setInterval(()=>{G(C),O(!0),c(i=>(i+1)%S.length),setTimeout(()=>O(!1),D.animationDuration)},D.intervalDuration)},[C]);(0,f.useEffect)(()=>(M(!0),()=>M(!1)),[]),(0,f.useEffect)(()=>(T(),()=>{g.current&&clearInterval(g.current)}),[T]);let J=()=>{h(!0),setTimeout(()=>{h(!1),a()},300)},_=(0,f.useCallback)(i=>{let{baseOffset:d,secondCardOffset:w,lastCardOffset:v}=D;return i===0?0:i===1?w:i===S.length-1?v:i<=S.length/2?-(d*2)-(i-2)*d:d*2+(S.length-i-2)*d},[]),B=(0,f.useCallback)(i=>{let{topCardScale:d,secondCardScale:w,lastCardScale:v,defaultScale:A}=D;return i===0?d:i===1?w:i===S.length-1?v:A},[]),K=(0,f.useCallback)(i=>{let{baseOffset:d,visibilityThreshold:w}=D,v=d*w;return Math.abs(i)<=v},[]);return e(O1,null,e("div",{style:{display:"flex",height:"100%",opacity:P?0:t&&x?1:t?0:1,position:"relative",transform:P?"none":t&&x?"translateX(0)":t?"translateX(25%)":"none",transition:P?"opacity 300ms ease-in-out":t?"transform 300ms ease-in-out, opacity 300ms ease-in-out":"none",visibility:t&&!x?"hidden":"visible",width:"100%"}},t&&e(G1,{onClick:J},e(C1,null)),e(z,{onClick:u},e(W,null)),e(_1,null,e(R1,null,e(U1,null,"Get Your Reading Superpowers"),e(Z1,null,"Join 30+ Million Listeners in Transforming How You Consume Content")),e(W1,null,le.map(({icon:i,title:d,description:w})=>e(Y1,{key:d},e(i,null),e(F1,null,e(z1,null,d),e(N1,null,w))))),e($1,null,e(j1,{"aria-label":R("PAYWALL_BUTTON"),onClick:o},"Try for Free"),e(q1,null,e(f1,{alt:"New premium users",src:"paywall/avatars.png",width:52,height:24}),e(J1,null,l()," joined Premium this week")))),e(K1,null,S.map((i,d)=>{let w=(d-q+S.length)%S.length,v=(d-C+S.length)%S.length,A=_(w),X=_(v),Q=B(w),Q1=B(v),l1=I?A:X,H1=I?Q:Q1,ee=v===0;return e("div",{key:d,style:{position:"absolute",width:"260px",height:"120px",transition:"transform 0.5s ease-in-out",transform:`translateY(${l1}px) scale(${H1})`,visibility:K(l1)?"visible":"hidden"}},e(D1,{item:i,isMiddleCard:ee,isTransitioning:I}))}))))}function o1({isSettingsUpsell:t,root:u,source:a="",variant:o="global"}){let[l,C]=(0,p.useState)(t),[c,x]=(0,p.useState)(!0),[M,P]=(0,p.useState)(a),[h,I]=(0,p.useState)(o);(0,p.useEffect)(()=>{let i=async()=>{x(!1)},d=async(w,v)=>{let{isSettingsUpsell:A,source:X,variant:Q}=v||{isSettingsUpsell:!1,variant:"global",source:""};C(A),x(!0),P(X||""),I(Q)};return H("close-paywall-modal",i,"paywall-modal"),H("show-paywall-modal",d,"paywall-modal"),()=>{e1("close-paywall-modal",i),e1("show-paywall-modal",d)}},[c,x]),(0,p.useEffect)(()=>{if(c)return t1(),window.addEventListener("keydown",G),()=>{window.removeEventListener("keydown",G),p1()}},[c]),(0,p.useEffect)(()=>{c&&V("hide-settings-modal",{},"settings-modal")},[c]);let O=(0,p.useMemo)(()=>!l,[l]),q=(0,p.useMemo)(()=>{if(M)return M;switch(h){case"global":return"paywall_modal_global";case"increased_listening_speeds":return"paywall_modal_increased_listening_speeds";case"premium_voices":return"paywall_modal_premium_voices"}},[M,h]),G=i=>{i.key==="Escape"&&g()},g=()=>{x(!1)},T=()=>{l&&V("close-settings-modal",{},"settings-modal"),g()},J=i=>{i.target===i.currentTarget&&(l&&V("close-settings-modal",{},"settings-modal"),g())},_=()=>{V("show-settings-modal",{},"settings-modal"),g()},B=()=>{l&&V("close-settings-modal",{},"settings-modal"),g(),c1(q)},K=(0,p.useMemo)(()=>s1({key:"paywall-emotion-cache",container:u}),[u]),i1=(0,p.useMemo)(()=>{switch(h){case"global":return e(X1,{isSettingsUpsell:l,onCloseClick:T,onPreviousClick:_,onUpgradeClick:B});case"increased_listening_speeds":case"premium_voices":return e(A1,{onCloseClick:T,onUpgradeClick:B,variant:h});default:return null}},[l,h]);return c?e(a1,{value:K},e(g1,{showOverlay:O,onClick:J},i1)):null}var re=`
  position: fixed;
  z-index: 2147483647;
  top:0; 
  left: 0;
  height: fit-content;
  font-size: initial;
`,j,se=()=>{if(!j){let t=document.createElement("div");t.id=b,t.style.cssText="position: absolute; bottom: 0; right: 0;",document.body.appendChild(t),j=t.attachShadow({mode:"open"})}},ae=()=>()=>{let t=document.querySelector(`#${b}`);t&&document.body.removeChild(t),j=null},de=async(t,u,a)=>{se();let o=document.createElement("div");o.id=d1,o.style.cssText=re,j.appendChild(o);let{isSettingsUpsell:l,variant:C,source:c}=a||{isSettingsUpsell:!1,variant:"global",source:""};return r1(e(o1,{isSettingsUpsell:l,root:o,source:c,variant:C}),o),ae()},vt=de;export{vt as default};
//# sourceMappingURL=init-4ZR765TH.js.map
