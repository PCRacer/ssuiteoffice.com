import{a as I1}from"./chunk-GM73DFVY.js";import{a as _1}from"./chunk-Q4YKR5OJ.js";import{a as P1,b as v1}from"./chunk-YORI6CWH.js";import{C as J,F as L1,u as b1,v as E1,y as j}from"./chunk-43GP4A7N.js";import"./chunk-MBHSJ34F.js";import{a as y1}from"./chunk-DMUXVFIA.js";import{a as x1}from"./chunk-Z3E43XMU.js";import"./chunk-BN5XPDNR.js";import"./chunk-YYPSUSZQ.js";import"./chunk-56NWWOIX.js";import"./chunk-EF43U47C.js";import"./chunk-GWCIFOLA.js";import"./chunk-NK4CKTAC.js";import{a as C1,g as h1}from"./chunk-KO4WPNRU.js";import"./chunk-F5622KQ7.js";import"./chunk-WC6QURV6.js";import"./chunk-TIGAXALM.js";import"./chunk-ZQRXZJGY.js";import"./chunk-6S4AP2UG.js";import"./chunk-O3LC63CS.js";import{a as f}from"./chunk-AG3QEKLJ.js";import{Da as p1,Na as U,Oa as X,Oc as G,Qb as g1,Ta as Y,Ua as u1,Uc as S1,Va as l,Wa as s,bd as Q,d as r1,gb as D,i as a1,kc as w1,qa as d1,ua as c1}from"./chunk-RISKGE32.js";import{T as l1,V as s1,fa as m1,ha as f1,ja as O}from"./chunk-6O6MLDWR.js";import{a as q,b as y,c as z,g as Z,k as m}from"./chunk-F4AZU7R4.js";import{g as F}from"./chunk-GQY3J744.js";import{d as k,g as o,i as e,j as g,k as K,m as me,n as i}from"./chunk-CLPINNGF.js";i();o();me();i();o();var I=k(F());i();o();var u=k(F());i();o();i();o();var B1=t=>e(g,null,e(x1,{top:"unset",left:"unset"}),e(H,{...t})),H=t=>e(f,{"aria-label":l("PLAY_BUTTON"),"data-testid":s.PLAY_BUTTON,xmlns:"http://www.w3.org/2000/svg",fill:"currentColor",viewBox:"0 0 32 32",className:"status-icon",...t},e("g",{"clip-path":"url(#clip0_533_5051)"},e("circle",{cx:"16",cy:"16",r:"16",fill:"currentColor"}),e("path",{d:"M22.1998 14.9608C22.9998 15.4227 22.9998 16.5774 22.1998 17.0392L13.7998 21.889C12.9998 22.3509 11.9998 21.7735 11.9998 20.8497L11.9998 11.1503C11.9998 10.2265 12.9998 9.64915 13.7998 10.111L22.1998 14.9608Z",fill:"white"})),e("defs",null,e("clipPath",{id:"clip0_533_5051"},e("rect",{width:"32",height:"32",fill:"white"})))),T1=t=>e(f,{"aria-label":l("PAUSE_BUTTON"),"data-testid":s.PAUSE_BUTTON,className:"icon--pressed status-icon",role:"presentation",xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 32 32",fill:"currentColor",...t},e("g",{"clip-path":"url(#clip0_420_17231)"},e("circle",{cx:"16",cy:"16",r:"16",fill:"currentColor"}),e("path",{d:"M11 11C11 10.4477 11.4477 10 12 10H14C14.5523 10 15 10.4477 15 11V21C15 21.5523 14.5523 22 14 22H12C11.4477 22 11 21.5523 11 21V11Z",fill:"white"}),e("path",{d:"M17 11C17 10.4477 17.4477 10 18 10H20C20.5523 10 21 10.4477 21 11V21C21 21.5523 20.5523 22 20 22H18C17.4477 22 17 21.5523 17 21V11Z",fill:"white"})),e("defs",null,e("clipPath",{id:"clip0_420_17231"},e("rect",{width:"32",height:"32",fill:"white"})))),A1=t=>e(f,{"aria-label":l("REPLAY_BUTTON"),"data-testid":s.REPLAY_BUTTON,className:"icon--pressed",role:"presentation",xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 32 32",fill:"currentColor",...t},e("circle",{cx:"16",cy:"16",r:"16",fill:"#4759F7"}),e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M20.3393 13.1331C19.4076 11.726 17.8115 10.8001 16.0002 10.8001C13.1283 10.8001 10.8002 13.1282 10.8002 16.0001C10.8002 18.872 13.1283 21.2001 16.0002 21.2001C18.6696 21.2001 20.8701 19.188 21.1662 16.5982C21.2164 16.1593 21.613 15.8441 22.0519 15.8943C22.4909 15.9445 22.8061 16.341 22.7559 16.78C22.3685 20.1686 19.4922 22.8001 16.0002 22.8001C12.2447 22.8001 9.20019 19.7556 9.2002 16.0001C9.2002 12.2445 12.2447 9.20007 16.0002 9.20007C18.2024 9.20007 20.1592 10.2471 21.4013 11.8683V10.8325C21.4013 10.3907 21.7595 10.0325 22.2013 10.0325C22.6431 10.0325 23.0013 10.3907 23.0013 10.8325V13.9331C23.0013 14.3749 22.6431 14.7331 22.2013 14.7331L19.1007 14.7331C18.6589 14.7331 18.3007 14.3749 18.3007 13.9331C18.3007 13.4913 18.6589 13.1331 19.1007 13.1331L20.3393 13.1331Z",fill:"white"}));function e1({isPlaying:t,isLoading:n,isLoadingFailed:E,isFinished:d}){return E?h1:n?B1:t?T1:d?A1:H}i();o();var R1=t=>e(f,{width:"20px",height:"20px",viewBox:"0 0 20 20",xmlns:"http://www.w3.org/2000/svg","aria-label":l("HIDE_LISTENING_BAR"),"data-testid":s.LISTENING_BAR_HIDE_BUTTON,...t},e("path",{"fill-rule":"evenodd","clip-rule":"evenodd",d:"M18.6364 2.61879C18.9879 2.26732 18.9879 1.69747 18.6364 1.346C18.2849 0.994529 17.7151 0.994529 17.3636 1.346L14.9269 3.78274C13.4728 2.95781 11.7916 2.48679 10.0005 2.48679C5.34186 2.48679 1.42744 5.67293 0.317383 9.98499C0.843831 12.03 2.001 13.8217 3.56916 15.1404L1.3636 17.346C1.01213 17.6975 1.01213 18.2673 1.3636 18.6188C1.71508 18.9703 2.28492 18.9703 2.6364 18.6188L5.07019 16.185C6.52512 17.0113 8.20768 17.4831 10.0004 17.4831C14.659 17.4831 18.5735 14.297 19.6835 9.98494C19.1567 7.93855 17.9983 6.14574 16.4285 4.82672L18.6364 2.61879ZM13.5948 5.11478C12.5092 4.58441 11.2893 4.28679 10.0005 4.28679C6.34639 4.28679 3.24688 6.67893 2.18993 9.98498C2.68248 11.5256 3.61861 12.8678 4.84771 13.8619L13.5948 5.11478ZM6.40203 14.8532L15.1499 6.10533C16.3806 7.09971 17.318 8.44291 17.811 9.98494C16.754 13.291 13.6545 15.6831 10.0004 15.6831C8.70995 15.6831 7.48864 15.3848 6.40203 14.8532Z",fill:"#9899A6"}));i();o();var M1=t=>e(f,{width:"24",height:"16",viewBox:"0 0 24 16",fill:"currentColor",xmlns:"http://www.w3.org/2000/svg","aria-label":l("LOGO"),"data-testid":s.LOGO,...t},e("path",{"fill-rule":"evenodd","clip-rule":"evenodd",d:"M5.44974 4.96208C6.05988 4.07046 6.589 3.6296 7.38119 3.8745C7.86056 4.02269 8.05734 4.63464 7.86056 5.40248C7.51457 6.75258 7.38119 7.52757 7.38119 8.44993C8.59809 5.89931 10.8476 2.50931 11.8226 1.36909C12.4964 0.580999 13.4623 0.681502 13.826 0.85729C14.4168 1.14292 14.448 1.76225 14.2441 2.35454C12.8332 6.45229 12.784 8.64083 12.6108 10.767C13.4877 8.40895 14.5538 6.19084 15.8412 4.62867C16.3836 3.8794 17.3344 3.64419 17.9349 3.88759C18.5354 4.13099 18.6722 4.71333 18.5354 5.44307C18.1784 7.34607 18.0013 8.23798 18.0013 8.97519C18.6534 8.47644 19.1726 8.05506 20.3597 7.95875C21.5468 7.86244 24 8.33505 24 8.33505C24 8.33505 22.5838 8.57568 21.8357 8.7591C20.3023 9.13515 19.7667 9.57492 18.7741 11.0288C18.4856 11.4512 18.0013 11.7755 17.4557 11.7343C16.9101 11.693 16.5437 11.3498 16.3836 10.8862C16.1612 10.2419 16.095 9.27822 16.3836 7.19267C14.9694 9.3444 14.2441 12.2672 13.275 14.2055C13.0273 14.7011 12.6041 15.2659 12.0307 15.2659C11.4572 15.2659 10.7136 15.0434 10.617 13.3396C10.3697 8.97519 11.1942 5.50209 11.1942 5.50209C9.58829 8.0484 9.07541 9.53265 8.5168 10.3066C7.95818 11.0806 7.41614 11.7508 6.7568 11.7343C6.09747 11.7177 5.71375 10.9806 5.63031 10.3066C5.54688 9.63261 5.52287 8.77179 5.76656 7.19267C5.13224 7.82699 4.57449 8.25658 3.57562 8.52559C2.57674 8.79459 1.38397 8.62337 0 8.33505C1.38397 8.33505 3.71298 7.50006 5.44974 4.96208Z",fill:"currentColor"}));i();o();var G1=t=>e(f,{viewBox:"0 0 4 12",width:"16px",height:"16px",xmlns:"http://www.w3.org/2000/svg","aria-label":l("LISTENING_BAR_MORE"),"data-testid":s.LISTENING_BAR_MORE_BUTTON,...t},e("path",{d:"M2.225 2.871a1.23 1.23 0 001.242-1.254 1.243 1.243 0 00-2.485 0c0 .692.563 1.254 1.243 1.254zm0 4.365c.697 0 1.242-.545 1.242-1.242 0-.685-.557-1.236-1.242-1.236-.68 0-1.243.55-1.243 1.236 0 .686.563 1.242 1.243 1.242zm0 4.383c.697 0 1.242-.55 1.242-1.242 0-.697-.557-1.254-1.242-1.254a1.25 1.25 0 000 2.496z"}));i();o();var N1=t=>e(f,{xmlns:"http://www.w3.org/2000/svg",width:"20px",height:"20px",viewBox:"0 0 20 20","aria-label":l("GO_TO_SETTINGS"),"data-testid":s.GO_TO_SETTINGS,...t},e("path",{"fill-rule":"evenodd","clip-rule":"evenodd",d:"M8.90544 3.39998H11.0977L11.4871 4.19493C12.0056 5.25336 13.113 5.89274 14.2889 5.81252L15.1717 5.75229L16.268 7.65111L15.7744 8.38555C15.117 9.36375 15.117 10.6425 15.7744 11.6207L16.2677 12.3547L15.1712 14.254L14.2889 14.1938C13.113 14.1135 12.0056 14.7529 11.4871 15.8113L11.0982 16.6054H8.905L8.51605 15.8113C7.99761 14.7529 6.89016 14.1135 5.7143 14.1938L4.83186 14.254L3.7354 12.3548L4.22877 11.6207C4.88617 10.6425 4.88617 9.36375 4.22877 8.38555L3.73512 7.65101L4.83135 5.75228L5.7143 5.81252C6.89016 5.89275 7.99761 5.25336 8.51605 4.19493L8.90544 3.39998ZM12.6059 2.38709C12.3305 1.82486 11.7679 1.59998 11.3016 1.59998H8.70156C8.23526 1.59998 7.67264 1.82486 7.39724 2.38709L6.89956 3.40313C6.70291 3.8046 6.28284 4.04712 5.83683 4.01669L4.70808 3.93968C4.08366 3.89708 3.60769 4.27173 3.37457 4.67549L2.07421 6.9278C1.8411 7.33156 1.75462 7.93108 2.10373 8.45055L2.7348 9.38957C2.98416 9.76061 2.98416 10.2457 2.7348 10.6167L2.10373 11.5557C1.75489 12.0748 1.84115 12.6739 2.07416 13.0775L3.37541 15.3313C3.60842 15.7349 4.08414 16.1092 4.70808 16.0666L5.83683 15.9896C6.28284 15.9592 6.70291 16.2017 6.89956 16.6032L7.39724 17.6192C7.67221 18.1806 8.23391 18.4054 8.6998 18.4054H11.3034C11.7693 18.4054 12.331 18.1805 12.6059 17.6192L13.1036 16.6032C13.3003 16.2017 13.7203 15.9592 14.1664 15.9896L15.2951 16.0666C15.9189 16.1092 16.3946 15.735 16.6276 15.3314L17.929 13.0773C18.162 12.6737 18.2482 12.0747 17.8995 11.5557L17.2684 10.6167C17.019 10.2457 17.019 9.76061 17.2684 9.38957L17.8995 8.45055C18.2485 7.93118 18.1621 7.33175 17.929 6.92803L16.6284 4.67537C16.3953 4.27165 15.9194 3.89709 15.2951 3.93968L14.1664 4.01669C13.7203 4.04712 13.3003 3.8046 13.1036 3.40313L12.6059 2.38709ZM11.5343 10.0037C11.5343 10.8506 10.8478 11.5371 10.0009 11.5371C9.1541 11.5371 8.4676 10.8506 8.4676 10.0037C8.4676 9.15691 9.1541 8.47041 10.0009 8.47041C10.8478 8.47041 11.5343 9.15691 11.5343 10.0037ZM13.3343 10.0037C13.3343 11.8447 11.8419 13.3371 10.0009 13.3371C8.15999 13.3371 6.6676 11.8447 6.6676 10.0037C6.6676 8.16279 8.15999 6.67041 10.0009 6.67041C11.8419 6.67041 13.3343 8.16279 13.3343 10.0037Z",fill:"#9899A6"}));i();o();var O1=t=>e(f,{xmlns:"http://www.w3.org/2000/svg",width:"20",height:"20",viewBox:"0 0 20 20","aria-label":l("LISTENING_BAR_SAVE_TO_LIBRARY"),"data-testid":s.LISTENING_BAR_SAVE_TO_LIBRARY,...t},e("g",{clipPath:"url(#clip0_993_344)"},e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M16.167 1C16.7193 1 17.167 1.44772 17.167 2V4H19.167C19.7193 4 20.167 4.44772 20.167 5C20.167 5.55228 19.7193 6 19.167 6H17.167V8C17.167 8.55228 16.7193 9 16.167 9C15.6147 9 15.167 8.55228 15.167 8V6H13.167C12.6147 6 12.167 5.55228 12.167 5C12.167 4.44771 12.6147 4 13.167 4H15.167V2C15.167 1.44772 15.6147 1 16.167 1ZM5.83366 4C5.46547 4 5.16699 4.29848 5.16699 4.66667L5.16702 15.7589L9.66312 13.1362C9.97448 12.9546 10.3595 12.9546 10.6709 13.1362L15.167 15.7589V12C15.167 11.4477 15.6147 11 16.167 11C16.7193 11 17.167 11.4477 17.167 12V17.5C17.167 17.858 16.9755 18.1888 16.6651 18.3671C16.3546 18.5454 15.9724 18.5442 15.6631 18.3637L10.167 15.1577L4.6709 18.3637C4.36161 18.5442 3.97946 18.5454 3.66897 18.3671C3.35848 18.1888 3.16703 17.858 3.16703 17.5L3.16699 4.66667C3.16699 3.19391 4.3609 2 5.83366 2H10.167C10.7193 2 11.167 2.44772 11.167 3C11.167 3.55228 10.7193 4 10.167 4H5.83366Z"})),e("defs",null,e("clipPath",{id:"clip0_993_344"},e("rect",{width:"20",height:"20",transform:"translate(0.166992)"}))));i();o();var D1=t=>e(f,{xmlns:"http://www.w3.org/2000/svg",width:"20",height:"20",viewBox:"0 0 20 20","aria-label":l("LISTENING_BAR_SUMMARIZE"),"data-testid":s.LISTENING_BAR_SUMMARIZE,...t},e("path",{d:"M12.5837 8.57655L12.4638 8.62092C10.6833 9.27974 9.27956 10.6835 8.62074 12.4639L8.57637 12.5838C8.40969 13.0343 7.98016 13.3334 7.49984 13.3334C7.01952 13.3334 6.58999 13.0343 6.4233 12.5838L6.37894 12.4639C5.72012 10.6835 4.31635 9.27974 2.53591 8.62092L2.41602 8.57655C1.96556 8.40987 1.6665 7.98034 1.6665 7.50002C1.6665 7.0197 1.96556 6.59017 2.41602 6.42348L2.53591 6.37912C4.31635 5.7203 5.72012 4.31653 6.37894 2.5361L6.4233 2.41621C6.58999 1.96574 7.01952 1.66669 7.49984 1.66669C7.98016 1.66669 8.40969 1.96574 8.57637 2.41621L8.62074 2.5361C9.27956 4.31654 10.6833 5.7203 12.4638 6.37912L12.5837 6.42348C13.0341 6.59017 13.3332 7.0197 13.3332 7.50002C13.3332 7.98034 13.0341 8.40987 12.5837 8.57655Z",fill:"url(#paint0_radial_629_2758)"}),e("path",{d:"M14.9998 11.6667C15.2743 11.6667 15.5197 11.8376 15.615 12.095L15.6404 12.1635C16.0168 13.1809 16.819 13.983 17.8364 14.3595L17.9049 14.3849C18.1623 14.4801 18.3332 14.7256 18.3332 15C18.3332 15.2745 18.1623 15.5199 17.9049 15.6152L17.8364 15.6405C16.819 16.017 16.0168 16.8192 15.6404 17.8365L15.615 17.9051C15.5197 18.1625 15.2743 18.3334 14.9998 18.3334C14.7254 18.3334 14.4799 18.1625 14.3847 17.9051L14.3593 17.8365C13.9829 16.8192 13.1807 16.017 12.1633 15.6405L12.0948 15.6152C11.8374 15.5199 11.6665 15.2745 11.6665 15C11.6665 14.7256 11.8374 14.4801 12.0948 14.3849L12.1633 14.3595C13.1807 13.983 13.9829 13.1809 14.3593 12.1635L14.3847 12.095C14.4799 11.8376 14.7254 11.6667 14.9998 11.6667Z",fill:"url(#paint1_radial_629_2758)"}),e("defs",null,e("radialGradient",{id:"paint0_radial_629_2758",cx:"0",cy:"0",r:"1",gradientUnits:"userSpaceOnUse",gradientTransform:"translate(-5.41683 -0.833311) rotate(44.6155) scale(43.9005)"},e("stop",{offset:"0.224035",stopColor:"#EA6AFF"}),e("stop",{offset:"0.664903",stopColor:"#6B78FC"})),e("radialGradient",{id:"paint1_radial_629_2758",cx:"0",cy:"0",r:"1",gradientUnits:"userSpaceOnUse",gradientTransform:"translate(-5.41683 -0.833311) rotate(44.6155) scale(43.9005)"},e("stop",{offset:"0.224035",stopColor:"#EA6AFF"}),e("stop",{offset:"0.664903",stopColor:"#6B78FC"}))));i();o();var P=k(F()),V1=k(F()),fe=({anchorElement:t,open:n,children:E,onClose:d})=>{let C=(0,P.useRef)(null),[a,h]=(0,P.useState)({left:0,top:0,width:0,height:0}),r=new ResizeObserver(L=>{let p=L[0];if(p&&p.contentRect&&p.contentRect.width){let{width:v,height:w}=p.contentRect;h(T=>({...T,width:v,height:w}))}}),c=()=>{if(t){let{left:L,top:p,width:v,height:w}=t.getBoundingClientRect();h({left:L,top:p,width:v,height:w})}},B=new MutationObserver(()=>{c()});(0,P.useEffect)(()=>(t&&(r.observe(t),B.observe(document.body,{childList:!0,subtree:!0})),window.addEventListener("resize",c),c(),()=>{r.disconnect(),B.disconnect(),window.removeEventListener("resize",c)}),[t]),(0,P.useEffect)(()=>{let L=p=>{C.current&&!C.current.contains(p.target)&&t&&!t.contains(p.target)&&d()};return n&&document.addEventListener("mousedown",L),()=>{document.removeEventListener("mousedown",L)}},[n,t,d]);let M=(0,P.useMemo)(()=>z({key:"menu-cache",container:C.current}),[C.current]),N=(0,P.useMemo)(()=>({top:a.top+a.height/2+window.scrollY,left:a.left+a.width/2+window.scrollX}),[a]);return!n||!t?null:(0,V1.createPortal)(e("div",{ref:C,style:{position:"absolute",zIndex:1e3,...N}},e(Z,{value:M},E)),document.body)},k1=fe;var he=m("div")`
  display: flex;
  flex-direction: column;
  border-radius: 16px;
  margin: 24px 0;
  border: 0.5px solid ${y.brdrSec2060};
  min-width: 360px;
  max-width: 100%;
`,ge=m(u1)`
  background-color: ${y.bgPrimW100};
  padding: 15px;
  box-sizing: border-box;
  border-radius: ${({importEnabled:t})=>t?"16px 16px 0px 0px":"16px"};
`.withComponent("div"),z1=m(D)`
  font-size: 16px;
  font-weight: 500;
  line-height: 24px;
  letter-spacing: 0.16px;
  justify-self: start;
  margin-left: 8px;
  font-family: 'ABCDiatype';
  > div > div {
    width: 100%;
  }
  text-align: left;
  width: calc(100% - 24px);

  .seek-handle {
    top: 16px;
  }
`.withComponent("div"),xe=m("div")`
  display: flex;
  padding: 12px 16px;
  align-items: center;
  justify-content: space-between;
  background-color: #262940;
  border-radius: 0px 0px 16px 16px;
`,ye=m(D)`
  font-family: ABCDiatype;
  font-size: 14px;
  font-style: normal;
  font-weight: 500;
  line-height: 20px; /* 142.857% */
  letter-spacing: 0.14px;
  color: ${y.icnTxtPrim};
`,be=m(Y)`
  align-items: center;
  gap: 6px;
  cursor: pointer;

  & svg {
    color: #8894fe;
  }

  > span {
    font-family: ABCDiatype;
    font-size: 14px;
    font-style: normal;
    font-weight: 500;
    line-height: 20px; /* 142.857% */
    letter-spacing: 0.14px;
    color: #8894fe;
  }

  &:hover {
    opacity: 0.75;
  }

  &:active {
    opacity: 0.5;
  }
`,Ee=m(D)`
  position: absolute;
  top: -105px;
  left: -155px;
  display: flex;
  flex-direction: column;
  padding: 4px;
  gap: 2px;
  border-radius: 12px;
  background: #252627;
  border: 0.5px solid #2d2d2f;
  box-shadow: 0px 6px 16px -6px rgba(0, 0, 0, 0.64);
  z-index: 100001;
`.withComponent("div"),F1=m("div")`
  display: flex;
  align-items: center;
  flex-direction: row;
  gap: 8px;
  padding: 10px 12px;
  cursor: pointer;
  border-radius: 8px;
  > span {
    font-family: ABCDiatype;
    font-size: 14px;
    font-style: normal;
    font-weight: 500;
    line-height: 20px;
    letter-spacing: 0.14px;
    color: ${y.icnTxtPrim};
    width: 100px;
    text-align: left;
  }

  &:hover {
    background: #2d2d2f;
  }

  &:active {
    background: #3c3c3e;
  }

  & svg {
    width: 20px;
    height: 20px;
  }
`,Z1=m("div")`
  position: relative;
  display: flex;
  align-items: center;
  cursor: pointer;
  color: ${y.icnTxtPrim};
  & svg {
    width: 24px;
    height: 24px;
    color: ${y.icnTxtPrim};
    &:hover {
      opacity: 0.75;
    }
    &:active {
      opacity: 0.5;
    }
  }

  & .tooltip {
    display: none;
  }

  &:hover .tooltip {
    display: flex;
  }

  &:active .tooltip {
    display: flex;
  }
`,Le=m(Z1)`
  margin-right: 8px;
  ${({active:t})=>t?"color: #9899A6;":""}
  & svg {
    height: 16px;
  }
`,we=m("div")`
  display: flex;
  align-items: center;
`,U1=m("div")`
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #2d2d2f;
  color: #ffffff;
  gap: 6px;
  border-radius: 10px;
  padding: 6px 16px 6px 12px;
  margin-right: 8px;
  cursor: pointer;

  &:hover {
    background-color: #343537;
  }

  &:active {
    background-color: #3c3c3e;
  }

  > span {
    font-family: ABCDiatype;
    font-size: 14px;
    font-style: normal;
    line-height: 20px;
    font-weight: 500;
  }
`,Y1=m(Y)`
  position: absolute;
  z-index: 2000;
  bottom: 34px;
  right: 0px;
  transform: translateX(calc(50% - 12px));
  font-family: 'ABCDiatype';
  font-style: normal;
  border-radius: 6px;
  padding: 6px 8px;
  box-shadow: 0px 4px 12px -4px rgba(0, 0, 0, 0.16);
  color: ${y.icnTxtPrimInv};
  background-color: #e9eaf0;

  ::before {
    content: '';
    display: block;
    width: 0;
    height: 0;
    position: absolute;
    left: calc(50% - 4px);
    top: 100%;
    border-style: solid;
    border-width: 4px;
    border-color: #e9eaf0 transparent transparent transparent;
  }

  ::after {
    content: '';
    display: block;
    position: absolute;
    width: 0;
    height: 0;
    left: calc(50% - 3px);
    top: 100%;
    border-style: solid;
    border-width: 3px;
    border-color: #e9eaf0 transparent transparent transparent;
  }
`,W1=m(D)`
  font-weight: 400;
  font-size: 12px;
  line-height: 16px;
  letter-spacing: 0.01em;
  width: max-content;
  color: ${y.icnTxtPrimInv};
`,Se=m("button")`
  position: relative;
  background-color: #4759f7;
  border-radius: 50%;
  height: 32px;
  width: 32px;
  display: flex;
  justify-content: center;
  align-items: center;
  outline: none;
  border: none;
  padding: 0;

  .status-icon {
    color: #4759f7;
  }

  &:hover {
    .status-icon {
      & circle {
        color: #4454e3;
      }
    }
  }

  &:active {
    .status-icon {
      & circle {
        color: #3d4ac4;
      }
    }
  }
`,Pe=()=>e(Y1,{className:"tooltip"},e(W1,null,"More")),ve=()=>e(Y1,{className:"tooltip"},e(W1,null,"Open Speechify library"));z1.defaultProps={color:y.bgPrimInvBW};var $1=({onClick:t,isActive:n,isLoadingFailed:E,isLoading:d,isPlaying:C,duration:a,configure:h,importEnabled:r=!1,isFinished:c})=>{let B=y1(),M=!B||Q(B),{seekTo:N}=U,L=e1({isLoadingFailed:E,isLoading:d,isPlaying:C,isFinished:c}),[p,v]=(0,u.useState)(!1),[w,T]=(0,u.useState)(!1),[_,$]=(0,u.useState)(!1),[o1,j1]=(0,u.useState)(null),[J1,Q1]=(0,u.useState)(!1),[i1,H1]=(0,u.useState)(!1),V=(0,u.useMemo)(()=>w1(),[window.location.hostname]),n1=x=>{let{disabled_websites:S,enabled_websites:A,enabled_by_default:de}=x,ce=S.includes(V),pe=A.includes(V);$((ce||!de)&&!pe)};(0,u.useLayoutEffect)(()=>{let x=j.listen(A=>{n1(A)}),S=async()=>{j.getAll().then(A=>{n1(A)})};return S(),m1("embedded-summary-error",S,"embedded-summaries"),()=>{x(),f1("embedded-summary-error",S)}},[]),(0,u.useEffect)(()=>{async function x(){let S=await b1(),A=await E1();Q1(S),H1(A)}x()},[]);let ee=()=>{w||T(!0),t()},te=()=>{v(!p)},oe=()=>{v(!1)},ie=()=>{g1.toggleFeatureOnDomain("embedded-player",!1),v(!1),G("extension_usage_hide_player",{site:h.site})},ne=()=>{G("extension_import_on_embedded_player"),a1().then(x=>{if(x&&!Q(x)){let S=`${q.speechifyWebApp.baseUrl}/importUrl?url=${encodeURIComponent(window.location.href)}`;window.open(S,"_blank")}else window.open("https://app.speechify.com","_blank","noopener")})},re=()=>{window.open(q.speechifyWebApp.baseUrl,"_blank")},ae=()=>{L1("/visibility"),G("extension_usage_settings_clicked",{source:"embedded_player"}),O("show-settings-modal")},le=async()=>{G("extension_embedded_summary_summarize_btn_clicked",{option:"everywhere"}),$(!1),await J(V)},se=async()=>{G("extension_sidepanel_summarize_btn_clicked",{source:"embedded_player"}),$(!1);try{await Promise.allSettled([J(V),P1()]),await v1()}catch(x){r1("EmbeddedPlayerSummarizeButton").error("Failed to open side panel or request summarization:",x)}};return(0,u.useEffect)(()=>{C&&!w&&T(!0)},[C,w]),(0,u.useEffect)(()=>{n||T(!1)},[n]),e(he,null,e(ge,{importEnabled:r,height:h.height,yAlign:!0,xAlign:!0,columns:"32px 1fr max-content"},e(Se,{"aria-label":l("EMBED_PLAYER_PLAY_BUTTON"),"data-testid":s.EMBED_PLAYER_PLAY_BUTTON},e(L,{onClick:ee,width:"32px",height:"32px",color:y.icnTxtPrim,style:{pointerEvents:"all"}})),e(z1,null,w?e(I1,{style:{marginLeft:"8px"},customStyle:{timeLabelColor:"#ffffff"},duration:a,seek:N}):e("span",null,"Listen to This ",r?"Chapter":"Page",e("span",{style:{color:"#747580",margin:"0px 4px"}},"·"),l1("long")(a))),e(Y,null,!M&&_&&J1&&!i1&&e(U1,{onClick:le},e(D1,null),e("span",null,"Summarize")),!M&&i1&&e(U1,{onClick:se},e(_1,null),e("span",null,"Summarize")),e(Le,{onClick:te,active:p},e(we,{ref:x=>j1(x)},e(G1,null)),!p&&e(Pe,null),o1&&e(k1,{anchorElement:o1,open:p,onClose:oe},e(Ee,null,e(F1,{onClick:ae},e(N1,null),e("span",null,"Settings")),e(F1,{onClick:C1(ie)},e(R1,null),e("span",null,"Hide player"))))),e(Z1,{onClick:re},e(M1,null),e(ve,null)))),r&&e(xe,null,e(ye,null,"Save all chapters of this story and listen anytime"),e(be,{onClick:ne},e(O1,null),e("span",null,"Save to Library"))))};function K1({container:t,importEnabled:n,config:E}){let d=X.usePlayingState(),{play:C,pause:a}=U,h=X.useCurrentContent(),r=["EmbeddedPlayer","PillPlayer"].includes(h?.metadata.source??""),c=r&&d==="playing",B=r&&d==="ended",M=r&&d==="buffering",N=r&&d==="errored",L=r&&d==="ended",[p,v]=(0,I.useState)(0),w=(0,I.useCallback)(async()=>{if(c)return a();r||await O("restart-page-content",{animate:!1},"standard-player"),s1()||O("browser-action",{animate:!1},"pill-player"),d!=="playing"&&C(),S1({triggeredFrom:"EmbeddedPlayer"})},[r,d,B,C,a,c]),T=(0,I.useMemo)(()=>z({key:"player-emotion-cache",container:t}),[t]),_=p1();return(0,I.useEffect)(()=>{r&&!_.isLoading&&_.duration&&v(_.duration)},[r,!_.isLoading&&_.duration]),_.isLoading===!0?null:e(Z,{value:T},e($1,{onClick:w,isActive:r,isLoadingFailed:N,isLoading:M,isPlaying:c,duration:p,configure:E,importEnabled:!!n,isFinished:L}))}var t1="speechify-embedded-player",W;function q1(){let t=document.querySelector(`#${t1}`);W&&W.disconnect(),t&&(K(()=>null,t),t.remove())}async function _e(t){let n=t.inlinePlayerContentSelector?t.inlinePlayerContentSelector:t.inlinePlayerSelector,E=n.indexOf("::prepend")!==-1,d=n.indexOf("::before")!==-1,C=E?n.replace("::prepend",""):d?n.replace("::before",""):n,a=d1(C);if(a&&a.parentNode){let h=document.createElement("div");h.id=t1,h.style.cssText=t.inlinePlayerStyle??"width: 100%; max-width: 1200px; margin: 0 auto;";let r=h.attachShadow({mode:"open"});E?a.parentNode.prepend(h):a.parentNode.insertBefore(h,d?a:a.nextElementSibling);let c=document.createElement("div");c.id="speechify-embedded-player-root",r.appendChild(c),t.inlinePlayerContentStyle&&(c.style.cssText=t.inlinePlayerContentStyle),K(e(K1,{container:c,importEnabled:t.importEnabled,config:t}),c)}return()=>{}}async function X1(t){if(await c1(t?.awaitedElement??""),!document.querySelector(`#${t1}`))return t?.site?_e(t):()=>{}}async function Ie(t){let n=await X1(t);return W=new MutationObserver(()=>X1(t)),W.observe(document,{subtree:!0,childList:!0}),()=>{n&&n(),q1&&q1()}}export{Ie as default};
//# sourceMappingURL=init-ECTO7AH4.js.map
