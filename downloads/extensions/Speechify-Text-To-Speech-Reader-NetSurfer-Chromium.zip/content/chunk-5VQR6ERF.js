import{Ad as R,Bd as S,Fd as _,Ya as D,dd as N}from"./chunk-RISKGE32.js";import{ba as Z}from"./chunk-6O6MLDWR.js";import{c as I,g as h,j as C,k as b}from"./chunk-F4AZU7R4.js";import{g as j}from"./chunk-GQY3J744.js";import{d as H,g as d,i as s,k as x,m as Y,n as f}from"./chunk-CLPINNGF.js";f();d();Y();f();d();var i=H(j()),L=H(Z());var Q=-45,tt=-30,g=10,ot=12,et=8,nt=C`
  from { opacity: 0; }
  to { opacity: 1; }
`,it=b(D)`
  cursor: pointer;
  position: absolute;
  right: 6px;
  top: 8px;
`,rt=b.div`
  position: absolute;
  z-index: 2147483645;
  height: fit-content;
  font-size: initial;

  opacity: ${({visible:t})=>t?1:0};
  animation: ${nt} 0.25s ease;

  background: #373737;
  border: 1px solid #373737;
  border-radius: 4px;
  color: #fff;
  cursor: pointer;
  font-family: ABCDiatype, sans-serif;
  font-size: 14px;
  line-height: 16px;
  padding: ${et}px ${ot}px;

  margin-top: ${Q}px;
  margin-left: ${tt}px;
  width: max-content;

  svg {
    display: none;
  }

  &.closable {
    padding: 8px 32px 8px 12px;

    svg {
      display: inherit;
      fill: #fff;
    }
  }

  &::after {
    border-color: #373737 transparent transparent transparent;
    border-style: solid;
    border-width: ${g/2}px;
    bottom: ${-g}px;
    content: '';
    left: ${g}px;
    position: absolute;
  }

  &.light {
    background: #f1f4f9;
    border: 1px solid #e4eaf1;
    color: #1e1e1e;

    &::after {
      border-color: #f1f4f9 transparent transparent transparent;
    }

    svg {
      fill: #1e1e1e;
    }
  }
`,st=t=>{if(!t)return null;if(t.nodeType===Node.ELEMENT_NODE)return t.getBoundingClientRect();if(t.nodeType===Node.TEXT_NODE){let o=document.createRange();return o.selectNode(t),o.getBoundingClientRect()}return null},P=({className:t,onClick:o,onClose:e,root:l,text:r="",visible:$=!0,anchorElement:a,xOffset:k=0,yOffset:M=0,maxWidth:A,hintId:v,...z})=>{let{isDarkBackground:B}=N(document.body),[F,G]=(0,i.useState)(0),[U,W]=(0,i.useState)(0),m=(0,i.useRef)(null),K=(0,i.useMemo)(()=>I({key:"player-emotion-cache",container:l}),[l]),V=n=>{n.preventDefault(),n.stopPropagation(),o&&o()},X=n=>{n.preventDefault(),n.stopPropagation(),e&&e()};return(0,i.useEffect)(()=>{if(!a)return;let n=()=>{if(!a)return;let p=st(a)||{left:0,top:0};G(p.left),W(p.top)},c=new ResizeObserver(n);c.observe(a),n();let T=(0,L.default)(n,50);return window.addEventListener("resize",T),()=>{c.disconnect(),window.removeEventListener("resize",T)}},[a]),(0,i.useEffect)(()=>{let n=new IntersectionObserver(c=>{c.find(p=>p.isIntersecting)&&(w(v),n.disconnect())});return n.observe(m.current),()=>{n.disconnect()}},[m.current,v]),s(h,{value:K},s(rt,{ref:m,id:"speechify-hint-tooltip",visible:$,className:`
              ${t?`${t} `:""}
              fadeIn
              ${B?"light":""}
              ${z.closable?"closable":""}
            `,onClick:V,style:{display:"inherit",position:"absolute",top:`${U+M+window.scrollY}px`,left:`${F+k+window.scrollX}px`,maxWidth:A,zIndex:2147483640}},s("span",{className:"hint-tooltip-text"},r),s(it,{onClick:X})))};var ht=["hover-player-hints","click-to-listen-hints"],Ct=new Date(2024,0,1),Dt=async(t,o=!1)=>{let e=await _(t);if(!o&&e){let{dismissedByUser:l,displayCount:r}=e;if(l||r>=1)return!1}return!0},E,u={},y=t=>{let o=u[t];o&&(x(null,o),o.remove(),u[t]=null)},Nt=y,lt=t=>{S(t),y(t)},O={},w=t=>{let o=O[t],e=window.location.href;o!==e&&(O[t]=e,R(t))},Rt=({hintId:t,...o})=>{if(!E){let r=document.createElement("div");r.id="speechify-hint-tooltip-shadow-root",document.body.appendChild(r),E=r.attachShadow({mode:"open"})}let e=u[t];e||(e=document.createElement("div"),e.id=`speechify-hint-tooltip-root-${t}`,E.appendChild(e),u[t]=e);let l=o.onClose??(()=>lt(t));return x(s(P,{...o,root:e,hintId:t,onClose:l}),e),()=>y(t)};export{tt as a,g as b,ht as c,Ct as d,Dt as e,Nt as f,lt as g,w as h,Rt as i};
//# sourceMappingURL=chunk-5VQR6ERF.js.map
