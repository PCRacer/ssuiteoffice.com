import{h as o,i as t}from"./chunk-RISKGE32.js";import{g as i}from"./chunk-GQY3J744.js";import{d as n,g as u,n as f}from"./chunk-CLPINNGF.js";f();u();var e=n(i());function m(){let[r,s]=(0,e.useState)(t.getCacheSync());return(0,e.useEffect)(()=>{r||t().then(s)},[]),(0,e.useEffect)(()=>o.on("userupdate",s),[]),r}export{m as a};
//# sourceMappingURL=chunk-DMUXVFIA.js.map
