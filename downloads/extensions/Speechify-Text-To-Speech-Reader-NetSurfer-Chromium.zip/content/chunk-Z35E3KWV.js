import{a as be,b as wn,c as Tt}from"./chunk-F6QDPILS.js";import{b as ze}from"./chunk-CXWBUGW7.js";import{a as bt}from"./chunk-FD2XQWPC.js";import{b as ht}from"./chunk-3UDU62CH.js";import{a as yt}from"./chunk-FKJPRJ46.js";import{a as Le}from"./chunk-43GP4A7N.js";import{a as Ct}from"./chunk-MBHSJ34F.js";import{c as U}from"./chunk-BN5XPDNR.js";import{b as ke}from"./chunk-EF43U47C.js";import{c as Pe}from"./chunk-NK4CKTAC.js";import{d as xt}from"./chunk-TIGAXALM.js";import{g as ft,j as gt}from"./chunk-O3LC63CS.js";import{a as F}from"./chunk-AG3QEKLJ.js";import{A as M,C as it,D as We,E as Fe,Eb as Ue,F as ee,G as rt,K as st,Oa as te,Oc as he,S as Ve,T as lt,Ta as D,Tb as vt,U as at,Ub as St,Va as oe,Vb as wt,Wa as G,Wb as Vt,Wc as Oe,X as ct,Xc as Pt,Yc as Lt,Zc as kt,_c as Rt,a as vn,ad as Et,ba as pt,e as fe,gb as xe,j as tt,kb as ut,la as dt,u as nt,v as Se,xa as W,z as we}from"./chunk-RISKGE32.js";import{H as ue,T as ot,j as Y,u as et}from"./chunk-6O6MLDWR.js";import{b as R,k as n,m as mt}from"./chunk-F4AZU7R4.js";import{a as K,b as X,d as J,e as ge,f as Sn,g as V}from"./chunk-GQY3J744.js";import{d as w,f as b,g as l,i as e,j as g,n as a}from"./chunk-CLPINNGF.js";a();l();var It,Pn=200,Ln=.05,kn=[{min:.5,max:1,time:3},{min:1.1,max:1.5,time:4},{min:1.6,max:2,time:5},{min:2.1,max:2.5,time:10},{min:2.6,max:3,time:20},{min:3.1,max:3.5,time:20},{min:3.6,max:4,time:25},{min:4.1,max:4.5,time:25}],Rn=600,En=t=>Math.round(t/50)*50,Tn=t=>Math.round(t*10)/10,je=t=>{let o=Tn(t),i=kn.find(c=>o>=c.min&&o<=c.max);if(!i)return Rn;let s=Pn*o,r=Math.round(s*i.time);return En(r)};async function ur(){It?.(),It=vt.on("consumed",async()=>{let{autoSpeedUp:t,playbackSpeed:o}=await st(),i=await Et();if(!t||!i)return;let s=je(o);i>=s&&await In(o)})}var In=async t=>Ve(t+Ln,ue,!0);a();l();var ln=w(vn());a();l();var Dt=w(V());var Mn=n.div`
  align-items: flex-start;
  align-self: stretch;
  background: #2d2d2f;
  border-radius: 10px;
  display: flex;
  flex-direction: column;
  gap: 8px;
  padding: 8px;
`,Bt=n.div`
  border-radius: 9999px;
  background: #1e1e1f;
  display: flex;
  padding: 2px;
  align-items: center;
  gap: 10px;
`,An=n(Bt)`
  transform: rotate(180deg);
`,Mt=n.div`
  align-items: center;
  align-self: stretch;
  color: #fff;
  display: flex;
  font-size: 14px;
  font-style: normal;
  font-weight: 400;
  gap: 4px;
  letter-spacing: 0.14px;
  line-height: 20px;
`;function At(){return e("svg",{xmlns:"http://www.w3.org/2000/svg",width:"16",height:"16",viewBox:"0 0 16 16",fill:"none"},e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M3.96625 4.75971C4.25915 4.46682 4.73402 4.46682 5.02691 4.75971L7.80632 7.53912C7.94697 7.67977 8.02599 7.87054 8.02599 8.06945C8.02599 8.26836 7.94697 8.45913 7.80632 8.59978L5.02691 11.3792C4.73402 11.6721 4.25914 11.6721 3.96625 11.3792C3.67336 11.0863 3.67336 10.6114 3.96625 10.3185L6.21533 8.06944L3.96625 5.82037C3.67336 5.52748 3.67336 5.0526 3.96625 4.75971ZM8.51499 4.75971C8.80788 4.46682 9.28276 4.46682 9.57565 4.75971L12.3551 7.53912C12.4957 7.67977 12.5747 7.87054 12.5747 8.06945C12.5747 8.26836 12.4957 8.45913 12.3551 8.59978L9.57565 11.3792C9.28275 11.6721 8.80788 11.6721 8.51499 11.3792C8.22209 11.0863 8.2221 10.6114 8.51499 10.3185L10.7641 8.06945L8.51499 5.82037C8.2221 5.52748 8.2221 5.0526 8.51499 4.75971Z",fill:"white"}))}function Ge(){return(0,Dt.useEffect)(()=>{at()},[]),e(D,{padding:"12px",xAlign:!0,column:!0,separation:"8px",style:{paddingTop:0}},e(Mn,null,e(Mt,null,"Use"," ",e(Bt,null,e(At,null))," ","to skip forward."),e(Mt,null,"Use"," ",e(An,null,e(At,null))," ","to skip backward.")))}a();l();var ne=w(V());var Bn=n(D)`
  align-items: center;
  border-radius: 12px;
  border: 1.5px dashed #3c3c3e;
  box-sizing: border-box;
  color: #ffffff;
  cursor: pointer;
  justify-content: center;
  padding: 12px 16px;
  width: 100%;
  max-width: 100%;

  &:hover {
    border-color: #8894fe;

    span {
      color: #8894fe;
    }

    svg {
      path {
        fill: #8894fe;
      }
    }
  }

  &:active {
    opacity: 0.5;
  }
`,_n=n(ut)`
  color: #ffffff;
  font-size: 14px;
  font-weight: 500;
  padding: 8px 16px;

  &:hover {
    opacity: 0.75;
  }

  &:active {
    opacity: 0.5;
  }
`,Nn=()=>{let t=(0,ne.useCallback)(()=>{Ce("/"),yt("broken-site-menu")},[]);return e(Bn,{xAlign:!0,column:!0,separation:"4px",onClick:t},e(gt,null),e(xe,{fontSize:"14px",medium:!0},"Capture and listen"))};function Ze({onReport:t}){let{reportedDomains:o}=W(),i=(0,ne.useMemo)(()=>o?.includes(Ue()),[o]),s=(0,ne.useCallback)(()=>{Ce("/")},[]),r=(0,ne.useCallback)(()=>{i||(he("extension_usage_broken_site_reported"),pt(Ue()),t?.()),s()},[i]);return e(D,{padding:"12px",xAlign:!0,column:!0,separation:"8px"},e(Nn,null),e(D,{xAlign:!0,column:!0,separation:"16px"},e(xe,{align:"center",fontSize:"14px",color:"#9899A6"},"Take a screenshot of a",e("br",null),"selected area and listen to it."),e(_n,{onClick:r},i?"Site reported":"Still not working? Report Site")))}a();l();var B=w(V());a();l();var Re=w(V());a();l();var _t=n.div`
  align-items: flex-start;
  display: flex;
  gap: 8px;
  justify-content: center;
  padding: 0px 40px 24px 40px;
`,Nt=n.div`
  align-items: center;
  display: flex;
  flex-shrink: 0;
  gap: 0px;
  justify-content: flex-end;
  padding: 2px;
  width: 32px;

  .react-switch-bg {
    background: ${({checked:t})=>t?"radial-gradient(263.4% 263.4% at -38.15% -15%, #ea6aff 22.4%, #6b78fc 66.49%) !important":"initial"};
  }

  .react-switch-handle {
    background: ${R.icnTxtWhite} !important;
  }
`,$t=n.div`
  display: flex;
  align-items: flex-start;
  flex-direction: column;
  flex-shrink: 0;
  gap: 4px;
  width: 216px;
`,Wt=n.div`
  align-self: stretch;
  color: #fff;
  font-size: 14px;
  font-style: normal;
  font-weight: 500;
  letter-spacing: 0.14px;
  line-height: 20px;
`,Ft=n.div`
  align-self: stretch;
  color: #afb9c8;
  font-size: 12px;
  font-style: normal;
  font-weight: 400;
  letter-spacing: 0.12px;
  line-height: 16px;
`;var $n=({isLocked:t})=>{let{autoSpeedUp:o,playbackSpeed:i}=W(),s=(0,Re.useMemo)(()=>{if(t)return"You reached your speed limit";let c=(i||1.1)*200;return`Adds 10 wpm every ${(je(i||1.1)/c).toFixed(0)} minutes`},[t,i]),r=(0,Re.useCallback)(()=>ct(!o),[o]);return e(_t,null,e($t,null,e(Wt,null,"Increase speed automatically"),e(Ft,null,s)),e(Nt,{checked:!!o},e(Ct,{"aria-label":oe("AUTOMATIC_PLAYBACK_SPEED_UP_SWITCH"),"data-testid":G.AUTOMATIC_PLAYBACK_SPEED_UP_SWITCH,checked:o,disabled:t,onChange:r})))},Ot=$n;a();l();a();l();function zt(t){return Math.round(t*200)}a();l();var jt=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",width:"16",height:"16",viewBox:"0 0 16 16",fill:"none"},e("g",{"clip-path":"url(#clip0_20322_3343)"},e("rect",{width:"16",height:"16",rx:"8",fill:"#1E1E1E"}),e("circle",{cx:"8.00006",cy:"8.00006",r:"6.02545",fill:"#1E1E1E"}),e("path",{d:"M7.2 5.5V7H8.8V5.5C8.8 5.05817 8.44183 4.7 8 4.7C7.55817 4.7 7.2 5.05817 7.2 5.5Z",fill:"#AFB9C8"}),e("path",{"fill-rule":"evenodd","clip-rule":"evenodd",d:"M8 16C12.4183 16 16 12.4183 16 8C16 3.58172 12.4183 0 8 0C3.58172 0 0 3.58172 0 8C0 12.4183 3.58172 16 8 16ZM5.7 7H6V5.5C6 4.39543 6.89543 3.5 8 3.5C9.10457 3.5 10 4.39543 10 5.5V7H10.3C10.9627 7 11.5 7.53726 11.5 8.2V10.7371C11.5 11.3999 10.9627 11.9371 10.3 11.9371H5.7C5.03726 11.9371 4.5 11.3999 4.5 10.7371V8.2C4.5 7.53726 5.03726 7 5.7 7Z",fill:"#AFB9C8"})),e("defs",null,e("clipPath",{id:"clip0_20322_3343"},e("rect",{width:"16",height:"16",rx:"8",fill:"white"})))),Gt=()=>e("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg"},e("g",{id:"icons/20"},e("path",{id:"Vector",d:"M9 9H3C2.44772 9 2 9.44772 2 10C2 10.5523 2.44772 11 3 11H9H11H17C17.5523 11 18 10.5523 18 10C18 9.44772 17.5523 9 17 9H11H9Z",fill:"#AFB9C8"}))),Zt=()=>e("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg"},e("g",{id:"icons/20"},e("path",{id:"Vector","fill-rule":"evenodd","clip-rule":"evenodd",d:"M11 3C11 2.44772 10.5523 2 10 2C9.44772 2 9 2.44772 9 3V9H3C2.44772 9 2 9.44772 2 10C2 10.5523 2.44772 11 3 11H9V17C9 17.5523 9.44772 18 10 18C10.5523 18 11 17.5523 11 17V11H17C17.5523 11 18 10.5523 18 10C18 9.44772 17.5523 9 17 9H11V3Z",fill:"#AFB9C8"}))),qt=()=>e("svg",{width:"21",height:"20",viewBox:"0 0 21 20",fill:"none",xmlns:"http://www.w3.org/2000/svg"},e("g",null,e("path",{id:"Vector",d:"M14.3717 5.87813L15.5717 7.07813L11.505 11.1448L8.76336 8.40313C8.43836 8.07813 7.91336 8.07813 7.58836 8.40313L2.58835 13.4115C2.26335 13.7365 2.26335 14.2615 2.58835 14.5865C2.91335 14.9115 3.43835 14.9115 3.76335 14.5865L8.17169 10.1698L10.9134 12.9115C11.2384 13.2365 11.7634 13.2365 12.0884 12.9115L16.7467 8.26147L17.9467 9.46147C18.205 9.7198 18.655 9.53647 18.655 9.1698V5.58647C18.6634 5.35313 18.48 5.1698 18.2467 5.1698H14.6717C14.2967 5.1698 14.1134 5.6198 14.3717 5.87813Z",fill:"#30D158"})));a();l();var Yt=n.div`
  align-items: center;
  display: flex;
  flex-direction: column;
  gap: 12px;
`,Kt=n.div`
  display: flex;
  align-items: center;
  align-self: stretch;
  flex-direction: column;
  gap: 32px;
  justify-content: center;
  padding: 24px 20px;
`,qe=n.button`
  align-items: flex-start;
  background: ${({disabled:t})=>t?"#828282":"#111112"};
  border: none;
  border-radius: 8px;
  cursor: ${({disabled:t})=>t?"not-allowed":"pointer"};
  display: flex;
  gap: 0px;
  opacity: ${({disabled:t})=>t?.3:1};
  padding: 8px;

  &:hover {
    background: ${({disabled:t})=>t?"#828282":"transparent"};
  }
`,Xt=n.div`
  align-items: center;
  display: flex;
  gap: 16px;
  justify-content: center;
`,Jt=n.div`
  color: #fff;
  font-size: 24px;
  font-style: normal;
  font-weight: 700;
  line-height: 32px;
  text-align: center;
  width: 80px;
`,Qt=n.div`
  align-self: stretch;
  color: #afb9c8;
  font-size: 12px;
  font-style: normal;
  font-weight: 400;
  letter-spacing: 0.12px;
  line-height: 16px;
  text-align: center;
`,Ht=n.div`
  align-items: center;
  align-self: stretch;
  display: flex;
  gap: 4px;
  justify-content: center;
`,eo=n.div`
  display: flex;
  align-items: center;
  align-self: stretch;
  flex-direction: column;
  gap: 4px;
`,to=n.div`
  align-items: center;
  background: #1e5028;
  border-radius: 4px;
  color: #30d158;
  display: flex;
  font-size: 12px;
  font-style: normal;
  font-weight: 400;
  gap: 4px;
  justify-content: center;
  letter-spacing: 0.12px;
  line-height: 16px;
  padding: 2px 8px;
  text-align: center;
`,oo=n.div`
  height: 24px;
`,no=n.div`
  align-items: center;
  align-self: stretch;
  color: #fff;
  display: flex;
  font-size: 18px;
  font-style: normal;
  font-weight: 700;
  gap: 4px;
  justify-content: center;
  letter-spacing: 0.16px;
  line-height: 24px;
  text-align: center;
`,io=n.div`
  align-items: flex-start;
  align-self: stretch;
  color: #afb9c8;
  display: flex;
  flex: 1 0 0;
  font-size: 12px;
  font-style: normal;
  font-weight: 400;
  justify-content: center;
  letter-spacing: 0.12px;
  line-height: 16px;
  text-align: center;
`;var Wn=(t,o)=>{let i=(o-t)/t*100;return i>=0?Math.round(i):0},Fn=t=>{let o={Slow:[.4,1],Normal:[1,1.5],Fast:[1.5,3],"Speed Reader":[3,4.6]};for(let[i,[s,r]]of Object.entries(o))if(t>=s&&t<r)return i;return"Invalid Speed"},Un=({baseWPM:t,maxPlaybackSpeed:o,minPlaybackSpeed:i,onDecrement:s,onIncrement:r,playbackSpeed:c})=>{let d=te.useTime(),u=d.isLoading===!0?0:d.totalEstimatedDuration,C=ot("short")(u),p=zt(c),x=Wn(t,p);return e(Kt,null,e(eo,null,e(no,null,Fn(c)),e(Qt,null,"Duration: ~",C)),e(Yt,null,x>0?e(to,null,e(qt,null),x,"% productivity boost"):e(oo,null),e(Xt,null,e(qe,{disabled:c===i,onClick:s},e(Gt,null)),e(Jt,{"data-testid":G.PLAYBACK_SPEED_PANEL_SPEED_VALUE},c.toFixed(1),"x"),e(qe,{disabled:c===o,onClick:r},e(Zt,null))),e(io,null,p," words per minute")),e(Ht,null))},ro=Un;a();l();var T=w(V());a();l();var Te=w(V());a();l();var bo=w(V());a();l();var Ee=w(V());var so=n.div`
  align-items: center;
  display: flex;
  justify-content: center;
  width: 348px;
`,lo=n.div`
  align-items: flex-start;
  background: #1e1e1e;
  display: flex;
  flex-direction: column;
  width: 348px;
`,ao=({children:t,enabled:o=!0,text:i,showOnRight:s=!1,visible:r=!0,...c})=>{let{onMouseEnter:d,onMouseLeave:u,showTooltip:C}=xt(),[p,x]=(0,Ee.useState)(!1),f=()=>x(!0);return(0,Ee.useEffect)(()=>{p&&setTimeout(()=>{x(!1)},500)},[p]),e(zn,{onClick:f,onMouseLeave:u,onMouseEnter:d,...c,visible:r},C&&!p&&i&&o&&e(On,{showOnRight:s},i),t)},On=n.div`
  background: #fff;
  border-radius: 6px;
  box-shadow: 0px 4px 6px 0px rgba(0, 0, 0, 0.32);
  color: #1e1e1e;
  font-size: 12px;
  ${({showOnRight:t=!1})=>t?"left: 50px;":"right: 48px"};
  line-height: 16px;
  padding: 4px 8px;
  position: absolute;
  text-align: center;
  top: 20%;
  width: max-content;
  max-width: 200px;
`,zn=n.div`
  position: relative;
  opacity: ${({visible:t})=>t?1:0};
  ${({visible:t})=>!t&&"pointer-events: none;"}
  transition: opacity 0.15s ease-in-out;
`;a();l();var co=n.div`
  align-items: center;
  display: flex;
  flex-direction: column;
  gap: 2px;
  justify-content: center;
  padding: 20px;
`,po=n.div`
  align-items: center;
  cursor: pointer;
  display: flex;
  inset: 0;
  justify-content: center;
  pointer-events: none;
  position: absolute;
`,mo=n.div`
  border-radius: 6px;
  cursor: pointer;
  gap: 2px;
  height: 270px;
  position: relative;
  width: 44px;

  &:focus {
    outline: none;
  }
`,uo=n.div`
  background: ${({autoSpeedUp:t})=>t?"radial-gradient(263.4% 263.4% at -38.15% -15%, #ea6aff 22.4%, #6b78fc 66.49%)":"#6b78fc"};
  border-radius: 8px;
  bottom: 0px;
  height: ${({clampedPercent:t})=>t}%;
  padding: 4px;
  pointer-events: none;
  position: absolute;
  width: 36px;
`,fo=n.div`
  background-color: ${R.icnTxtWhite};
  border-radius: 3px;
  cursor: grab;
  padding-bottom: 3px;
  padding-top: 3px;
`,go=n.div`
  align-items: center;
  background-color: ${({isLocked:t})=>t?"#373737":"#111112"};
  display: flex;
  flex-direction: column-reverse;
  flex-grow: 1;
  height: 54px;
  justify-content: space-between;
  margin-bottom: 8px;
  padding: 4px 8px;
  position: relative;
`,xo=n.div`
  align-items: center;
  cursor: ${({isLocked:t})=>t?"not-allowed":"pointer"};
  display: flex;
  height: 6px;
  justify-content: center;
  position: relative;
  width: 100%;
`,ho=n.div`
  background-color: ${({isLocked:t})=>t?"#8791A0":"#373737"};
  border-radius: 9999px;
  height: 2px;
  opacity: ${({isLocked:t})=>t?.5:1};
  width: ${({stepIndex:t})=>t===3?"28px":"18px"};

  ${({disableHover:t,isLocked:o})=>!o&&!t&&`
    &:hover {
      background-color: #5f9bf0;
    }
  `}
`;var jn=bo.default.memo(({steps:t,isLocked:o,style:i})=>e(ao,{text:"Upgrade to Premium to listen faster than 300WPM",enabled:o},e(go,{isLocked:o,style:i},t.map((s,r)=>e(xo,{"aria-label":`Set speed to ${s} words per minute`,isLocked:o,key:`speed-picker-step-${s}`},e(ho,{stepIndex:r,isLocked:o}))),o&&e(po,null,e(jt,null))))),Co=jn;var Gn=(t,o)=>{let i=(o-t)/10;return Array.from({length:8},(s,r)=>Math.round((t+i*(r+1))*100)/100)},Zn=Te.default.memo(({isLocked:t,sectionRanges:o})=>{let i=(0,Te.useMemo)(()=>o.map(s=>Gn(s.min,s.max)),[o]);return e("div",{style:{display:"flex",flexDirection:"column-reverse",height:"100%",gap:"-2px",position:"relative"}},i.map((s,r)=>e(Co,{key:`speed-picker-section-${r}`,isLocked:t&&r>=2,steps:s,style:{borderTopLeftRadius:r===i.length-1?"8px":"0",borderTopRightRadius:r===i.length-1?"8px":"0",borderBottomLeftRadius:r===0?"8px":"0",borderBottomRightRadius:r===0?"8px":"0"}})))}),yo=Zn;var N=[{min:.5,max:1},{min:1,max:1.5},{min:1.5,max:3},{min:3,max:4.5}],qn=t=>{let o=N.find(u=>t>=u.min&&t<=u.max);if(!o)return t<=N[0].min?0:100;let{min:i,max:s}=o,r=N.indexOf(o),c=100/N.length*r,d=(t-i)/(s-i)*(100/N.length);return c+d},Yn=(t,o)=>{let i=t.length,s=100/i,r=Y(0,i-1,Math.floor(o/s));if(r===i-1){let{min:C,max:p}=t[r];return C+(o-s*(i-1))/s*(p-C)}let{min:c,max:d}=t[r],u=o%s;return c+u/s*(d-c)},Kn=({isLocked:t=!1,onLockedInteraction:o=()=>{},onMouseMove:i,onPlaybackSpeedChange:s,playbackSpeed:r})=>{let{autoSpeedUp:c}=W(),d=(0,T.useRef)(!1),u=(0,T.useRef)(null),C=(0,T.useRef)(null),p=(0,T.useMemo)(()=>qn(r),[r]),x=(0,T.useMemo)(()=>Y(6,t?50:100,p),[t,p]);(0,T.useLayoutEffect)(()=>{u.current&&(C.current=u.current.getBoundingClientRect())},[]);let f=(0,T.useCallback)(S=>{if(C.current){let E=C.current.height,j=S-C.current.top,Q=Y(0,100,(E-j)/E*100),k=N.length,P=Y(0,k-1,Math.floor(Q/(100/k)));if(t&&P>=k-2){o();return}let _=Yn(N,Q),ce=Math.round(_*40)/40;d.current?i?.(ce):s(ce)}},[t,o,i]),y=(0,T.useCallback)(S=>{d.current&&f(S)},[f]);(0,T.useEffect)(()=>{let S=j=>{y(j.clientY)},E=()=>{d.current=!1};return window.addEventListener("pointermove",S,{passive:!0}),window.addEventListener("pointerup",E,{passive:!0}),()=>{window.removeEventListener("pointermove",S),window.removeEventListener("pointerup",E)}},[y]);let m=(0,T.useCallback)(S=>{S.preventDefault(),S.stopPropagation(),d.current=!0,u.current?.setPointerCapture(S.pointerId)},[]),v=(0,T.useCallback)(S=>{d.current=!1,u.current?.releasePointerCapture(S.pointerId),f(S.clientY)},[r]);return e(co,null,e(mo,{"aria-label":"Playback Speed","aria-valuenow":r,"aria-valuemin":N[0].min,"aria-valuemax":N[N.length-1].max,onPointerDown:m,onPointerUp:v,ref:u,role:"slider",tabIndex:0},e(yo,{isLocked:t,sectionRanges:N}),e(uo,{autoSpeedUp:!!c,clampedPercent:x},e(fo,{autoSpeedUp:!!c}))))},vo=Kn;a();l();var ye=w(V());var So=t=>{let o=(0,ye.useRef)(void 0);(0,ye.useEffect)(()=>{(async()=>{let{playbackSpeed:s}=await fe("/user-settings/get");o.current=s,t(s)})()},[]),(0,ye.useEffect)(()=>{let i=rt.on("update",s=>{s.playbackSpeed!==o.current&&(t(s.playbackSpeed),o.current=s.playbackSpeed)});return()=>{i()}},[])};var wo=.5,Jn=4.5,Qn=1e3,Hn=()=>{let[t,o]=(0,B.useState)(1);So(o);let i=Le(),s=(0,B.useRef)(Date.now()),r=(0,B.useMemo)(()=>i&&Pt(i)&&i.status!=="expired"?Jn:ue,[i]),c=(0,B.useMemo)(()=>t>=r,[t,r]),d=(0,B.useCallback)(y=>{let m=Y(wo,r,y);Ve(m,r),o(m)},[r]),u=()=>{Pe("speed_picker","increased_listening_speeds")},C=(0,B.useCallback)(y=>{o(y);let m=Date.now();m-s.current>Qn&&(s.current=m,d(y))},[d]),p=(0,B.useCallback)(y=>{d(y)},[d]),x=(0,B.useCallback)(()=>d(t-.1),[t,d]),f=(0,B.useCallback)(()=>d(t+.1),[t,d]);return e(g,null,e(lo,null,e(so,null,e(ro,{baseWPM:200,maxPlaybackSpeed:r,minPlaybackSpeed:wo,onDecrement:x,onIncrement:f,playbackSpeed:t}),e(vo,{isLocked:r===ue,onLockedInteraction:u,onMouseMove:C,onPlaybackSpeedChange:p,playbackSpeed:t}))),e(Ot,{isLocked:c}))},Vo=Hn;a();l();var Po=w(V());var ei=n(D)`
  width: 100%;
  padding: 32px;
  box-sizing: border-box;
`,Lo=()=>{let{state:t}=te.usePlayingState();return(0,Po.useEffect)(()=>{["playing","buffering"].includes(t)&&(Ro(!1),ko(!0))},[t]),e(ei,{column:!0,xAlign:!0,separation:"32px"},e(xe,{align:!0},"This website is unsupported"))};a();l();Sn();a();l();var L=w(V());a();l();var Eo=t=>e(F,{xmlns:"http://www.w3.org/2000/svg",width:"140",height:"140",viewBox:"0 0 140 140",fill:"none",...t},e("g",{"clip-path":"url(#clip0_20620_4093)"},e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M0.90002 42.9138C1.97944 27.1559 2.51915 19.2769 10.9755 10.8414C19.4318 2.40579 27.252 1.88942 42.8922 0.856688C50.7115 0.340376 59.7525 0 70 0C80.2475 0 89.2885 0.340376 97.1078 0.856687C112.748 1.88942 120.568 2.40579 129.025 10.8414C137.481 19.2769 138.021 27.1559 139.1 42.9138C139.64 50.8046 140 59.863 140 70C140 79.5518 139.681 88.1461 139.192 95.7081C138.122 112.252 137.587 120.524 129.134 128.997C120.682 137.471 112.352 138.03 95.6931 139.149C88.0563 139.662 79.4427 140 70 140C60.5573 140 51.9437 139.662 44.3069 139.149C27.648 138.03 19.3185 137.471 10.8658 128.997C2.41318 120.524 1.87821 112.252 0.808262 95.7081C0.319199 88.1461 0 79.5518 0 70C0 59.863 0.359505 50.8045 0.90002 42.9138Z",fill:"#141414"}),e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M67.6001 70.3414C77.8396 78.8464 93.035 77.4405 101.54 67.201C110.045 56.9615 108.639 41.7661 98.3998 33.261C88.1603 24.7559 72.9649 26.1619 64.4598 36.4014C55.9547 46.6408 57.3607 61.8363 67.6001 70.3414ZM63.1644 75.6816C76.3532 86.6364 95.9255 84.8255 106.88 71.6367C117.835 58.4479 116.024 38.8756 102.835 27.9208C89.6467 16.9659 70.0744 18.7769 59.1196 31.9657C48.1647 45.1544 49.9757 64.7267 63.1644 75.6816Z",fill:"url(#paint0_linear_20620_4093)"}),e("path",{d:"M57.1882 74.6823C58.4356 73.3007 60.5506 73.149 61.9824 74.3383L64.7227 76.6144C66.1459 77.7966 66.3918 79.8873 65.2816 81.3673L43.2707 110.712C40.896 113.878 36.3551 114.412 33.3108 111.883C30.284 109.369 29.9591 104.84 32.596 101.92L57.1882 74.6823Z",fill:"url(#paint1_linear_20620_4093)"}),e("path",{d:"M72.9727 41.7734L93.0266 61.8275",stroke:"#424242",strokeWidth:"5.78512",strokeLinecap:"round"}),e("path",{d:"M93.0264 41.7734L72.9725 61.8275",stroke:"#424242",strokeWidth:"5.78512",strokeLinecap:"round"})),e("defs",null,e("linearGradient",{id:"paint0_linear_20620_4093",x1:"54.3173",y1:"130.642",x2:"55.8542",y2:"-9.54324",gradientUnits:"userSpaceOnUse"},e("stop",{offset:"0.202777",stopColor:"#353535"}),e("stop",{offset:"0.602023",stopColor:"#474747"})),e("linearGradient",{id:"paint1_linear_20620_4093",x1:"15.1331",y1:"144.154",x2:"-8.83031",y2:"101.947",gradientUnits:"userSpaceOnUse"},e("stop",{offset:"0.202777",stopColor:"#353535"}),e("stop",{offset:"0.602023",stopColor:"#474747"})),e("clipPath",{id:"clip0_20620_4093"},e("rect",{width:"140",height:"140",fill:"white"}))));a();l();var Io=w(V());a();l();a();l();var Ie=t=>e(F,{width:"22",height:"22",viewBox:"0 0 22 22",fill:"none",xmlns:"http://www.w3.org/2000/svg",...t},e("path",{d:"M11 21.0371C16.5176 21.0371 21.0879 16.4766 21.0879 10.9492C21.0879 5.43164 16.5176 0.861328 10.9902 0.861328C5.47266 0.861328 0.912109 5.43164 0.912109 10.9492C0.912109 16.4766 5.48242 21.0371 11 21.0371ZM9.91602 15.7734C9.54492 15.7734 9.24219 15.6074 8.96875 15.2559L6.57617 12.3457C6.40039 12.1309 6.3125 11.8965 6.3125 11.6523C6.3125 11.1543 6.70312 10.7441 7.21094 10.7441C7.51367 10.7441 7.74805 10.8613 7.99219 11.1738L9.87695 13.5664L13.9199 7.10156C14.125 6.75977 14.3984 6.59375 14.7109 6.59375C15.1992 6.59375 15.6387 6.93555 15.6387 7.44336C15.6387 7.66797 15.5215 7.91211 15.3848 8.12695L10.8145 15.2559C10.5898 15.5879 10.2773 15.7734 9.91602 15.7734Z",fill:"currentColor"}));a();l();var ie=t=>e(F,{xmlns:"http://www.w3.org/2000/svg",width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",...t},e("g",{"clip-path":"url(#clip0_20617_6525)"},e("rect",{width:"16",height:"16",rx:"8",fill:"#1E1E1E"}),e("circle",{cx:"8.00006",cy:"8.00006",r:"6.02545",fill:"#1E1E1E"}),e("path",{d:"M7.2 5.5V7H8.8V5.5C8.8 5.05817 8.44183 4.7 8 4.7C7.55817 4.7 7.2 5.05817 7.2 5.5Z",fill:"#AFB9C8"}),e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M8 16C12.4183 16 16 12.4183 16 8C16 3.58172 12.4183 0 8 0C3.58172 0 0 3.58172 0 8C0 12.4183 3.58172 16 8 16ZM5.7 7H6V5.5C6 4.39543 6.89543 3.5 8 3.5C9.10457 3.5 10 4.39543 10 5.5V7H10.3C10.9627 7 11.5 7.53726 11.5 8.2V10.7371C11.5 11.3999 10.9627 11.9371 10.3 11.9371H5.7C5.03726 11.9371 4.5 11.3999 4.5 10.7371V8.2C4.5 7.53726 5.03726 7 5.7 7Z",fill:"#AFB9C8"})),e("defs",null,e("clipPath",{id:"clip0_20617_6525"},e("rect",{width:"16",height:"16",rx:"8",fill:"white"}))));a();l();var ti=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",width:"40",height:"40",viewBox:"0 0 40 40",fill:"none"},e("g",{"clip-path":"url(#clip0_2615_4266)"},e("circle",{cx:"20",cy:"20",r:"20",fill:"#36373A",fillOpacity:"0.8"}),e("path",{d:"M14 13.9C14 13.1268 14.6268 12.5 15.4 12.5H17.1C17.8732 12.5 18.5 13.1268 18.5 13.9V26.1C18.5 26.8732 17.8732 27.5 17.1 27.5H15.4C14.6268 27.5 14 26.8732 14 26.1V13.9Z",fill:"white"}),e("path",{d:"M21.5 13.9C21.5 13.1268 22.1268 12.5 22.9 12.5H24.6C25.3732 12.5 26 13.1268 26 13.9V26.1C26 26.8732 25.3732 27.5 24.6 27.5H22.9C22.1268 27.5 21.5 26.8732 21.5 26.1V13.9Z",fill:"white"})),e("defs",null,e("clipPath",{id:"clip0_2615_4266"},e("rect",{width:"40",height:"40",fill:"white"})))),Me=ti;a();l();var oi=n.div`
  position: relative;
  display: inline-block;
  pointer-events: auto;

  span {
    ${({down:t})=>t?"top: 110%":"bottom: 130%"};
    ${({right:t})=>t?"left: 100%; margin-left: -20px;":"left: 154%; margin-left: -87px;"};
    background-color: #fff;
    border-radius: 6px;
    color: #1e1e1e;
    font-size: 12px;
    line-height: 16px;
    opacity: 1;
    padding: 6px 8px;
    position: absolute;
    text-align: center;
    visibility: hidden;
    width: 133px;
    z-index: 21;

    &:after {
      content: '';
      position: absolute;
      ${({down:t})=>t?"bottom: 100%":"top: 100%"};
      ${({right:t})=>t?"left: 5%;":"left: 50%; margin-left: -9px;"};
      border-width: 5px;
      border-style: solid;
      ${({down:t,right:o})=>t?"border-color: transparent transparent #fff transparent;":"border-color: #fff transparent transparent transparent;"};
    }
  }

  :hover span {
    visibility: visible;
  }
`,re=({title:t,tooltipText:o,down:i=!1,right:s=!1,style:r})=>e(oi,{down:i,right:s,onClick:c=>c.preventDefault(),style:r},t,e("span",null,o));var ni=n.div`
  background-color: #373737;
  border-radius: 50%;
  color: #6b78fc;
  height: 24px;
  margin: 10px 0 0 100px;
  position: absolute;
  width: 24px;
`,ii=n.div`
  align-items: flex-start;
  background-color: #373737;
  border-radius: 100px;
  border: 1px solid #373737;
  display: flex;
  gap: 10px;
`,ri=n.div`
  align-items: center;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  justify-content: center;
`,Ae=n.div`
  align-self: stretch;
  font-size: 12px;
  font-style: normal;
  font-weight: 400;
  letter-spacing: 0.12px;
  line-height: 16px;
  text-align: center;
  white-space: nowrap;
`,si=n.div`
  display: flex;
  align-self: stretch;
  color: #fff;
  flex-direction: column;
  font-size: 14px;
  font-style: normal;
  font-weight: 500;
  height: 16px;
  justify-content: center;
  letter-spacing: 0.14px;
  line-height: 20px;
  text-align: center;
`,li=n.div`
  height: 40px;
  margin: 1px;
  padding: 0;
  position: absolute;
  width: 40px;
`,ai=t=>t.replace("Microsoft","").trim(),To=({checked:t,isPremiumVoiceDisabled:o,isPreviewPlaying:i,item:s})=>{let r=M(s),c=()=>{if(r){if(r.personal)return e(di,null,"Custom");if(r.labels?.includes("ai-enhanced"))return e(ci,null,"AI Enhanced");if(r.labels?.includes("celebrity"))return e(pi,null,"Celebrity");if(r.labels?.includes("label:partner"))return e(Ye,null,"Official Partner");if(r.labels?.includes("label:narrator"))return e(Ye,null,"Narrator");if(r.labels?.includes("label:founder"))return e(Ye,null,"Founder")}};return e(g,null,e(ii,null,e(U,{alt:"",width:"40px",height:"40px",flag:r?.avatarImage??"US.svg",variant:"circle"}),r?.premium&&o&&e(re,{style:{pointerEvents:"auto",marginLeft:"30px",marginTop:"26px",position:"absolute"},title:e(ie,null),tooltipText:"Upgrade to Premium to access this voice"})),e(ri,null,e(si,null,ai(r?.displayName??r?.name??"...")),c()),t&&e(ni,null,e(Ie,null)),t&&i&&e(li,null,e(Me,null)))},ci=n(Ae)`
  color: ${R.icnTxtSuccess};
`,pi=n(Ae)`
  color: ${R.icnTxtAlert};
`,di=n(Ae)`
  color: ${()=>R.icnTxtBlue};
`,Ye=n(Ae)`
  color: ${()=>R.icnTxtSec};
`;var Mo=n.div`
  align-content: center;
  align-items: center;
  align-self: stretch;
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  justify-content: center;
  padding: 6px 12px 0 12px;
`,mi=n.div`
  align-items: center;
  background-color: ${({checked:t})=>t?"#283750":"#1e1e1e"};
  border-radius: 12px;
  border: ${({checked:t})=>t?"0.5px solid #6B78FC":"0.5px solid #373737"};
  cursor: pointer;
  display: flex;
  flex-direction: column;
  flex: 1 0 0;
  gap: 6px;
  min-width: 138px;
  outline: ${({checked:t})=>t?"1px solid #6B78FC":"none"};
  padding: 8px 4px;
  position: relative;

  &:hover {
    background-color: ${({checked:t})=>t?"#283750":"#2E2E2E"};
    border-color: ${({checked:t})=>t?"#6B78FC":"#505050"};
  }

  &::after {
    content: '';
    position: absolute;
    left: 10px;
    bottom: 2px;
    height: 2px;
    background-color: #8894fe;
    width: ${({previewPercentagePlayed:t})=>t!==null?`calc(${t}% - ${t/100*15}px)`:"0%"};
    border-radius: 2px;
    transition: width 0.3s ease-in-out;
    display: ${({previewPercentagePlayed:t})=>t!==null&&t>0?"block":"none"};
  }
`,Ao=({checked:t,idx:o,item:i,isPremiumVoicesDisabled:s,isPreviewPlaying:r,onClick:c,previewPercentagePlayed:d})=>{let u=(0,Io.useMemo)(()=>M(i),[i]),C=()=>{c(i)};return e(mi,{"aria-selected":t,checked:!!t,isPremiumVoiceDisabled:!!(s&&u?.premium),onClick:C,previewPercentagePlayed:r?d:null},e(To,{checked:!!t,idx:o,isPreviewPlaying:r,item:i,isPremiumVoiceDisabled:!!(s&&u?.premium)}))};a();l();var De=w(V());a();l();var Z=`
  &::-webkit-scrollbar {
    width: 6px;
  }

  &::-webkit-scrollbar-track {
    border-radius: 4px;
    background-color: transparent;
  }

  &::-webkit-scrollbar-thumb {
    border-radius: 4px;
    background-color: #8791a0;
  }

  &::-webkit-scrollbar-button {
    display: none;
  }
`;a();l();var ui=n.div`
  align-items: flex-start;
  background-color: #373737;
  border-radius: 100px;
  display: flex;
  gap: 10px;
`,fi=n.div`
  align-items: center;
  border-bottom: 0.5px solid #373737;
  display: flex;
  flex: 1 0 0;
  gap: 8px;
  margin-right: 4px;
  padding: 12px 12px 12px 0px;
`,gi=n.div`
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  flex: 1 0 0;
`,xi=n.div`
  align-items: flex-start;
  align-self: stretch;
  display: flex;
  gap: 4px;
  max-width: 184px;
`,hi=n.div`
  color: #fff;
  font-size: 14px;
  font-style: normal;
  font-weight: 500;
  letter-spacing: 0.14px;
  line-height: 20px;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
`,bi=n.div`
  align-items: center;
  align-self: stretch;
  color: #afb9c8;
  display: flex;
  font-size: 14px;
  font-style: normal;
  font-weight: 400;
  letter-spacing: 0.14px;
  line-height: 20px;
`,Ci=n.div`
  align-items: flex-start;
  border-radius: 0px;
  display: flex;
  gap: 0px;
  padding: 0px;
  width: 20px;
`,Ke=n.div`
  align-items: flex-start;
  background: #1e1e1e;
  border-radius: 4px;
  color: #6b78fc;
  display: flex;
  font-size: 12px;
  font-style: normal;
  font-weight: 400;
  gap: 2px;
  letter-spacing: 0.12px;
  line-height: 16px;
  padding: 2px 4px;
`,yi=n.div`
  border-radius: 50%;
  height: 40px;
  margin: 0;
  position: absolute;
  width: 40px;
`,vi=n(Ke)`
  background-color: ${({isSelected:t})=>t?"#1e1e1e":R.bgSuccess};
  color: ${R.icnTxtSuccess};
`,Si=n(Ke)`
  background-color: ${({isSelected:t})=>t?"#1e1e1e":"#5A4015"};
  color: ${R.icnTxtAlert};
`,wi=n(Ke)`
  background-color: ${({isSelected:t})=>t?"#1E1E1E":"#1F2C3E"};
  color: #6b78fc;
`,Do=t=>t.replace("Microsoft","").trim(),Bo=({checked:t,isPremiumVoiceDisabled:o,isPreviewPlaying:i,item:s})=>{let r=s?.language?.split("-")[1]??"US",c=M(s),d=()=>{if(c){if(c.personal)return e(wi,{isSelected:t},"Custom");if(c.labels?.includes("ai-enhanced"))return e(vi,{isSelected:t},"AI Enhanced");if(c.labels?.includes("celebrity"))return e(Si,{isSelected:t},"Celebrity")}};return e(g,null,e(ui,null,e(U,{alt:"",width:"40px",height:"40px",flag:c?.avatarImage??"US.svg",variant:"circle"})),c?.premium&&o&&e(re,{right:!0,down:!0,style:{pointerEvents:"auto",marginLeft:"30px",marginTop:"26px",position:"absolute"},title:e(ie,null),tooltipText:"Upgrade to Premium to access this voice"}),i&&e(yi,null,e(Me,null)),e(fi,null,e(gi,null,e(xi,null,e(hi,{"data-testid":G.VOICE_NAME_TEXT(Do(c?.displayName??c?.name??"")),"data-local-voice":s.engine===we},Do(c?.displayName??c?.name??"...")),d()),e(bi,null,r,c?.gender&&c.gender!=="notSpecified"&&` • ${ke(c.gender)}`)),e(Ci,null),t&&e(Ie,{style:{color:"#6B78FC"}})))};var _o=n(D)`
  overflow-y: scroll;
  margin: 0 3px 0 12px;
  position: relative;

  ${Z}
`,Vi=n.div`
  align-items: center;
  align-self: stretch;
  background: ${({checked:t})=>t?"#283750":"#1e1e1e"};
  border-radius: 6px;
  cursor: pointer;
  display: flex;
  gap: 0px;
  margin-right: 3px;
  opacity: ${({isFreeVoicesDisabled:t})=>t?.5:1};
  padding-left: 12px;

  &:hover {
    background: ${({checked:t})=>t?"#283750":"#2e2e2e"};
  }
`,Pi=n.div`
  align-items: center;
  display: flex;
  gap: 12px;
  position: relative;
  width: 328px;

  &::after {
    content: '';
    position: absolute;
    left: -11px;
    bottom: 1px;
    height: 3px;
    background-color: #8894fe;
    width: ${({previewPercentagePlayed:t})=>t!==null?`calc(${t}% + ${t/100*11}px)`:"0%"};
    border-radius: 2px;
    transition: width 0.3s ease-in-out;
    display: ${({previewPercentagePlayed:t})=>t!==null&&t>0?"block":"none"};
  }
`,Be=(0,De.forwardRef)(({checked:t,idx:o,item:i,isFreeVoicesDisabled:s,isPremiumVoicesDisabled:r,isPreviewPlaying:c,onClick:d,previewPercentagePlayed:u},C)=>{let p=(0,De.useMemo)(()=>M(i),[i]),x=()=>{d(i)};return e(Vi,{"aria-selected":t,checked:!!t,isFreeVoicesDisabled:!!s&&!p?.premium,isPremiumVoiceDisabled:!!(r&&p?.premium),onClick:x,ref:t?C:null,"data-testid":G.VOICE_LIST_ITEM(p?.displayName||p?.name||String(o))},e(Pi,{previewPercentagePlayed:c?u:null},e(Bo,{checked:!!t,idx:o,isPreviewPlaying:c,item:i,isPremiumVoiceDisabled:!!(r&&p?.premium)})))});a();l();var Fo=w(V());a();l();var $o=w(V());a();l();var No=t=>e(F,{xmlns:"http://www.w3.org/2000/svg",width:"14",height:"14",viewBox:"0 0 14 14",fill:"none",...t},e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M3.52654 2.59846C3.27026 2.34218 2.85474 2.34218 2.59846 2.59846C2.34218 2.85474 2.34218 3.27026 2.59846 3.52654L6.07192 7L2.59846 10.4735C2.34218 10.7297 2.34218 11.1453 2.59846 11.4015C2.85474 11.6578 3.27026 11.6578 3.52654 11.4015L7 7.92808L10.4735 11.4015C10.7297 11.6578 11.1453 11.6578 11.4015 11.4015C11.6578 11.1453 11.6578 10.7297 11.4015 10.4735L7.92808 7L11.4015 3.52654C11.6578 3.27026 11.6578 2.85474 11.4015 2.59846C11.1453 2.34218 10.7297 2.34218 10.4735 2.59846L7 6.07192L3.52654 2.59846Z",fill:"white"}));var Li=n.div`
  align-items: flex-start;
  background-color: #373737;
  border-radius: 100px;
  border: 1px solid #373737;
  display: flex;
  gap: 10px;
`,ki=n.div`
  align-items: center;
  align-self: stretch;
  display: flex;
  flex-direction: column;
`,Ri=n.div`
  color: #afb9c8;
  font-size: 12px;
  font-style: normal;
  font-weight: 400;
  letter-spacing: 0.12px;
  line-height: 16px;
  text-align: center;
`,Ei=n.div`
  align-self: stretch;
  color: #fff;
  font-size: 14px;
  font-style: normal;
  font-weight: 500;
  letter-spacing: 0.14px;
  line-height: 20px;
  text-align: center;
`,Ti=n(No)`
  align-items: center;
  background: #8791a0;
  border-radius: 100px;
  display: flex;
  cursor: pointer;
  flex-direction: column;
  gap: 10px;
  margin: -4px 0 0 30px;
  opacity: 0;
  padding: 2px;
  position: absolute;
  transition: opacity 0.2s ease-in-out;
`,Ii=t=>t.replace("Microsoft","").trim(),Wo=({isPremiumVoiceDisabled:t,item:o,onRemove:i})=>{let[s,r]=(0,$o.useState)(!1),c=o?.language?.split("-")[1]??"US",d=M(o),u=(d?.displayName??d?.name??"...").split(" ")[0],C=p=>{p.stopPropagation(),i()};return e(g,null,e(Li,{onMouseEnter:()=>r(!0),onMouseLeave:()=>r(!1)},e(U,{alt:"",width:"40px",height:"40px",flag:d?.avatarImage??"US.svg",variant:"circle"}),e(Ti,{onClick:C,style:{opacity:s?1:0}}),d?.premium&&t&&e(re,{style:{pointerEvents:"auto",marginLeft:"30px",marginTop:"26px",position:"absolute"},title:e(ie,null),tooltipText:"Upgrade to Premium to access this voice"})),e(ki,null,e(Ei,null,Ii(u)),e(Ri,null,c)))};var Uo=n.div`
  align-content: flex-start;
  align-items: flex-start;
  align-self: stretch;
  display: flex;
  flex-wrap: wrap;
  gap: 24px 4px;
  height: 330px;
  padding: 14px 4px;
  overflow: auto;

  ${Z}
`,Mi=n.div`
  align-items: center;
  display: flex;
  flex-direction: column;
  flex: 1 0 0;
  gap: 4px;
  max-width: 80px;
  min-width: 80px;
`,Oo=({idx:t,item:o,isPremiumVoicesDisabled:i,onClick:s,onRemove:r})=>{let c=(0,Fo.useMemo)(()=>M(o),[o]),d=()=>{r(o)};return e(Mi,{onClick:()=>{s(o)}},e(Wo,{idx:t,item:o,isPremiumVoiceDisabled:!!(i&&c?.premium),onRemove:d}))};a();l();a();l();var z=w(V());var zo=w(wn());function Ai(t){return(o,...i)=>o.key==="Enter"&&t(o,...i)}var Di=n.div`
  display: flex;
  align-items: center;
  width: 255px;

  > div {
    align-items: flex-start;
    border-radius: 8px;
    border: 1.5px solid #6b78fc;
    display: flex;
    flex-direction: column;
    flex: 1 0 0;
    gap: 8px;
    position: relative;
  }

  input {
    background: url('${b.runtime.getURL("/images/search-icon.svg")}') no-repeat scroll 9px 9px;
    background-position: 10px center;
    background-size: 16px;
    border: none;
    box-sizing: border-box;
    color: #fff;
    font-size: 14px;
    font-weight: 400;
    line-height: 20px;
    outline: none;
    padding: 6px 26px 6px 40px;
    width: 100%;

    &::placeholder {
      color: #8791a0;
      font-size: 14px;
      font-weight: 400;
      line-height: 20px;
    }
  }

  > div > div:empty {
    display: none;
  }

  > div > div {
    position: absolute;
    left: 0;
    right: 0;
    top: calc(100% - 5px);
    background: ${R.bgPrimWB};
    z-index: 5000;
    border: none;
    border-top: none;
    max-height: 400px;
    overflow-y: auto;
    box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.05);
    border-radius: 0px 0px 5px 5px;

    max-height: ${({suggestionsMaxHeight:t})=>t};
    overflow-y: auto;

    ${Z}

    > ul {
      list-style-type: none;
      padding: 0;
      margin: 0;
    }

    > ul > li {
      padding: 0;
      > button {
        background: ${R.bgPrimWB};
        color: ${R.icnTxtPrim};

        padding: 12px 28px;
        border: none;
        margin: none;
        outline: none;

        text-align: left;
        cursor: pointer;
        width: 100%;
      }

      &:hover > button,
      &:focus > button,
      &.react-autosuggest__suggestion--highlighted > button {
        background: ${R.bgPrimW100};
      }
    }
  }
`,Bi=n(Tt)`
  left: 245px;
  margin-top: 0px;
  position: absolute;
`,jo=({suggestions:t,value:o,placeholder:i,onChange:s,onBlur:r,onFocus:c=()=>{},suggestionsMaxHeight:d,autoFocus:u=!1,...C})=>{let p=(0,z.useMemo)(()=>new be(t,[]),[t]),[x,f]=(0,z.useState)([]),y=(0,z.useRef)(null);return(0,z.useEffect)(()=>{o===""&&Array.isArray(t)&&f(t)},[o,t]),(0,z.useEffect)(()=>{u&&y.current&&y.current.focus()},[u]),e(Di,{suggestionsMaxHeight:d},e(zo.default,{suggestions:x,renderSuggestion:m=>e("button",{type:"button",onClick:v=>dt(s(m))(v),onKeyDown:Ai(()=>s(m))},m),inputProps:{ref:y,value:o,onChange:(m,{newValue:v,method:S})=>!["down","up"].includes(S)&&typeof s=="function"&&s(v),onBlur:(m,v)=>typeof r=="function"&&r(v?.highlightedSuggestion??""),onFocus:c,placeholder:i,...C},shouldRenderSuggestions:m=>t.indexOf(m)===-1,getSuggestionValue:m=>m,onSuggestionsClearRequested:()=>f([]),onSuggestionsFetchRequested:({value:m,reason:v})=>v!=="suggestions-revealed"&&f(p.search(m).sort((S,E)=>S.toLowerCase().localeCompare(E.toLowerCase())))}),o!==""&&e(Bi,{onClick:()=>s("")}))};var _i=n.div`
  align-items: center;
  align-self: stretch;
  display: flex;
  gap: 8px;
  padding: 5px 12px 5.5px 12px;
`,Ni=n.button`
  align-items: center;
  background: transparent;
  border: none;
  border-radius: 10px;
  color: #afb9c8;
  cursor: pointer;
  display: flex;
  font-size: 14px;
  font-style: normal;
  font-weight: 500;
  gap: 0px;
  justify-content: center;
  letter-spacing: 0.14px;
  line-height: 20px;
  padding: 8px;
`,Go=({searchValue:t,setSearchValue:o})=>e(_i,null,e(jo,{"aria-label":oe("VOICE_SEARCH_INPUT"),placeholder:"Search for language, accents",suggestions:[],value:t,onChange:o,suggestionsMaxHeight:"250px",autoFocus:!0}),e(Ni,{onClick:()=>{o(""),Ce("/voices")}},"Cancel"));a();l();var q=w(V());a();l();var Xe=(t,o)=>{try{let i=new Intl.DisplayNames([o],{type:"language"}).of(t);return i?ke(i):t}catch{return t}},Zo=t=>Array.from(new Set(t.map(o=>o.language))),Je=t=>{let o=t.split("-")[1];if(o&&!/^\d+$/.test(o))return`${o.toUpperCase()}.svg`},qo=t=>{let o=et(i=>i.split("-")[0],t);return Object.entries(o).map(([i,s])=>{let r=s.map(c=>Je(c)).flatMap(c=>c?[c]:[]);return{id:i,name:Xe(i,i),flags:r}})};var $i=n.div`
  align-items: center;
  display: flex;
  flex: 1 0 0;
  gap: 4px;
  justify-content: flex-end;
`,Wi=n.div`
  align-items: center;
  align-self: stretch;
  background: #1e1e1e;
  border-radius: 0;
  border-top: 0.5px solid #373737;
  display: flex;
  justify-content: space-between;
  margin-left: 9px;
  margin-right: 9px;
  padding: 12px 12px 4px 12px;
`,Fi=n.div`
  color: #fff;
  flex: 1 0 0;
  font-size: 14px;
  font-style: normal;
  font-weight: 700;
  letter-spacing: 0.14px;
  line-height: 20px;
`,Yo=(0,q.forwardRef)(({disableFreeVoices:t,disablePremiumVoices:o,onVoiceSelection:i,previewingVoice:s,previewPercentagePlayed:r,sectionRefs:c,voices:d},u)=>{let{voice:C}=W(),p=(0,q.useMemo)(()=>{let m=d.map(v=>v.language);return m.length>0?m[0].split("-")[0]:"en"},[d]),x=(0,q.useMemo)(()=>Xe(p,p),[p]),f=(0,q.useMemo)(()=>{let m=d.map(v=>Je(v.language)).flatMap(v=>v?[v]:[]);return Array.from(new Set(m))},[d]),y=(0,q.useCallback)(m=>v=>{c[m]=v},[]);return e(D,{column:!0,style:{position:"relative"}},p!=="en"&&e(Wi,{ref:y(p)},e(Fi,null,x),e($i,null,f.map(m=>e(U,{key:m,flag:m,variant:"rectangle",height:12,alt:m})))),e(D,{column:!0},d.map((m,v)=>{let S=C&&ee(m,C);return e(Be,{"aria-label":oe("VOICE_SELECT_BUTTON")(m.name),checked:S,isFreeVoicesDisabled:t,isPremiumVoicesDisabled:o,key:Fe(m),id:Fe(m),idx:v,isPreviewPlaying:s?.displayName===m.displayName,item:m,onClick:i.bind(null,m),previewPercentagePlayed:r,ref:u})})))});a();l();var se=w(V());function Ko(t,o){let[i,s]=(0,se.useState)(),r=(0,se.useRef)(!1),c=d=>d.name.startsWith("PVL:");return(0,se.useEffect)(()=>{let d=wt.subscribe(({history:u})=>{if(t&&r.current){let C=u.map(p=>c(p)&&o.some(x=>p.name===x.name)?p:t.find(x=>ee(p,x))).filter(p=>!!p);s(C)}});return Vt().then(()=>{r.current=!0}),d},[t]),i}a();l();var le=w(V());function Xo(t){let[o,i]=(0,le.useState)(void 0);return(0,le.useEffect)(()=>{(async()=>{let s=await Se();i(s)})()},[]),(0,le.useMemo)(()=>(o?.tabs[0]?.categories[0]?.voices??[]).map(s=>t?.find(c=>ee(c,s))).filter(s=>!!s),[t,o])}a();l();var O=w(V());a();l();var Jo=t=>e(F,{xmlns:"http://www.w3.org/2000/svg",width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",...t},e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M18.0168 4.59663C18.4073 4.98716 18.4073 5.62033 18.0168 6.01084L8.62378 15.4033C8.43623 15.5908 8.18185 15.6962 7.91662 15.6961C7.65139 15.6961 7.39703 15.5907 7.20951 15.4032L1.98324 10.1758C1.59276 9.78519 1.59283 9.15202 1.9834 8.76154C2.37397 8.37106 3.00713 8.37113 3.39761 8.7617L7.91679 13.2819L16.6026 4.59658C16.9932 4.20607 17.6263 4.20609 18.0168 4.59663Z",fill:"#AFB9C8"}));var Ui=n.div`
  display: flex;
  align-items: center;
  gap: 4px;
  justify-content: flex-end;
`,Oi=n.button`
  align-items: center;
  background: #1e1e1e;
  border-radius: 8px;
  border: 1px solid #373737;
  cursor: pointer;
  display: flex;
  gap: 12px;
  padding: 8px 12px;
  width: 100%;
  justify-content: space-between;

  &:hover {
    border-color: #505050;
  }
`,zi=n.div`
  display: flex;
  flex-direction: column;
  padding: 12px;
  background: #1e1e1e;
`,ji=n.div`
  display: flex;
`,Gi=n.div`
  position: relative;
`,Zi=n.div`
  display: flex;
  flex-direction: column;
  height: 220px;
  overflow-y: auto;
  padding-right: 3px;

  ${Z}
`,qi=n.div`
  background: #1e1e1e;
  border-radius: 8px;
  border: 1.5px solid #6b78fc;
  box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.32);
  height: 222px;
  margin: -50px 12px 0;
  padding: 5px 3px 4px 4px;
  position: absolute;
  width: 312px;
  z-index: 1;
`,Yi=n.svg`
  width: 16px;
  height: 16px;
`,Qo=n.span`
  color: #fff;
  font-size: 14px;
  font-weight: 700;
  flex-grow: 1;
  text-align: left;
`,Ki=n.div`
  align-items: center;
  background: ${({selected:t})=>t?"#283750":"#1e1e1e"};
  border-radius: 4px;
  cursor: pointer;
  display: flex;
  gap: 12px;
  padding: 8px 20px 8px 12px;

  &:hover {
    background: ${({selected:t})=>t?"#283750":"#2e2e2e"};
  }
`,Ho=({flags:t})=>e(Ui,null,t.map(o=>e(U,{key:o,flag:o,alt:o,variant:"rectangle",height:12}))),en=({languages:t,onLanguageChange:o,selectedLanguageId:i})=>{let s=(0,O.useMemo)(()=>t.find(f=>f.id===i),[i,t]);if(!s)return;let[r,c]=(0,O.useState)(!1),d=(0,O.useRef)(null),u=(0,O.useRef)(null),C=()=>c(!r),p=f=>{c(!1),o(f)};(0,O.useEffect)(()=>{if(r&&d.current&&u.current){let f=d.current.getBoundingClientRect(),m=u.current.getBoundingClientRect().top-f.top+d.current.scrollTop;d.current.scrollTop=m-10}},[r]);let x=(0,O.useMemo)(()=>t.map(f=>{let y=f.id===i;return e(Ki,{key:f.id,selected:f.id===i,onClick:()=>p(f.id),ref:y?u:null},y&&e(ji,null,e(Jo,null)),e(Qo,null,f.name),e(Ho,{flags:f.flags}))}),[t,i]);return e(Gi,null,e(zi,null,e(Oi,{type:"button","aria-haspopup":"true","aria-expanded":r,onClick:C},e(Qo,null,s.name),e(Ho,{flags:s.flags}),e(Yi,{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 16 16",fill:"none"},e("path",{d:"M13 6L8 11L3 6",stroke:"#AFB9C8",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"})))),r&&e(qi,null,e(Zi,{ref:d},x)))};a();l();var tn=w(V());var on=(r=>(r.All="All Voices",r.Custom="Custom",r.Recent="Recent",r.Recommended="Featured",r))(on||{}),Xi=n.div`
  align-items: center;
  background: transparent;
  border-radius: 8px;
  border: none;
  color: #afb9c8;
  cursor: pointer;
  display: flex;
  flex: 1 0 0;
  font-size: 14px;
  font-style: normal;
  font-weight: 700;
  gap: 0px;
  justify-content: center;
  letter-spacing: 0.14px;
  line-height: 20px;
  overflow: hidden;
  padding: 6px 8px;
  white-space: nowrap;
  z-index: 20;

  &[aria-selected='true'] {
    color: #fff;
  }
`,nn=(0,tn.forwardRef)(({tab:t,selectedTab:o,setSelectedTab:i},s)=>e(Xi,{ref:s,"data-testId":t,role:"presentation",onClick:()=>i(t),"aria-selected":o===t?"true":"false"},on[t]));var Ji=n.div`
  align-items: stretch;
  display: flex;
  flex-direction: column;
  height: 380px;
  width: 348px;
`,Qi=n.div`
  align-items: center;
  align-self: stretch;
  background-color: #2d2d2f;
  display: flex;
  gap: 8px;
  margin-top: 8px;
  padding: 10px 16px;
`,Hi=n.div`
  color: #fff;
  flex: 1 0 0;
  font-size: 14px;
  font-style: normal;
  font-weight: 400;
  letter-spacing: -0.07px;
  line-height: 20px;
`,er=n.span`
  color: #8894fe;
  cursor: pointer;
`,tr=n.div`
  align-items: center;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  flex-shrink: 0;
  gap: 20px;
  height: 330px;
  justify-content: center;

  > div {
    color: #afb9c8;
    font-size: 14px;
    font-style: normal;
    font-weight: 500;
    letter-spacing: 0.14px;
    line-height: 20px;
    max-width: 80%;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
`,or=n.div`
  background-color: #1e1e1e;
  border-radius: 8px;
  box-shadow: 0px 4px 6px 0px rgba(0, 0, 0, 0.32);
  height: 30px;
  left: ${({left:t})=>t}px;
  position: absolute;
  transition: left 0.3s ease-in-out;
  width: ${({width:t})=>t}px;
  z-index: 10;
`,nr=n.div`
  display: flex;
  padding: 3px 12px;
  align-items: flex-start;
`,ir=n.div`
  display: flex;
  align-items: flex-start;
  background: #111112;
  border-radius: 10px;
  flex: 1 0 0;
  padding: 4px;
  position: relative;
`;function rn({allVoices:t,disablePremiumVoices:o,hasClientVoices:i,onRecentVoiceRemove:s,onVoiceSelection:r,personalVoices:c,previewingVoice:d,previewPercentagePlayed:u,route:C,searchValue:p,setSearchValue:x,voicesByKey:f}){let{voice:y}=W(),m=Ko(t,c)?.filter(h=>h.displayName!==y?.displayName),v=Xo(t).slice(0,6),S=(0,L.useRef)(null),E=(0,L.useRef)(null),j=(0,L.useRef)(!1),Q=(0,L.useRef)(!1),k=(0,L.useRef)(),P=(0,L.useRef)({}),_=(0,L.useRef)({}),[ce,ve]=(0,L.useState)("en"),[A,pe]=(0,L.useState)("Recent"),Ne=(0,L.useMemo)(()=>m?.length,[m]),Qe=(0,L.useMemo)(()=>!p&&["Recommended"].includes(A),[p,A]),pn=(0,L.useMemo)(()=>{let h=Zo(t);return qo(h)},[t]);(0,L.useEffect)(()=>{if(A!=="All")return;let h=E.current;if(!h)return;let I=()=>{if(!E.current)return;let $=E.current,de=$.getBoundingClientRect(),me=[...Object.entries(P.current)].reverse().find(([,H])=>H&&H.getBoundingClientRect().top<=de.top);if(me){let[H]=me;ve(H)}Q.current=$.scrollTop>0};return(()=>{if(S.current&&E.current){let $=h.getBoundingClientRect(),de=S.current.getBoundingClientRect(),H=h.scrollTop+(de.top-$.top)-80;h.scrollTo({top:H,behavior:"instant"})}})(),h.addEventListener("scroll",I),()=>{h&&h.removeEventListener("scroll",I)}},[A]),(0,L.useEffect)(()=>{C==="/voices/search"?(k.current=A,pe("All")):C==="/voices"&&k.current&&(pe(k.current),k.current=void 0)},[C]);let dn=()=>{let I=[{type:"Recommended",condition:!0},{type:"Recent",condition:Ne},{type:"Custom",condition:c.length>0},{type:"All",condition:!0}],He=I.filter(({condition:$})=>$).length;return e(nr,null,e(ir,{role:"tablist","aria-orientation":"horizontal"},I.map(({type:$,condition:de})=>de?e(nn,{key:$,ref:me=>_.current[$]=me,tab:$,selectedTab:A,setSelectedTab:pe}):null),e(or,{left:_.current[A]?.offsetLeft??0,width:316/He})))};(0,L.useEffect)(()=>{!j.current&&m&&!Ne&&(pe("Recommended"),j.current=!0)},[Ne,m,y]);let $e=h=>{if(!y||!h)return!1;if(h.personal){if(y.name===h.name)return!0}else if(y.displayName===h.displayName)return!0;return!1},mn=h=>{ve(h),h==="en"?E.current?.scrollTo({top:0,behavior:"instant"}):P.current[h]?.scrollIntoView({behavior:"instant"})},un=h=>{m?.length===1&&pe("Recommended"),s(h)},fn=()=>{let h=ht();if(!h){he("extension_no_client_voices_notification_shown",{action:"no download url"});return}he("extension_no_client_voices_notification_shown",{action:"download"}),mt(h)},gn=()=>{if(A==="All"&&C!=="/voices/search")return e(en,{languages:pn,onLanguageChange:mn,selectedLanguageId:ce})},xn=()=>c.map((h,I)=>e(Be,{checked:$e(h),idx:I,isFreeVoicesDisabled:!i,isPremiumVoicesDisabled:o,isPreviewPlaying:d?.name===h.name,previewPercentagePlayed:u,item:h,key:h.displayName,onClick:r})),hn=()=>m?.map((h,I)=>e(Oo,{checked:$e(h),idx:I,isPremiumVoicesDisabled:o,item:h,key:h.displayName,onClick:r,onRemove:un})),bn=()=>v.map((h,I)=>e(Ao,{checked:$e(h),idx:I,isPremiumVoicesDisabled:o,isPreviewPlaying:d?.displayName===h.displayName,previewPercentagePlayed:u,item:h,key:h.displayName,onClick:r})),Cn=()=>{if(p.length>0||A==="All")return e(g,null,Object.entries(f).map(([h,I])=>h!=="Custom"&&e(Yo,{key:h,disableFreeVoices:!i,disablePremiumVoices:o,onVoiceSelection:r,previewingVoice:d,previewPercentagePlayed:u,ref:S,sectionRefs:P.current,selectedVoice:y,voices:I})),Object.entries(f).length===0&&e(tr,null,e(Eo,null),e("div",null,"No results found for ",p)));switch(A){case"Custom":return xn();case"Recent":return hn();case"Recommended":return bn()}},yn=()=>{let h=A==="Recent"?Uo:Qe?Mo:_o,I=A==="Recent"?{}:{column:!Qe};return e(h,{key:`${A}-${p}`,...I,ref:E},Cn())};return e(Ji,null,C==="/voices/search"&&e(Go,{searchValue:p,setSearchValue:x}),C!=="/voices/search"&&dn(),!i&&A==="All"&&e(Qi,null,e(ft,null),e(Hi,null,"No voices available on your device.",e("br",null),e(er,{onClick:fn},"Download a language pack")," ","to enable speech.")),gn(),yn())}var sn=t=>t.normalize("NFD").replace(/[\u0300-\u036f]/g,""),rr=()=>{let[t,o]=K([]),[i,s]=K([]),[r,c]=K();X(()=>{let p=async()=>{let[f,y]=await Promise.all([Se(),it()]);o(y);let m=f.tabs.find(v=>v.displayName==="All");m&&c(m)},x=async()=>{let f=await nt({forceRefetch:!0});s(f)};p(),x()},[]),X(()=>{let p=St.on("updated",({personalVoiceList:x})=>{s(x)});return()=>p()});let d=J(()=>r?.categories??[],[r]),u=J(()=>r?.categories?.flatMap(p=>{let x=t.filter(f=>p.localVoices.languages.includes(f.language.split("-")[0]));return[...p.voices,...x].map(f=>({...f,category:p.displayName}))})??[],[r]),C=ge(p=>{let x=d.find(y=>y.displayName===p)??null;if(!x)return[];let f=t.filter(y=>x.localVoices.languages.includes(y.language.split("-")[0]));return[...x.voices,...f].map(y=>({...y,category:x.displayName}))},[d]);return{categories:d,allVoices:u,getVoicesForCategory:C,personalVoices:i}},sr=(t,o)=>{let[i,s]=K(0),[r,c]=K(),d=ge((p,x)=>fe("/tts/get-audio",{voice:p,ssml:x}),[]);return X(()=>{(t==="playing"||t==="buffering"||t==="errored")&&(s(0),c(void 0))},[t]),X(()=>{let p=()=>{s(100),c(void 0)};return o&&o.addEventListener("ended",p),()=>{o&&o.removeEventListener("ended",p)}},[o]),X(()=>{if(!o)return;let p=()=>{if(o.duration){let x=o.currentTime/o.duration*100;s(x)}else s(0)};return o.addEventListener("timeupdate",p),()=>{o.removeEventListener("timeupdate",p)}},[o]),{percentagePlayed:i,playPreview:p=>{if(o&&(o.pause(),s(0),c(void 0)),!o)return;if(p.previewAudio){o.src=p.previewAudio,o.play().then(()=>c(p));return}if(p.engine!==we)return d(p,`<speak>${We(p)}</speak>`).then(({audioData:f})=>{o.src=f,o.play().then(()=>c(p))});let x=new SpeechSynthesisUtterance(We(p));x.voice=speechSynthesis.getVoices().find(f=>f.name?.toLowerCase()===p.name?.toLowerCase())??null,speechSynthesis.cancel(),setTimeout(()=>{speechSynthesis.speak(x),c(p)},250)},previewingVoice:r,stopPreview:()=>{o?o.pause():speechSynthesis.cancel(),s(0),c(void 0)}}};function _e({audioPlayer:t,hasClientVoices:o,route:i}){let[s,r]=K(""),c=Le(),{allVoices:d,personalVoices:u}=rr(),C=J(()=>{if(!Array.isArray(d)||!Array.isArray(u))return new be([],[]);let k=[...d.map(P=>({...P,normalizedDisplayName:sn(P.displayName)})),...u.map(P=>({...P,category:"Custom",normalizedDisplayName:sn(P.displayName)}))];return new be(k,["displayName","normalizedDisplayName","category"])},[d,u]),p=J(()=>ar(C,s),[s,C]),x=J(()=>c&&Oe(c),[c]),f=te.getPlayingState(),{percentagePlayed:y,playPreview:m,previewingVoice:v,stopPreview:S}=sr(f,t);X(()=>()=>{S()},[]);let E=ge(k=>{fe("/user-settings/remove-voice-from-history",{voice:k})},[]),j=ge(async k=>{let P=M(k),_=await tt();if(!(Rt(_)&&P.premium)){if(!Oe(_)&&P.premium){if(Lt(_)||_.status==="expired")return await bt(!0),Pe("popup_voice_switch","premium_voices");if(kt(_)){let ve=new Date(_.currentBatchExpiresAt*1e3).toLocaleDateString("en-US",{month:"long",day:"numeric"});return ze(`You are out of your 450k premium words for this month, you'll get access to more on ${ve}`,{})}}f!=="playing"&&(v?S():m(P)),P.labels?.includes("beta")&&ze("This voice is still in beta which might lead to longer load times in some instance.",{duration:8e3}),await lt(k,{isUserSelection:!0})}},[x,v,f]),Q=J(()=>{let k={};return Object.keys(p).forEach(P=>{k[P]=x?p[P]:lr(p[P])}),k},[p,x]);return e(rn,{allVoices:d,disablePremiumVoices:!x,hasClientVoices:o,onRecentVoiceRemove:E,onVoiceSelection:j,personalVoices:u,previewingVoice:v,previewPercentagePlayed:y,route:i,searchValue:s,setSearchValue:r,voicesByKey:Q})}function lr(t){let o=t.map(M),i=o.filter(r=>r.premium);return[...o.filter(r=>!r.premium),...i]}function ar(t,o){let i={};return t.search(o).forEach(s=>{i[s.category]??=[],i[s.category].push(s)}),i}var an={route:"/",defaultRoute:"/",collapseState:"collapsed",allowCollapse:!0,isPlayerMinimized:!1},ae=new ln.Store({...an});function ld(){ae.set(()=>({...an}))}function Ce(t){ae.set(()=>({route:t}))}var cn={"/pillreport":{name:"Report",render:Ze},"/featureprompt/skipsentences":{name:"How to Skip Sentences?",render:Ge},"/speed":{name:"Select Speed",render:Vo},"/unsupported":{name:"Unsupported Website",render:Lo},"/voices":{name:"Select Voice",render:_e},"/voices/search":{name:"Select Voice",render:_e}};function ad(t){return cn[t]?.render}function cd(t){return cn[t]??{}}function ko(t){ae.get().allowCollapseModified||ae.set(()=>({allowCollapse:t,collapseState:"expanded"}))}function Ro(t){ae.get().allowCollapseModified||ae.set(()=>({hidePlayerPill:t}))}export{ur as a,ae as b,ld as c,Ce as d,ad as e,cd as f};
//# sourceMappingURL=chunk-Z35E3KWV.js.map
