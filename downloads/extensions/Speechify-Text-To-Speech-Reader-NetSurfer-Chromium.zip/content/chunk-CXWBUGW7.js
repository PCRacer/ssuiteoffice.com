import{a as s}from"./chunk-WC6QURV6.js";import{Dd as m,Ya as l,mb as a}from"./chunk-RISKGE32.js";import{F as e}from"./chunk-6O6MLDWR.js";import{b as d,k as n}from"./chunk-F4AZU7R4.js";import{g as p,i as o,n as u}from"./chunk-CLPINNGF.js";u();p();var E=n("p")`
  padding: 24px;
  margin: 0;
`,f=n("button")`
  color: ${({color:r})=>r??d.icnTxtPrim};
  background: transparent;
  outline: none;
  border: none;
  position: absolute;
  top: 8px;
  right: 8px;
  cursor: pointer;
  padding: 2px;
`,c=n("div")`
  position: relative;
`,x=({children:r,dismiss:i})=>o(c,null,o(f,{onClick:()=>i()},o(l,null)),o(E,null,r)),O=(r,i)=>{m({id:"player-error",timeSensitive:!0,priority:150,duration:5e3,showOnMobile:!0,render:({dismiss:t})=>e()?o(s,null,r):o(x,{dismiss:t},r),...i})},W=(r,i)=>{m({id:"player-message",timeSensitive:!1,priority:50,duration:7e3,showOnMobile:!0,render:({dismiss:t})=>e()?o(s,null,r):o(a,{removeNotification:t},o(E,{onClick:t},r)),...i})};export{O as a,W as b};
//# sourceMappingURL=chunk-CXWBUGW7.js.map
