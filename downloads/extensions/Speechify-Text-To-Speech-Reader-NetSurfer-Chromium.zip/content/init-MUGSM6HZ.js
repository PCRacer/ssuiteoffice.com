import{a as I}from"./chunk-H2Q7MKM3.js";import{a as k}from"./chunk-DM55HIHZ.js";import{a as A,b as D,c as R}from"./chunk-VUIW4JA2.js";import{b as M}from"./chunk-BTWOJWRN.js";import"./chunk-FKJPRJ46.js";import"./chunk-5PO6RROQ.js";import"./chunk-ETIPD2TL.js";import"./chunk-43GP4A7N.js";import"./chunk-MBHSJ34F.js";import"./chunk-DMUXVFIA.js";import"./chunk-Z3E43XMU.js";import"./chunk-BN5XPDNR.js";import"./chunk-YYPSUSZQ.js";import"./chunk-56NWWOIX.js";import"./chunk-EF43U47C.js";import"./chunk-GWCIFOLA.js";import"./chunk-NK4CKTAC.js";import"./chunk-KO4WPNRU.js";import"./chunk-F5622KQ7.js";import"./chunk-WC6QURV6.js";import"./chunk-TIGAXALM.js";import"./chunk-ZQRXZJGY.js";import"./chunk-6S4AP2UG.js";import"./chunk-O3LC63CS.js";import"./chunk-AG3QEKLJ.js";import"./chunk-C4ZBMBCR.js";import{Ic as O,Oc as _,Ta as d,e as S,za as E}from"./chunk-RISKGE32.js";import{fa as L,ha as P}from"./chunk-6O6MLDWR.js";import{b as c,c as T,g as w,k as s}from"./chunk-F4AZU7R4.js";import{g as G}from"./chunk-GQY3J744.js";import{d as V,g as a,i as o,k as v,m as Y,n as p}from"./chunk-CLPINNGF.js";p();a();Y();p();a();var t=V(G());p();a();var F=e=>o("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",...e},o("g",{id:"icons/20"},o("path",{d:"M0 10C0 4.47715 4.47715 0 10 0C15.5228 0 20 4.47715 20 10C20 15.5228 15.5228 20 10 20C4.47715 20 0 15.5228 0 10Z",fill:"#2D2D2F"}),o("path",{id:"Union","fill-rule":"evenodd","clip-rule":"evenodd",d:"M12.3884 6.38861C12.6813 6.09572 13.1561 6.09572 13.449 6.38862C13.7419 6.68151 13.7419 7.15639 13.449 7.44928L10.9794 9.91892L13.4491 12.3886C13.742 12.6815 13.742 13.1564 13.4491 13.4493C13.1562 13.7422 12.6813 13.7422 12.3884 13.4493L9.9187 10.9796L7.44897 13.4493C7.15607 13.7422 6.6812 13.7422 6.38831 13.4493C6.09542 13.1564 6.09542 12.6815 6.38831 12.3886L8.85803 9.91892L6.38837 7.44928C6.09547 7.15639 6.09547 6.68151 6.38836 6.38862C6.68125 6.09572 7.15613 6.09572 7.44902 6.38861L9.9187 8.85826L12.3884 6.38861Z",fill:"#9899A6"})));var W=["speechify.com","onboarding.speechify.com","calendar.google.com","sheets.google.com","youtube.com","google.com","mail.google.com","read.amazon.in","read.amazon.com"],X=s.div`
  cursor: grab;
  position: fixed;
  z-index: 999999999;
  border: 6px solid transparent;

  opacity: 0.4;
  transition: opacity 0.2s ease-in-out;
  &:hover {
    opacity: 1;
  }
`,Z=s(d)`
  background: ${c.bgSec0110};
  color: #ffffff;
  padding: 8px;
  border-radius: 12px;
  border-color: ${c.brdrSec2060};
  font-size: 14px;
  font-family: ABCDiatype;
  position: relative;
  user-select: none;
`,K=s.div`
  width: 2px;
  height: 16px;
  border-radius: 999px;
  background: ${c.brdrPrim1080};
`,j=s(d)`
  position: relative;
  font-size: 14px;

  & > *:not(:last-child) {
    margin-right: 8px;
  }
`,q=s(d)`
  min-width: 12px;
  padding: 0 6px;
  height: 26px;
  border-radius: 6px;
  background-color: ${c.bgSec090};
  color: ${c.icnTxtWhite};
  border: 1px solid ${c.brdrPrim1080};
`,J=s(d)`
  padding: 4px;
`,Q=s.button`
  width: 20px;
  height: 20px;
  padding: 0px;
  background: none;
  border: none;
  outline: none;
  box-shadow: none;
`,H=s(F)`
  width: 20px;
  height: 20px;
  fill: #9899a6;

  &:hover {
    opacity: 0.8;
    cursor: pointer;
  }
`,oo=s(d)`
  width: 28px;
  height: 28px;
  background-color: ${c.logoSpeechifyBlue};
  border-radius: 6px;

  & > svg {
    width: 24px;
    color: ${c.icnTxtWhite};
  }
`,l={},eo=e=>{let r=(0,t.useRef)();(0,t.useEffect)(()=>{if(e){let n=m=>{if(r.current){let{x,y:u}=r.current,y=m.clientX-x,h=m.clientY-u,f={x:Number(e.style.left.replace("px","")),y:Number(e.style.bottom.replace("px",""))};l.x=f.x+y,l.y=f.y-h,e.style.left=`${l.x}px`,e.style.bottom=`${l.y}px`,r.current={x:m.clientX,y:m.clientY}}},i=()=>{r.current=void 0,e.style.cursor="grab"},g=m=>{e.style.cursor="grabbing",r.current={x:m.clientX,y:m.clientY}};return e.addEventListener("mousedown",g),document.addEventListener("mousemove",n),document.addEventListener("mouseup",i),()=>{e.removeEventListener("mousedown",g),document.removeEventListener("mousemove",n),document.removeEventListener("mouseup",i)}}},[e])},to=!1,no=()=>{let[e,r]=(0,t.useState)(!1);return(0,t.useEffect)(()=>{let n=async()=>r(!0);return L("hide-shortcut-prompt",n,"shortcuts-prompt"),()=>P("hide-shortcut-prompt",n)},[]),e};function U({root:e}){let[r,n]=(0,t.useState)(null),i=E(),g=no(),[m,x]=(0,t.useState)(!0),[u,y]=(0,t.useState)(!1),h=A();(0,t.useEffect)(()=>{R()},[]);let f=(0,t.useMemo)(()=>(h["play-pause-new"]||h["play-pause"])?.shortcut.split("+"),[h]);eo(r),I(x);let B=()=>{x(!0),M(),_("extension_shortcut_prompt_closed")},N=(0,t.useMemo)(()=>T({key:"shortcuts-prompt-emotion-cache",container:e}),[e]);return W.includes(window.location.hostname)||O()||g||m||!i||!f?null:o(w,{value:N},o(X,{ref:n,style:{left:l.x?l.x:to?274:26,bottom:l.y?l.y:26},onMouseEnter:()=>y(!0),onMouseLeave:()=>y(!1)},o(Z,{separation:"8px",yAlign:!0},o(oo,{xAlign:!0,yAlign:!0},o(k,null)),u&&o(K,null),u&&o("span",null,"Press"),o(j,{yAlign:!0},f.map(C=>o(d,{key:C,yAlign:!0,separation:"4px"},o(q,{yAlign:!0,xAlign:!0},C)))),u&&o("span",null,"to listen"),u&&o(J,null,o(Q,{onClick:B},o(H,null))))))}var b;async function ro({disabled:e=!1}){if(!e){if(!b){let i=document.createElement("div");i.id="speechify-shortcuts-prompt",document.body.appendChild(i),b=i.attachShadow({mode:"open"})}let r=async()=>{if(document.visibilityState==="hidden")return;let i=await S("/keyboard-shortcuts/force-get-command-list");D(i)};document.addEventListener("visibilitychange",r);let n=document.createElement("div");return n.id="speechify-shortcuts-prompt-root",b.appendChild(n),v(o(U,{root:n}),n),()=>{document.removeEventListener("visibilitychange",r),v(()=>null,n)}}}export{ro as default};
//# sourceMappingURL=init-MUGSM6HZ.js.map
