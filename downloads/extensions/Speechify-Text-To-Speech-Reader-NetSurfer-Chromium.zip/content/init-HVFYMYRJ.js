import{vd as a,wd as b,xd as c}from"./chunk-RISKGE32.js";import"./chunk-6O6MLDWR.js";import"./chunk-F4AZU7R4.js";import"./chunk-GQY3J744.js";import"./chunk-CLPINNGF.js";export{b as checkGlobalNotificationsContainerExists,a as default,c as setGlobalNotificationsContainer};
//# sourceMappingURL=init-HVFYMYRJ.js.map
