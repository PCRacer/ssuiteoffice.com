import{a as q,b as M}from"./chunk-U7XK3CBQ.js";import{c as G,e as O}from"./chunk-TIGAXALM.js";import{a as R}from"./chunk-ZQRXZJGY.js";import"./chunk-AG3QEKLJ.js";import{Ca as A,Ea as I,Ha as k,Ra as N,Ta as u,dd as W,gb as F,lb as B,ta as L}from"./chunk-RISKGE32.js";import{V as b,ja as D}from"./chunk-6O6MLDWR.js";import{b as i,k as m}from"./chunk-F4AZU7R4.js";import{g as H}from"./chunk-GQY3J744.js";import{d as J,f as y,g as x,i as n,j as h,k as P,m as Z,n as C}from"./chunk-CLPINNGF.js";C();x();Z();C();x();var s=J(H());var ee=m(u)`
  font-family: var(--font-family);
  background: ${({isDarkBackground:e})=>e?i.sfPrimCta:i.bgPrimInvBW};
  border-radius: 4000px;
  cursor: pointer;
  height: 24px;
  padding: 3px 4px;
  overflow: hidden;
  width: 55px;
  margin-left: ${({isUSVersion:e})=>e?"0px":"10px"};
  margin-top: 3px;
`,te=m(u)`
  font-family: var(--font-family);
  cursor: pointer;
  overflow: hidden;
`,oe=m(u)`
  font-size: 12px;
  font-weight: 500;
  line-height: 16px;
`,ne=O(m.div`
  position: relative;

  // this is to make sure the tooltip and the icon are center aligned and we don't have to hack the margin left/right values for the tooltip;
  display: flex;
  flex-direction: column;
  align-items: center;
`),ie=m(G)`
  position: absolute;
  margin-top: 42px;
  margin-left: 10px;
  z-index: 1000;
`,re=e=>o=>!(e.ignoredSelectors?.some(t=>o.classList.contains(t))||e.ignoredSelectorForCodeSegment&&e.ignoredTagForCodeSegment&&o.classList.contains(e.ignoredSelectorForCodeSegment)&&o.tagName.toLowerCase()===e.ignoredTagForCodeSegment);function U(e){let o="";return e instanceof Node?(e.childNodes.forEach(t=>{if(t.nodeType===Node.ELEMENT_NODE){let l=window.getComputedStyle(t);l.display!=="none"&&l.visibility!=="hidden"&&(o+=U(t))}else t.nodeType===Node.TEXT_NODE&&(o+=t.textContent)}),o.trim()):e.text}var le=({isPlaying:e,isLoading:o,isDarkBackground:t,...l})=>{let r=(0,s.useMemo)(()=>o?"loading":e?"playing":"paused",[e,o]);return n(u,{...l},r==="playing"&&n(q,{pathFill:t?i.icnTxtPrim:i.icnTxtPrimElectric,width:"18",height:"18"}),r==="loading"&&n(R,{color:t?i.icnTxtPrim:i.icnTxtPrimElectric,width:"18",height:"18"}),r==="paused"&&n(M,{pathFill:t?i.icnTxtPrim:i.icnTxtPrimElectric,width:"18",height:"18"}))},V=({isUSVersion:e,selectors:o})=>{let{isDarkBackground:t}=W(document.body),[l,r]=(0,s.useState)(!0),a=document.querySelector(o.contentMainSelector),$="showGoogleGenAIListenCopy",[T,z]=(0,s.useState)(null),{state:E,play:Q,pause:j,queueAndPlayContent:K,isActive:p}=k(T),{duration:w}=A(T,p),f=p&&E==="playing",S=p&&E==="buffering";(0,s.useEffect)(()=>{(async()=>{let X=Array.from(document.querySelectorAll(o.contentSelector)).filter(g=>getComputedStyle(g.parentElement,null)?.getPropertyValue("display")!=="none").filter(re(o)),Y={getContent:await N(async()=>({content:X,chunksAfter:0,chunksBefore:0})),converter:g=>({text:U(g),ref:{ref:g}}),options:{autoplay:!0,sideEffects:!1},metadata:{source:"GoogleGenAIResult"}};z(Y)})()},[a]),(0,s.useEffect)(()=>{(async()=>{let{showGoogleGenAIListenCopy:c}=await y.storage.local.get([$]);r(c??!0)})()},[]);let v=async c=>{if(c.preventDefault(),c.stopPropagation(),b()||D("browser-action",{animate:!1},"pill-player"),!p)return K();if(!S){if(f)return j();if(!f)return Q();await y.storage.local.set({showGoogleGenAIListenCopy:!1}),r(!1)}};return n(ne,null,c=>n(h,null,n(ie,{background:t?i.bgSecInv1000:i.bgPrimW100,display:c&&!l&&!S&&!f,direction:"up",tooltipStyle:{justifyContent:"space-between",minWidth:"128px",fontFamily:"ABCDiatype",fontSize:"14px"}},n(F,{color:t?i.icnTxtPrimInv:i.icnTxtPrim},"Listen to this answer")),n(te,{yAlign:!0,relative:!0,column:!1,onClick:d=>v(d)},n(ee,{yAlign:!0,relative:!0,column:!1,isUSVersion:!!e,onClick:d=>v(d),isDarkBackground:t,separation:"3px"},!w.isLoading&&n(le,{isLoading:S,isPlaying:f,isDarkBackground:t}),n(oe,{yAlign:!0,xAlign:!0},n(B,{color:t?i.icnTxtPrim:i.icnTxtPrimElectric,fixedWidthNumbers:!0,duration:w}))),l&&n("h3",{style:{color:t?i.icnTxtPrim:i.icnTxtPrimElectric,fontFamily:"ABCDiatype",marginLeft:"8px",marginTop:"4px",fontSize:"16px"}},"Listen to answer"))))};var _="speechify-google-gen-ai-player-root";async function ae(e){let o=e.selectors;await L(o.mainSelectorUS),se(),await I(800);let t=!document.querySelector(`${o.mainSelectorIN}`),l=t?o.mainSelectorUS:o.mainSelectorIN,r=document.querySelector(`${l}`);if(r){let a=document.createElement("span");a.id=_,t&&(a.style.display="flex",a.style.marginTop="10px",a.style.marginBottom="10px"),t?r.prepend(a):r.appendChild(a),P(n(V,{isUSVersion:t,selectors:o}),a)}}var se=()=>{let e=document.querySelector(`#${_}`);e&&(e.remove(),P(null,e))};export{ae as default};
//# sourceMappingURL=init-K6SXTGWF.js.map
