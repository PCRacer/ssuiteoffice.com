/**
 * Agent Builder — utilities.
 *
 * Validation, cost computation, placeholder extraction, DOM helpers.
 * All pure functions — no state mutation, no DOM side effects.
 */

import { state, notify, cleanAgentForExport } from './state.js';
import { fetchHelper } from '/marketplace/js/shared/fetch-helper.js';
import { placeFixedPopover } from '/marketplace/js/shared/popover-position.js';
import { setStepKinds, kindCredits, stepKindOf, stepKindSpecOf, placeholderSourcesOf } from '/marketplace/js/shared/step-kinds.js';
import { COMPONENT_META } from '/marketplace/js/components/form/component-meta.js';

/* ---------------- Schema control resolution ----------------
 *
 * Given a schema key (the property name a model expects, e.g. "image_url")
 * and its property descriptor, decide which `ui_component` the editor should
 * render. The resolution mirrors what the runtime mapper does in
 * src/models/model-input-mapper.ts — the wizard would feel wrong if the
 * runner ends up showing a file uploader for `image_url` while the wizard
 * shows a textarea for the same key.
 *
 * Order, cheapest first:
 *   1. Catalog `concepts[<key>]` exists                 → use that concept's ui_component
 *   2. Some concept has `mapped_to` that includes <key> → use that concept's ui_component
 *   3. Property declares `enum`                         → 'select'
 *   4. Property `type`                                  → 'toggle' / 'input' (number) /
 *                                                          'textarea' (string fallback) /
 *                                                          'json-input' (object/array)
 *
 * Returns `{ uiComponent, source, conceptId, enum }`:
 *   - `source` ∈ 'catalog-id' | 'catalog-mapped_to' | 'enum' | 'type'
 *   - `conceptId` set when source is one of the catalog branches; useful when
 *     callers want to read further metadata (enum/range/description) from the
 *     concept.
 *   - `enum` echoed when the concept or property declares one, so the renderer
 *     doesn't have to re-derive it.
 */
export function resolveSchemaControl(key, prop) {
  const catalog = Array.isArray(state.config.catalog) ? state.config.catalog : [];
  const property = prop || {};

  // 1. Exact-id match — the most common case for canonical keys
  //    (aspect_ratio, duration, seed, …).
  const byId = catalog.find(c => c.id === key);
  if (byId && byId.ui_component) {
    return {
      uiComponent: byId.ui_component,
      source: 'catalog-id',
      conceptId: byId.id,
      enum: Array.isArray(byId.enum) ? byId.enum : (Array.isArray(property.enum) ? property.enum : null),
    };
  }

  // 2. Reverse lookup via mapped_to — provider-specific names like
  //    `image_url`, `first_frame_image`, `input_image` all map back to the
  //    canonical `image` concept.
  //
  // EXCEPTION: never resolve a key to the reserved `prompt` concept. The
  // `prompt` concept's mapped_to lists provider text keys (`text`, `gen_text`,
  // `llm_prompt`, …), but `prompt` is owned by the step's `soul`, not by a form
  // field — resolving here would wire `step.schema[key] = "${prompt}"`, which
  // points at a field that can't exist and breaks the run with "Placeholder
  // ${prompt} does not match…". A key like a TTS model's `text` must stay its
  // own key (→ custom field `${text}`), never collapse into `${prompt}`.
  for (const concept of catalog) {
    if (concept.id === 'prompt') continue;
    if (Array.isArray(concept.mapped_to) && concept.mapped_to.includes(key) && concept.ui_component) {
      return {
        uiComponent: concept.ui_component,
        source: 'catalog-mapped_to',
        conceptId: concept.id,
        enum: Array.isArray(concept.enum) ? concept.enum : (Array.isArray(property.enum) ? property.enum : null),
      };
    }
  }

  // 3. Enum on the property itself — even without a catalog hit, an enum is
  //    a closed choice list, so render a select.
  if (Array.isArray(property.enum) && property.enum.length > 0) {
    return { uiComponent: 'select', source: 'enum', conceptId: null, enum: property.enum };
  }

  // 4. Fall back to the property's JSON-Schema type.
  switch (property.type) {
    case 'boolean': return { uiComponent: 'toggle', source: 'type', conceptId: null, enum: null };
    case 'integer':
    case 'number':  return { uiComponent: 'input',  source: 'type', conceptId: null, enum: null };
    case 'array':
    case 'object':  return { uiComponent: 'json-input', source: 'type', conceptId: null, enum: null };
    case 'string':
    default:        return { uiComponent: 'textarea', source: 'type', conceptId: null, enum: null };
  }
}

/* ---------------- Auto-field detour (Pass 4 → Pass 3 sync) ----------------
 *
 * When a step's schema declares a key that has a canonical concept in
 * AGENT_INPUT_MAP, the wizard treats that as a strong signal: the end user
 * will need a form control for it (an `image_url` is something the end user
 * uploads, an `aspect_ratio` is something they pick). The author shouldn't
 * have to manually duplicate that wiring across passes.
 *
 * `ensureFieldForKey` is the bridge. Given a schema key + its property
 * descriptor:
 *
 *   - If `resolveSchemaControl` finds a catalog match, ensure a compact
 *     `{ id: <conceptId> }` entry exists in `state.agent.fields`. The
 *     resolver carries the conceptId; we use that as the field id so the
 *     mapper (and `${conceptId}` placeholders) all agree on naming.
 *
 *   - Returns `{ fieldId, added }`. `fieldId` is the canonical id to wire
 *     `step.schema[key] = '${' + fieldId + '}'`. `added` tells the caller
 *     whether a *new* field landed in `fields[]` this call (so the wizard
 *     can decide to detour to Pass 3 to show what changed).
 *
 *   - Returns `null` when the key has no catalog match. The caller leaves
 *     the value alone (literal entry / textarea fallback).
 *
 * Newly-added fields are tagged with `__autoAdded: true` so Pass 3 can
 * highlight them. The flag is `__`-prefixed and stripped from the export.
 */
export function ensureFieldForKey(key, prop) {
  const resolved = resolveSchemaControl(key, prop);
  if (!resolved.conceptId) return null;
  const conceptId = resolved.conceptId;

  // Already present (catalog entry or custom field with same id)?
  const existing = state.agent.fields.find(f => f.id === conceptId);
  if (existing) {
    return { fieldId: conceptId, added: false };
  }

  // Add a compact catalog entry. Defaults flow through from AGENT_INPUT_MAP
  // at render time — we don't snapshot anything here.
  state.agent.fields.push({ id: conceptId, __autoAdded: true });
  return { fieldId: conceptId, added: true };
}

/**
 * Scan a free-form string (typically a prompt template or any textarea-shaped
 * schema value) for `${id}` placeholders and auto-promote any unknown id into
 * a custom string field. The author's typing flow is:
 *
 *   "make it ${shadowPrompt}, with ${lighting}"
 *
 * — the moment they type `${shadowPrompt}`, the wizard recognizes that as an
 * intent to wire a form value in, and synthesizes a custom textarea field
 * `shadowPrompt` so Pass 3 has somewhere to capture the user's input. Ids
 * that already resolve (an existing field, an upstream output_id from the
 * same agent) are left alone.
 *
 * Returns the array of `field_id`s newly added. Callers (the textarea/input
 * `oninput` handlers) can ignore the value or use it to flash a toast.
 *
 * `upstreamOutputIds` lets callers pass the set of output ids that count as
 * "already known" — usually `state.agent.steps.map(s => s.output_id)`.
 */
// Placeholder ids the wizard refuses to synthesize a field for. `prompt` is
// reserved: the model's `schema.prompt` slot is filled by the resolver from
// `step.soul` at runtime — having a form field also named `prompt` would
// create a conflicting second source of truth.
const RESERVED_PLACEHOLDER_IDS = new Set(['prompt']);

// Placeholder-token patterns, in one place so the allowed id charset evolves
// uniformly. Two variants exist: the plain one (field/output ids) and the
// dot-path one (`${research.priceTrend}` — a content-research output's
// sub-fields). Returned as fresh instances from a factory because a shared
// `/g` regex carries `lastIndex` between calls and would desync reuse.
const PLACEHOLDER_CHARS = 'a-zA-Z0-9_-';
const PLACEHOLDER_DOT_CHARS = 'a-zA-Z0-9_.-';
/** Fresh global matcher for `${id}` tokens (dot-paths optional). */
const placeholderMatcher = (dotPaths = false) =>
  new RegExp('\\$\\{([' + (dotPaths ? PLACEHOLDER_DOT_CHARS : PLACEHOLDER_CHARS) + ']+)\\}', 'g');
/** Tests whether a string CONTAINS a dot-path-capable `${id}` token. */
const CONTAINS_DOT_PLACEHOLDER_RE = new RegExp('\\$\\{[' + PLACEHOLDER_DOT_CHARS + ']+\\}');

export function autoPromotePlaceholdersFromText(text, upstreamOutputIds = []) {
  if (typeof text !== 'string') return [];
  const known = new Set([
    ...state.agent.fields.map(f => f.id),
    ...upstreamOutputIds.filter(Boolean),
  ]);
  const added = [];
  const re = placeholderMatcher();
  let m;
  while ((m = re.exec(text)) !== null) {
    const id = m[1];
    if (RESERVED_PLACEHOLDER_IDS.has(id)) continue;
    if (known.has(id)) continue;
    // Skip canonical concept ids that have a catalog match — they should
    // route through `ensureFieldForKey` so they pick up the catalog's
    // ui_component (file-upload, select, etc.), not a default textarea.
    const resolved = resolveSchemaControl(id, null);
    if (resolved.conceptId) {
      const ensured = ensureFieldForKey(id, null);
      if (ensured?.added) {
        added.push(ensured.fieldId);
        known.add(ensured.fieldId);
      } else if (ensured) {
        known.add(ensured.fieldId);
      }
      continue;
    }
    // Pure custom string field — author wrote `${something_arbitrary}` in a
    // prompt. Seed as a textarea so the user can type free-form text.
    state.agent.fields.push({
      __custom: true,
      __autoAdded: true,
      id,
      title: id.replace(/[_-]+/g, ' ').replace(/\b\w/g, c => c.toUpperCase()),
      description: '',
      type: 'string',
      ui_component: 'textarea',
      default: null,
      visible: true,
      advanced: false,
      step: false,
    });
    known.add(id);
    added.push(id);
  }
  return added;
}

/* ---------------- Cost floor ---------------- */

/**
 * A step's USD range [cheapest, dearest] over every value its fields allow — its model's price sheet priced by
 * the shared engine (credits.js → getBuilderDraftStepUsdRange), literals as written, author multipliers at their
 * range ends. The server's publish floor runs the same function.
 */
export function stepFloorUsd(step) {
  const fn = window.AitopiaCredits?.getBuilderDraftStepUsdRange;
  if (typeof fn !== 'function' || !step) return { min: 0, max: 0 };
  return fn(step, state.agent.fields, state.config.models);
}

/**
 * Per-step floor breakdown. The sidebar uses this to show one line per step
 * (and a total). It also surfaces whether the step is a checkpoint, so the
 * UI can label regenerate-eligible steps.
 */
export function stepwiseFloorUsd() {
  return state.agent.steps.map((s, idx) => ({
    index: idx,
    model_id: s.model_id,
    kind: s.kind,
    isCheckpoint: !!s.step,
    isFinal: idx === state.agent.steps.length - 1,
    ...stepFloorUsd(s),
  }));
}

export function totalFloorUsd() {
  let min = 0, max = 0;
  for (const s of state.agent.steps) {
    const { min: a, max: b } = stepFloorUsd(s);
    min += a; max += b;
  }
  return { min, max };
}

/**
 * Platform margin multiplier from /config billing (BUILDER_PRICE_MARGIN).
 * Marks builder products up over raw model cost. Default 1 (no markup);
 * values below 1 are ignored. Mirror of server getBuilderPriceMargin().
 */
export function priceMargin() {
  const m = Number(state.config.billing?.priceMargin);
  return Number.isFinite(m) && m >= 1 ? m : 1;
}

/** The doc's agent-group step and its selector field, or null. */
export function agentGroupOf(doc = state.agent) {
  const step = (doc?.steps || []).find(s => s?.kind === 'agent-group');
  if (!step) return null;
  return { step, field: (doc.fields || []).find(f => f?.id === step.field_id) || {} };
}

const _groupQuotes = new Map();

/** Every mode's price, quoted by the server since each lives on that mode's
 *  agent. Undefined without a group, null until quoted. */
export function agentGroupModes() {
  const g = agentGroupOf();
  if (!g) return undefined;
  const key = JSON.stringify([g.step.options, g.field.enum]);
  const modes = _groupQuotes.get(key);
  if (!modes) {
    _groupQuotes.set(key, fetchHelper('https://aitopia.ai/api/agent-builder/agent-group-quote', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ agent: cleanAgentForExport(state.agent) }),
    })
      .then(r => r.json())
      .then(j => { _groupQuotes.set(key, j?.ok ? j.modes || {} : {}); notify(); })
      .catch(() => { _groupQuotes.set(key, {}); }));
  }
  return !modes || modes instanceof Promise ? null : modes;
}

/** The group's price: the tested pick's alone, else every mode's min–max. */
export function agentGroupRange() {
  const modes = agentGroupModes();
  if (!modes) return modes;
  const picked = modes[state.testInputs?.[agentGroupOf().step.field_id]];
  const all = picked > 0 ? [picked] : Object.values(modes).filter(n => n > 0);
  return all.length ? { min: Math.min(...all), max: Math.max(...all) } : null;
}

/** Badge text for the group's price; undefined without a group. */
export function agentGroupCreditsLabel() {
  const r = agentGroupRange();
  if (r === undefined) return undefined;
  if (!r) return '';
  return r.min === r.max ? String(r.min) : `${r.min}–${r.max}`;
}

export function floorCredits() {
  // A group page is served as its mode's agent, so that agent's price is the floor.
  const group = agentGroupRange();
  if (group !== undefined) return group?.min ?? 0;
  const usdPerCredit = Number(state.config.billing?.usdPerCredit || 0.02);
  if (!Number.isFinite(usdPerCredit) || usdPerCredit <= 0) return 0;
  // Single math source (shared with the store/preview surfaces): price each
  // model step at its LOWEST allowed field value, honour LITERAL values baked
  // into the step schema, and apply the platform margin. content-research steps
  // keep their kind-catalog credits. See getBuilderDraftFloorCredits in
  // public/js/shared/credits.js.
  const fn = window.AitopiaCredits?.getBuilderDraftFloorCredits;
  if (typeof fn === 'function') {
    return fn({
      steps: state.agent.steps,
      fields: state.agent.fields,
      models: state.config.models,
      usdPerCredit,
      margin: priceMargin(),
      kindCreditsFn: kindStepCredits,
    });
  }
  // credits.js (and the engine) not loaded yet: nothing to price with.
  return 0;
}

// Fallback anchors, used only if /config didn't carry billing.pricingBands.
// Server copy (the source of truth) is PRICING_BANDS in agent-builder.ts.
const PRICING_BANDS_FALLBACK = {
  minMultiplier: 1.3,
  ceilingMultiplier: 1.2,
  ceilingFlat: 3000,
  hardStop: 9000,
  anchors: [[80, 2.0, 5.0], [250, 1.5, 4.0], [500, 1.3, 3.0]],
};

/**
 * Pricing band for a floor: { min, suggested, max, collapsed, blocked }.
 * Mirror of builderPricingBand() in src/api/routes/agent-builder.ts — see
 * docs/AGENT-BUILDER-FLOOR-CREDIT-PRICING-BANDS.md.
 */
export function pricingBand(floor = floorCredits()) {
  const B = state.config?.billing?.pricingBands || PRICING_BANDS_FALLBACK;
  if (!Number.isFinite(floor) || floor <= 0) {
    return { floor: 0, min: 0, suggested: 0, max: 0, collapsed: false, blocked: false };
  }
  if (floor > B.hardStop) {
    return { floor, min: 0, suggested: 0, max: 0, collapsed: false, blocked: true };
  }
  const pick = (idx) => {
    const a = B.anchors;
    if (floor <= a[0][0]) return a[0][idx];
    for (let i = 1; i < a.length; i++) {
      if (floor <= a[i][0]) {
        const x0 = a[i - 1][0], y0 = a[i - 1][idx], x1 = a[i][0], y1 = a[i][idx];
        return y0 + (y1 - y0) * (Math.log(floor / x0) / Math.log(x1 / x0));
      }
    }
    return a[a.length - 1][idx];
  };
  const ceiling = Math.min(Math.max(B.ceilingFlat, Math.ceil(floor * B.ceilingMultiplier)), B.hardStop);
  const max = Math.min(Math.ceil(floor * pick(2)), ceiling);
  const min = Math.min(Math.ceil(floor * B.minMultiplier), max);
  const suggested = Math.min(Math.max(Math.ceil(floor * pick(1)), min), max);
  return { floor, min, suggested, max, collapsed: min === max, blocked: false };
}

export function kindStepCredits(step) {
  if (Array.isArray(state.config?.stepKinds) && state.config.stepKinds.length) {
    setStepKinds(state.config.stepKinds);
  }
  return kindCredits(step);
}

/**
 * Convert a step's USD range to credits. Reused by the sidebar breakdown and
 * by Pass 4 publish gating.
 */
export function usdToCredits(usd) {
  const usdPerCredit = Number(state.config.billing?.usdPerCredit || 0.02);
  if (!Number.isFinite(usdPerCredit) || usdPerCredit <= 0) return 0;
  const engine = globalThis.AitopiaPricingEngine;
  return engine ? engine.creditsForUsd(Math.max(0, usd), usdPerCredit) : Math.ceil(usd / usdPerCredit);
}

/* ---------------- Placeholder discovery ---------------- */

/**
 * Walk a step's schema object collecting every ${id} placeholder. Returns the unique
 * set of ids referenced. Used both for validation (every id must resolve) and for
 * the prompt-editor tag rows.
 */
export function placeholdersInSchema(schema) {
  const found = new Set();
  const stack = [schema];
  while (stack.length) {
    const v = stack.pop();
    if (typeof v === 'string') {
      const re = placeholderMatcher();
      let m;
      while ((m = re.exec(v)) !== null) found.add(m[1]);
    } else if (Array.isArray(v)) {
      for (const item of v) stack.push(item);
    } else if (v && typeof v === 'object') {
      for (const item of Object.values(v)) stack.push(item);
    }
  }
  return Array.from(found);
}

/* ---------------- Per-pass validation ---------------- */

export function validateMetadata() {
  const errors = [];
  const a = state.agent;
  if (!a.id || !/^[a-z0-9][a-z0-9-]*$/.test(a.id)) errors.push('ID must be kebab-case (a-z, 0-9, dash).');
  else if (state.idTaken) errors.push(`ID "${a.id}" is already used by a published agent. Pick a different id.`);
  if (!a.name.trim()) errors.push('Name is required.');
  // version is server-owned (read-only in the UI); we don't validate it here.
  if (!a.description.trim()) errors.push('Description is required.');
  if (!a.category.trim()) errors.push('Category is required.');
  return errors;
}

export function validateTemplate() {
  const errors = [];
  if (!state.config.templates.includes(state.agent.template)) {
    errors.push(`Template must be one of: ${state.config.templates.join(', ')}.`);
  }
  return errors;
}

/**
 * For a field row, return the effective enum if any. Catalog fields inherit
 * their concept's enum unless the author has narrowed it; custom fields read
 * their own. Returns `null` when no enum applies.
 */
function effectiveEnumFor(field) {
  if (field.__custom) {
    return Array.isArray(field.enum) && field.enum.length ? field.enum : null;
  }
  const concept = state.config.catalog.find(c => c.id === field.id);
  const base = Array.isArray(concept?.enum) ? concept.enum : null;
  const override = Array.isArray(field.enum) ? field.enum : null;
  const eff = override ?? base;
  return Array.isArray(eff) && eff.length ? eff : null;
}

export function validateFields() {
  const errors = [];
  const seen = new Set();
  for (const f of state.agent.fields) {
    if (!f.id || !/^[a-zA-Z0-9_-]+$/.test(f.id)) errors.push(`Field "${f.id}" has an invalid id.`);
    if (seen.has(f.id)) errors.push(`Duplicate field id: ${f.id}`);
    seen.add(f.id);
    // `field.step` (wizard-form gating) is no longer template-gated — it's
    // valid under every template now. The old V2-only check has been removed.

    // Enum-locked default: when a field declares an enum, its `default` MUST
    // be one of those values (or null/absent). The wizard's editor already
    // renders a <select> for enum defaults, but a stale value from before the
    // enum was narrowed could still slip through — catch it here.
    const enumOpts = effectiveEnumFor(f);
    if (enumOpts && f.default != null && f.default !== '') {
      const allowed = enumOpts.map(String);
      // A multi-valued control stores its picks as one comma-separated string,
      // so each part is checked on its own. Mirrors validateAgent on the server.
      const spec = COMPONENT_META.find(c => c.id === f.ui_component);
      const multiValued = f.type === 'array' || spec?.types.includes('array');
      // Array when the field editor wrote it, comma-joined string when the
      // component saved its own state. Both mean "several picks".
      const parts = Array.isArray(f.default)
        ? f.default.map(v => String(v).trim()).filter(Boolean)
        : multiValued && typeof f.default === 'string'
          ? f.default.split(',').map(v => v.trim()).filter(Boolean)
          : [String(f.default)];
      // An editable select exists to accept values outside its own list.
      const stray = f.ui_component === 'editable-select'
        ? []
        : parts.filter(v => !allowed.includes(v));
      if (stray.length) {
        // A default that reads as several enum values joined by commas means the
        // control is wrong, not the value — say that instead of listing an enum
        // that visibly contains what the author typed.
        const severalValid = Array.isArray(f.default)
          ? f.default.length > 1 && f.default.every(v => allowed.includes(String(v).trim()))
          : typeof f.default === 'string'
            && f.default.includes(',')
            && f.default.split(',').every(v => allowed.includes(v.trim()));
        errors.push(severalValid
          ? `Field "${f.id}": default holds several values, but "${f.ui_component}" takes one. Use multi-select (type: "array") for several, or pick a single default.`
          : `Field "${f.id}": default ${stray.map(v => `"${v}"`).join(', ')} not in enum [${enumOpts.join(', ')}].`);
      }
    }
  }
  return errors;
}

export function validateSteps() {
  const errors = [];
  const steps = state.agent.steps;
  if (steps.length === 0) errors.push('Add at least one step.');
  // Mirror the server cap (env AGENT_BUILDER_MAX_STEPS) so the client never
  // rejects a pipeline publish would accept.
  const maxSteps = Number(state.config?.maxSteps);
  if (Number.isFinite(maxSteps) && maxSteps > 0 && steps.length > maxSteps) {
    errors.push(`Maximum ${maxSteps} steps allowed.`);
  }

  const fieldIds = new Set(state.agent.fields.map(f => f.id));
  const allOutputs = new Set(steps.map(x => x.output_id).filter(Boolean));
  // Collect every ${id} (dot-paths allowed) reachable from a value tree.
  const collectRefs = (node, acc) => {
    if (typeof node === 'string') {
      const re = placeholderMatcher(true);
      let m;
      while ((m = re.exec(node)) !== null) acc.push(m[1]);
    } else if (Array.isArray(node)) {
      node.forEach(v => collectRefs(v, acc));
    } else if (node && typeof node === 'object') {
      Object.values(node).forEach(v => collectRefs(v, acc));
    }
    return acc;
  };
  const outputIds = new Set();
  steps.forEach((s, i) => {
    const kind = stepKindOf(s);
    const spec = stepKindSpecOf(kind);
    // No single model_id, but it wires a schema: it takes the model checks below.
    const isSelector = kind === 'model-selector';
    const picksModel = kind === 'model' || spec?.picksModel === true || isSelector;

    if (isSelector) {
      const rows = Array.isArray(s.models) ? s.models.filter(r => r && r.id) : [];
      if (rows.length === 0) errors.push(`Step ${i + 1}: add at least one model to choose from.`);
      else if (!s.default_model) errors.push(`Step ${i + 1}: pick which model runs by default.`);
    } else if (picksModel && !s.model_id) {
      errors.push(`Step ${i + 1}: pick a model.`);
    }
    if (!s.output_id) errors.push(`Step ${i + 1}: set an output_id.`);
    else {
      if (outputIds.has(s.output_id)) errors.push(`Step ${i + 1}: duplicate output_id "${s.output_id}".`);
      if (fieldIds.has(s.output_id)) errors.push(`Step ${i + 1}: output_id "${s.output_id}" collides with a field id.`);
      outputIds.add(s.output_id);
    }

    if (!picksModel) {
      // Placeholder roots across every declared field; a dot-path only needs
      // its root to be known.
      const refs = [];
      for (const source of placeholderSourcesOf(s)) collectRefs(source, refs);
      for (const ref of refs) {
        const root = ref.split('.')[0];
        if (!fieldIds.has(root) && !allOutputs.has(root)) {
          errors.push(`Step ${i + 1}: unresolved \${${ref}}.`);
        }
      }
      return; // non-model kind done
    }

    if (!s.schema || typeof s.schema !== 'object') {
      errors.push(`Step ${i + 1}: schema is empty.`);
    } else {
      // Placeholder resolution covers both the schema values AND the soul
      // (the wizard's top-level prompt for this step). Auto-promote handles
      // the typing path; this is the safety net for hand-edited imports or
      // edge cases the proactive scan missed.
      const refs = placeholdersInSchema(s.schema);
      if (typeof s.soul === 'string' && s.soul) {
        const re = placeholderMatcher(true);
        let m;
        while ((m = re.exec(s.soul)) !== null) refs.push(m[1]);
      }
      for (const ref of refs) {
        const root = ref.split('.')[0];
        if (!fieldIds.has(root) && !allOutputs.has(root)) {
          errors.push(`Step ${i + 1}: unresolved \${${ref}}.`);
        }
      }
      // Enum-locked literal: when the model's schema declares an enum for a
      // key and the author wrote a literal value (not a placeholder), it must
      // be in the enum. Placeholders bypass this check because their runtime
      // value isn't known at edit time — the runner validates them.
      const props = s.__schemaMeta?.properties || {};
      for (const [key, value] of Object.entries(s.schema)) {
        const prop = props[key];
        if (!prop || !Array.isArray(prop.enum) || prop.enum.length === 0) continue;
        if (typeof value === 'string' && CONTAINS_DOT_PLACEHOLDER_RE.test(value)) continue; // placeholder
        if (value == null || value === '') continue; // empty (optional unset)
        if (!prop.enum.map(String).includes(String(value))) {
          errors.push(`Step ${i + 1}: ${key} = "${value}" is not in enum [${prop.enum.join(', ')}].`);
        }
      }
    }
  });
  if (steps.length > 0 && steps[steps.length - 1].step === true) {
    errors.push('The final step must be silent (step=false).');
  }
  return errors;
}

export function validateCredits() {
  const errors = [];
  const floor = floorCredits();
  const band = pricingBand(floor);
  if (band.blocked) {
    const hardStop = (state.config?.billing?.pricingBands || PRICING_BANDS_FALLBACK).hardStop;
    errors.push(`Provider cost is ${floor} credits, above the ${hardStop}-credit ceiling. This agent cannot be published — reduce cost (fewer steps, cheaper models, shorter durations).`);
    return errors;
  }
  if (!Number.isFinite(state.creditsPerRun) || state.creditsPerRun < band.min) {
    errors.push(`Credits per run must be at least ${band.min}.`);
  } else if (state.creditsPerRun > band.max) {
    errors.push(`Credits per run must be at most ${band.max}.`);
  }
  return errors;
}

/* ---------------- Derived fields ---------------- */

/** The MIME an agent declares for a model's media type (text declares none). */
const MEDIA_TYPE_MIME = { video: 'video/mp4', image: 'image/png', audio: 'audio/mpeg' };

export function recomputeDerived() {
  // inputTypes: union of file-upload field kinds; default to "text"
  const inputTypes = new Set();
  for (const f of state.agent.fields) {
    if (f.ui_component === 'file-upload') inputTypes.add('image'); // safe default
  }
  if (inputTypes.size === 0) inputTypes.add('text');
  state.agent.inputTypes = Array.from(inputTypes);

  // outputTypes: from the final step's model — its capability media type, else its tags
  const out = new Set();
  const last = state.agent.steps[state.agent.steps.length - 1];
  if (last) {
    const model = state.config.models.find(m => m.id === last.model_id);
    if (model?.mediaType) {
      if (MEDIA_TYPE_MIME[model.mediaType]) out.add(MEDIA_TYPE_MIME[model.mediaType]);
    } else if (model?.tags) {
      for (const t of model.tags) {
        if (/^video/.test(t)) out.add('video/mp4');
        if (/^image/.test(t)) out.add('image/png');
        if (/^audio/.test(t)) out.add('audio/mpeg');
      }
    }
  }
  state.agent.outputTypes = Array.from(out);

  // costEstimate
  const { min, max } = totalFloorUsd();
  const usdPerCredit = Number(state.config.billing?.usdPerCredit || 0.02);
  const creditsUsd = state.creditsPerRun * usdPerCredit;
  state.agent.costEstimate = {
    minCost: Number(min.toFixed(6)),
    maxCost: Number((max + Math.max(creditsUsd - min, 0)).toFixed(6)),
    currency: 'USD',
  };
}

/* ---------------- DOM helpers ---------------- */

export function $(sel, root = document) { return root.querySelector(sel); }
export function $$(sel, root = document) { return Array.from(root.querySelectorAll(sel)); }

export function el(tag, attrs = {}, ...children) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === 'class') node.className = v;
    else if (k === 'dataset') Object.assign(node.dataset, v);
    else if (k.startsWith('on') && typeof v === 'function') node.addEventListener(k.slice(2).toLowerCase(), v);
    else if (v === true) node.setAttribute(k, '');
    else if (v === false || v == null) { /* skip */ }
    else node.setAttribute(k, String(v));
  }
  for (const c of children.flat()) {
    if (c == null || c === false) continue;
    node.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
  }
  return node;
}

export function toast(msg, kind = 'info', ms = 3000) {
  const node = document.getElementById('ab-toast');
  if (!node) return;
  node.textContent = msg;
  node.className = 'ab-toast visible' + (kind ? ' ' + kind : '');
  setTimeout(() => { node.className = 'ab-toast'; }, ms);
}

export function confirmModal({
  title = 'Are you sure?',
  message = '',
  confirmLabel = 'OK',
  cancelLabel = 'Cancel',
  danger = false,
} = {}) {
  return new Promise((resolve) => {
    const prev = document.getElementById('ab-modal-confirm');
    if (prev) {
      if (typeof prev._abDismiss === 'function') prev._abDismiss();
      else prev.remove();
    }
    const back = el('div', { class: 'ab-modal-back visible', id: 'ab-modal-confirm', 'aria-hidden': 'false' });
    const onKey = (e) => { if (e.key === 'Escape') done(false); };
    let settled = false;
    const done = (val) => {
      if (settled) return;
      settled = true;
      document.removeEventListener('keydown', onKey);
      back.remove();
      resolve(val);
    };
    back._abDismiss = () => done(false);
    back.addEventListener('click', (e) => { if (e.target === back) done(false); });
    document.addEventListener('keydown', onKey);

    const confirmStyle = danger
      ? 'background:#E94242; border:none; color:#FFFFFF; border-radius:12px; font-weight:700; padding:0.6rem 1.15rem;'
      : 'background:var(--ab-gradient); border:none; color:#FFFFFF; border-radius:12px; font-weight:700; padding:0.6rem 1.15rem;';
    const cancelBtn = el('button', {
      class: 'btn', type: 'button',
      style: 'background:transparent; border:none; color:var(--ab-text); font-weight:600;',
      onclick: () => done(false),
    }, cancelLabel);
    const modal = el('div', { class: 'ab-modal', style: 'max-width: 440px;', role: 'alertdialog', 'aria-modal': 'true' },
      el('h3', { class: 'text-lg font-bold mb-2' }, title),
      message ? el('p', { class: 'text-sm mb-4', style: 'color:var(--ab-muted); line-height:1.5;' }, message) : null,
      el('div', { class: 'flex justify-end gap-2 items-center' },
        cancelBtn,
        el('button', { class: 'btn', type: 'button', style: confirmStyle, onclick: () => done(true) }, confirmLabel),
      ),
    );
    back.appendChild(modal);
    document.body.appendChild(back);
    cancelBtn.focus();
  });
}

export function installDarkSelectDropdowns() {
  let pop = null;
  let openFor = null;
  const close = () => { pop?.remove(); pop = null; openFor = null; };
  const closeIfDetached = () => { if (openFor && !openFor.isConnected) close(); };

  const open = (sel) => {
    close();
    pop = el('div', { class: 'ab-select-pop', role: 'listbox' });
    openFor = sel;
    [...sel.options].forEach((opt, i) => {
      const value = opt.value;
      const item = el('button', {
        type: 'button',
        class: 'ab-select-pop-item' + (i === sel.selectedIndex ? ' selected' : ''),
        disabled: opt.disabled ? 'disabled' : null,
        onclick: () => {
          if (!sel.isConnected) { close(); return; }
          const idx = [...sel.options].findIndex((o) => o.value === value);
          if (idx === -1) { close(); return; } // option no longer exists
          if (sel.selectedIndex !== idx) {
            sel.selectedIndex = idx;
            sel.dispatchEvent(new Event('input', { bubbles: true }));
            sel.dispatchEvent(new Event('change', { bubbles: true }));
          }
          close();
          sel.focus();
        },
      }, opt.textContent);
      pop.appendChild(item);
    });
    pop.hidden = true;
    document.body.appendChild(pop);

    placeFixedPopover(pop, sel, { matchWidth: true, gap: 4 });
    pop.querySelector('.selected')?.scrollIntoView({ block: 'nearest' });
  };

  document.addEventListener('mousedown', (e) => {
    closeIfDetached();
    const sel = e.target.closest?.('select');
    if (!sel) {
      if (pop && !e.target.closest('.ab-select-pop')) close();
      return;
    }
    if (sel.disabled || sel.multiple) return;
    e.preventDefault();
    sel.focus();
    if (openFor === sel) { close(); return; }
    open(sel);
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { close(); return; }
    if (pop && e.target.closest?.('.ab-select-pop')) {
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        const items = [...pop.querySelectorAll('.ab-select-pop-item:not([disabled])')];
        const at = items.indexOf(document.activeElement);
        const next = items[at + (e.key === 'ArrowDown' ? 1 : -1)] || items[e.key === 'ArrowDown' ? 0 : items.length - 1];
        next?.focus();
      }
      return;
    }
    const sel = e.target.closest?.('select');
    if (!sel || sel.disabled || sel.multiple) return;
    if (e.key === ' ' || e.key === 'Enter' || e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault();
      if (openFor === sel) { close(); return; }
      open(sel);
      (pop.querySelector('.ab-select-pop-item.selected') || pop.querySelector('.ab-select-pop-item'))?.focus();
    }
  });
  window.addEventListener('scroll', (e) => {
    if (!pop) return;
    if (e.target instanceof Node && pop.contains(e.target)) return;
    close();
  }, { capture: true, passive: true });
  window.addEventListener('resize', close);
}

// Insufficient-credits (402) helper. Builds the message from the server's
// credit numbers and opens the shared pricing modal, same as the store runner.
export function isInsufficientCredits(status, json) {
  return status === 402 && json?.code !== 'QUEUE_LIMIT_EXCEEDED';
}

export function insufficientCreditsMessage(json) {
  const required = Number(json?.requiredCredits);
  const available = Number(json?.availableCredits);
  if (Number.isFinite(required) && Number.isFinite(available)) {
    return `Insufficient credits — this needs ${required} credit${required === 1 ? '' : 's'} but you have ${available}. Upgrade your plan to keep creating.`;
  }
  return json?.error || 'Insufficient credits. Upgrade your plan to keep creating.';
}

export function openPricingModal() {
  if (typeof window.__pricingModal === 'function') {
    setTimeout(() => window.__pricingModal(), 0);
    return;
  }
  import('/marketplace/js/shared/pricing-modal.js')
    .then((m) => { window.__pricingModal = m.pricingModal; m.pricingModal(); })
    .catch(() => {});
}

export function ensureSignedIn(message) {
  return import('/marketplace/js/shared/login-modal.js')
    .then((m) => m.ensureSignedIn({ message }))
    .catch(() => false);
}
