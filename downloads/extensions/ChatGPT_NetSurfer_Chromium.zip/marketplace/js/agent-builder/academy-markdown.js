/**
 * Lesson body renderer, shared by the public lesson page (through academy.js)
 * and the admin editor's preview, so what the editor sees is what ships.
 *
 * micromark (CommonMark, vendored at public/vendor/micromark.esm.js by
 * scripts/vendor-micromark.mjs) does the parsing. Raw HTML is never emitted,
 * and the constructs moderators do not need are switched off so they stay
 * literal text: inline HTML, indented code, reference links, setext
 * underlines. Bare https links come from the GFM autolink extension. Before
 * the compiler runs, the event stream is walked once: a link that is not
 * http(s) or has no text, an image off our own CDN (S81) and an e-mail
 * autolink become the text they were typed as, and a newline inside a
 * paragraph becomes a line break (S74). The HTML then gets the page's shape:
 * headings start at h2, links carry rel, images lazy-load.
 */

import {
  compile, gfmAutolinkLiteral, gfmAutolinkLiteralHtml, parse, postprocess, preprocess,
} from '../../vendor/micromark.esm.js';

export function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
  ));
}

const OPTIONS = {
  extensions: [
    gfmAutolinkLiteral(),
    { disable: { null: ['codeIndented', 'definition', 'htmlFlow', 'htmlText', 'setextUnderline'] } },
  ],
  htmlExtensions: [gfmAutolinkLiteralHtml()],
};

export function renderLessonBody(markdown) {
  // micromark keeps the line endings it is given; one kind keeps the output stable.
  const source = String(markdown || '').replace(/\r\n?/g, '\n');
  if (!source.trim()) return '';
  const events = postprocess(parse(OPTIONS).document().write(preprocess()(source, undefined, true)));
  return shape(compile(OPTIONS)(rewrite(events)));
}

/**
 * Where a lesson image may come from: https, aitopia.ai or a subdomain (the
 * CDN), a path ending in an image extension, nothing after it. Anything else
 * stays text, so notes can never embed a foreign picture or a tracking pixel.
 */
const LESSON_IMAGE = /^https:\/\/(?:[a-z0-9-]+\.)*aitopia\.ai\/[^\s?#]*\.(?:png|jpe?g|gif|webp)$/i;

export function isLessonImageUrl(url) {
  return LESSON_IMAGE.test(String(url || ''));
}

const LINK_URL = /^https?:\/\//i;
const MEDIA = new Set(['link', 'image', 'literalAutolink', 'autolink']);
const BREAKS = new Set(['hardBreakTrailing', 'hardBreakEscape']);

/** Index of the event that closes the token opened at `start`. */
function closing(events, start) {
  const token = events[start][1];
  let i = start + 1;
  while (i < events.length && events[i][1] !== token) i += 1;
  return i;
}

/** Index of the first `type` opened in [from, to), or -1. */
function find(events, type, from, to) {
  for (let i = from; i < to; i += 1) if (events[i][0] === 'enter' && events[i][1].type === type) return i;
  return -1;
}

const text = (events, i) => events[i][2].sliceSerialize(events[i][1]);

/** A link with text and an http(s) address, an image from our CDN, a bare or <bracketed> http(s) link. */
function allowed(events, start, end) {
  const { type } = events[start][1];
  if (type === 'literalAutolink') return find(events, 'literalAutolinkEmail', start, end) === -1;
  if (type === 'autolink') {
    const protocol = find(events, 'autolinkProtocol', start, end);
    return protocol !== -1 && LINK_URL.test(text(events, protocol));
  }
  // The media's own label closes before its resource; an image nested in a
  // link label carries its own destination in there and is judged on its own.
  const labelEnd = closing(events, find(events, 'label', start, end));
  const destination = find(events, 'resourceDestinationString', labelEnd, end);
  const url = destination === -1 ? '' : text(events, destination);
  if (type === 'image') return isLessonImageUrl(url);
  const label = find(events, 'labelText', start, labelEnd);
  return LINK_URL.test(url) && label !== -1 && text(events, label).trim() !== '';
}

/**
 * The policy pass. A rejected construct becomes one `data` token over its
 * whole span, which the compiler prints as the escaped source text. A
 * `lineEnding` inside a paragraph gets a hard break in front of it, unless
 * one is already there; inside a code span or a link's resource it is left
 * alone, where a break would land in the wrong place.
 */
function rewrite(events) {
  const out = [];
  let paragraph = 0;
  let verbatim = 0;
  for (let i = 0; i < events.length; i += 1) {
    const [kind, token, context] = events[i];
    if (kind === 'enter' && MEDIA.has(token.type)) {
      const end = closing(events, i);
      if (!allowed(events, i, end)) {
        const literal = { type: 'data', start: token.start, end: token.end };
        out.push(['enter', literal, context], ['exit', literal, context]);
        i = end;
        continue;
      }
    }
    const step = kind === 'enter' ? 1 : -1;
    if (token.type === 'paragraph') paragraph += step;
    if (token.type === 'codeText' || token.type === 'resource') verbatim += step;
    if (kind === 'enter' && token.type === 'lineEnding' && paragraph > 0 && verbatim === 0) {
      const previous = out[out.length - 1];
      if (!(previous?.[0] === 'exit' && BREAKS.has(previous[1].type))) {
        const brk = { type: 'hardBreakTrailing', start: token.start, end: token.start };
        out.push(['enter', brk, context], ['exit', brk, context]);
      }
    }
    out.push(events[i]);
  }
  return out;
}

/**
 * micromark's HTML in the page's shape. Every `<` in text is encoded by the
 * compiler, so these tags can only be its own. Headings drop one level since
 * the lesson title is the page's h2, and stop at h4. Titles are dropped: the
 * editor has no way to write one and the whitelist has no room for it.
 */
function shape(html) {
  return html
    .replace(/<(\/?)h([1-6])>/g, (_, close, level) => `<${close}h${Math.min(Number(level) + 1, 4)}>`)
    .replace(/<a href="([^"]*)"(?: title="[^"]*")?>/g, '<a href="$1" rel="noopener noreferrer">')
    .replace(/<img src="([^"]*)" alt="([^"]*)"(?: title="[^"]*")? \/>/g, '<img src="$1" alt="$2" loading="lazy" decoding="async" />');
}
