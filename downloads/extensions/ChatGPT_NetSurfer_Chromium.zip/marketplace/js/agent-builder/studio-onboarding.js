/**
 * Studio onboarding: the Academy's entry points inside the builder.
 *
 * Three surfaces, all additive to the Studio empty state: the slide carousel,
 * the `See How It Works` video modal, and the dismissible coach-mark. The modal
 * writes the same progress key the Academy reads, so a lesson watched here
 * counts there.
 */

import { ACADEMY_URL, formatDuration, loadAcademy, openVideoModal } from './academy.js';

const COACH_DISMISSED_KEY = 'aitopia.academy.coach.v1';
const TOOLTIP_VIDEO = 'https://cdn.aitopia.ai/storages/1/main/files/studio-tooltip-1080-v1.mp4';
const SLIDE_INTERVAL_MS = 7000;
const HOVER_INTENT_MS = 120;

/**
 * Carousel slides. Each pairs the empty-state copy with the silent cut the
 * stage previews on hover and that cut's first frame as a poster. The course
 * its `See How It Works` button opens is the admin's pick, served by the
 * academy payload under `studio.slides[id]` (S84); `id` must match
 * STUDIO_SLIDES in src/academy/studio-references.ts. A third slide gets a
 * third dot automatically; the dots are always rendered from this array,
 * never a fixed count.
 */
const SLIDES = [
  {
    id: 'prompt',
    title: 'What will your agent do?',
    body: 'Describe it in one sentence. Ready to <strong>test</strong>, <strong>publish</strong> and <strong>earn</strong>.',
    ctaLabel: 'See How It Works',
    stageVideo: 'https://cdn.aitopia.ai/storages/1/main/files/studio-stage-quick-guide-one-prompt-1080-v3.mp4',
    stagePoster: 'https://cdn.aitopia.ai/storages/1/main/files/studio-stage-quick-guide-one-prompt-poster-v3.jpg',
  },
  {
    id: 'types',
    title: 'Types of Agents You Can Build',
    body: 'See what you can build, from images and videos to workflows.',
    ctaLabel: 'Mini Video Guide',
    stageVideo: 'https://cdn.aitopia.ai/storages/1/main/files/studio-stage-types-of-agents-1080-v1.mp4',
    stagePoster: 'https://cdn.aitopia.ai/storages/1/main/files/studio-stage-types-of-agents-poster-v1.jpg',
  },
];

const TIPS = [
  '<strong>One sentence is enough.</strong> Name the input and the output: "turn a product photo into a short vertical ad".',
  '<strong>Test before you publish.</strong> A test run shows the real output and the real credit cost.',
  '<strong>Price it last.</strong> Credits per run set your earnings, and you can change them on the next version.',
];

const prefersReducedMotion = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;

/** Wire every onboarding surface. Safe to call when the elements are absent. */
export function wireStudioOnboarding() {
  // Lessons are only needed once a button is pressed, and the load can fail.
  // Resolve it lazily so a dead JSON never blocks the Studio from rendering.
  let academyPromise = null;
  const academy = () => (academyPromise ||= loadAcademy());

  // The stage previews the active slide's clip, and the carousel must not
  // move underneath a clip that is playing, so the two are cross-wired.
  let stage = null;
  const carousel = wireCarousel(academy, { onChange: () => { stage?.stop(); stage?.aim(); } });
  stage = wireStage({
    source: () => carousel?.slide() || SLIDES[0],
    onPlay: () => carousel?.hold(),
    onStop: () => carousel?.release(),
    onOpen: () => carousel?.peek(),
  });
  wireQuickTips();
  wireCoachMark();
}

/* ------------------------------------------------------------------ stage */

/**
 * The flow diagram sits in a 16:9 frame that crossfades to the active slide's
 * muted clip. A fine pointer plays on hover and a click opens the lesson
 * itself, with sound, in the popup; a coarse pointer, or reduced motion, plays
 * on an explicit tap or click and opens the popup on a tap while it plays.
 * While it plays a hairline bar and the elapsed seconds sit along the bottom
 * edge. The poster of the active slide is always in place, and a device that
 * can hover also buffers its clip while the stage is on screen, so the first
 * hover shows a frame at once and moves within a few frames more.
 *
 * @param {object} hooks
 * @param {() => {stageVideo: string, stagePoster: string}} hooks.source   the active slide
 * @param {() => void} hooks.onPlay     playback started
 * @param {() => void} hooks.onStop     playback ended
 * @param {() => void} hooks.onOpen     the preview was clicked: open the lesson
 * @returns {{stop: () => void, aim: () => void} | undefined}
 */
function wireStage({ source, onPlay, onStop, onOpen }) {
  const stage = document.getElementById('ab-studio-stage');
  const video = document.getElementById('ab-studio-stage-video');
  if (!stage || !video) return undefined;
  const progress = document.getElementById('ab-studio-stage-progress');
  const bar = progress?.querySelector('i');
  const clock = progress?.querySelector('span');

  const hoverable = !prefersReducedMotion() && window.matchMedia('(hover: hover)').matches;

  let intent = null;
  let active = false;
  let visible = false;
  let pointerType = '';

  const render = (playing) => stage.classList.toggle('is-playing', playing);
  const tick = () => {
    if (!bar || !clock) return;
    const { currentTime, duration } = video;
    bar.style.width = `${Number.isFinite(duration) && duration > 0 ? (currentTime / duration) * 100 : 0}%`;
    clock.textContent = formatDuration(currentTime);
  };
  const attach = () => {
    const { stageVideo } = source();
    if (video.getAttribute('src') !== stageVideo) video.src = stageVideo;
  };
  const aim = () => {
    const { stagePoster } = source();
    if (video.getAttribute('poster') !== stagePoster) video.poster = stagePoster;
    if (!hoverable || !visible) return;
    video.preload = 'auto';
    attach();
  };
  const play = () => {
    active = true;
    attach();
    video.muted = true;
    // The poster is on screen from here; a refused or broken clip must not
    // leave it frozen under the badge, so both roads lead back to the diagram.
    video.play().catch(() => stop());
    render(true);
    onPlay();
  };
  const stop = () => {
    clearTimeout(intent);
    intent = null;
    if (!active) return;
    active = false;
    video.pause();
    video.currentTime = 0;
    tick();
    render(false);
    onStop();
  };
  // A cursor crossing the stage on its way to the composer must not start the clip.
  const engage = () => {
    if (active || intent) return;
    intent = setTimeout(() => { intent = null; play(); }, HOVER_INTENT_MS);
  };
  const toggle = () => (active || intent ? stop() : play());

  video.addEventListener('timeupdate', () => { if (active) tick(); });
  video.addEventListener('error', () => stop());

  if (hoverable) {
    stage.addEventListener('pointerenter', (e) => { if (e.pointerType !== 'touch') engage(); });
    stage.addEventListener('pointerleave', (e) => { if (e.pointerType !== 'touch') stop(); });
  }
  // With hover driving playback a mouse click always opens the lesson; touch
  // and reduced motion first play the preview, then open it on the next tap.
  stage.addEventListener('pointerdown', (e) => { pointerType = e.pointerType; });
  stage.addEventListener('click', () => {
    const ambient = hoverable && pointerType && pointerType !== 'touch';
    pointerType = '';
    if (ambient || active) { stop(); onOpen(); return; }
    toggle();
  });

  const release = () => {
    stop();
    video.removeAttribute('src');
    video.load();
  };
  new IntersectionObserver((entries) => {
    visible = entries.some((e) => e.isIntersecting);
    if (visible) aim(); else release();
  }).observe(stage);
  document.addEventListener('visibilitychange', () => { if (document.hidden) stop(); });

  aim();
  return { stop, aim };
}

/* --------------------------------------------------------------- carousel */

/**
 * @param {() => Promise<object>} course
 * @param {object} hooks
 * @param {() => void} hooks.onChange   the visible slide changed
 * @returns {{slide: () => object, hold: () => void, release: () => void, peek: () => Promise<void>} | undefined}
 */
function wireCarousel(academy, { onChange }) {
  const titleEl = document.getElementById('ab-studio-slide-title');
  const bodyEl = document.getElementById('ab-studio-slide-sub');
  const dotsEl = document.getElementById('ab-studio-dots');
  const seeHow = document.getElementById('ab-studio-see-how');
  const seeHowLabel = document.getElementById('ab-studio-see-how-label');
  if (!titleEl || !bodyEl || !dotsEl || !seeHow) return undefined;

  let index = 0;
  let timer = null;
  let inside = false;
  let peeking = false;

  dotsEl.innerHTML = '';
  SLIDES.forEach((slide, i) => {
    const dot = document.createElement('button');
    dot.type = 'button';
    dot.setAttribute('role', 'tab');
    dot.setAttribute('aria-label', slide.title);
    dot.addEventListener('click', () => { show(i); restart(); });
    dotsEl.appendChild(dot);
  });

  function show(next) {
    index = ((next % SLIDES.length) + SLIDES.length) % SLIDES.length;
    const slide = SLIDES[index];
    titleEl.textContent = slide.title;
    bodyEl.innerHTML = slide.body;   // authored copy, not user input
    if (seeHowLabel) seeHowLabel.textContent = slide.ctaLabel;
    [...dotsEl.children].forEach((dot, i) => dot.setAttribute('aria-selected', String(i === index)));
    onChange();
  }

  function restart() {
    if (timer) clearInterval(timer);
    // A pointer parked inside the card, or an open quick peek, keeps the
    // carousel still: neither a dot click nor a pointer drifting onto the
    // modal's scrim may wake the timer under it.
    if (inside || peeking || SLIDES.length < 2 || prefersReducedMotion()) return;
    timer = setInterval(() => show(index + 1), SLIDE_INTERVAL_MS);
  }

  const pause = () => { if (timer) { clearInterval(timer); timer = null; } };
  // Pointer events, filtered to non-touch: a tap fires a synthetic mouseenter
  // but never a mouseleave, which used to park the carousel for good.
  const card = dotsEl.closest('.ab-studio-empty');
  card?.addEventListener('pointerenter', (e) => { if (e.pointerType !== 'touch') { inside = true; pause(); } });
  card?.addEventListener('focusin', pause);
  card?.addEventListener('pointerleave', (e) => { if (e.pointerType !== 'touch') { inside = false; restart(); } });

  // A `disabled` guard would blur the button, and the modal restores focus to
  // whatever was focused when it opened, so re-entry is gated by a flag.
  let opening = false;
  async function peek() {
    if (opening) return;
    opening = true;
    const slide = SLIDES[index];
    try {
      const { courses, player, studio } = await academy();
      // The admin's pick for this slide; a pick that is not published falls back to the first course.
      const slug = studio?.slides?.[slide.id];
      const course = courses.find((c) => c.slug === slug) || courses[0];
      if (!course) return;
      pause();
      peeking = true;
      openVideoModal({ course, lesson: course.lessons[0], player, onClose: () => { peeking = false; restart(); } });
    } catch (err) {
      // The Academy pages own the retry UI; from here the honest fallback is
      // to hand the user the full course rather than fail silently.
      console.error('[academy] lesson load failed', err);
      window.location.href = ACADEMY_URL;
    } finally {
      opening = false;
    }
  }
  seeHow.addEventListener('click', peek);

  show(0);
  restart();

  return {
    slide: () => SLIDES[index],
    hold: pause,
    release: restart,
    peek,
  };
}

/* ------------------------------------------------------------- quick tips */

function wireQuickTips() {
  const trigger = document.getElementById('ab-studio-quick-tips');
  if (!trigger) return;
  let pop = null;

  const close = () => {
    if (!pop) return;
    pop.remove();
    pop = null;
    trigger.setAttribute('aria-expanded', 'false');
    document.removeEventListener('keydown', onKey, true);
    document.removeEventListener('pointerdown', onOutside, true);
  };
  const onKey = (e) => { if (e.key === 'Escape') { close(); trigger.focus(); } };
  const onOutside = (e) => { if (pop && !pop.contains(e.target) && e.target !== trigger) close(); };

  trigger.addEventListener('click', () => {
    if (pop) { close(); return; }
    pop = document.createElement('div');
    pop.className = 'ab-tips-pop';
    pop.setAttribute('role', 'dialog');
    pop.setAttribute('aria-label', 'Quick tips');
    pop.innerHTML = `<ul>${TIPS.map((t) => `<li>${t}</li>`).join('')}</ul>`;
    document.body.appendChild(pop);

    const box = trigger.getBoundingClientRect();
    const left = Math.min(box.left + window.scrollX, window.scrollX + document.documentElement.clientWidth - pop.offsetWidth - 12);
    // The Studio body is a non-scrolling 100dvh box, so a popover that runs
    // past the bottom edge is clipped, not scrolled to. Open upward instead.
    const fitsBelow = box.bottom + 8 + pop.offsetHeight <= document.documentElement.clientHeight - 12;
    const top = fitsBelow ? box.bottom + 8 : box.top - 8 - pop.offsetHeight;
    pop.style.top = `${Math.max(12, top + window.scrollY)}px`;
    pop.style.left = `${Math.max(12, left)}px`;

    trigger.setAttribute('aria-expanded', 'true');
    document.addEventListener('keydown', onKey, true);
    document.addEventListener('pointerdown', onOutside, true);
  });
}

/* ------------------------------------------------------------- coach-mark */

function wireCoachMark() {
  const card = document.getElementById('ab-studio-coach');
  const video = document.getElementById('ab-studio-coach-video');
  const dismiss = document.getElementById('ab-studio-coach-dismiss');
  if (!card || !video || !dismiss) return;

  let alreadyDismissed = false;
  try { alreadyDismissed = localStorage.getItem(COACH_DISMISSED_KEY) === '1'; } catch { /* private mode */ }
  if (alreadyDismissed) return;

  card.hidden = false;
  // Autoplay is a battery cost on a 1080p loop, so the source is only attached
  // when the card is actually on screen, and playback stops the moment it is
  // not, or the tab is hidden.
  const reduced = prefersReducedMotion();
  video.loop = !reduced;

  let visible = false;
  const sync = () => {
    if (!visible || document.hidden) { video.pause(); return; }
    if (!video.src) video.src = TOOLTIP_VIDEO;
    video.play().catch(() => { /* autoplay policy: the poster still reads */ });
  };

  const observer = new IntersectionObserver((entries) => {
    visible = entries.some((e) => e.isIntersecting);
    sync();
  }, { threshold: 0.4 });
  observer.observe(card);
  document.addEventListener('visibilitychange', sync);

  const hide = () => {
    observer.disconnect();
    document.removeEventListener('visibilitychange', sync);
    video.pause();
    video.removeAttribute('src');
    video.load();
    card.hidden = true;
    try { localStorage.setItem(COACH_DISMISSED_KEY, '1'); } catch { /* private mode */ }
  };
  dismiss.addEventListener('click', hide);
  // Following the cap the card points at is the hint doing its job. Hiding
  // before the navigation matters: coming back may restore this page from
  // the back-forward cache exactly as it was, without running any of this.
  document.getElementById('ab-academy-link')?.addEventListener('click', hide);
}
