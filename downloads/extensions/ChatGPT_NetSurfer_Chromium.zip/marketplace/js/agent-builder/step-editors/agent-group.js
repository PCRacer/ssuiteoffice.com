// Rows come from the bound field's enum, so modes are added on the field itself.

import { el } from '../utils.js';

function labelFor(field, value) {
  const values = Array.isArray(field?.enum) ? field.enum : [];
  const labels = Array.isArray(field?.enumLabels) ? field.enumLabels : [];
  const i = values.indexOf(value);
  return (i >= 0 && typeof labels[i] === 'string' && labels[i]) || value;
}

function renderRow(step, field, value, onChange, redraw, openPicker) {
  const row = step.options?.[value] || (step.options[value] = { agent_id: '' });
  const picked = typeof row.agent_id === 'string' ? row.agent_id : '';

  return el('div', { class: 'ab-check-row', style: 'gap:0.5rem; align-items:center; flex-wrap:wrap;' },
    el('span', { class: 'ab-badge' }, labelFor(field, value)),
    el('button', {
      class: 'btn', type: 'button',
      onclick: () => {
        if (typeof openPicker !== 'function') return;
        openPicker({
          onPick: (entry) => {
            // The id is the whole answer — everything else is read from the
            // agent itself, never copied onto this doc.
            row.agent_id = entry.id || entry.slug || '';
            for (const k of Object.keys(row)) if (k !== 'agent_id') delete row[k];
            redraw();
            onChange();
          },
        });
      },
    }, picked ? '⟳ Change agent' : '+ Pick agent'),
    el('span', { class: 'text-sm font-mono' }, picked || '(no agent selected)'),
  );
}

export function renderAgentGroup(step, fields, onChange, openPicker) {
  const box = el('div', {});

  const draw = () => {
    box.innerHTML = '';
    const field = (Array.isArray(fields) ? fields : []).find(f => f && f.id === step.field_id);
    const values = Array.isArray(field?.enum)
      ? field.enum.filter(v => typeof v === 'string' && v)
      : [];

    if (!field) {
      box.appendChild(el('div', { class: 'text-xs text-muted-foreground' },
        'This group has no selector field. Give a field the “Agent group (tabs)” component.'));
      return;
    }
    if (values.length === 0) {
      box.appendChild(el('div', { class: 'text-xs text-muted-foreground' },
        `Add choices to “${field.title || field.id}” on the Fields pass — each one becomes a tab.`));
      return;
    }
    if (!step.options || typeof step.options !== 'object') step.options = {};
    values.forEach(value => box.appendChild(
      renderRow(step, field, value, onChange, draw, openPicker)));
  };

  draw();
  return box;
}
