// Renders a kind's editor from the catalog's declarative editorFields, so a
// new kind needs no client code. Bespoke renderers stay as escape hatches.

import { el } from '../utils.js';
import { kindSkills, readStepField, applyPickSnapshot } from '/marketplace/js/shared/step-kinds.js';
import { renderModelList } from './model-list.js';
import { renderAgentGroup } from './agent-group.js';
import { renderScottyToolInput } from './scotty-tool.js';

function optionsFor(field, spec) {
  if (Array.isArray(field.options) && field.options.length) return field.options;
  if (!field.optionsFrom) return [];
  const raw = field.optionsFrom === 'skills' ? kindSkills(spec) : spec?.[field.optionsFrom];
  return Array.isArray(raw)
    ? raw.map(o => (typeof o === 'string' ? { id: o, label: o } : o)).filter(o => o && o.id)
    : [];
}

// `finalOnly` options open a viewer, which only the last step gets. An earlier
// step keeps a already-chosen one, labelled, rather than silently losing it.
function gateFinalOnly(options, value, isFinal) {
  if (isFinal) return options;
  return options
    .filter(o => !o.finalOnly || String(value ?? '') === String(o.id))
    .map(o => (o.finalOnly ? { ...o, label: `${o.label || o.id} — only opens on the final step` } : o));
}

function fieldVisible(field, step) {
  const skill = field.visibleWhen?.skill;
  if (!skill) return true;
  const skills = readStepField(step, 'skills');
  return Array.isArray(skills) && skills.includes(skill);
}

// A control can gate on the option picked in another field lacking a flag.
function gateBlocks(field, step, spec) {
  const gate = field.disabledWhen;
  if (!gate) return false;
  const picked = readStepField(step, gate.field);
  if (!picked) return false;
  const opts = Array.isArray(spec?.[gate.optionsFrom]) ? spec[gate.optionsFrom] : [];
  const match = opts.find(o => o && o.id === picked);
  return Boolean(match) && match[gate.lacksFlag] === false;
}

function optionLabel(opt) {
  const base = opt.label || opt.id;
  return Number(opt.creditCost) > 0 ? `${base} (+${opt.creditCost})` : base;
}

function toJsonText(value) {
  if (value == null || value === '') return '';
  if (typeof value === 'string') return value;
  try { return JSON.stringify(value, null, 2); } catch { return ''; }
}

function helpNode(field) {
  const bits = [];
  if (field.help) bits.push(field.help);
  if (field.acceptsPlaceholders) bits.push('Accepts ${field} and ${output_id} placeholders.');
  return bits.length ? el('p', { class: 'text-xs text-muted-foreground mt-1' }, bits.join(' ')) : null;
}

function renderAgentPicker(field, step, onChange, openPicker) {
  const wrap = el('div', { class: 'flex items-center gap-2 flex-wrap' });
  const render = () => {
    wrap.innerHTML = '';
    const picked = readStepField(step, field.name);
    const credits = Number(readStepField(step, field.creditsField) || 0);
    wrap.appendChild(el('button', {
      class: 'btn', type: 'button',
      onclick: () => openPicker({
        onPick: (entry) => {
          step[field.name] = entry.id || entry.slug;
          applyPickSnapshot(step, field, entry);
          render();
          onChange();
        },
      }),
    }, picked ? '⟳ Change agent' : '+ Pick agent'));
    wrap.appendChild(el('span', { class: 'text-sm font-mono' }, picked || '(no agent selected)'));
    if (picked && credits > 0) wrap.appendChild(el('span', { class: 'ab-badge' }, credits + ' credits'));
  };
  render();
  return wrap;
}

function renderControl(field, step, onChange, spec, openPicker, opts = {}) {
  const name = field.name;
  const current = readStepField(step, name);
  const value = current === undefined ? field.default : current;
  // An option may need doc-level fields to exist before it can run (a mindmap's
  // hidden helper fields); the host supplies the effect keyed by option id.
  const commit = (v) => {
    const changed = JSON.stringify(readStepField(step, name)) !== JSON.stringify(v);
    step[name] = v;
    if (changed && field.resetsTo) Object.assign(step, structuredClone(field.resetsTo));
    const effect = opts.optionEffects?.[`${name}:${v}`];
    if (effect) effect(step);
    onChange();
  };

  switch (field.control) {
    case 'textarea':
      return el('textarea', {
        rows: '4',
        placeholder: field.placeholder || '',
        oninput: (e) => commit(e.target.value),
      }, value == null ? '' : String(value));

    case 'select': {
      const sel = el('select', { onchange: (e) => commit(e.target.value) });
      if (field.default === undefined) {
        const blank = (field.emptyLabelFrom ? spec?.[field.emptyLabelFrom] : field.emptyLabel) || '—';
        sel.appendChild(el('option', { value: '' }, blank));
      }
      for (const opt of gateFinalOnly(optionsFor(field, spec), value, opts.isFinal !== false)) {
        const o = el('option', { value: opt.id }, optionLabel(opt));
        if (String(value ?? '') === String(opt.id)) o.selected = true;
        sel.appendChild(o);
      }
      return sel;
    }

    case 'multiselect': {
      const box = el('div', {});
      const enabled = Array.isArray(value) ? value : [];
      const blocked = gateBlocks(field, step, spec);
      for (const opt of optionsFor(field, spec)) {
        const id = `ab-kf-${name}-${opt.id}`;
        const wrap = el('div', { class: 'ab-check-row' });
        const cb = el('input', {
          type: 'checkbox', id,
          disabled: blocked ? 'disabled' : null,
          oninput: (e) => {
            const prev = readStepField(step, name);
            const list = Array.isArray(prev) ? [...prev] : [];
            const at = list.indexOf(opt.id);
            if (e.target.checked) { if (at === -1) list.push(opt.id); } else if (at !== -1) list.splice(at, 1);
            commit(list);
          },
        });
        if (enabled.includes(opt.id)) cb.checked = true;
        wrap.appendChild(cb);
        wrap.appendChild(el('label', { for: id, class: 'text-sm' }, optionLabel(opt),
          opt.description ? el('span', { class: 'text-xs', style: 'opacity:0.6; margin-left:0.4rem;' }, opt.description) : null));
        box.appendChild(wrap);
      }
      if (blocked) {
        box.appendChild(el('div', { class: 'text-xs', style: 'opacity:0.7; margin-top:0.25rem;' },
          field.disabledWhen.note));
      }
      return box;
    }

    case 'json':
    case 'keyvalue':
      // Parsed on blur, not per keystroke — a half-typed object is not an error.
      return el('textarea', {
        rows: '6',
        class: 'font-mono text-xs',
        placeholder: field.placeholder || '{}',
        onblur: (e) => {
          const text = e.target.value.trim();
          if (!text) { commit(field.control === 'keyvalue' ? {} : null); return; }
          try { commit(JSON.parse(text)); e.target.classList.remove('ab-invalid'); }
          catch { e.target.classList.add('ab-invalid'); }
        },
      }, toJsonText(value));

    case 'agent-picker':
      return openPicker ? renderAgentPicker(field, step, onChange, openPicker) : null;

    case 'model-list':
      return renderModelList(step, onChange, opts.openModelPicker,
        opts.onSelectorDefaultChange, opts.renderSoul, opts.loadModelKeys);

    case 'agent-group':
      return renderAgentGroup(step, opts.docFields, onChange, openPicker);

    case 'scotty-tool-input':
      return renderScottyToolInput(field, step, spec, onChange, opts);

    case 'list': {
      const minRows = Number.isFinite(field.minRows) ? field.minRows : 2;
      const rows = Array.isArray(value) ? [...value] : [];
      while (rows.length < minRows) rows.push('');
      const box = el('div', {});
      const write = (next) => commit(next.filter((v, i) => String(v).trim() !== '' || i < minRows));
      rows.forEach((row, i) => {
        const input = el('input', {
          value: row == null ? '' : String(row),
          placeholder: field.placeholder || '',
          oninput: (e) => { const next = [...rows]; next[i] = e.target.value; write(next); },
        });
        input.style.flex = '1';
        const move = (delta) => {
          const next = [...rows];
          const j = i + delta;
          if (j < 0 || j >= next.length) return;
          [next[i], next[j]] = [next[j], next[i]];
          commit(next);
        };
        const line = el('div', { class: 'ab-check-row', style: 'gap:0.4rem; align-items:center;' },
          el('span', { class: 'pick-id', style: 'min-width:1.6rem;' }, String(i + 1)),
          input,
          el('button', { class: 'btn', type: 'button', title: 'Move up', onclick: () => move(-1) }, '↑'),
          el('button', { class: 'btn', type: 'button', title: 'Move down', onclick: () => move(1) }, '↓'),
          el('button', {
            class: 'btn', type: 'button', title: 'Remove',
            onclick: () => { const next = rows.filter((_, k) => k !== i); commit(next.length >= minRows ? next : [...next, '']); },
          }, '×'),
        );
        box.appendChild(line);
      });
      const ceiling = field.maxFrom ? Number(spec?.[field.maxFrom]) : NaN;
      const capped = Number.isFinite(ceiling) && ceiling > 0;
      const atCeiling = capped && rows.length >= ceiling;
      box.appendChild(el('button', {
        class: 'btn mt-2', type: 'button',
        disabled: atCeiling ? 'disabled' : null,
        title: atCeiling ? `Limit is ${ceiling}.` : null,
        onclick: () => { if (!atCeiling) commit([...rows, '']); },
      }, field.addLabel || '+ Add input'));

      // Clicking an upstream tag appends it as its own row, so the author never
      // has to know the placeholder syntax or where the commas go.
      const upstream = Array.isArray(opts.upstreamTokens) ? opts.upstreamTokens : [];
      if (upstream.length) {
        const free = rows.map((r, i) => [r, i]).filter(([r]) => !String(r || '').trim());
        box.appendChild(el('div', { class: 'ab-tags mt-2' },
          el('span', { class: 'text-xs text-muted-foreground mr-1' }, 'Upstream:'),
          ...upstream.map(token => el('span', {
            class: 'ab-tag output',
            title: 'Add as the next clip',
            onclick: () => {
              if (atCeiling) return;
              const next = [...rows];
              const slot = free.length ? free[0][1] : next.length;
              next[slot] = '${' + token + '}';
              commit(next);
            },
          }, '${' + token + '}')),
        ));
      }
      return box;
    }

    case 'text':
    default:
      return el('input', {
        value: value == null ? '' : String(value),
        placeholder: field.placeholder || '',
        oninput: (e) => commit(e.target.value),
      });
  }
}

// A hidden control must not leave a stale value in the doc — or in the step hash.
function clearHiddenSkillFields(fields, step) {
  for (const field of fields) {
    if (!field?.name || !field.visibleWhen?.skill) continue;
    if (fieldVisible(field, step)) continue;
    if (readStepField(step, field.name) === undefined) continue;
    step[field.name] = Array.isArray(field.default) ? [] : (field.default ?? '');
  }
}

/** Null when the kind declares no editorFields, so callers can fall back. */
export function renderDeclarativeEditor(step, spec, onChange, openPicker, opts = {}) {
  const fields = Array.isArray(spec?.editorFields) ? spec.editorFields : [];
  if (fields.length === 0) return null;
  const box = el('div', {});

  // A skill toggle shows or hides other fields, so this redraws itself rather
  // than waiting for the step card to be rebuilt.
  const draw = () => {
    box.innerHTML = '';
    for (const field of fields) {
      if (!field || !field.name) continue;
      if (field.pickerOnly) continue;
      if (!fieldVisible(field, step)) continue;
      box.appendChild(el('div', { class: 'field mb-3' },
        el('label', {}, field.label || field.name),
        renderControl(field, step, afterChange, spec, openPicker, opts),
        helpNode(field),
      ));
    }
  };
  // A redraw replaces every control, so typing would lose focus each keystroke.
  const TEXTLIKE_INPUT_TYPES = new Set(['text', 'number', 'search', 'email', 'url', 'tel', 'password', '']);
  const typingInside = () => {
    const active = document.activeElement;
    if (!active || !box.contains(active)) return false;
    return active.tagName === 'TEXTAREA'
      || (active.tagName === 'INPUT' && TEXTLIKE_INPUT_TYPES.has(active.type));
  };

  const afterChange = () => {
    clearHiddenSkillFields(fields, step);
    onChange();
    if (!typingInside()) draw();
  };

  clearHiddenSkillFields(fields, step);
  draw();
  return box;
}
