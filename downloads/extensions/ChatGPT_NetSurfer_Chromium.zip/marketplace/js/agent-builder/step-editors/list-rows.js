// The step editor's controls for one `list` row field (components/form/list.js
// draws the rows). A value is the literal the author set or a `${…}` reference,
// read back exactly as stored.
import { typeOf, uploadKindOf } from '../../components/form/list.js';

export const PLACEHOLDER = /\$\{[a-zA-Z0-9_.-]+\}/;

/** `addTags(container, input)` adds the editor's field/output tag rows under a text control. */
export function stepRowField(name, sub, { title, isRequired }, addTags) {
  const value = sub.default;
  const type = typeOf(sub);
  const isRef = typeof value === 'string' && PLACEHOLDER.test(value);
  const wrap = document.createElement('div');
  wrap.className = 'field';
  const label = document.createElement('label');
  label.textContent = isRequired ? `${title} *` : title;
  wrap.appendChild(label);

  if (!isRef && Array.isArray(sub.enum) && sub.enum.length) {
    const select = document.createElement('select');
    select.appendChild(new Option('- pick -', ''));
    sub.enum.forEach((opt, i) => select.appendChild(new Option(String(opt), String(i))));
    const at = sub.enum.findIndex((opt) => opt === value);
    select.value = at >= 0 ? String(at) : '';
    wrap.appendChild(select);
    return { node: wrap, read: () => (select.value === '' ? undefined : sub.enum[Number(select.value)]) };
  }

  if (!isRef && type === 'boolean') {
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.checked = value === true;
    label.prepend(checkbox, ' ');
    label.className = 'flex items-center gap-2 cursor-pointer text-sm';
    return { node: wrap, read: () => checkbox.checked };
  }

  // Text, numbers, uploads and nested JSON: typed, pasted or wired with a tag.
  const json = type === 'array' || type === 'object';
  const numeric = type === 'number' || type === 'integer';
  const input = document.createElement(json || sub.ui?.component === 'textarea' ? 'textarea' : 'input');
  if (input.tagName === 'TEXTAREA') input.rows = 2;
  else input.type = 'text';
  input.spellcheck = false;
  input.value = value == null ? '' : (typeof value === 'string' ? value : JSON.stringify(value));
  if (uploadKindOf(name, sub)) input.placeholder = 'Paste a URL, or click a tag below';
  wrap.appendChild(input);
  addTags(wrap, input);
  return {
    node: wrap,
    read: () => {
      const raw = input.value;
      if (raw === '') return undefined;
      if (json) {
        try { return JSON.parse(raw); } catch { return raw; }
      }
      if (numeric && !PLACEHOLDER.test(raw) && raw.trim() !== '' && Number.isFinite(Number(raw))) return Number(raw);
      return raw;
    },
  };
}
