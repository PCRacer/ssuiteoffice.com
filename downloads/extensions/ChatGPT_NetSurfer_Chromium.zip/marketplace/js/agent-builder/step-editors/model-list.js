// The model-selector step's option list.

import { el } from '../utils.js';

// Control flags, not inputs: the prompt slots come from the step soul and
// referenceMode is routing. Mirror of RESERVED_SCHEMA_KEYS in steps-pass.js.
const RUNTIME_FILLED_KEYS = new Set(['prompt', 'system_prompt', 'referenceMode']);

function readRows(step) {
  return Array.isArray(step?.models) ? step.models.filter(r => r && typeof r === 'object') : [];
}

function schemaKeys(step) {
  const schema = step?.schema && typeof step.schema === 'object' ? step.schema : {};
  return Object.keys(schema).filter(k => !RUNTIME_FILLED_KEYS.has(k));
}

/** `__` prefix so cleanAgentForExport strips it before publish. */
function expandedSet(step) {
  if (!(step.__expandedModels instanceof Set)) step.__expandedModels = new Set();
  return step.__expandedModels;
}

function sectionHeader(label, open, onToggle) {
  return el('button', {
    type: 'button',
    style: 'display:flex; align-items:center; gap:0.4rem; width:100%; padding:0.25rem 0.2rem;'
      + 'background:transparent; border:none; cursor:pointer; text-align:left;'
      + 'font-size:0.72rem; font-weight:600; color:hsl(var(--ait-m-muted-foreground));'
      + 'text-transform:uppercase; letter-spacing:0.04em;',
    onclick: onToggle,
  },
  el('span', {
    style: `display:inline-block; width:0.7rem; transition:transform 0.15s; transform:rotate(${open ? 90 : 0}deg);`,
  }, '▶'),
  el('span', {}, label));
}

/** Index of the row that runs by default. */
function defaultIndexOf(step) {
  const rows = readRows(step);
  const wanted = typeof step.default_model === 'string' ? step.default_model : '';
  let i = rows.findIndex(r => (r.key || '') === wanted);
  if (i < 0) i = rows.findIndex(r => r.id === wanted);
  return i;
}

/** The default row's flag lives on the step, where the card's own toggle writes
 *  it — one truth, so the two controls can never disagree. */
function isReferenceOn(step, row, index) {
  if (index === defaultIndexOf(step)) {
    const schema = step && typeof step.schema === 'object' ? step.schema : {};
    return schema.referenceMode === true;
  }
  return row.referenceMode === true;
}

function setReferenceOn(step, row, index, on) {
  if (index === defaultIndexOf(step)) {
    if (!step.schema || typeof step.schema !== 'object') step.schema = {};
    if (on) step.schema.referenceMode = true;
    else delete step.schema.referenceMode;
    delete row.referenceMode;
    return;
  }
  if (on) row.referenceMode = true;
  else delete row.referenceMode;
}

/** The keys this row offers: its reference-mode set when the mode is on. */
function rowKeys(row, on) {
  const keys = on && Array.isArray(row.__referenceKeys) ? row.__referenceKeys : row.__modelKeys;
  return Array.isArray(keys) ? keys : [];
}

/** Where a schema key lands: the author's pick, else the auto-match. */
function resolvedTarget(row, key, on) {
  const remap = row.remap && typeof row.remap === 'object' ? row.remap : {};
  if (typeof remap[key] === 'string' && remap[key].trim()) return remap[key].trim();
  const suggested = row.__suggestedRemap && typeof row.__suggestedRemap === 'object' ? row.__suggestedRemap : {};
  if (typeof suggested[key] === 'string' && suggested[key].trim()) return suggested[key].trim();
  const keys = rowKeys(row, on);
  // No snapshot: assume the name carries over, as the runtime does.
  return keys.length === 0 || keys.includes(key) ? key : '';
}

/** Only keys needing a decision; ones that already match are left out. */
function unresolvedKeys(step, row, on) {
  return schemaKeys(step).filter(key => resolvedTarget(row, key, on) !== key);
}

// Use-model-fields only: the buyer fields in form order, movable within their required/optional group.
function modelFieldsSection(step, row, on, optionKey, commit, redraw) {
  const split = window.AitopiaCredits?.builderSelectorModelFields?.(step, row, on);
  if (!split) return null;
  const line = (text) => el('div', {
    class: 'text-xs text-muted-foreground',
    style: 'padding:0.15rem 0.2rem; overflow-wrap:anywhere;',
  }, text);
  if (!split.loaded) return line('Model fields not loaded yet.');

  const box = el('div', { style: 'display:flex; flex-direction:column; gap:0.2rem;' });
  box.appendChild(line(`Mapped by you: ${split.mapped.join(', ') || 'nothing'}`));
  const expanded = expandedSet(step);
  const orderKey = `${optionKey}::order`;
  const open = expanded.has(orderKey);
  box.appendChild(sectionHeader(
    `Buyer fields — ${split.buyer.length}${split.buyer.some(f => f.hidden) ? `, ${split.buyer.filter(f => f.hidden).length} hidden` : ''} (order / hide)`,
    open,
    () => { if (open) expanded.delete(orderKey); else expanded.add(orderKey); redraw(); },
  ));
  if (!open) return box;

  const keys = split.buyer.map(f => f.key);
  split.buyer.forEach((f, i) => {
    const swap = (j) => {
      const next = keys.slice();
      [next[i], next[j]] = [next[j], next[i]];
      row.buyerFieldOrder = next;
      commit();
      redraw();
    };
    const canUp = i > 0 && split.buyer[i - 1].required === f.required;
    const canDown = i < split.buyer.length - 1 && split.buyer[i + 1].required === f.required;
    const arrow = (label, enabled, j) => el('button', {
      class: 'btn', type: 'button', title: label === '↑' ? 'Move up' : 'Move down',
      disabled: !enabled,
      style: enabled ? '' : 'opacity:0.35;',
      onclick: () => { if (enabled) swap(j); },
    }, label);
    // Only optional keys can be hidden; a hidden one runs at the model page default.
    let hideToggle = null;
    if (!f.required) {
      const cb = el('input', {
        type: 'checkbox',
        onchange: (e) => {
          const set = new Set(Array.isArray(row.hiddenBuyerFields) ? row.hiddenBuyerFields : []);
          if (e.target.checked) set.add(f.key); else set.delete(f.key);
          if (set.size) row.hiddenBuyerFields = Array.from(set); else delete row.hiddenBuyerFields;
          commit();
          redraw();
        },
      });
      if (f.hidden) cb.checked = true;
      hideToggle = el('label', { class: 'text-xs text-muted-foreground', style: 'display:inline-flex; gap:0.25rem; align-items:center; cursor:pointer;' },
        cb, 'Hidden');
    }
    box.appendChild(el('div', { class: 'ab-check-row', style: 'gap:0.4rem; align-items:center; padding-left:0.2rem;' + (f.hidden ? ' opacity:0.55;' : '') },
      el('span', { class: 'text-xs font-mono', style: 'flex:1; min-width:0; overflow-wrap:anywhere;' }, f.key),
      f.required ? el('span', { class: 'text-xs text-muted-foreground' }, 'required') : hideToggle,
      arrow('↑', canUp, i - 1),
      arrow('↓', canDown, i + 1)));
  });
  return box;
}

function mappingBody(step, row, commit, redraw, on) {
  const allKeys = schemaKeys(step);
  if (allKeys.length === 0) {
    return el('div', { class: 'text-xs text-muted-foreground', style: 'padding:0.3rem 0.2rem;' },
      'Wire the step inputs first — each one gets a mapping row here.');
  }

  const pending = unresolvedKeys(step, row, on);
  const matched = allKeys.length - pending.length;
  const body = el('div', { style: 'display:flex; flex-direction:column; gap:0.3rem; padding-left:0.2rem;' });

  if (matched > 0) {
    body.appendChild(el('div', { class: 'text-xs text-muted-foreground' },
      `${matched} of ${allKeys.length} input${allKeys.length === 1 ? '' : 's'} already match this model — nothing to do for ${matched === 1 ? 'it' : 'them'}.`));
  }
  if (pending.length === 0) return body;

  const modelKeys = rowKeys(row, on);
  const required = new Set(Array.isArray(row.requiredKeys) ? row.requiredKeys : []);
  // Required first: that is the choice that matters.
  const options = modelKeys.filter(k => !RUNTIME_FILLED_KEYS.has(k)).sort((a, b) => {
    const ra = required.has(a) ? 0 : 1;
    const rb = required.has(b) ? 0 : 1;
    return ra !== rb ? ra - rb : a.localeCompare(b);
  });

  for (const key of pending) {
    const current = resolvedTarget(row, key, on);
    const write = (value) => {
      const next = { ...(row.remap && typeof row.remap === 'object' ? row.remap : {}) };
      if (value) next[key] = value;
      else delete next[key];
      row.remap = next;
      commit();
      redraw();
    };

    let control;
    if (options.length === 0) {
      // No snapshot: fall back to typing the key.
      control = el('input', {
        value: current,
        placeholder: key,
        oninput: (e) => write(e.target.value.trim()),
      });
    } else {
      control = el('select', { onchange: (e) => write(e.target.value) });
      control.appendChild(el('option', { value: '' }, 'Not sent to this model'));
      for (const opt of options) {
        const o = el('option', { value: opt }, required.has(opt) ? `${opt} (required)` : opt);
        if (opt === current) o.selected = true;
        control.appendChild(o);
      }
    }
    control.style.flex = '1';

    body.appendChild(el('div', { class: 'ab-check-row', style: 'gap:0.4rem; align-items:center;' },
      el('span', { class: 'text-xs font-mono', style: 'min-width:9rem; opacity:0.75;' }, key),
      el('span', { class: 'text-xs', style: 'opacity:0.5;' }, '→'),
      control));
  }
  return body;
}

function renderRow(step, row, index, commit, redraw, onDefaultChange, renderSoul, loadModelKeys) {
  const expanded = expandedSet(step);
  const modelId = typeof row.id === 'string' ? row.id : '';
  // Keyed, not id'd: the same model may be listed more than once.
  const optionKey = (typeof row.key === 'string' && row.key) || modelId;
  const promptKey = `${optionKey}::soul`;
  const mapKey = `${optionKey}::map`;
  const wanted = typeof step.default_model === 'string' ? step.default_model : '';
  const siblings = readRows(step);
  // By INDEX: two rows of one model share an id, so a value match lights both.
  let defaultIndex = siblings.findIndex(r => (r.key || '') === wanted);
  if (defaultIndex < 0) defaultIndex = siblings.findIndex(r => r.id === wanted);
  const isDefault = defaultIndex === index;
  const referenceOn = isReferenceOn(step, row, index);

  const card = el('div', {
    class: 'ab-check-row',
    style: 'flex-direction:column; align-items:stretch; gap:0.35rem; padding:0.5rem;'
      + 'border-radius:0.4rem; margin-bottom:0.4rem;'
      + (isDefault
        ? 'border:1px solid hsl(var(--ait-m-primary) / 0.55); background:hsl(var(--ait-m-primary) / 0.05);'
        : 'border:1px solid hsl(var(--ait-m-border));'),
  });

  const nameInput = el('input', {
    value: typeof row.label === 'string' ? row.label : '',
    placeholder: 'Name the buyer sees',
    oninput: (e) => { row.label = e.target.value; commit(); },
  });
  nameInput.style.flex = '1';

  const move = (delta) => {
    const rows = readRows(step);
    const j = index + delta;
    if (j < 0 || j >= rows.length) return;
    [rows[index], rows[j]] = [rows[j], rows[index]];
    step.models = rows;
    commit();
    redraw();
  };

  card.appendChild(el('div', { class: 'ab-check-row', style: 'gap:0.4rem; align-items:center;' },
    el('span', { class: 'pick-id', style: 'min-width:1.6rem;' }, String(index + 1)),
    nameInput,
    el('span', { class: 'text-xs font-mono', style: 'opacity:0.6;' }, modelId || '(no model)'),
    el('button', {
      class: 'btn', type: 'button',
      title: isDefault ? 'This model runs by default' : 'Make this the default',
      style: isDefault
        ? 'background:hsl(var(--ait-m-primary) / 0.16); color:hsl(var(--ait-m-primary));'
          + 'border-color:hsl(var(--ait-m-primary) / 0.5); font-weight:600;'
        : 'opacity:0.65;',
      onclick: () => {
        if (isDefault) return;
        // The step-level flag follows the default, so hand the outgoing row its
        // own copy before taking it over.
        const rows = readRows(step);
        const prev = rows[defaultIndex];
        const prevOn = isReferenceOn(step, prev || {}, defaultIndex);
        if (prev && prevOn) prev.referenceMode = true;
        step.default_model = optionKey;
        setReferenceOn(step, row, index, referenceOn);
        // The step schema is about to be re-read from this model, so its own
        // override and mapping would apply unseen. Drop them.
        delete row.soul;
        delete row.remap;
        commit();
        redraw();
        // Step inputs come from the default model's schema.
        if (typeof onDefaultChange === 'function') onDefaultChange();
      },
    }, isDefault ? '★ Default' : 'Make default'),
    el('button', { class: 'btn', type: 'button', title: 'Move up', onclick: () => move(-1) }, '↑'),
    el('button', { class: 'btn', type: 'button', title: 'Move down', onclick: () => move(1) }, '↓'),
    el('button', {
      class: 'btn', type: 'button', title: 'Remove',
      onclick: () => {
        const wasDefault = isDefault;
        step.models = readRows(step).filter((_, k) => k !== index);
        if (wasDefault) {
          const next = readRows(step)[0];
          step.default_model = next ? (next.key || next.id) : '';
        }
        commit();
        redraw();
        if (wasDefault && typeof onDefaultChange === 'function') onDefaultChange();
      },
    }, '×'),
  ));
  const fieldsSection = modelFieldsSection(step, row, referenceOn, optionKey, commit, redraw);
  if (fieldsSection) card.appendChild(fieldsSection);

  // The step's prompt, inputs and reference mode ARE this row's — repeating
  // them here would only restate the card's own controls.
  if (isDefault) {
    card.appendChild(el('div', { class: 'text-xs text-muted-foreground', style: 'padding:0.15rem 0.2rem;' },
      'Uses the step prompt, inputs and reference mode above.'));
    return card;
  }

  // Only for a model with an r2v endpoint; flipping it re-reads that endpoint's
  // keys, so the mapping below offers the reference fields instead.
  if (row.__supportsReference === true) {
    const on = referenceOn;
    const toggle = el('label', {
      class: 'ab-check-row',
      style: 'gap:0.5rem; align-items:center; cursor:pointer; padding:0.2rem;',
    });
    const cb = el('input', {
      type: 'checkbox',
      onchange: (e) => {
        setReferenceOn(step, row, index, e.target.checked);
        commit();
        redraw();
      },
    });
    if (on) cb.checked = true;
    toggle.appendChild(cb);
    toggle.appendChild(el('span', { class: 'text-xs' }, 'Reference mode',
      el('span', { class: 'text-xs text-muted-foreground', style: 'margin-left:0.4rem;' },
        'route to reference-to-*; the start frame is ignored')));
    card.appendChild(toggle);
  }

  // Optional: the step soul runs unless this row fills it in.
  const promptOpen = expanded.has(promptKey);
  const hasOwnSoul = typeof row.soul === 'string' && row.soul.trim() !== '';
  card.appendChild(sectionHeader(
    `Prompt override${hasOwnSoul ? ' — set' : ' (optional)'}`,
    promptOpen,
    () => { if (promptOpen) expanded.delete(promptKey); else expanded.add(promptKey); redraw(); },
  ));
  if (promptOpen && typeof renderSoul === 'function') {
    card.appendChild(renderSoul({
      read: () => row.soul,
      write: (v) => { row.soul = v; commit(); },
      rows: 4,
      placeholder: 'Only fill this in when this model needs different wording',
      hint: 'Leave this empty and the step prompt above runs for this model. Click a tag to insert a placeholder.',
    }));
  }

  // Count in the header: a fully matching model needs no visit.
  const mapOpen = expanded.has(mapKey);
  const pendingCount = unresolvedKeys(step, row, referenceOn).length;
  card.appendChild(sectionHeader(
    pendingCount === 0
      ? 'Field mapping — all inputs match'
      : `Field mapping — ${pendingCount} to set`,
    mapOpen,
    () => { if (mapOpen) expanded.delete(mapKey); else expanded.add(mapKey); redraw(); },
  ));
  if (mapOpen) {
    // A reloaded draft has no key snapshot; fetch once, then redraw.
    if (!Array.isArray(row.__modelKeys) && typeof loadModelKeys === 'function') {
      loadModelKeys(row).then(got => { if (got) redraw(); });
    }
    card.appendChild(mappingBody(step, row, commit, redraw, referenceOn));
  }

  return card;
}

/** `openPicker` opens the step's model picker in add-model mode. */
export function renderModelList(step, onChange, openPicker, onDefaultChange, renderSoul, loadModelKeys) {
  const box = el('div', {});

  const draw = () => {
    box.innerHTML = '';
    const rows = readRows(step);

    if (rows.length === 0) {
      box.appendChild(el('div', { class: 'text-xs text-muted-foreground mb-2' },
        'No models yet — add the first one to set this step’s media kind.'));
    }
    // A draft written before `enums` existed carries none, and the buyer's form
    // needs them whether or not the author ever opens Field mapping.
    if (typeof loadModelKeys === 'function') {
      const missing = rows.filter(r => !r.enums || !Object.keys(r.enums).length);
      if (missing.length) {
        Promise.all(missing.map(r => loadModelKeys(r)))
          .then(got => { if (got.some(Boolean)) { onChange(); draw(); } });
      }
    }
    rows.forEach((row, i) => box.appendChild(
      renderRow(step, row, i, onChange, draw, onDefaultChange, renderSoul, loadModelKeys)));

    box.appendChild(el('button', {
      class: 'btn mt-2', type: 'button',
      onclick: () => {
        if (typeof openPicker !== 'function') return;
        openPicker({
          onPick: () => { draw(); onChange(); },
        });
      },
    }, rows.length ? '+ Add another model' : '+ Add model'));
  };

  draw();
  return box;
}
