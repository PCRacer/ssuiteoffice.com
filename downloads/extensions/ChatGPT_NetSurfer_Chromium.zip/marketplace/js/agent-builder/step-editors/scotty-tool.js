// A Scotty tool step's inputs, drawn from the picked tool's own JSON schema.

import { el } from '../utils.js';

function toolOf(step, spec) {
  const tools = Array.isArray(spec?.scottyTools) ? spec.scottyTools : [];
  return tools.find(t => t && t.id === step?.tool) || null;
}

function typeOf(schema) {
  return Array.isArray(schema?.type) ? schema.type[0] : schema?.type;
}

function isBlank(v) {
  return v === undefined || v === null || (typeof v === 'string' && v.trim() === '') || (Array.isArray(v) && v.length === 0);
}

function rangeHint(schema) {
  const lo = schema.minimum ?? schema.minItems;
  const hi = schema.maximum ?? schema.maxItems;
  if (lo === undefined && hi === undefined) return '';
  return `${lo ?? ''}–${hi ?? ''}`;
}

function toText(v) {
  if (v == null) return '';
  if (typeof v === 'string') return v;
  try { return JSON.stringify(v); } catch { return ''; }
}

function tokenChips(tokens, onPick) {
  if (!tokens.length) return null;
  return el('div', { class: 'ab-tags mt-1' },
    el('span', { class: 'text-xs text-muted-foreground mr-1' }, 'Upstream:'),
    ...tokens.map(token => el('span', {
      class: 'ab-tag output', title: 'Use this output', onclick: () => onPick('${' + token + '}'),
    }, '${' + token + '}')));
}

function readableLabel(key, schema = {}) {
  return schema.title || String(key)
    .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
    .replace(/[_-]/g, ' ')
    .replace(/^./, c => c.toUpperCase());
}

function branchFor(schema, value) {
  if (value === null) return (schema.anyOf || schema.oneOf || []).findIndex(branch => branch.type === 'null');
  return (schema.anyOf || schema.oneOf || []).findIndex(branch => {
    if (branch.const !== undefined) return branch.const === value;
    if (Array.isArray(branch.enum)) return branch.enum.includes(value);
    if (branch.type === 'array') return Array.isArray(value);
    if (branch.type === 'object') return value !== null && typeof value === 'object' && !Array.isArray(value);
    if (branch.type === 'number') return typeof value === 'number';
    if (branch.type === 'string') return typeof value === 'string';
    return false;
  });
}

function defaultFor(schema) {
  if (schema.default !== undefined) return schema.default;
  if (schema.const !== undefined) return schema.const;
  if (Array.isArray(schema.enum) && schema.enum.length) return schema.enum[0];
  if (schema.type === 'object') return {};
  if (schema.type === 'array') return [];
  if (schema.type === 'number' || schema.type === 'integer') return schema.minimum ?? 0;
  if (schema.type === 'boolean') return false;
  if (schema.type === 'null') return null;
  return '';
}

/** Render a schema object recursively as labeled fields. */
function renderObject(schema, value, write, tokens, depth = 0) {
  if (depth > 12) return el('p', { class: 'text-xs text-muted-foreground' }, 'Nested fields are too deep to display.');
  const props = schema.properties && typeof schema.properties === 'object' ? schema.properties : {};
  let current = value && typeof value === 'object' && !Array.isArray(value) ? { ...value } : {};
  const required = new Set(Array.isArray(schema.required) ? schema.required : []);
  const box = el('div', { class: 'space-y-3' });

  for (const [key, property] of Object.entries(props)) {
    const field = property || {};
    const setter = next => {
      const updated = { ...current };
      if (next === undefined || next === '') delete updated[key];
      else updated[key] = next;
      current = updated;
      write(updated);
    };
    box.appendChild(el('div', { class: 'field mb-3' },
      el('label', {}, readableLabel(key, field) + (required.has(key) ? ' *' : '')),
      renderProperty(key, field, current[key], setter, tokens, depth + 1),
      field.description ? el('p', { class: 'text-xs text-muted-foreground mt-1' }, field.description) : null,
    ));
  }

  if (!Object.keys(props).length) {
    // Some schemas describe an open object. Show existing keys as individual
    // editable values, so users never have to edit a JSON blob.
    for (const [key, child] of Object.entries(current)) {
      const field = schema.additionalProperties && typeof schema.additionalProperties === 'object'
        ? schema.additionalProperties : { type: typeof child === 'number' ? 'number' : 'string' };
      box.appendChild(el('div', { class: 'field mb-3' },
        el('label', {}, readableLabel(key, field)),
        renderProperty(key, field, child, next => {
          current = { ...current, [key]: next };
          write(current);
        }, tokens, depth + 1)));
    }
    if (!Object.keys(current).length) {
      box.appendChild(el('p', { class: 'text-xs text-muted-foreground' }, 'This tool accepts an object with no predefined fields.'));
    }
  }
  return box;
}

/** Object and non-string arrays use schema-shaped fields, without JSON editors or new controls. */
function renderStructuredArray(key, schema, value, write, tokens, depth) {
  const itemSchema = schema.items || {};
  const existing = Array.isArray(value) ? value : [];
  const minimum = Number.isFinite(schema.minItems) ? schema.minItems : 0;
  // One visible row gives an empty optional/required list useful fields to edit.
  const count = Math.max(existing.length, minimum, 1);
  const values = Array.from({ length: count }, (_, index) => existing[index]);
  const box = el('div', { class: 'space-y-3' });
  values.forEach((itemValue, index) => {
    const childWrite = next => {
      values[index] = next;
      write(values.map(v => v === undefined
        ? (typeOf(itemSchema) === 'object' ? {} : '')
        : v));
    };
    box.appendChild(el('fieldset', { class: 'field mb-3' },
      el('legend', { class: 'text-sm font-medium mb-1' }, readableLabel(key, schema) + (count > 1 ? ` ${index + 1}` : '')),
      renderProperty(`${key} ${index + 1}`, itemSchema, itemValue, childWrite, tokens, depth + 1)));
  });
  return box;
}

// Rows of text, one item each; a row may hold a placeholder that resolves to a list.
function renderStringList(schema, value, write, tokens) {
  const rows = Array.isArray(value) ? value.map(toText) : (isBlank(value) ? [] : [toText(value)]);
  if (rows.length === 0) rows.push('');
  const box = el('div', {});
  const commit = (next) => write(next.filter(r => String(r).trim() !== ''));
  rows.forEach((row, i) => {
    const input = el('input', {
      value: row, placeholder: schema.items?.format === 'uri' ? '${output_1} or https://…' : '',
      oninput: (e) => { rows[i] = e.target.value; commit(rows); },
    });
    input.style.flex = '1';
    box.appendChild(el('div', { class: 'ab-check-row', style: 'gap:0.4rem; align-items:center;' },
      el('span', { class: 'pick-id', style: 'min-width:1.6rem;' }, String(i + 1)),
      input,
      el('button', { class: 'btn', type: 'button', title: 'Remove', onclick: () => commit(rows.filter((_, k) => k !== i)) }, '×')));
  });
  const max = Number(schema.maxItems);
  const full = Number.isFinite(max) && rows.length >= max;
  box.appendChild(el('button', {
    class: 'btn mt-2', type: 'button', disabled: full ? 'disabled' : null,
    onclick: () => { if (!full) write([...rows, '']); },
  }, '+ Add item'));
  const chips = tokenChips(tokens, (tag) => {
    if (full) return;
    const at = rows.findIndex(r => !String(r).trim());
    const next = [...rows];
    next[at === -1 ? next.length : at] = tag;
    commit(next);
  });
  if (chips) box.appendChild(chips);
  return box;
}

function renderProperty(key, schema, value, write, tokens, depth = 0) {
  const type = typeOf(schema);
  const enumValues = Array.isArray(schema.enum) ? schema.enum : null;

  if (Array.isArray(schema.anyOf) || Array.isArray(schema.oneOf)) {
    const variants = schema.anyOf || schema.oneOf;
    const selected = branchFor(schema, value);
    const select = el('select', {
      'aria-label': readableLabel(key, schema) + ' type',
      onchange: event => write(defaultFor(variants[Number(event.target.value)])),
    });
    variants.forEach((variant, index) => {
      const name = variant.title || (variant.enum
        ? variant.enum.map(item => String(item)).join(' / ')
        : readableLabel(variant.type || 'value'));
      select.appendChild(el('option', { value: String(index) }, name));
    });
    select.value = String(selected < 0 ? 0 : selected);
    const branch = variants[Number(select.value)] || variants[0];
    return el('div', {}, select,
      renderProperty(key, branch, value === null && branch.type !== 'null' ? defaultFor(branch) : value,
        write, tokens, depth + 1));
  }

  if (schema.const !== undefined) return el('span', { class: 'text-sm' }, String(schema.const));

  if (type === 'object') return renderObject(schema, value, write, tokens, depth);

  if (enumValues || type === 'boolean') {
    const options = enumValues || ['true', 'false'];
    const sel = el('select', { onchange: (e) => write(e.target.value) });
    sel.appendChild(el('option', { value: '' }, '— default —'));
    for (const opt of options) {
      const o = el('option', { value: String(opt) }, String(opt));
      if (String(value ?? '') === String(opt)) o.selected = true;
      sel.appendChild(o);
    }
    return sel;
  }

  if (type === 'array' && typeOf(schema.items) === 'string') {
    return renderStringList(schema, value, write, tokens);
  }

  if (type === 'array') return renderStructuredArray(key, schema, value, write, tokens, depth);

  const long = type === 'string' && (Number(schema.maxLength) > 200 || /text|prompt/i.test(key));
  if (type === 'null') return el('p', { class: 'text-xs text-muted-foreground' }, 'No value');
  const box = el('div', {});
  const numeric = type === 'number' || type === 'integer';
  const input = long
    ? el('textarea', { rows: '3', oninput: (e) => write(e.target.value) }, toText(value))
    : el('input', {
      type: numeric ? 'number' : 'text',
      step: type === 'integer' ? '1' : numeric ? 'any' : null,
      min: schema.minimum,
      max: schema.maximum,
      value: toText(value),
      placeholder: schema.format === 'uri' ? '${output_1} or https://…' : rangeHint(schema),
      oninput: (e) => write(numeric && e.target.value !== '' ? Number(e.target.value) : e.target.value),
    });
  box.appendChild(input);
  const chips = schema.format === 'uri' ? tokenChips(tokens, (tag) => { input.value = tag; write(tag); }) : null;
  if (chips) box.appendChild(chips);
  return box;
}

export function renderScottyToolInput(field, step, spec, onChange, opts = {}) {
  const tool = toolOf(step, spec);
  if (!tool) return el('p', { class: 'text-xs text-muted-foreground' }, 'Pick a tool above to see its inputs.');

  const schema = tool.schema || {};
  const tokens = Array.isArray(opts.upstreamTokens) ? opts.upstreamTokens : [];
  const current = () => (step[field.name] && typeof step[field.name] === 'object' && !Array.isArray(step[field.name]) ? step[field.name] : {});
  const write = next => {
    step[field.name] = next;
    onChange();
  };

  const box = el('div', {});
  if (tool.description) box.appendChild(el('p', { class: 'text-xs text-muted-foreground mb-2' }, tool.description));
  const keys = schema.properties && typeof schema.properties === 'object' ? Object.keys(schema.properties) : [];
  if (keys.length === 0 && schema.additionalProperties === false) {
    box.appendChild(el('p', { class: 'text-xs text-muted-foreground' }, 'This tool takes no inputs.'));
  } else {
    box.appendChild(renderObject(schema, current(), write, tokens));
  }
  return box;
}
