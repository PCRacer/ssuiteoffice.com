/**
 * Video.js v10 loader. The build is self-hosted under public/vendor/videojs
 * (written by scripts/vendor-videojs.mjs, which checks this version against
 * the installed package): the player preset with its packaged skin, plus the
 * hls.js media element. Loaded on demand so the Studio pays for it only when
 * the See How It Works modal opens.
 */

export const VIDEOJS_VERSION = '10.0.0-rc.2';
export const VIDEOJS_BASE = `/vendor/videojs/${VIDEOJS_VERSION}`;

let loading = null;

/** Resolves once both modules are loaded; a failed load is forgotten so a retry fetches again. */
export function loadVideoJs() {
  loading ||= Promise.all([
    import(`${VIDEOJS_BASE}/video.js`),
    import(`${VIDEOJS_BASE}/media/hlsjs-video.js`),
  ]).then(() => undefined, (err) => { loading = null; throw err; });
  return loading;
}
