/**
 * AITOPIA Academy: shared course data, progress and player.
 *
 * The academy is a list of courses, each an ordered run of lessons (Lesson 1,
 * 2, 3…). Imported by both Academy pages AND the Studio (agent-builder.html),
 * so a lesson watched in the Studio's quick-peek modal counts as watched in
 * the Academy: one loader, one progress key, one player.
 */

import { loadVideoJs } from './academy-player.js';

const COURSE_URL = 'https://aitopia.ai/api/academy';
const PROGRESS_KEY = 'aitopia.academy.progress.v2';
export const ACADEMY_URL = '/academy';

/** A lesson counts as watched at 90%: people skip outros, and requiring
 *  `ended` leaves lessons permanently unfinished. */
const COMPLETE_AT = 0.9;

/** Video.js builds its playback engine after `source` is assigned and the
 *  media fires `loadstart` once it has one; a play() before that is lost.
 *  The wait is bounded so a media element that never loads cannot hang the click. */
const ENGINE_WAIT_MS = 3000;

/* ---------------------------------------------------------------- academy */

/**
 * Fetch the academy: courses, each holding its ordered lessons. A course that
 * cannot be opened (no slug, no lessons) is dropped here so the pages never
 * have to guard against it. A transport/parse failure throws so callers can
 * offer a retry. An empty academy and a failed load are different states and
 * must not render the same way.
 */
export async function loadAcademy() {
  const res = await fetch(COURSE_URL, { headers: { accept: 'application/json' } });
  if (!res.ok) throw new Error(`course ${res.status}`);
  const json = await res.json();
  const courses = (Array.isArray(json?.courses) ? json.courses : [])
    .filter((c) => c && c.slug)
    .map((c) => ({ ...c, lessons: (Array.isArray(c.lessons) ? c.lessons : []).filter((l) => l && l.slug) }))
    .filter((c) => c.lessons.length);
  // The player's buffer target is a Settings row served here, never a page constant.
  const bufferSeconds = Number(json?.player?.bufferSeconds);
  // Which course each Studio slide opens: the admin's pick, keyed by slide id (S84).
  const slides = Object.entries(json?.studio?.slides ?? {}).filter(([, slug]) => typeof slug === 'string');
  return {
    title: String(json?.title || 'AITOPIA Academy'),
    subtitle: String(json?.subtitle || ''),
    courses,
    player: Number.isFinite(bufferSeconds) && bufferSeconds > 0 ? { bufferSeconds } : null,
    studio: { slides: Object.fromEntries(slides) },
  };
}

/** Lesson slugs are only unique inside their course, so everything keyed by a
 *  lesson (progress, hrefs) carries the course slug too. */
export function lessonKey(course, lesson) {
  return `${course.slug}/${lesson.slug}`;
}
export const courseHref = (course) => `${ACADEMY_URL}/${encodeURIComponent(course.slug)}`;
export const lessonHref = (course, lesson) => `${courseHref(course)}/${encodeURIComponent(lesson.slug)}`;

/**
 * Locate a lesson and its neighbours. The academy reads as one linear
 * playlist, so `next` after a course's last lesson is the following course's
 * first. `sameCourse` tells the caller whether to say "Next Lesson" or
 * "Next Course".
 *
 * @returns {{course, courseIndex, lesson, lessonIndex, next, previous}|null}
 */
export function findLesson(courses, courseSlug, lessonSlug) {
  const courseIndex = courses.findIndex((c) => c.slug === courseSlug);
  if (courseIndex === -1) return null;
  const course = courses[courseIndex];
  const lessonIndex = course.lessons.findIndex((l) => l.slug === lessonSlug);
  if (lessonIndex === -1) return null;
  const neighbour = (courseStep, lessonStep) => {
    const inCourse = course.lessons[lessonIndex + lessonStep];
    if (inCourse) return { course, lesson: inCourse, sameCourse: true };
    const other = courses[courseIndex + courseStep];
    if (!other) return null;
    const lesson = courseStep > 0 ? other.lessons[0] : other.lessons[other.lessons.length - 1];
    return { course: other, lesson, sameCourse: false };
  };
  return {
    course,
    courseIndex,
    lesson: course.lessons[lessonIndex],
    lessonIndex,
    next: neighbour(1, 1),
    previous: neighbour(-1, -1),
  };
}

/* ---------------------------------------------------------------- progress */

/** @returns {{completed: string[], lastWatched: string|null}} lesson keys */
export function readProgress() {
  try {
    const parsed = JSON.parse(localStorage.getItem(PROGRESS_KEY) || '{}');
    return {
      completed: Array.isArray(parsed.completed) ? parsed.completed : [],
      lastWatched: typeof parsed.lastWatched === 'string' ? parsed.lastWatched : null,
    };
  } catch {
    return { completed: [], lastWatched: null };
  }
}

function writeProgress(next) {
  try {
    localStorage.setItem(PROGRESS_KEY, JSON.stringify(next));
  } catch {
    // Private mode / quota: progress is a convenience, never a blocker.
  }
}

export function markComplete(key) {
  const p = readProgress();
  if (p.completed.includes(key)) return p;
  const next = { ...p, completed: [...p.completed, key] };
  writeProgress(next);
  return next;
}

export function markWatching(key) {
  const p = readProgress();
  if (p.lastWatched === key) return p;
  const next = { ...p, lastWatched: key };
  writeProgress(next);
  return next;
}

export function isComplete(course, lesson, progress) {
  return progress.completed.includes(lessonKey(course, lesson));
}

export function courseCompletion(course, progress) {
  return course.lessons.filter((l) => isComplete(course, l, progress)).length;
}

/** Where to pick a course up: the unfinished lesson you were last on, else
 *  the first unwatched one, else lesson 1 once it is all watched. */
export function resumeInCourse(course, progress) {
  const last = course.lessons.find((l) => lessonKey(course, l) === progress.lastWatched);
  if (last && !isComplete(course, last, progress)) return last;
  return course.lessons.find((l) => !isComplete(course, l, progress)) || course.lessons[0];
}

/** Where to pick up across the academy: the first course with something
 *  unwatched, resumed the same way its own row would, or null when done. */
export function resumeLesson(courses, progress) {
  const course = courses.find((c) => courseCompletion(c, progress) < c.lessons.length);
  return course ? { course, lesson: resumeInCourse(course, progress) } : null;
}

/* ------------------------------------------------------------------- utils */

export function formatDuration(seconds) {
  const total = Math.max(0, Math.floor(Number(seconds) || 0));
  return `${Math.floor(total / 60)}:${String(total % 60).padStart(2, '0')}`;
}

/** The video is optional: a lesson that has none is read instead of watched. */
export function hasVideo(lesson) {
  return Boolean(lesson?.hlsUrl || lesson?.videoUrl);
}

const WORDS_PER_MINUTE = 200;
const MIN_READING_SECONDS = 60;

/** How long the notes take to read: link and image targets and code are not read. */
export function readingSeconds(markdown) {
  const words = String(markdown || '')
    .replace(/```[\s\S]*?```/g, ' ')
    .replace(/`[^`]*`/g, ' ')
    .replace(/!?\[([^\]]*)\]\([^)]*\)/g, '$1')
    .split(/\s+/)
    .filter((word) => /[\p{L}\p{N}]/u.test(word)).length;
  return Math.max(MIN_READING_SECONDS, Math.round((words / WORDS_PER_MINUTE) * 60));
}

/** What one lesson costs a learner, so a course of readings still has an honest total. */
export function lessonSeconds(lesson) {
  return hasVideo(lesson) ? Math.max(0, Number(lesson.durationSeconds) || 0) : readingSeconds(lesson.bodyMarkdown);
}

export function doneWord(lesson) {
  return hasVideo(lesson) ? 'watched' : 'read';
}

export function formatReadingTime(seconds) {
  return `${Math.max(1, Math.round(seconds / 60))} min read`;
}

/**
 * Call `onReached` once the element has been at least half visible and
 * `dwellMs` has passed since the call, in either order: the end of a short
 * lesson is already on screen when the page renders.
 *
 * @returns {() => void} stop observing
 */
export function observeEnd(element, { dwellMs = 0 } = {}, onReached) {
  if (!element || typeof IntersectionObserver !== 'function') return () => {};
  let visible = false;
  let dwelled = false;
  let done = false;
  const stop = () => { clearTimeout(timer); observer.disconnect(); };
  const settle = () => {
    if (done || !visible || !dwelled) return;
    done = true;
    stop();
    onReached();
  };
  const observer = new IntersectionObserver((entries) => {
    visible = entries.some((entry) => entry.isIntersecting);
    settle();
  }, { threshold: 0.5 });
  const timer = setTimeout(() => { dwelled = true; settle(); }, dwellMs);
  observer.observe(element);
  return stop;
}

import { escapeHtml, renderLessonBody } from './academy-markdown.js';
export { escapeHtml, renderLessonBody };

/** SVG glyphs, all `currentColor` so they inherit the token on their parent. */
export const ICONS = {
  play: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round" aria-hidden="true"><path d="M9.5 8.3v7.4c0 1.1 1.2 1.8 2.1 1.2l6-3.7c.9-.6.9-1.9 0-2.4l-6-3.7c-.9-.6-2.1.1-2.1 1.2z"/></svg>',
  ring: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><circle cx="12" cy="12" r="9"/></svg>',
  check: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="m8.5 12 2.4 2.4 4.6-4.8"/></svg>',
  arrowRight: '<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg>',
  arrowLeft: '<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 18l-6-6 6-6"/></svg>',
  close: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M18 6 6 18M6 6l12 12"/></svg>',
};

/* ------------------------------------------------------------------ player */

/**
 * Build the poster + play-badge player used by the lesson page and the modal.
 *
 * The badge and the player's controls are mutually exclusive: the badge sits
 * over a poster until it is activated, and only then does the player mount
 * (Video.js v10 for a lesson with an HLS ladder, a native `<video>` with
 * `controls` for a progressive-only one). Rendering both at once gives the
 * user two competing play affordances.
 *
 * @param {object} options
 * @param {object} options.lesson      lesson record from the academy payload
 * @param {{bufferSeconds?: number}|null} [options.player] the payload's `player` block
 * @param {() => void} [options.onComplete] fired once, at 90% watched
 * @param {HTMLElement} [options.endCard] revealed on `ended` (U5)
 * @returns {{root: HTMLElement, video: HTMLElement, activate: ()=>Promise<void>, reset: ()=>void}}
 */
export function createPlayer({ lesson, player, onComplete, endCard } = {}) {
  const root = document.createElement('div');
  root.className = 'acad-player';

  const hls = Boolean(lesson.hlsUrl);
  const captions = Array.isArray(lesson.captions) ? lesson.captions : [];
  const media = document.createElement(hls ? 'hlsjs-video' : 'video');
  media.setAttribute('preload', 'none');   // nothing downloads before a click
  media.setAttribute('playsinline', '');
  // Tracks live on the CDN, and a text track is only readable cross-origin
  // when the media itself was fetched in CORS mode. Set before any source.
  if (hls || captions.length) media.setAttribute('crossorigin', 'anonymous');
  media.setAttribute('aria-label', lesson.title);
  // Attributes, not properties: the HLS element forwards its <track> children
  // to the video it owns by copying attributes.
  for (const caption of captions) {
    const track = document.createElement('track');
    track.setAttribute('kind', caption.kind || 'subtitles');
    track.setAttribute('srclang', caption.srclang);
    track.setAttribute('label', caption.label);
    track.setAttribute('src', caption.src);
    if (caption.default) track.setAttribute('default', '');
    media.appendChild(track);
  }

  let mount = media;
  let poster = null;
  if (hls) {
    mount = document.createElement('video-player');
    if (lesson.posterUrl) mount.setAttribute('poster', lesson.posterUrl);
    const skin = document.createElement('video-skin');
    skin.appendChild(media);
    mount.appendChild(skin);
    if (lesson.posterUrl) {
      poster = document.createElement('img');
      poster.className = 'acad-poster';
      poster.alt = '';
      poster.decoding = 'async';
      poster.src = lesson.posterUrl;
      root.appendChild(poster);
    }
    // Start the download now so the click only waits on what is still in flight.
    loadVideoJs().catch(() => { /* reported when the badge is pressed */ });
  } else {
    media.poster = lesson.posterUrl || '';
    media.src = lesson.videoUrl || '';
    root.appendChild(media);
  }

  const badge = document.createElement('button');
  badge.type = 'button';
  badge.className = 'acad-play';
  badge.innerHTML = `<span>${ICONS.play}</span>`;
  badge.setAttribute('aria-label', `Play: ${lesson.title}`);

  const error = document.createElement('div');
  error.className = 'acad-player-error';
  error.hidden = true;
  error.innerHTML = '<p>This video could not be loaded.</p>';
  const retry = document.createElement('button');
  retry.type = 'button';
  retry.textContent = 'Try again';
  error.appendChild(retry);

  root.append(badge, error);
  if (endCard) root.appendChild(endCard);

  /** Fullscreen is the skin's own container (inside its shadow tree) or the
   *  native video: nothing of ours renders there, so the end card and the
   *  error panel need the page back first. The store also covers WebKit's
   *  presentation mode; the native fallback only has the document API. */
  const leaveFullscreen = () => {
    const store = mount.store;
    const left = store?.fullscreen ? store.exitFullscreen?.()
      : root.contains(document.fullscreenElement) ? document.exitFullscreen?.()
        : media.webkitDisplayingFullscreen ? media.webkitExitFullscreen?.() : undefined;
    left?.catch?.(() => { /* already back */ });
  };

  const showError = () => { leaveFullscreen(); error.hidden = false; badge.hidden = true; };

  /** The packaged skin answers a media error with a modal dialog that marks
   *  every sibling up the tree `inert`, our retry panel included. Clearing the
   *  error from the player store closes that dialog, lifts the inert, and
   *  leaves our panel (the one with Try again) as the only error surface. */
  const takeOverErrors = () => {
    const store = mount.store;
    if (!store?.subscribe) return;
    store.subscribe(() => {
      if (!store.error) return;
      store.dismissError();
      showError();
    });
  };

  /** What the HLS element plays and how. hls.js is preferred on desktop Safari
   *  too, so the quality menu exists there; the buffer target is the Settings
   *  row the payload carries, and hls.js keeps its default without one.
   *  `maxBufferLength` alone is a floor in hls.js (its byte budget lets a low
   *  bitrate buffer minutes ahead), so the ceiling is set to the same value. */
  const source = () => {
    const next = { src: lesson.hlsUrl, preferPlayback: 'mse' };
    const seconds = Number(player?.bufferSeconds);
    if (Number.isFinite(seconds) && seconds > 0) next.engine = { hlsJs: { maxBufferLength: seconds, maxMaxBufferLength: seconds } };
    return next;
  };

  const engineReady = () => new Promise((resolve) => {
    media.addEventListener('loadstart', resolve, { once: true });
    setTimeout(resolve, ENGINE_WAIT_MS);
  });

  /** The source language is switched on whenever the media (re)loads: Video.js
   *  owns caption state and starts every forwarded track off, and WebKit leaves
   *  a native `default` track disabled when the element is built by script. */
  const defaultLanguage = captions.find((caption) => caption.default)?.srclang;
  const showDefaultTrack = () => {
    if (!defaultLanguage) return;
    for (const track of media.textTracks ?? []) {
      if (track.language === defaultLanguage) track.mode = 'showing';
    }
  };
  media.addEventListener('loadedmetadata', showDefaultTrack);

  let completed = false;
  let mounted = !hls;
  const activate = async () => {
    badge.hidden = true;
    if (endCard) endCard.hidden = true;
    if (hls) {
      try {
        await loadVideoJs();
      } catch (err) {
        console.error('[academy] player load failed', err);
        showError();
        return;
      }
      // The modal can close while the modules are still in flight. A player
      // built after that plays into nothing, and is never torn down because
      // it was never connected.
      if (!root.isConnected) return;
      if (!mounted) {
        poster?.remove();
        root.prepend(mount);
        globalThis.customElements?.upgrade?.(mount);
        mounted = true;
        takeOverErrors();
        const ready = engineReady();
        media.source = source();
        await ready;
      }
    } else {
      media.controls = true;
    }
    if (!root.isConnected) return;
    const played = media.play?.();
    if (played?.catch) played.catch(() => { /* autoplay policy: controls are up */ });
  };
  const reset = () => {
    if (!mounted) return;
    try { media.pause(); } catch { /* not started */ }
    media.currentTime = 0;
    if (!hls) media.controls = false;
    badge.hidden = false;
    if (endCard) endCard.hidden = true;
  };

  badge.addEventListener('click', activate);
  retry.addEventListener('click', () => {
    error.hidden = true;
    if (mounted) media.load?.();
    activate();
  });
  media.addEventListener('error', showError);
  media.addEventListener('timeupdate', () => {
    // `duration` is NaN until metadata lands, so guard before dividing.
    if (completed || !Number.isFinite(media.duration) || media.duration <= 0) return;
    if (media.currentTime / media.duration < COMPLETE_AT) return;
    completed = true;
    onComplete?.();
  });
  if (endCard) media.addEventListener('ended', () => { leaveFullscreen(); endCard.hidden = false; });

  return { root, video: media, activate, reset };
}

/* ------------------------------------------------------------------- modal */

const FOCUSABLE = 'a[href], button:not(:disabled), video[controls], [tabindex]:not([tabindex="-1"])';

/**
 * Open a lesson in an overlay, the Studio quick peek. Traps focus, closes on
 * Esc and on scrim click, locks body scroll, and restores focus to whatever
 * opened it. Progress written here is the same key the Academy reads.
 *
 * @param {() => void} [options.onClose] fired once the overlay is gone
 * @returns {() => void} close
 */
export function openVideoModal({ course, lesson, player, onClose } = {}) {
  const opener = document.activeElement;
  const scrim = document.createElement('div');
  scrim.className = 'acad-modal';
  scrim.setAttribute('role', 'dialog');
  scrim.setAttribute('aria-modal', 'true');
  scrim.setAttribute('aria-label', lesson.title);

  // A lesson without a video is read here too: the notes take the player's place.
  const notes = !hasVideo(lesson);
  const card = document.createElement('div');
  card.className = notes ? 'acad-modal-card is-notes' : 'acad-modal-card';

  const head = document.createElement('div');
  head.className = 'acad-modal-head';
  const heading = document.createElement('h2');
  heading.textContent = lesson.title;
  const close = document.createElement('button');
  close.type = 'button';
  close.className = 'acad-modal-close';
  close.setAttribute('aria-label', notes ? 'Close' : 'Close video');
  close.innerHTML = ICONS.close;
  head.append(heading, close);

  const key = lessonKey(course, lesson);
  const playback = notes ? null : createPlayer({
    lesson,
    player,
    onComplete: () => { markComplete(key); },
  });

  const body = document.createElement('div');
  body.className = 'acad-modal-body acad-body';
  if (notes) body.innerHTML = renderLessonBody(lesson.bodyMarkdown);

  const foot = document.createElement('div');
  foot.className = 'acad-modal-foot';
  const full = document.createElement('a');
  full.href = lessonHref(course, lesson);
  full.textContent = 'Open the full lesson';
  foot.appendChild(full);

  card.append(head, notes ? body : playback.root, foot);
  scrim.appendChild(card);

  const previousOverflow = document.body.style.overflow;
  document.body.style.overflow = 'hidden';

  const onKey = (e) => {
    if (e.key === 'Escape') { e.stopPropagation(); dismiss(); return; }
    if (e.key !== 'Tab') return;
    const items = [...card.querySelectorAll(FOCUSABLE)].filter((el) => el.offsetParent !== null);
    if (!items.length) return;
    const first = items[0];
    const last = items[items.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  };

  let dismissed = false;
  function dismiss() {
    if (dismissed) return;
    dismissed = true;
    document.removeEventListener('keydown', onKey, true);
    document.body.style.overflow = previousOverflow;
    try { playback?.video.pause(); } catch { /* never started */ }
    scrim.remove();
    if (opener instanceof HTMLElement) opener.focus();
    onClose?.();
  }

  // A drag that starts in the card and ends outside it lands its click on the
  // scrim (the common ancestor), so only a press that began there may close.
  let pressedScrim = false;
  scrim.addEventListener('pointerdown', (e) => { pressedScrim = e.target === scrim; });
  scrim.addEventListener('click', (e) => { if (e.target === scrim && pressedScrim) dismiss(); });
  close.addEventListener('click', dismiss);
  document.addEventListener('keydown', onKey, true);

  document.body.appendChild(scrim);
  markWatching(key);
  close.focus();
  return dismiss;
}
