/**
 * Moderation thread modal — the creator's side of the conversation a moderator
 * starts. A rejected version's reason arrives as the thread's first message, so
 * this is where the author reads WHY and answers without re-publishing blind.
 *
 * Threads are opened by moderators only; the creator can reply, not start one.
 */

import { el, toast } from './utils.js';
import { fetchHelper } from '/marketplace/js/shared/fetch-helper.js';

function fmtDate(iso) {
  if (!iso) return '';
  try {
    return new Date(iso).toLocaleString(undefined, {
      year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit',
    });
  } catch { return ''; }
}

/** Per-version thread summaries for one agent, keyed by version. */
export async function loadTicketSummaries(id) {
  const map = new Map();
  if (!id) return map;
  try {
    const res = await fetchHelper(`https://aitopia.ai/api/agent-builder/tickets/${encodeURIComponent(id)}`);
    if (!res.ok) return map;
    const json = await res.json();
    for (const t of (Array.isArray(json?.tickets) ? json.tickets : [])) {
      map.set(t.version, t);
    }
  } catch { /* badges are optional — a failed load just renders none */ }
  return map;
}

function messageNode(m) {
  const isAdmin = m.authorType === 'admin';
  const who = isAdmin ? (m.authorName ? `Moderator · ${m.authorName}` : 'Moderator') : 'You';
  return el('div', {
    class: 'ab-ticket-msg' + (isAdmin ? ' is-admin' : ''),
  },
    el('div', { class: 'ab-ticket-msg-head' },
      el('strong', {}, who),
      m.kind === 'rejected' ? el('span', { class: 'ab-ver-badge rejected' }, 'Rejection reason') : null,
      el('span', { class: 'ab-ticket-time' }, fmtDate(m.createdAt)),
    ),
    el('p', { class: 'ab-ticket-body' }, m.body),
  );
}

/**
 * Open the thread for one version. Resolves when the modal closes; the boolean
 * says whether anything was posted, so the caller can refresh its badges.
 */
export function openTicketModal(id, version) {
  return new Promise((resolve) => {
    const prev = document.getElementById('ab-modal-ticket');
    if (prev) prev.remove();

    let posted = false;
    let settled = false;
    const back = el('div', { class: 'ab-modal-back visible', id: 'ab-modal-ticket', 'aria-hidden': 'false' });
    const onKey = (e) => { if (e.key === 'Escape') done(); };
    const done = () => {
      if (settled) return;
      settled = true;
      document.removeEventListener('keydown', onKey);
      back.remove();
      resolve(posted);
    };
    back._abDismiss = done;
    back.addEventListener('click', (e) => { if (e.target === back) done(); });
    document.addEventListener('keydown', onKey);

    const list = el('div', { class: 'ab-ticket-list' }, el('p', { class: 'ab-ticket-empty' }, 'Loading…'));
    const input = el('textarea', {
      class: 'ab-ticket-input',
      rows: '3',
      placeholder: 'Reply to the moderator…',
    });
    const sendBtn = el('button', {
      class: 'btn', type: 'button',
      style: 'background:var(--ab-gradient); border:none; color:#FFFFFF; border-radius:12px; font-weight:700; padding:0.55rem 1.1rem;',
      onclick: () => send(),
    }, 'Send');
    const composer = el('div', { class: 'ab-ticket-composer', hidden: true }, input, el('div', { class: 'flex justify-end mt-2' }, sendBtn));

    async function render() {
      try {
        const res = await fetchHelper(
          `https://aitopia.ai/api/agent-builder/ticket/${encodeURIComponent(id)}/${encodeURIComponent(version)}`,
        );
        const json = res.ok ? await res.json() : null;
        const messages = Array.isArray(json?.messages) ? json.messages : [];
        list.innerHTML = '';
        if (!messages.length) {
          list.appendChild(el('p', { class: 'ab-ticket-empty' },
            'No moderator messages for this version yet.'));
          composer.hidden = true;
          return;
        }
        for (const m of messages) list.appendChild(messageNode(m));
        list.scrollTop = list.scrollHeight;
        // Replying is only possible once a moderator has opened the thread.
        composer.hidden = false;
      } catch (err) {
        list.innerHTML = '';
        list.appendChild(el('p', { class: 'ab-ticket-empty' }, 'Could not load the thread.'));
      }
    }

    async function send() {
      const body = input.value.trim();
      if (!body) return;
      sendBtn.disabled = true;
      try {
        const res = await fetchHelper(
          `https://aitopia.ai/api/agent-builder/ticket/${encodeURIComponent(id)}/${encodeURIComponent(version)}/messages`,
          { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ body }) },
        );
        if (!res.ok) { toast('Could not send the message.', 'error', 4000); return; }
        input.value = '';
        posted = true;
        await render();
      } catch (err) {
        toast('Network error sending the message.', 'error', 4000);
      } finally {
        sendBtn.disabled = false;
      }
    }

    const modal = el('div', { class: 'ab-modal ab-ticket-modal', role: 'dialog', 'aria-modal': 'true' },
      el('div', { class: 'flex items-center justify-between mb-1' },
        el('h3', { class: 'text-lg font-bold' }, `Moderation · v${version}`),
        el('button', {
          class: 'btn', type: 'button', 'aria-label': 'Close',
          style: 'background:transparent; border:none; color:var(--ab-muted); font-size:20px; line-height:1; padding:0 0.25rem;',
          onclick: done,
        }, '×'),
      ),
      el('p', { class: 'text-sm mb-3', style: 'color:var(--ab-muted); line-height:1.5;' },
        'Messages from the review team about this version, and your replies.'),
      list,
      composer,
    );

    back.appendChild(modal);
    document.body.appendChild(back);
    render();
  });
}
