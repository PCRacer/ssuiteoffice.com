/**
 * Pass 4 — Steps.
 *
 * Each step is one model call. The author's flow is:
 *
 *   1. Click "+ Add step". The model picker opens *before* a step exists.
 *   2. Pick a model. A new step is created with `model_id` already set.
 *   3. The wizard immediately fetches that model's input schema from
 *      `GET /api/models/schema?modelId=<id>` and pre-fills `step.schema` from
 *      the schema's `required` + `properties`. Required keys are enabled and
 *      locked on; optional keys appear with a disabled checkbox (the author
 *      flips them on when they want to override the model's default).
 *
 * This means the schema shape always matches what the chosen model actually
 * accepts — the wizard never invents fields and never silently drops keys the
 * model requires.
 *
 * `step.__schemaMeta` carries the fetched schema in-memory for the renderer.
 * It is stripped from the persisted JSON in state.js / utils.js so it never
 * leaks into the published agent document.
 */

import { state, notify, invalidatePreviewFrom, cleanAgentForExport, rememberModel } from './state.js';
import { el, $, toast, confirmModal, placeholdersInSchema, resolveSchemaControl, ensureFieldForKey, floorCredits, agentGroupOf, agentGroupModes, agentGroupCreditsLabel, priceMargin, kindStepCredits, isInsufficientCredits, insufficientCreditsMessage, openPricingModal, ensureSignedIn } from './utils.js';
import { placeFixedPopover as placeFixedPopoverShared } from '/marketplace/js/shared/popover-position.js';
import { REFERENCE_MODE_KEY, isHiddenByReferenceMode as refModeHides, referenceModeClassOf } from '../shared/reference-mode.js';
import { fetchHelper } from '/marketplace/js/shared/fetch-helper.js';
import { MINDMAP_HELPER_FIELDS } from '/marketplace/js/runner/rich-output.js';
// Dependency planning shared with the server runtime — independent steps run
// concurrently, a checkpoint runs alone.
import { planWaves } from '/marketplace/js/shared/step-waves.js';
// ETA rules shared with the server, so every surface shows the same number.
import { maxModelDurationSeconds, estimateStepMs, applyLearnedStepDuration } from '/marketplace/js/shared/step-estimate.js';
import {
  setStepKinds,
  stepKindList,
  stepKindSpecOf,
  stepKindOf as kindOfStep,
  stepFamilies,
  familyMeta,
  placeholderSourcesOf,
  placeholderRoots,
  objectSchemaPropsOf,
  stepEmitsText,
  stepEmitsObject,
  seedStep,
  readStepField,
  applyPickSnapshot,
  pickedManyName,
} from '/marketplace/js/shared/step-kinds.js';
// Shared verbatim with the preview tab so the two hashes cannot drift.
import { stepForHash } from '/marketplace/js/agent-builder-preview/storage-keys.js';
import { renderDeclarativeEditor } from './step-editors/declarative.js';
// Run-prep modal draws its inputs with the runner's own form.
import { renderSchemaForm } from '/marketplace/js/runner/schema-form.js';
import { optionLabelsFor, optionListOf } from '/marketplace/js/components/form/field-shape.js';
// Same media classifier the published agent runner uses (image / video / audio
// from URL extension or data: prefix). Reusing it keeps builder output panels
// visually identical to /agents/<slug>.
import { collectMediaUrls } from '/marketplace/js/runner/collect-media-urls.js';
// Markdown renderer for content-research text output, so the preview panel
// shows rendered headings/bold/lists like the published runner does.
import { renderMarkdownInto } from '/marketplace/js/shared/markdown.js';
import { COMPONENT_META } from '/marketplace/js/components/form/component-meta.js';
import { ASSET_SOURCES } from '/marketplace/js/components/form/asset-sources.js';

// Schema keys the wizard owns at runtime — author should not be offered them
// in the optional-enable row, and they don't surface in the required block.
//   - prompt        → soul owns it (single-slot models)
//   - system_prompt → runtime maps soul to it automatically (dual-slot models)
//   - referenceMode → r2v routing flag, rendered as a dedicated toggle (see
//                     renderReferenceModeToggle); never a normal input field
const RESERVED_SCHEMA_KEYS = new Set(['prompt', 'system_prompt', REFERENCE_MODE_KEY]);

function openModal(id) {
  document.getElementById(id)?.classList.add('visible');
  document.getElementById(id)?.setAttribute('aria-hidden', 'false');
}
function closeModal(id) {
  document.getElementById(id)?.classList.remove('visible');
  document.getElementById(id)?.setAttribute('aria-hidden', 'true');
}

// ---------------------------------------------------------------------------
// Step kinds (dynamic — driven entirely by /config `stepKinds`)
// ---------------------------------------------------------------------------
//
// Nothing about a kind is hardcoded here: the kind picker, each editor, and
// pricing all read from the catalog the server ships. Adding a new kind on the
// server makes it appear in the builder with no change to this file beyond an
// editor renderer (and even unknown kinds degrade gracefully).

function stepKinds() {
  if (Array.isArray(state.config?.stepKinds) && state.config.stepKinds.length) {
    setStepKinds(state.config.stepKinds);
  }
  return stepKindList();
}

function stepKindSpec(kind) {
  stepKinds();
  return stepKindSpecOf(kind);
}

function stepKindOf(step) {
  return kindOfStep(step);
}

/** Throwaway DOM, so a new kind needs no HTML. */
function openPickerShell(title, subtitle) {
  document.getElementById('ab-modal-stepkind')?.remove();
  const back = el('div', {
    class: 'ab-modal-back visible',
    id: 'ab-modal-stepkind',
    'aria-hidden': 'false',
    onclick: (e) => { if (e.target === back) back.remove(); },
  });
  const modal = el('div', { class: 'ab-modal', style: 'max-width: 760px;' });
  const head = el('div', { class: 'flex items-center justify-between mb-3' },
    el('h3', { class: 'text-lg font-bold' }, title),
    el('button', { class: 'btn ab-modal-close', type: 'button', 'aria-label': 'Close', onclick: () => back.remove() }, '×'),
  );
  modal.appendChild(head);
  if (subtitle) modal.appendChild(el('p', { class: 'text-sm text-muted-foreground mb-4' }, subtitle));
  const search = el('input', {
    placeholder: 'Filter…',
    class: 'mb-3',
    style: 'width:100%; padding:0.7rem 1rem; border-radius:14px; background:var(--ab-elev); border:none; color:var(--ab-text); outline:none;',
    oninput: () => {
      const q = search.value.trim().toLowerCase();
      for (const card of grid.querySelectorAll('.ab-catalog-pick')) {
        card.style.display = !q || card.textContent.toLowerCase().includes(q) ? '' : 'none';
      }
    },
  });
  modal.appendChild(search);
  const grid = el('div', { class: 'ab-catalog-grid' });
  modal.appendChild(grid);
  back.appendChild(modal);
  document.body.appendChild(back);
  search.focus();
  return { back, modal, grid };
}

function pickCard(title, description, onPick, specs) {
  const chips = (specs || []).filter(Boolean);
  return el('div', {
    class: 'ab-catalog-pick',
    role: 'button',
    tabindex: '0',
    onclick: onPick,
    onkeydown: (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onPick(); } },
  },
    el('div', { class: 'pick-title' }, title),
    description ? el('div', { class: 'pick-desc' }, description) : null,
    chips.length ? el('div', { class: 'pick-specs' }, ...chips) : null,
  );
}

/** What a kind costs before it is configured, from its own catalog entry. */
function kindBaseChip(spec) {
  const base = Number(spec?.baseCredits);
  if (!Number.isFinite(base) || base <= 0) return null;
  const chip = creditsChip(base, { dim: true });
  chip.classList.add('pick-spec');
  return chip;
}

/** Family, then kind - both tiers derived from the catalog. */
function openStepKindPicker() {
  stepKinds();
  const families = stepFamilies();
  if (families.length === 0) { startAddStep('model'); return; }
  if (families.length === 1 && families[0].kinds.length === 1) {
    startAddStep(families[0].kinds[0].kind);
    return;
  }
  if (families.length === 1) { openKindTier(families[0], null); return; }

  const { back, grid } = openPickerShell('Add a step', 'What should this step do?');
  for (const fam of families) {
    const meta = familyMeta(fam.family);
    const pick = fam.kinds.length === 1
      ? () => { back.remove(); startAddStep(fam.kinds[0].kind); }
      : () => { back.remove(); openKindTier(fam, () => openStepKindPicker()); };
    grid.appendChild(pickCard(meta.label, meta.description || fam.kinds.map(k => k.label || k.kind).join(' · '), pick));
  }
}

function openKindTier(fam, onBack) {
  const meta = familyMeta(fam.family);
  const { back, modal, grid } = openPickerShell(meta.label, meta.description);
  for (const spec of fam.kinds) {
    grid.appendChild(pickCard(spec.label || spec.kind, spec.whenToUse || spec.description,
      () => { back.remove(); startAddStep(spec.kind, () => openKindTier(fam, onBack)); }, [kindBaseChip(spec)]));
  }
  if (onBack) {
    modal.appendChild(el('button', {
      class: 'btn mt-3', type: 'button',
      onclick: () => { back.remove(); onBack(); },
    }, '← Back'));
  }
}

/** Begin creating a step of the given kind; onBack reopens the picker it came from. */
function startAddStep(kind, onBack) {
  const spec = stepKindSpec(kind);
  // Server-owned cap (AGENT_BUILDER_MAX_STEPS) via state.config, never a literal.
  const maxSteps = Number(state.config?.maxSteps);
  if (Number.isFinite(maxSteps) && maxSteps > 0 && state.agent.steps.length >= maxSteps) {
    toast(`Maximum ${maxSteps} steps.`, 'error');
    return;
  }
  // A kind that picks something creates its step only once the pick is made.
  if (!spec || spec.picksModel) {
    modelPickerMode = { kind: 'new' };
    openModelPicker();
    return;
  }
  if (spec.picksMany) {
    openManyPicker(kind, spec, maxSteps, onBack);
    return;
  }
  if (spec.picksFirst) {
    const cap = Number(spec.maxPerDoc);
    if (Number.isFinite(cap) && cap > 0) {
      const used = state.agent.steps.filter(s => kindOfStep(s) === kind).length;
      if (used >= cap) {
        toast(`Maximum ${cap} ${spec.label || kind} steps.`, 'error');
        return;
      }
    }
    const field = (spec.editorFields || []).find(f => f.name === spec.picksFirst);
    openAgentPicker({
      onPick: async (entry) => {
        const step = seedStep(kind, 'output_' + (state.agent.steps.length + 1));
        step[spec.picksFirst] = entry.id || entry.slug;
        if (field) applyPickSnapshot(step, field, entry);
        // Opens expanded, like a model step, so the author lands on the inputs.
        step.__expanded = true;
        state.agent.steps.push(step);
        notify();
        const added = await loadAndApplyPickedSchema(step, spec);
        if (added.length) announceAddedFields(added);
      },
    });
    return;
  }
  const step = seedStep(kind, 'output_' + (state.agent.steps.length + 1));
  // Opens expanded, like a model or agent step, so the author lands on its form.
  step.__expanded = true;
  state.agent.steps.push(step);
  notify();
}

/** Checklist of a kind's options; every checked one becomes its own step. */
function openManyPicker(kind, spec, maxSteps, onBack) {
  const field = (spec.editorFields || []).find(f => f.name === spec.picksMany);
  const source = field?.optionsFrom ? spec[field.optionsFrom] : field?.options;
  const options = (Array.isArray(source) ? source : []).filter(o => o && o.id);
  const { back, modal, grid } = openPickerShell(spec.label || kind, 'Tick the tools to add; each becomes its own step.');
  const picked = [];
  const addBtn = el('button', { class: 'btn primary', type: 'button', disabled: 'disabled' }, 'Add steps');
  const refresh = () => {
    addBtn.textContent = picked.length ? `Add ${picked.length} step${picked.length === 1 ? '' : 's'}` : 'Add steps';
    addBtn.disabled = picked.length === 0;
  };
  for (const opt of options) {
    const cb = el('input', { type: 'checkbox', style: 'margin-right:0.5rem;' });
    const toggle = () => {
      const at = picked.indexOf(opt.id);
      if (at === -1) picked.push(opt.id); else picked.splice(at, 1);
      cb.checked = at === -1;
      refresh();
    };
    cb.addEventListener('click', (e) => { e.stopPropagation(); toggle(); });
    const card = pickCard(opt.label || opt.id, firstSentence(opt.description), toggle);
    card.querySelector('.pick-title')?.prepend(cb);
    // Long tool docs stay readable on hover instead of stretching the grid.
    const desc = card.querySelector('.pick-desc');
    if (desc) {
      desc.title = opt.description;
      desc.style.cssText = 'display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden;';
    }
    grid.appendChild(card);
  }
  addBtn.addEventListener('click', () => {
    const room = Number.isFinite(maxSteps) && maxSteps > 0 ? maxSteps - state.agent.steps.length : Infinity;
    if (picked.length > room) {
      toast(`Maximum ${maxSteps} steps — untick ${picked.length - room}.`, 'error');
      return;
    }
    back.remove();
    // Steps follow the tick order, so the author can tick in the order they want them to run.
    for (const id of picked) {
      const step = seedStep(kind, 'output_' + (state.agent.steps.length + 1));
      step[spec.picksMany] = id;
      step.__expanded = true;
      state.agent.steps.push(step);
    }
    notify();
  });
  modal.appendChild(el('div', { class: 'flex items-center justify-between mt-3' },
    onBack
      ? el('button', { class: 'btn', type: 'button', onclick: () => { back.remove(); onBack(); } }, '← Back')
      : el('span', {}),
    addBtn));
}

function firstSentence(text) {
  const s = String(text || '').trim();
  const m = /^.+?[.!?](?=\s+[A-Z]|$)/.exec(s);
  return m ? m[0] : s;
}

/**
 * Mode of the picker:
 *   - { kind: 'new' }                          → picking the model creates a new step
 *   - { kind: 'change', stepIndex: n }         → picking the model swaps an existing step's model
 *   - { kind: 'add-model', stepIndex, onPick } → appends to a selector's list
 */
let modelPickerMode = null;

/* ---------------- Schema fetch + apply ---------------- */

const _schemaCache = new Map(); // modelId → schema response

// Steps whose model schema has been re-merged this page load. A WeakSet keyed
// on the step object so it resets on refresh (the boot loop re-runs once per
// load) and never holds a step alive past a delete/replace. See the boot loop
// in renderStepsPass for why a stored `__schemaMeta` alone isn't trusted.
const _rehydratedSchemaSteps = new WeakSet();

/** Match each schema key to this model's own key via `mapped_to`, else by
 *  name. `remap` is stored; `hints` is placeholder text only. */
/** A key no other row uses; the model id wins when free, else -2, -3… */
function nextOptionKey(rows, modelId) {
  const taken = new Set((rows || []).map(r => (r && r.key) || (r && r.id)).filter(Boolean));
  if (!taken.has(modelId)) return modelId;
  for (let n = 2; n < 500; n++) {
    const candidate = `${modelId}-${n}`;
    if (!taken.has(candidate)) return candidate;
  }
  return `${modelId}-${Date.now()}`;
}

/** The option a model-selector step wires its schema from: the author's
 *  default, else the first row. */
function defaultSelectorModelId(step) {
  const rows = Array.isArray(step?.models) ? step.models.filter(r => r && r.id) : [];
  if (!rows.length) return '';
  const wanted = typeof step.default_model === 'string' ? step.default_model.trim() : '';
  // default_model names an option key; older drafts name a model id.
  const row = (wanted && (rows.find(r => (r.key || r.id) === wanted) || rows.find(r => r.id === wanted)))
    || rows[0];
  return row.id;
}

/** The closed choice lists a model declares, keyed by its own field name. */
function collectModelEnums(props, keys) {
  const out = {};
  for (const key of keys) {
    const values = Array.isArray(props[key]?.enum) ? props[key].enum.filter(v => v != null) : [];
    if (values.length) out[key] = values.map(String);
  }
  return out;
}

/** Media kind a model-selector step is locked to: whatever its first model is.
 *  Null until the first pick, when every tab is still on offer. */
function selectorMediaKind(step) {
  const first = Array.isArray(step?.models) ? step.models.find(r => r && r.id) : null;
  if (!first) return null;
  // Remembered from the picker, so the lock survives an empty model cache.
  if (typeof first.__mediaKind === 'string' && first.__mediaKind) return first.__mediaKind;
  const models = Array.isArray(state.config?.models) ? state.config.models : [];
  const entry = models.find(m => m && m.id === first.id);
  if (!entry) return null;
  // Same derivation the picker's type tabs use, so the two cannot disagree.
  const kind = entry.mediaType || modelOutputType(entry);
  return ['video', 'audio', 'image', 'text'].includes(kind) ? kind : null;
}

function suggestRemap(stepSchema, modelSchema) {
  const keys = Object.keys(stepSchema && typeof stepSchema === 'object' ? stepSchema : {});
  const props = Object.keys(modelSchema?.properties || {});
  const remap = {};
  const hints = {};
  if (keys.length === 0 || props.length === 0) return { remap, hints };

  const catalog = Array.isArray(state.config?.catalog) ? state.config.catalog : [];
  const conceptOf = (name) => {
    const hit = catalog.find(c => c.id === name
      || (Array.isArray(c.mapped_to) && c.mapped_to.includes(name)));
    return hit ? hit.id : null;
  };

  const taken = new Set();
  for (const key of keys) {
    if (props.includes(key)) { hints[key] = key; taken.add(key); continue; }
    const concept = conceptOf(key);
    if (!concept) continue;
    const match = props.find(p => !taken.has(p) && conceptOf(p) === concept);
    if (!match) continue;
    remap[key] = match;
    hints[key] = match;
    taken.add(match);
  }
  return { remap, hints };
}

async function fetchModelSchema(modelId) {
  if (_schemaCache.has(modelId)) return _schemaCache.get(modelId);
  // /api/agent-builder/model-schema returns a UNION of every endpoint the
  // model can route to (native provider + every FAL endpoint alias).
  // /api/models/schema only returns one endpoint at a time, which made the
  // builder miss fields like Source Image / End Frame on multi-endpoint
  // models (seedance, kling, veo, …) where production runs hit i2v or r2v
  // depending on input shape.
  const res = await fetchHelper(`https://aitopia.ai/api/agent-builder/model-schema?modelId=${encodeURIComponent(modelId)}`);
  if (!res.ok) {
    let detail = '';
    try { detail = (await res.json())?.message || ''; } catch {}
    throw new Error(`Schema fetch failed (${res.status}) ${detail}`.trim());
  }
  const json = await res.json();
  // The schema response carries per-model pricing/output metadata in `x-model`
  // (cost, tags, tier, capabilities, creditsEstimated). Cache it so the per-step
  // floor + output-type lookups resolve — this is what hydrates a loaded agent's
  // models on edit/refresh without a separate /api/models/compact call.
  if (json && json['x-model'] && typeof json['x-model'] === 'object' && json['x-model'].provider) {
    rememberModel({ id: modelId, ...json['x-model'] });
  }
  _schemaCache.set(modelId, json);
  return json;
}

/**
 * Compute a sensible literal "starter" value for an optional key. We never put
 * a `${placeholder}` here — the author wires those in explicitly via the tag
 * rows. For required keys we leave the value as an empty string so the author
 * is forced to choose a source (form field, upstream output, or literal).
 */
function starterValueFor(prop) {
  if (!prop || typeof prop !== 'object') return '';
  // Provider default wins, even if it's a falsy value (false, 0, "").
  if (Object.prototype.hasOwnProperty.call(prop, 'default')) return prop.default;
  switch (prop.type) {
    case 'integer':
    case 'number':
      if (typeof prop.minimum === 'number') return prop.minimum;
      return 0;
    case 'boolean':
      return false;
    case 'array':
      return [];
    case 'object':
      return {};
    default:
      return '';
  }
}

/**
 * Apply a fetched schema to a step. Required keys go in straight away; optional
 * keys are tracked in `step.__optionalAvailable` so the renderer can offer them
 * as checkboxes without polluting the persisted JSON. Existing values on the
 * step are preserved when their key still exists in the new schema (e.g. when
 * the author swaps to a sibling model with overlapping inputs).

 * **Prompt is highlighted, not forced.** Some models genuinely don't take a
 * prompt — background removers, upscalers, format converters. For those the
 * step's schema simply has no `prompt` key, and the wizard does not invent
 * one. But *when* the model's schema does declare a `prompt`, the wizard
 * treats it as the most important field: it's hoisted to the top of the
 * editor, given a primary-tinted card, and visually distinguished from the
 * other knobs. Authors wire form-field placeholders into the prompt, so when
 * it's there it's the spine of the step.
 */
/**
 * Apply a fetched schema to a step.
 *
 * Behaviour (auto-wire required keys):
 *   - For every required key whose previous value is empty/missing AND not
 *     already a `${placeholder}`: synthesize a form field for it and rewrite
 *     `step.schema[key] = '${' + fieldId + '}'`. Catalog match drives the
 *     concept id + ui_component; otherwise a custom textarea field is created
 *     under the schema key's own name.
 *   - Previous wirings (`${field_id}` placeholders, hand-typed literals, or
 *     upstream output references) survive intact — model change inside a step
 *     should not blow away the author's explicit choices.
 *   - `prompt` is reserved; soul owns it.
 *
 * Optional keys remain in `__optionalAvailable` until the author enables one.
 * The "+ Enable optional" handler runs the same field bridge.
 *
 * Returns `{ addedFieldIds }` so the caller can decide whether to nudge the
 * author toward Pass 4 (Fields).
 */
function applySchemaToStep(step, schema, opts = {}) {
  // An agent step wires into `inputs`, and a sub-agent may declare a real
  // `prompt` form field, so reserved keys are model-only.
  const target = opts.target || 'schema';
  const reserved = opts.reserved === false ? new Set() : RESERVED_SCHEMA_KEYS;
  const props = (schema && schema.properties) || {};
  const required = Array.isArray(schema?.required) ? schema.required : [];
  const requiredSet = new Set(required);

  const previousSchema = step[target] && typeof step[target] === 'object' ? step[target] : {};
  const nextSchema = {};
  const addedFieldIds = [];

  const isAlreadyWired = (val) => {
    if (typeof val !== 'string') return val != null && val !== '';
    if (val === '') return false;
    // ${...} placeholder OR a hand-typed literal — both count as "author owns this".
    return true;
  };

  for (const key of required) {
    if (reserved.has(key)) {
      // `prompt` and `system_prompt` are runtime-owned. The runtime sees the
      // model declares them (via the fetched model schema) and writes soul
      // (and, if the author enabled an optional `prompt`, soul + user prompt)
      // into the right slot at call time. The builder does NOT pre-seed the
      // key in step.schema — that would be a stale literal the runtime has
      // to special-case. No form field is created either.
      continue;
    }
    const prev = previousSchema[key];
    if (isAlreadyWired(prev)) {
      nextSchema[key] = prev;
      continue;
    }
    // Empty / missing → auto-create field and wire placeholder.
    const fieldId = ensureFieldForRequiredKey(key, props[key]);
    nextSchema[key] = '${' + fieldId + '}';
    if (!addedFieldIds.includes(fieldId)) addedFieldIds.push(fieldId);
  }

  // Optional keys: untouched here. They stay in __optionalAvailable until the
  // author explicitly enables one via the "+ enable" row.
  //
  // `prompt` is reserved — soul owns it.
  // `system_prompt` is also reserved — the runtime maps soul → system_prompt
  // automatically when the model declares one; surfacing it as an enable-able
  // optional would let the author wire a second source of truth.
  const optionalAvailable = [];
  for (const key of Object.keys(props)) {
    if (requiredSet.has(key)) continue;
    if (reserved.has(key)) continue;
    if (Object.prototype.hasOwnProperty.call(previousSchema, key)) {
      nextSchema[key] = previousSchema[key];
    } else if (opts.enableAllOptional) {
      const fieldId = ensureFieldForRequiredKey(key, props[key], false);
      const prop = props[key] || {};
      if (Object.prototype.hasOwnProperty.call(prop, 'default')) {
        const f = state.agent.fields.find(x => x.id === fieldId);
        if (f && (f.default === undefined || f.default === null)) f.default = prop.default;
      }
      nextSchema[key] = '${' + fieldId + '}';
      if (!addedFieldIds.includes(fieldId)) addedFieldIds.push(fieldId);
    } else {
      optionalAvailable.push(key);
    }
  }

  // Carry the r2v flag across a re-apply (it's reserved, so the loops skip it),
  // but only if the new model still supports reference mode.
  if (schema?.supportsReference === true && previousSchema[REFERENCE_MODE_KEY] === true) {
    nextSchema[REFERENCE_MODE_KEY] = true;
  }

  step[target] = nextSchema;
  step.__schemaMeta = { properties: props, required };
  step.__supportsReference = schema?.supportsReference === true;
  step.__optionalAvailable = optionalAvailable;
  // Drop keys from the inactive mode (cleans up agents saved before this guard).
  if (step.__supportsReference) pruneReferenceModeKeys(step, isReferenceModeOn(step));
  // Persist the model's required key list onto the step itself (not __-prefixed
  // so cleanAgentForExport keeps it). Runtime uses this to decide which fields
  // are truly required — soul references and optional-key wires don't qualify.
  //
  // INVARIANT: only keep a key in requiredKeys if it actually has a counterpart
  // in this step's schema. A requiredKey with no schema entry forces nothing —
  // it's noise at best, and for `prompt` (supplied by soul, never a schema key,
  // dropped by RESERVED_SCHEMA_KEYS above) it gets treated downstream as a
  // placeholder that must resolve to a field/output, producing
  // "Placeholder ${prompt} does not match any field or upstream output_id" and
  // breaking the run. So: keep keys present in schema, drop the rest.
  step.requiredKeys = [...required].filter((k) => Object.prototype.hasOwnProperty.call(nextSchema, k));

  return { addedFieldIds };
}

/**
 * Build a synthesized custom field from the resolver's view of a schema key.
 * Both auto-add paths (required-key seeding and key→custom promotion) create
 * the same shape: title humanised from the key, ui_component/enum/range from
 * the resolved control, default lifted from the property when present.
 * `expanded` adds the `__expanded` flag the promotion path opens the row with.
 */
function buildCustomField(id, key, prop, resolved, { expanded = false, required = false } = {}) {
  const field = {
    __custom: true,
    __autoAdded: true,
    ...(expanded ? { __expanded: true } : {}),
    id,
    title: (prop && prop.title) || key.replace(/[_-]+/g, ' ').replace(/\b\w/g, c => c.toUpperCase()),
    description: (prop && prop.description) || '',
    type: (prop && prop.type) || 'string',
    ui_component: resolved.uiComponent,
    default: prop && Object.prototype.hasOwnProperty.call(prop, 'default') ? prop.default : null,
    visible: true,
    advanced: false,
    required,
    step: false,
  };
  if (Array.isArray(resolved.enum) && resolved.enum.length) field.enum = [...resolved.enum];
  if (prop && (prop.minimum != null || prop.maximum != null)) {
    field.range = { min: prop.minimum ?? null, max: prop.maximum ?? null };
  }
  return field;
}

/**
 * Ensure a form field exists for a required schema key, returning the field id
 * the step should wire its placeholder to.
 *
 *   - Catalog match (via `resolveSchemaControl`)  → push `{ id: conceptId, __autoAdded:true }`
 *     (compact catalog entry — defaults flow through from AGENT_INPUT_MAP).
 *   - No catalog match                             → push a custom field whose id is the
 *                                                    schema key itself, seeded from the
 *                                                    property's ui-component / enum / range.
 *
 * Idempotent: if a field with that id already exists, returns it untouched.
 */
function ensureFieldForRequiredKey(key, prop, required = true) {
  const resolved = resolveSchemaControl(key, prop);
  const fieldId = resolved.conceptId || key;
  const existing = state.agent.fields.find(f => f.id === fieldId);
  if (existing) return fieldId;

  if (resolved.conceptId) {
    // Step-driven auto-add: the author wired this key into a step (required or
    // optional-enable), so the field needs to show up in the end-user form.
    // We pin `visible: true` explicitly even when the catalog concept defaults
    // to `visible: false` (e.g. `images` is hidden in the taxonomy because most
    // agents don't expose multi-image input). The catalog's default is meant
    // for forms that pick the field manually without a step demanding it; a
    // step wire is a stronger signal of intent. required: true — the step reads
    // it via `${id}`, so an empty value would be an unresolved placeholder.
    state.agent.fields.push({ id: resolved.conceptId, visible: true, required, __autoAdded: true });
    return resolved.conceptId;
  }

  // Custom field — author has to refine, but at least the shape is plausible.
  state.agent.fields.push(buildCustomField(key, key, prop, resolved, { required }));
  return key;
}

/**
 * Garbage-collect `__autoAdded` fields that no step references anymore.
 *
 * Called whenever a step is removed, a model is swapped, or a schema entry is
 * unbound. Manual fields (`__autoAdded` falsy/absent) are never touched, even
 * if they become orphaned — the author put them there on purpose.
 */
/** Mirrors a model-selector's picker onto the Fields pass as a locked row:
 *  editable presentation, choices owned by the step. */
export function syncSelectorPickerFields() {
  const steps = Array.isArray(state.agent.steps) ? state.agent.steps : [];
  const fields = Array.isArray(state.agent.fields) ? state.agent.fields : (state.agent.fields = []);
  const wanted = new Map();

  steps.forEach((step, i) => {
    if (!step || step.kind !== 'model-selector') return;
    const rows = Array.isArray(step.models) ? step.models.filter(r => r && r.id) : [];
    if (!rows.length) return;
    const id = (typeof step.field_id === 'string' && step.field_id.trim())
      || (i > 0 ? `model_choice_${i + 1}` : 'model_choice');
    step.field_id = id;
    wanted.set(id, step);
  });

  let changed = false;
  for (let i = fields.length - 1; i >= 0; i--) {
    if (fields[i]?.__selectorPicker && !wanted.has(fields[i].id)) {
      fields.splice(i, 1);
      changed = true;
    }
  }
  for (const [id] of wanted) {
    if (fields.some(f => f && f.id === id)) continue;
    // Presentation only; the doc never carries a second copy of the list.
    fields.push({
      id,
      __selectorPicker: true,
      title: 'Model',
      description: 'Which model runs this step.',
      type: 'string',
      ui_component: 'select',
      visible: true,
      advanced: false,
    });
    changed = true;
  }
  return changed;
}

/** Mirror of syncSelectorPickerFields: an agent-selector field owns the modes,
 *  this gives it the step saying what each one runs. Dropping the component
 *  takes the step with it. Returns true when the doc changed. */
export function syncAgentGroupSteps() {
  const fields = Array.isArray(state.agent.fields) ? state.agent.fields : [];
  const steps = Array.isArray(state.agent.steps) ? state.agent.steps : (state.agent.steps = []);
  const wanted = new Set(
    fields.filter(f => f && f.ui_component === 'agent-selector' && f.id).map(f => f.id),
  );

  let changed = false;
  for (let i = steps.length - 1; i >= 0; i--) {
    if (steps[i]?.kind === 'agent-group' && !wanted.has(steps[i].field_id)) {
      steps.splice(i, 1);
      changed = true;
    }
  }
  for (const fieldId of wanted) {
    if (steps.some(s => s?.kind === 'agent-group' && s.field_id === fieldId)) continue;
    const taken = new Set(steps.map(s => s?.output_id).filter(Boolean));
    let outputId = 'output_' + (steps.length + 1);
    for (let n = steps.length + 1; taken.has(outputId); n++) outputId = 'output_' + n;
    steps.push({ kind: 'agent-group', field_id: fieldId, options: {}, output_id: outputId, step: false });
    changed = true;
  }

  // Enum values added or removed after the step existed.
  for (const step of steps) {
    if (step?.kind !== 'agent-group') continue;
    const field = fields.find(f => f && f.id === step.field_id);
    const values = Array.isArray(field?.enum) ? field.enum.filter(v => typeof v === 'string' && v) : [];
    if (!step.options || typeof step.options !== 'object') { step.options = {}; changed = true; }
    for (const value of values) {
      if (!step.options[value]) { step.options[value] = { agent_id: '' }; changed = true; }
    }
    for (const value of Object.keys(step.options)) {
      if (!values.includes(value)) { delete step.options[value]; changed = true; }
    }
  }
  return changed;
}

export function pruneOrphanAutoAddedFields() {
  const referenced = new Set();
  for (const step of state.agent.steps) {
    // A kind whose inputs live outside soul/schema would lose its fields.
    for (const source of placeholderSourcesOf(step)) placeholderRoots(source, referenced);
  }
  const before = state.agent.fields.length;
  state.agent.fields = state.agent.fields.filter(f => {
    if (!f.__autoAdded) return true; // manual field — keep regardless.
    return referenced.has(f.id);
  });
  return before - state.agent.fields.length;
}

const _agentSchemaCache = new Map();

/** Sub-agent schemas mirror the model schema, nested one level under `input`. */
async function fetchAgentSchema(agentId) {
  if (_agentSchemaCache.has(agentId)) return _agentSchemaCache.get(agentId);
  const p = fetchHelper(`https://aitopia.ai/api/agents/info/${encodeURIComponent(agentId)}/schema`)
    .then(r => (r.ok ? r.json() : Promise.reject(new Error('status ' + r.status))))
    .then(j => j?.input || j);
  _agentSchemaCache.set(agentId, p);
  return p;
}

/** Wires the picked agent's required inputs to form fields, as a model does. */
function withoutLockedInputs(schema) {
  const props = (schema && schema.properties) || {};
  const open = {};
  for (const [key, prop] of Object.entries(props)) {
    if (prop && typeof prop === 'object' && prop['x-uap'] && prop['x-uap'].hidden === true) continue;
    open[key] = prop;
  }
  const required = Array.isArray(schema?.required) ? schema.required.filter(k => k in open) : [];
  return { ...schema, properties: open, required };
}

async function loadAndApplyPickedSchema(step, spec) {
  const target = spec?.schemaTarget;
  const agentId = spec?.picksFirst ? step[spec.picksFirst] : '';
  if (!target || !agentId) return [];
  step.__schemaLoading = true;
  notify();
  let addedFieldIds = [];
  try {
    const schema = withoutLockedInputs(await fetchAgentSchema(agentId));
    addedFieldIds = applySchemaToStep(step, schema, {
      target, reserved: false, enableAllOptional: spec.wiresOptionalInputs === true,
    })?.addedFieldIds || [];
  } catch (err) {
    toast('Could not load agent schema: ' + err.message, 'error', 5000);
  } finally {
    step.__schemaLoading = false;
    notify();
  }
  return addedFieldIds;
}

/**
 * Fetch the model's schema and apply it to the step. Returns the canonical
 * field ids that were added to `state.agent.fields` as a side-effect of the
 * auto-field detour (empty array on the happy path where everything was
 * already wired). Callers decide whether to navigate the wizard to Pass 3
 * based on this return value.
 */
async function loadAndApplySchema(step) {
  // No model_id of its own: the inputs come from the default option.
  const selectorModel = step.kind === 'model-selector' ? defaultSelectorModelId(step) : '';
  if (!step.model_id && !selectorModel) return [];
  step.__schemaLoading = true;
  notify();
  let addedFieldIds = [];
  try {
    const schema = await fetchModelSchema(step.model_id || selectorModel);
    const result = applySchemaToStep(step, schema);
    addedFieldIds = result?.addedFieldIds || [];
  } catch (err) {
    toast('Could not load model schema: ' + err.message, 'error', 5000);
  } finally {
    step.__schemaLoading = false;
    notify();
  }
  return addedFieldIds;
}

/* ---------------- Step play (builder runtime) ---------------- */
//
// The author can hit ▶ Run on any step to execute that step in isolation
// against live models. We walk the pipeline from step 0 up to the target,
// using `state.previewOutputs` as a cache: any upstream step whose output
// has been cached is skipped, anything missing is run via POST /preview-step
// before the target. The target itself always re-runs (Play means "give me
// a fresh output for this step").
//
// Cache key per step is its index in `state.agent.steps`. Cache invalidation
// happens whenever a step's model_id, soul, schema, or output_id changes —
// stale outputs would silently feed the wrong values into downstream runs.

/**
 * Render a credits chip — the lightning-bolt SVG from the navbar's
 * `creditsDisplay` plus the supplied number. Returns a DOM node so the caller
 * can drop it inside a button label or an output header. Matches the visual
 * language of the rest of the marketplace (countdown banner, store credit
 * badges) so the author reads "credits" intuitively without a textual unit.
 *
 * Color: the amber tone the marketplace uses for credit-shaped accents
 * (`--cd-badge-color` / `--cd-title` in public/store/shared.css → `#FCD34D`).
 * Hard-coded here because this module is loaded outside the store CSS scope.
 */
const CREDITS_ACCENT = '#FCD34D';

function creditsChip(amount, opts = {}) {
  const wrap = document.createElement('span');
  wrap.style.cssText = `display: inline-flex; align-items: center; gap: 0.2rem; vertical-align: middle; color: ${CREDITS_ACCENT}; font-weight: 700;`;
  if (opts.dim) wrap.style.opacity = '0.75';
  wrap.innerHTML =
    '<svg style="width:0.95em;height:0.95em;flex-shrink:0;" fill="currentColor" viewBox="0 0 14 14" xmlns="http://www.w3.org/2000/svg">' +
    '<path d="M4.48963 7.68204H5.79855V11.5184C5.79855 12.0831 6.3577 12.3496 6.65422 11.9233L9.86088 7.34104C10.1405 6.94142 9.91595 6.31802 9.49235 6.31802H8.18342V2.48171C8.18342 1.91692 7.62426 1.65051 7.32774 2.07676L4.1211 6.65903C3.84576 7.05864 4.07026 7.68204 4.48963 7.68204Z"/>' +
    '</svg>';
  const num = document.createElement('span');
  num.textContent = String(amount);
  wrap.appendChild(num);
  return wrap;
}

/**
 * Estimate the credits a single step's Play will charge. Mirrors the
 * server-side `modelMaxCostUsd` logic so the button label matches what the
 * server will actually reserve.
 *
 * Returns 0 when the model isn't picked, has no cost data, or billing is off.
 */
function estimateStepCredits(step) {
  if (!step) return 0;

  // Single math source — the SAME function the Credits Floor sidebar and the
  // "Run all" total use (getBuilderDraftStepCredits): lowest-allowed field
  // value + baked-in literals + margin. Without this the Run button used
  // worst-case max duration and diverged from the sidebar (165 vs 44).
  const fn = window.AitopiaCredits?.getBuilderDraftStepCredits;
  if (typeof fn === 'function') {
    return fn(step, {
      fields: state.agent.fields,
      models: state.config.models,
      usdPerCredit: Number(state.config.billing?.usdPerCredit || 0.02),
      margin: priceMargin(),
      kindCreditsFn: kindStepCredits,
    });
  }

  if (stepKindOf(step) !== 'model') {
    stepKinds();
    return kindStepCredits(step);
  }
  if (!step.model_id) return 0;
  const usdPerCredit = Number(state.config.billing?.usdPerCredit || 0.02);
  if (!Number.isFinite(usdPerCredit) || usdPerCredit <= 0) return 0;
  const model = state.config.models.find(m => m.id === step.model_id);
  const cost = model?.cost;
  let usd = 0;
  if (cost) {
    if (typeof cost.perOutput === 'number' && cost.perOutput > 0) usd = cost.perOutput;
    else if (typeof cost.perSecond === 'number' && cost.perSecond > 0) usd = cost.perSecond * (maxModelDurationSeconds(model.tags) ?? 10);
    else if (typeof cost.perMillionOutput === 'number' && cost.perMillionOutput > 0) usd = (cost.perMillionOutput * 2000) / 1_000_000;
  }
  return Math.max(1, Math.ceil(usd / usdPerCredit));
}

/** Per-step run cache key. One projection, shared with the preview tab. */
export function stepDocHash(step) {
  if (!step || typeof step !== 'object') return '';
  return JSON.stringify(stepForHash(step));
}

/* ----------------------------------------------------------------------
 * Run-prep modal — collect missing field values before kicking off Run.
 *
 * The per-step Play used to send `state.testInputs` verbatim; when the author
 * hadn't filled anything in, required-by-step fields resolved to `null` and
 * the provider 422'd. We now scan the pipeline up to the target step, figure
 * out which form fields are *actually* read (either via `${id}` in a step's
 * soul/schema OR as a required key on a step whose cache is empty), check
 * which of those don't already have a value in `state.testInputs`, and pop a
 * small modal so the author can fill them in. The modal writes back to
 * `state.testInputs` and then calls `runStepBuilder` with the original index.
 * -------------------------------------------------------------------- */

// Soul + schema scan: every `${id}` that resolves to a real field id in the
// agent's `fields[]`. Returns the set of field ids the runner will read for
// the steps in [0..stepIndex].
export function collectFieldIdsUsedUpTo(stepIndex) {
  const steps = state.agent.steps;
  const fieldIds = new Set(state.agent.fields.map(f => f.id));
  const out = new Set();
  const re = /\$\{([a-zA-Z0-9_-]+)\}/g;
  const scan = (text) => {
    if (typeof text !== 'string') return;
    let m;
    while ((m = re.exec(text)) !== null) {
      if (fieldIds.has(m[1])) out.add(m[1]);
    }
  };
  const walk = (v) => {
    if (typeof v === 'string') { scan(v); return; }
    if (Array.isArray(v)) { for (const x of v) walk(x); return; }
    if (v && typeof v === 'object') { for (const x of Object.values(v)) walk(x); }
  };
  for (let i = 0; i <= stepIndex; i++) {
    const s = steps[i];
    if (!s) continue;
    for (const source of placeholderSourcesOf(s)) walk(source);
  }
  return out;
}

// Resolve a field's effective shape — merge catalog defaults under any
// per-agent overrides. Mirrors fields-pass.js#effectiveField without the
// import cycle (steps-pass already exports helpers fields-pass consumes).
function effectiveFieldForRun(field) {
  if (!field) return null;
  if (field.__custom) return { ...field };
  const concept = state.config.catalog.find(c => c.id === field.id) || null;
  if (!concept) return { ...field };
  return { ...concept, ...field };
}

// Build the list of (field, effective) the Run-prep modal needs. A field is
// included when it's used by a step in [0..stepIndex] AND `state.testInputs`
// has no usable value for it. Defaults DO NOT count as "already filled" — the
// author asked to make a choice every time in the builder's preview flow, so
// even a field with a default pops up in the modal (pre-selected to that
// default so the common case is a single Confirm click).
// True when a field gates the run — required AND no usable value yet. Optional
// fields are shown in the modal so the author CAN fill them, but they never
// block Run.
// Required-by-default: a field blocks the run unless it explicitly opts out
// with `required: false`. Mirrors fields-pass.js#isFieldEffectivelyRequired so
// the preview gates client-side on exactly what the builder shows as required —
// otherwise an empty required field slips through, queues, and the API 422s.
function isFieldRequired(f, eff) {
  if (f && f.required === false) return false;
  if (eff && eff.required === false) return false;
  return true;
}
function fieldHasValue(fieldId) {
  const current = state.testInputs?.[fieldId];
  return current != null && current !== '' && !(Array.isArray(current) && current.length === 0);
}

export function buildRunPrepRequirements(stepIndex) {
  const used = collectFieldIdsUsedUpTo(stepIndex);
  const out = [];
  for (const f of state.agent.fields) {
    if (!used.has(f.id)) continue;
    const eff = effectiveFieldForRun(f);
    if (fieldHasValue(f.id)) continue;
    // Every used-and-empty field is shown so the author can fill it; the
    // `required` flag drives whether it BLOCKS the run (see hasBlockingRunPrep).
    out.push({ field: f, eff, required: isFieldRequired(f, eff) });
  }
  return out;
}

// Whether any REQUIRED field is still empty — the only thing that should
// prevent a run. Optional empties are fine.
function hasBlockingRunPrep(stepIndex) {
  return buildRunPrepRequirements(stepIndex).some(r => r.required);
}

let _runPrepCtx = null; // { stepIndex, form, loading, wholeForm }

function closeRunPrepModal() {
  const submitBtn = document.getElementById('ab-run-prep-submit');
  if (submitBtn) submitBtn.textContent = 'Run step';
  document.getElementById('ab-modal-run-prep')?.classList.remove('visible');
  document.getElementById('ab-modal-run-prep')?.setAttribute('aria-hidden', 'true');
  _runPrepCtx = null;
}

/** The group mode whose agent is `subId`. */
function groupModeOf(subId) {
  const options = agentGroupOf()?.step.options || {};
  return Object.keys(options).find(v => options[v]?.agent_id === subId);
}

/** A group's Run carries its picked mode's price; other steps show none here. */
function paintRunPrepCredits(subId) {
  const mode = groupModeOf(subId);
  const credits = mode ? agentGroupModes()?.[mode] : 0;
  document.getElementById('ab-run-prep-submit')?.replaceChildren(
    el('span', {}, 'Run step'), runCreditsChip(credits > 0 ? String(credits) : '') || '');
}

/** The step's inputs, drawn by the runner's own form from the schema the server
 *  builds for this draft, so every component matches the live page. `fieldIds`
 *  narrows it to the inputs still missing; null shows the whole form. */
function openRunPrepModal(stepIndex, fieldIds) {
  const root = document.getElementById('ab-run-prep-fields');
  const errBox = document.getElementById('ab-run-prep-error');
  const title = document.getElementById('ab-run-prep-title');
  const sub = document.getElementById('ab-run-prep-sub');
  if (!root) return;

  if (errBox) { errBox.hidden = true; errBox.textContent = ''; }
  if (title) title.textContent = `Fill in the inputs Step ${stepIndex + 1} needs`;
  if (sub) {
    sub.textContent = fieldIds
      ? 'These are the form fields this step (and any upstream cached step it needs to run) reads from. Fill them in and the step will run against the live models.'
      : "Pick the mode to test, then fill in the inputs that mode's agent needs.";
  }
  const ctx = { stepIndex, form: null, loading: true, wholeForm: !fieldIds };
  _runPrepCtx = ctx;
  root.replaceChildren(el('div', { class: 'text-sm text-muted-foreground' }, 'Loading inputs…'));

  document.getElementById('ab-modal-run-prep')?.classList.add('visible');
  document.getElementById('ab-modal-run-prep')?.setAttribute('aria-hidden', 'false');
  void mountRunPrepForm(ctx, root, fieldIds);
}

async function mountRunPrepForm(ctx, root, fieldIds) {
  try {
    const res = await fetchHelper('https://aitopia.ai/api/agent-builder/preview-meta', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ agent: cleanAgentForExport(state.agent), draft: true }),
    });
    const json = await res.json().catch(() => null);
    if (_runPrepCtx !== ctx) return;
    if (!res.ok || !json?.ok) {
      const detail = Array.isArray(json?.errors) ? json.errors.map(e => e.message || e.code).join('; ') : '';
      throw new Error(detail || json?.message || `HTTP ${res.status}`);
    }
    const input = json.schema?.input || {};
    const properties = fieldIds
      ? Object.fromEntries(Object.entries(input.properties || {}).filter(([k]) => fieldIds.includes(k)))
      : (input.properties || {});
    const schema = {
      ...json.schema,
      input: { ...input, properties, required: (input.required || []).filter(k => k in properties) },
    };
    // schema-form mounts a group's mode picker just before its container.
    const host = el('div', {});
    root.replaceChildren(host);
    ctx.form = renderSchemaForm({ schema, container: host, onAgentChange: paintRunPrepCredits });
    paintRunPrepCredits(ctx.form.getActiveAgentId());
  } catch (err) {
    if (_runPrepCtx !== ctx) return;
    root.replaceChildren(el('div', { class: 'ab-error' },
      `Could not load the inputs: ${err instanceof Error ? err.message : String(err)}`));
  } finally {
    ctx.loading = false;
  }
}

async function submitRunPrep() {
  const ctx = _runPrepCtx;
  if (!ctx) return;
  const errBox = document.getElementById('ab-run-prep-error');
  const submitBtn = document.getElementById('ab-run-prep-submit');
  const setErr = (msg) => {
    if (errBox) { errBox.hidden = false; errBox.textContent = msg; }
  };
  if (errBox) { errBox.hidden = true; errBox.textContent = ''; }
  if (ctx.loading || !ctx.form) {
    setErr('Still loading the inputs.');
    return;
  }
  if (submitBtn) submitBtn.setAttribute('disabled', 'disabled');

  try {
    let values;
    try {
      values = await ctx.form.getValues();
    } catch (err) {
      if (err?.fieldId) ctx.form.setFieldError(err.fieldId, err.message);
      setErr(err?.fieldId ? `"${err.fieldId}": ${err.message}` : (err?.message || String(err)));
      return;
    }
    // Empty optionals stay out of testInputs.
    const collected = Object.fromEntries(Object.entries(values)
      .filter(([, v]) => v != null && v !== '' && !(Array.isArray(v) && v.length === 0)));
    // A group's form holds its mode's inputs; the mode itself rides alongside.
    const mode = ctx.wholeForm ? groupModeOf(ctx.form.getActiveAgentId()) : undefined;
    if (mode) collected[agentGroupOf().step.field_id] = mode;

    state.testInputs = { ...(state.testInputs || {}), ...collected };
    // New inputs make every cached output stale, so the run starts from step 1.
    if (Object.keys(collected).length) invalidatePreviewFrom(0);
    const target = ctx.stepIndex;
    closeRunPrepModal();
    notify();
    await runStepBuilder(target);
  } finally {
    if (submitBtn) submitBtn.removeAttribute('disabled');
  }
}

/**
 * Entry point for the Run button. If every field the pipeline reads up to
 * this step already has a value (in testInputs or as a field default), runs
 * immediately. Otherwise opens the prep modal to collect the missing values.
 */
// Module-scoped guard: only one Run pipeline may be in flight at a time. When
// the author hits Run on step 4, we walk 0..4 sequentially (skipping cached
// steps); kicking off a second Run on a different row mid-flight would race
// the credits reservation, the previewOutputs cache, and the order in which
// jobs settle. The Run buttons read this flag and disable themselves while
// it's set; requestRunStep() also bounces a stray click that slipped through.
let _runInFlight = false;

// Step-progress ticker. Updates only the running progress cells' elapsed
// counter + bar width *in place* — no notify(), no whole-list re-render.
// That's what kept videos in completed steps from being torn down every
// second. The renderer stamps each running cell with stable data hooks
// (data-step-progress-idx + data-progress-pct/bar/time) so we can find
// and mutate them without rebuilding anything.
let _progressTicker = null;
function startStepProgressTicker() {
  if (_progressTicker) return;
  _progressTicker = setInterval(() => {
    const outputs = state.previewOutputs || {};
    const runningIdxs = Object.keys(outputs).filter(k => outputs[k] && outputs[k].running);
    if (runningIdxs.length === 0) {
      clearInterval(_progressTicker);
      _progressTicker = null;
      return;
    }
    for (const k of runningIdxs) {
      updateRunningCellInPlace(Number(k), outputs[k]);
    }
  }, 1000);
}

// Update the running cell's text/bar in place. Returns false if the cell
// isn't on screen yet (first poll before initial render) so the caller
// can fall back to notify().
function updateRunningCellInPlace(stepIndex, cached) {
  const cell = document.querySelector(`[data-step-progress-idx="${stepIndex}"]`);
  if (!cell || !cached) return false;
  const startedAt = Number(cached.startedAt) || Date.now();
  // Elapsed is measured from the client startedAt only — never the server's
  // Date.now()-created_at elapsedMs, which inflates for queued/stale jobs.
  const elapsedNow = Math.max(0, Date.now() - startedAt);
  const elapsedSec = Math.round(elapsedNow / 1000);
  const serverProgress = typeof cached.progress === 'number' ? cached.progress : null;
  const estimatedMs = Number(cached.estimatedDurationMs) || 0;
  const isIndeterminate = serverProgress === null || estimatedMs <= 0;

  const timeEl = cell.querySelector('[data-progress-time]');
  if (timeEl) timeEl.textContent = formatRunningTimeText(elapsedSec, cached);

  const headerRight = cell.querySelector('[data-progress-header-right]');
  if (headerRight) {
    const exceeded = cached.estimateExceeded === true && estimatedMs > 0;
    headerRight.textContent = isIndeterminate ? (exceeded ? 'still working…' : 'estimating…') : `${serverProgress}%`;
    headerRight.style.fontStyle = isIndeterminate ? 'italic' : 'normal';
  }

  const barFill = cell.querySelector('[data-progress-bar-fill]');
  if (barFill && !isIndeterminate) barFill.style.width = `${serverProgress}%`;

  const cancelBtn = cell.querySelector('[data-progress-cancel]');
  if (cancelBtn && cancelBtn.hidden && elapsedNow >= 10000 && cached.jobId && !cached.cancelling) {
    cancelBtn.hidden = false;
  }
  return true;
}

function formatRunningTimeText(elapsedSec, cached) {
  const estimatedMs = Number(cached.estimatedDurationMs) || 0;
  const estSec = Math.round(estimatedMs / 1000);
  if (estimatedMs > 0 && (cached.estimateExceeded === true || elapsedSec > estSec)) {
    return `Taking longer than expected - ${elapsedSec}s elapsed (est. ~${estSec}s)`;
  }
  if (typeof cached.progress === 'number' && estimatedMs > 0) {
    return `Running… ${elapsedSec}s / ~${estSec}s`;
  }
  return `Running… ${elapsedSec}s elapsed`;
}

// Shared poll-tick handler. Writes the running snapshot into state and
// either does an in-place DOM update (no flicker) or falls back to a
// full notify() — exactly when the bar DOM has to swap shape
// (indeterminate ↔ determinate) or the cell isn't on screen yet.
function applyRunningTick(stepIndex, running) {
  const cached = state.previewOutputs[stepIndex] || {};
  const prevIndeterminate = typeof cached.progress !== 'number' || !(Number(cached.estimatedDurationMs) > 0);
  const nextProgress = typeof running.progress === 'number' ? running.progress : null;
  const nextEstimate = typeof running.estimatedDurationMs === 'number' && running.estimatedDurationMs > 0
    ? running.estimatedDurationMs
    : (cached.estimatedDurationMs || 0);
  const nextIndeterminate = nextProgress === null || !(nextEstimate > 0);
  state.previewOutputs[stepIndex] = {
    ...cached,
    running: true,
    error: null,
    progress: nextProgress,
    estimatedDurationMs: nextEstimate,
    // Do NOT store the server tick's elapsedMs. The server computes it as
    // Date.now() - job.created_at, which balloons for a queued/stale job and
    // pinned a bogus "10808s" on the bar. Elapsed is derived purely from the
    // client startedAt (set when Run was pressed) in updateRunningCellInPlace.
    estimateExceeded: running.estimateExceeded === true,
  };
  if (prevIndeterminate !== nextIndeterminate || !updateRunningCellInPlace(stepIndex, state.previewOutputs[stepIndex])) {
    notify();
  }
}

export function isRunInFlight() {
  return _runInFlight;
}

/**
 * Pull a human-readable error message out of a poll response body. The job
 * row's `error` field can land here as either a string or a `{ stepIndex,
 * message }` shape (preview-run vs preview-step format). Falls back to the
 * generic message for either an unrecognized error or a missing one.
 */
function extractStepError(json, stepIndex) {
  const info = json?.error;
  if (typeof info === 'string' && info) return info;
  if (info && typeof info === 'object' && typeof info.message === 'string' && info.message) return info.message;
  if (typeof json?.message === 'string' && json.message) return json.message;
  return `Step ${stepIndex + 1} failed`;
}

/**
 * Write a poll response into state.previewOutputs[stepIndex]. The same
 * cache layout serves three callers: the foreground runStepBuilder loop,
 * the resume-on-boot path, and any future direct-poll surfaces. Keeps the
 * shape in one place so adding a field (e.g. token usage) is a one-line
 * change.
 *
 * Returns true for success, false for a runtime failure verdict — the
 * caller decides whether to early-exit (foreground sequential loop) or
 * fall through (resume path, which processes one stepIndex at a time).
 */
function applyStepResultToCache(stepIndex, json) {
  const steps = state.agent.steps;
  if (!json?.success) {
    state.previewOutputs[stepIndex] = {
      running: false,
      error: extractStepError(json, stepIndex),
      ranAt: Date.now(),
    };
    return false;
  }
  state.previewOutputs[stepIndex] = {
    running: false,
    error: null,
    outputId: json.outputId,
    modelId: json.modelId,
    output: json.output,
    exposed: json.exposed,
    durationMs: json.durationMs,
    creditsCharged: typeof json.creditsCharged === 'number' ? json.creditsCharged : 0,
    ranAt: Date.now(),
    // Snapshot the authoring shape that produced this output. Future Play
    // presses compare against this — any edit invalidates the cache.
    docHash: steps[stepIndex] ? stepDocHash(steps[stepIndex]) : '',
  };
  // Adaptive estimate — overwrite the step's stored estimate from this run's
  // real wall-clock, plus 20% headroom. Updates the pipeline total too. The
  // draft only lives client-side until Publish, so we persist via state.notify.
  recordStepEstimate(stepIndex, json.durationMs);
  return true;
}

// Learn from every finished step, the way the server's recordStepDuration does.
// Persistence is automatic via state.notify (which writes the whole state.agent
// to localStorage); we just mutate here.
function recordStepEstimate(stepIndex, durationMs) {
  const totalSec = applyLearnedStepDuration(state.agent.steps, stepIndex, durationMs);
  if (totalSec == null) return;
  state.agent.estimatedDuration = { ...(state.agent.estimatedDuration || { min: 0 }), max: totalSec };
}

async function requestRunStep(stepIndex) {
  if (_runInFlight) {
    toast('Another step is still running - wait for it to finish.', 'error');
    return;
  }
  const steps = state.agent.steps;
  if (stepIndex < 0 || stepIndex >= steps.length) return;
  const target = steps[stepIndex];
  if (!target || (stepKindOf(target) === 'model' && !target.model_id)) {
    toast('Pick a model for this step first.', 'error');
    return;
  }
  if (target.kind === 'agent-group') {
    openRunPrepModal(stepIndex, null);
    return;
  }
  // Open the prep modal whenever a field the pipeline reads is still empty
  // (required or optional). submitRunPrep only blocks on empty required ones, so
  // optionals can be left blank and Run still proceeds.
  const missing = buildRunPrepRequirements(stepIndex);
  if (missing.length === 0) {
    await runStepBuilder(stepIndex);
    return;
  }
  openRunPrepModal(stepIndex, missing.map(r => r.field.id));
}

// Result shape. `started` separates "never issued a request" (bad index, no
// model, mutex held) from "ran and failed" — the caller cannot tell those apart
// from state.previewOutputs, since the early bails leave it untouched.
const RUN_NOT_STARTED = { started: false, ok: false, failedIndex: -1 };

export async function runStepBuilder(stepIndex) {
  const steps = state.agent.steps;
  if (stepIndex < 0 || stepIndex >= steps.length) return RUN_NOT_STARTED;
  const targetStep = steps[stepIndex];
  if (!targetStep || (stepKindOf(targetStep) === 'model' && !targetStep.model_id)) {
    toast('Pick a model for this step first.', 'error');
    return RUN_NOT_STARTED;
  }

  if (!(await ensureSignedIn('Sign in to run this step.'))) return;

  // Second-tier guard. requestRunStep() catches most stray clicks but a direct
  // call to runStepBuilder() (or a race against the button-render tick) could
  // slip past — bounce it here too. The flag is released in `finally` below so
  // any throw down the chain still resets it.
  if (_runInFlight) {
    toast('Another step is still running.', 'error');
    return RUN_NOT_STARTED;
  }
  _runInFlight = true;
  notify(); // re-render so every Run button picks up the disabled state

  const agentDoc = cleanAgentForExport(state.agent);

  try {
  // Steps that don't read each other's output run concurrently. Waves keep the
  // dependency order; a checkpoint step gets a wave to itself. Same rules the
  // server uses (shared/step-waves.js mirrors wizard-agent-runtime).
  const waves = planWaves(steps, stepIndex);

  const runOne = async (i) => {
    const currentHash = stepDocHash(steps[i]);
    const cached = state.previewOutputs[i];
    // Cache hit only when (a) we have a successful previous run AND (b) the
    // step's authoring shape hasn't changed since then. Otherwise the cached
    // output may have been produced from a different soul/schema/model.
    const cacheValid = cached && !cached.running && !cached.error && cached.docHash === currentHash;

    if (i < stepIndex && cacheValid) return true; // upstream + cached + fresh → skip
    if (i === stepIndex) delete state.previewOutputs[i]; // target → always rerun

    // Pre-fill so the bar animates before the kick-off round trip lands; the
    // server's createdAt + estimate overwrite these on response.
    const stepModelId = steps[i]?.model_id || '';
    const localModel = state.config.models.find(m => m.id === stepModelId);
    const preEstimateMs = estimateStepMs(steps[i], localModel?.tags);
    state.previewOutputs[i] = {
      ...(state.previewOutputs[i] || {}),
      running: true,
      error: null,
      startedAt: Date.now(),
      estimatedDurationMs: preEstimateMs,
    };
    notify();

    // Only settled upstream outputs — a step running beside this one in the
    // same wave has nothing to contribute (and by definition isn't referenced).
    const previousOutputs = {};
    for (let j = 0; j < i; j++) {
      const prev = state.previewOutputs[j];
      if (prev && prev.outputId && !prev.running) previousOutputs[prev.outputId] = prev.exposed;
    }
    console.log(`[builder-run] step ${i} starting`, {
      previousOutputs,
      cachedKeys: Object.keys(state.previewOutputs),
    });

    try {
      // Kick the step off. /preview-step now reserves credits + writes a row
      // into the jobs table, then returns 202 with the jobId before the model
      // call starts. We poll preview-step-job/:jobId below until the row's
      // status flips out of 'running'. (Validation / 402 insufficient-credits
      // still come back here as a non-2xx; we surface the body's message.)
      const kickRes = await fetchHelper('https://aitopia.ai/api/agent-builder/preview-step', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          agent: agentDoc,
          input: state.testInputs || {},
          stepIndex: i,
          previousOutputs,
          // Author testing their own draft — charge provider cost, not the
          // retail price they set for customers.
          atCost: true,
        }),
      });
      const kickJson = await kickRes.json().catch(() => null);
      if (!kickRes.ok || !kickJson?.jobId) {
        // The server returns detailed validation problems under `validationErrors`
        // (preview-step) or `errors` (publish) — each item is { code, field?, stepIndex?, message }.
        // Surface every one of them instead of collapsing to a bare "HTTP 422".
        const detailList = Array.isArray(kickJson?.validationErrors) ? kickJson.validationErrors
          : Array.isArray(kickJson?.errors) ? kickJson.errors
          : null;
        const detailMsg = detailList && detailList.length
          ? detailList.map((e) => {
              if (typeof e === 'string') return e;
              const where = e?.field ? ` [${e.field}]`
                : (Number.isInteger(e?.stepIndex) ? ` [step ${e.stepIndex + 1}]` : '');
              return `${e?.message || e?.code || 'unknown error'}${where}`;
            }).join('\n• ')
          : null;
        const insufficient = isInsufficientCredits(kickRes.status, kickJson);
        const msg = insufficient
          ? insufficientCreditsMessage(kickJson)
          : (detailMsg
            || kickJson?.error
            || kickJson?.message
            || `Step ${i + 1} failed to start (HTTP ${kickRes.status})`);
        if (insufficient) openPricingModal();
        // Always log the full server payload so the exact cause is recoverable
        // even when the toast truncates a long list.
        console.error(`[builder-run] step ${i + 1} failed (HTTP ${kickRes.status})`, kickJson);
        state.previewOutputs[i] = { running: false, error: msg, ranAt: Date.now() };
        notify();
        refreshCreditsBalance();
        const toastBody = insufficient ? msg : detailMsg ? `Step ${i + 1} failed:\n• ${detailMsg}` : `Step ${i + 1} failed: ${msg}`;
        toast(toastBody, 'error', 10000);
        return false;
      }

      // Stamp the running entry with the job id + the server's estimate.
      //
      // We keep the local `startedAt` set above (when the spinner first
      // appeared) instead of overwriting it with `kickJson.createdAt`.
      // Client clock and server clock are not guaranteed to be in sync;
      // mixing one timestamp (server createdAt) with the ticker's other
      // timestamp (client Date.now()) is what was making the progress
      // bar read "0s elapsed" forever — the server's createdAt sits in
      // the future relative to the client, so Date.now() - createdAt is
      // negative and the Math.max(0, ...) clamp pinned elapsed to zero.
      //
      // The server-issued createdAt is still useful for refresh resume
      // (resumeStepPollingOnBoot reads the jobs row directly there); for
      // the live foreground run we trust the same clock that drives the
      // ticker.
      const existing = state.previewOutputs[i] || {};
      state.previewOutputs[i] = {
        ...existing,
        running: true,
        error: null,
        jobId: kickJson.jobId,
        // Keep the same-clock startedAt we set right before this fetch.
        // Falls back to Date.now() defensively in case some other path
        // cleared it.
        startedAt: Number(existing.startedAt) || Date.now(),
        estimatedDurationMs: Number(kickJson.estimatedDurationMs) || Number(existing.estimatedDurationMs) || 10000,
        docHash: stepDocHash(steps[i]),
      };
      notify();

      // Poll the jobs row until it leaves the running state. Same shape the
      // preview tab uses for full-pipeline runs. Each running tick streams
      // the server's progress + (live, adaptive) estimatedDurationMs into
      // the row cache so the renderer can draw an honest bar — no local
      // synthetic math.
      const json = await pollPreviewStepJob(kickJson.jobId, {
        onProgress: (running) => applyRunningTick(i, running),
      });
      const ok = applyStepResultToCache(i, json);
      notify();
      // The server settled (or refunded) the reservation when the jobs row
      // flipped out of 'running'. Re-fetch the balance so the navbar credit
      // count reflects what the wallet actually has now — same hook
      // /agents/:id uses after every run.
      refreshCreditsBalance();
      if (!ok) {
        toast(`Step ${i + 1} failed: ${state.previewOutputs[i].error}`, 'error', 7000);
        return false;
      }
      return true;
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      state.previewOutputs[i] = { running: false, error: msg, ranAt: Date.now() };
      notify();
      // Network errors on the kick-off or polling path leave the reservation's
      // fate to the background promise on the server (it will settle or refund
      // when it finishes). Refresh anyway so a partial charge can't sit
      // invisible in the display.
      refreshCreditsBalance();
      toast(`Step ${i + 1} network error: ${msg}`, 'error', 7000);
      return false;
    }
  };

  // Run wave by wave; every step in a wave goes out at once. A wave with a
  // failure stops the run — later waves depend on it.
  for (const wave of waves) {
    const results = await Promise.all(wave.map(runOne));
    const at = results.indexOf(false);
    if (at !== -1) return { started: true, ok: false, failedIndex: wave[at] };
  }

  toast(`Step ${stepIndex + 1} done.`, 'success', 3000);
  return { started: true, ok: true, failedIndex: -1 };
  } finally {
    // Always release the in-flight flag, even when an early `return` inside
    // the loop bailed on the run (auth fail, validation, network error). The
    // notify() re-renders the Run buttons to lift their disabled state.
    _runInFlight = false;
    notify();
  }
}

/**
 * Poll /api/agent-builder/preview-step-job/:jobId until the row leaves the
 * 'running' state, then return the response body in the shape the caller
 * (runStepBuilder) expects — the same flat object the old synchronous
 * /preview-step response used to return.
 *
 * Shape on resolution:
 *   { success, stepIndex, outputId, modelId, output, exposed, durationMs,
 *     checkpoint, creditsEstimated, creditsCharged, error? }
 *
 * Throws on poll budget exhausted, on a hard 404 that never recovers, or on
 * a non-recoverable network failure. Transient 5xx and lone 404 windows
 * (a brief gap between INSERT and the row becoming readable) are tolerated
 * via short retries.
 */
async function pollPreviewStepJob(jobId, opts = {}) {
  const intervalMs = opts.intervalMs || 1500;
  const timeoutMs = opts.timeoutMs || 25 * 60 * 1000;
  const startedAt = Date.now();
  let consecutive404 = 0;

  // eslint-disable-next-line no-constant-condition
  while (true) {
    if (Date.now() - startedAt > timeoutMs) {
      throw new Error('Step polling exceeded the timeout budget.');
    }

    let res;
    try {
      res = await fetchHelper(`https://aitopia.ai/api/agent-builder/preview-step-job/${encodeURIComponent(jobId)}`, {
        method: 'GET',
        headers: { Accept: 'application/json' },
      });
    } catch (err) {
      // Transient network blip — wait and try again until the timeout budget
      // forces an exit above.
      await new Promise(r => setTimeout(r, intervalMs));
      continue;
    }

    if (res.status === 404) {
      consecutive404 += 1;
      // Five 404s in a row (≈7.5s) means the job was never created or
      // evicted. Bail out so the caller surfaces a real error instead of
      // looping forever.
      if (consecutive404 >= 5) throw new Error('Step job not found.');
      await new Promise(r => setTimeout(r, intervalMs));
      continue;
    }
    consecutive404 = 0;

    if (res.status >= 500) {
      // Server hiccup — retry on the next tick.
      await new Promise(r => setTimeout(r, intervalMs));
      continue;
    }

    const body = await res.json().catch(() => null);
    if (!body || !body.ok) {
      await new Promise(r => setTimeout(r, intervalMs));
      continue;
    }
    if (body.status === 'running') {
      // Forward the running snapshot so the caller can stamp the latest
      // server-side progress / estimatedDurationMs into the row's cache.
      // The renderer reads progress straight off the cache; without this
      // hook the bar would have nothing to update against between polls.
      if (typeof opts.onProgress === 'function') {
        try { opts.onProgress(body); } catch { /* listener errors don't kill the poll */ }
      }
      await new Promise(r => setTimeout(r, intervalMs));
      continue;
    }
    return body; // status is 'done' or 'failed' — caller branches on body.success
  }
}

/**
 * Force-refresh the navbar's credits display. Uses the shared credits
 * helper loaded via /js/shared/credits.js — same call /agents/:id makes
 * after every run. `loadCreditsBalance({ force: true })` busts the cache,
 * re-hits /api/credits/balance, and pipes the new total into the navbar
 * + drawer credit chips via updateGlobalCreditsDisplay.
 *
 * Wrapped in optional chaining so a page that hasn't loaded credits.js
 * (or a logged-out visitor whose API would 401) silently no-ops.
 */
function refreshCreditsBalance() {
  try {
    window.AitopiaCredits?.loadCreditsBalance?.({ force: true });
  } catch {
    // Display is best-effort; a missing helper or a transient fetch error
    // shouldn't surface in the wizard.
  }
}

/**
 * POST /api/agent-builder/preview-job/:jobId/cancel for a running step. The
 * row's poll loop sees the server flip to `failed`/`cancelled` on the next
 * tick and lands in the failure branch (which renders the red panel + clears
 * the spinner) — we don't need to mutate state.previewOutputs ourselves.
 *
 * We do set a `cancelling: true` transient so the button doesn't double-fire
 * if the author clicks during the round-trip. notify() between set and
 * fetch makes the "Cancelling…" message appear in place of the button.
 */
async function requestCancelStep(stepIndex) {
  const cached = state.previewOutputs[stepIndex];
  if (!cached || !cached.jobId || cached.cancelling) return;
  state.previewOutputs[stepIndex] = { ...cached, cancelling: true };
  notify();
  try {
    await fetchHelper(`https://aitopia.ai/api/agent-builder/preview-job/${encodeURIComponent(cached.jobId)}/cancel`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (err) {
    // Network error — the poll loop will keep trying; reset the latch
    // so the author can click again. (No toast here; the row's running
    // panel still shows so the user sees the state.)
    const stillCached = state.previewOutputs[stepIndex];
    if (stillCached && stillCached.cancelling) {
      state.previewOutputs[stepIndex] = { ...stillCached, cancelling: false };
      notify();
    }
    console.warn('[agent-builder] cancel request failed', err);
  }
  // On success we don't touch state — the poll loop will pick up the
  // server's `failed` status within ~1.5s and write the final row state.
  refreshCreditsBalance();
}

/**
 * Render the cached output (or running/error state) for a step underneath
 * its row body. Pure visual — clicking Play mutates state and notify()
 * triggers a re-render.
 */
export function renderStepOutputPanel(stepIndex) {
  const cached = state.previewOutputs[stepIndex];
  if (!cached) return null;

  if (cached.running) {
    // The server is the only source of truth for progress. Each poll tick
    // streams { progress, elapsedMs, estimatedDurationMs } into the cache
    // (see runStepBuilder#onProgress / resumeOneStepPoll#onProgress), and
    // we draw whatever is there — no local synthetic floor/ceiling.
    //
    //   - cached.progress is null  → indeterminate state. We've polled but
    //                                the server hasn't learned an estimate
    //                                for this draft yet (BUILDER_STEP_DURATION
    //                                is empty). The bar pulses gently; the
    //                                row still shows real elapsed time.
    //   - cached.progress is a num → honest percentage; 0..99. The server
    //                                will only ever send numbers in that
    //                                range until the run hits done/failed,
    //                                at which point this branch stops
    //                                rendering (replaced by the success/
    //                                error branches below).
    //
    // For the elapsed counter we still derive seconds locally between polls
    // (the server's elapsedMs is one poll old by the time we paint), but
    // we anchor that local count to the server's last elapsedMs + the time
    // we received it so a slow tick doesn't make the seconds count race
    // ahead of reality.
    const serverProgress = typeof cached.progress === 'number' ? cached.progress : null;
    const estimatedMs = Number(cached.estimatedDurationMs) || 0;
    const startedAt = Number(cached.startedAt) || Date.now();
    // Elapsed = client wall-clock since Run was pressed. We deliberately do
    // NOT floor against the server's elapsedMs (Date.now()-created_at): for a
    // queued or stale job that value balloons and pinned a bogus "10808s".
    const elapsedNow = Math.max(0, Date.now() - startedAt);
    const elapsedSec = Math.round(elapsedNow / 1000);

    const wrap = el('div', {
      class: 'mt-3 p-3 text-sm ab-step-progress',
      style: 'border-radius: 12px; background: hsl(var(--ait-m-secondary) / 0.4); border: 1px solid hsl(var(--ait-m-border));',
      'data-step-progress-idx': String(stepIndex),
    });

    // Header: elapsed/estimated text (data-progress-time) + right-side
    // status (% or "estimating…"). The ticker only mutates [data-progress-time];
    // bar width / pct only change on poll ticks (which call notify()).
    const isIndeterminate = serverProgress === null || estimatedMs <= 0;
    const exceeded = cached.estimateExceeded === true && estimatedMs > 0;
    const headerRight = isIndeterminate
      ? (exceeded ? 'still working…' : 'estimating…')
      : `${serverProgress}%`;
    wrap.appendChild(el('div', {
      style: 'display: flex; justify-content: space-between; align-items: center; gap: 0.5rem; font-size: 0.75rem; color: hsl(var(--ait-m-muted-foreground)); margin-bottom: 0.4rem;',
    },
      el('span', { style: 'display: inline-flex; align-items: center; gap: 0.45rem; min-width: 0;' },
        el('span', { class: 'ab-run-spinner' }),
        el('span', { 'data-progress-time': '', class: 'ab-shimmer-text', style: 'font-size: 0.75rem;' },
          formatRunningTimeText(elapsedSec, cached)),
      ),
      el('span', {
        'data-progress-header-right': '',
        style: isIndeterminate
          ? 'font-variant-numeric: tabular-nums; font-style: italic;'
          : 'font-variant-numeric: tabular-nums;',
      }, headerRight),
    ));

    if (isIndeterminate) {
      const bar = el('div', {
        style: 'height: 6px; border-radius: 999px; background: hsl(var(--ait-m-secondary)); overflow: hidden; position: relative;',
      });
      bar.appendChild(el('div', {
        style: 'position: absolute; top: 0; left: -30%; width: 30%; height: 100%; background: hsl(var(--ait-m-primary)); animation: ab-progress-indeterminate 1.4s ease-in-out infinite;',
      }));
      wrap.appendChild(bar);
    } else {
      const bar = el('div', {
        style: 'height: 6px; border-radius: 999px; background: hsl(var(--ait-m-secondary)); overflow: hidden;',
      });
      bar.appendChild(el('div', {
        'data-progress-bar-fill': '',
        style: `width: ${serverProgress}%; height: 100%; background: hsl(var(--ait-m-primary)); transition: width 0.3s ease;`,
      }));
      wrap.appendChild(bar);
    }

    // Cancel button — hidden until the 10-second wall. The ticker un-hides it
    // in place; we never recreate the row, so a running video output in a
    // sibling step isn't interrupted.
    const CANCEL_THRESHOLD_MS = 10000;
    const showCancelNow = elapsedNow >= CANCEL_THRESHOLD_MS && cached.jobId && !cached.cancelling;
    if (cached.cancelling) {
      wrap.appendChild(el('div', {
        style: 'margin-top: 0.55rem; font-size: 0.75rem; color: hsl(var(--ait-m-muted-foreground)); font-style: italic;',
      }, 'Cancelling…'));
    } else if (cached.jobId) {
      const cancelBtn = el('button', {
        class: 'ab-cancel-run',
        type: 'button',
        'data-progress-cancel': '',
        style: 'margin-top: 0.55rem; display: flex; margin-left: auto;',
        onclick: () => { void requestCancelStep(stepIndex); },
      }, '✕ Cancel run');
      cancelBtn.hidden = !showCancelNow;
      wrap.appendChild(cancelBtn);
    }

    startStepProgressTicker();
    return wrap;
  }

  if (cached.error) {
    return el('div', {
      class: 'mt-3 p-3 text-sm',
      style: 'border-radius: 12px; background: rgba(255,59,48,0.08); border: none; color: rgb(180,40,40);',
    },
      el('div', { style: 'font-weight: 700; margin-bottom: 0.25rem;' }, 'Failed'),
      el('div', { style: 'font-family: ui-monospace, Menlo, monospace; font-size: 0.78rem; white-space: pre-wrap;' }, cached.error),
    );
  }

  // Success — render the exposed value. Priority:
  //   1. Media (videos > images > audios) — same classifier the live agent
  //      page uses (collectMediaUrls). Same render style as /agents/<slug>.
  //   2. URL string                       — clickable link.
  //   3. Plain string                     — preserved-whitespace text block.
  //   4. Anything else                    — JSON dump.
  const exposed = cached.exposed;
  const body = el('div', { class: 'ab-step-output max-h-64 overflow-auto' });
  const secs = cached.durationMs ? `${(cached.durationMs / 1000).toFixed(1)}s` : null;
  body.appendChild(el('div', { class: 'ab-step-output-head' },
    el('span', { class: 'ab-step-output-dot' }),
    el('span', { class: 'ab-step-output-label' }, 'Output'),
    el('span', { class: 'ab-step-output-meta' },
      [cached.outputId, secs].filter(Boolean).join(' · '),
      cached.creditsCharged > 0 ? el('span', { class: 'ab-step-output-sep' }, '·') : null,
      cached.creditsCharged > 0 ? creditsChip(cached.creditsCharged, { dim: true }) : null,
    ),
  ));

  // A quoted image URL in text output would otherwise render as an image.
  const step = state.agent.steps[stepIndex];
  const emitsText = step ? stepEmitsText(step, cached.exposed) : false;
  const media = emitsText
    ? { videos: [], images: [], audios: [] }
    : collectMediaUrls(cached.exposed);

  const mediaWrap = el('div', { class: 'ab-step-media' });
  const mediaStyle = 'display: block; width: 100%; max-height: 400px; object-fit: contain;'
    + ' border-radius: 12px; background: #000;';
  let rendered = false;

  if (Array.isArray(media.videos) && media.videos.length > 0) {
    for (const url of media.videos) {
      const v = document.createElement('video');
      v.src = url;
      v.controls = true;
      v.playsInline = true;
      v.style.cssText = mediaStyle;
      mediaWrap.appendChild(v);
    }
    rendered = true;
  }
  if (Array.isArray(media.images) && media.images.length > 0) {
    for (const url of media.images) {
      const a = document.createElement('a');
      a.href = url;
      a.target = '_blank';
      a.rel = 'noopener noreferrer';
      a.style.cssText = 'display: block; width: 100%;';
      const img = document.createElement('img');
      img.src = url;
      img.alt = 'Step output';
      img.loading = 'lazy';
      img.style.cssText = 'display: block; width: 100%; height: auto; max-height: 400px; object-fit: contain;'
        + ' border-radius: 12px; background: hsl(var(--ait-m-secondary) / 0.4);';
      a.appendChild(img);
      mediaWrap.appendChild(a);
    }
    rendered = true;
  }
  if (Array.isArray(media.audios) && media.audios.length > 0) {
    for (const url of media.audios) {
      const a = document.createElement('audio');
      a.src = url;
      a.controls = true;
      a.style.cssText = 'width: 100%; max-width: 480px;';
      mediaWrap.appendChild(a);
    }
    rendered = true;
  }

  if (rendered) {
    body.classList.remove('max-h-64', 'overflow-auto');
    body.appendChild(mediaWrap);
    return body;
  }

  // A content-research step set to text output produces markdown — render it
  // (headings, bold, lists) instead of showing the raw `#`/`**` source, the
  // same way the published runner's Generated Content card does. The design is
  // unchanged; only the string body is upgraded from plain text to markdown.
  const isMarkdownText = emitsText && !stepEmitsObject(step);

  // No media found — fall back to the text/JSON renderer.
  const renderValue = (v) => {
    if (typeof v === 'string') {
      if (/^https?:\/\//.test(v.trim())) {
        return el('a', { href: v, target: '_blank', rel: 'noopener', style: 'word-break: break-all; color: hsl(var(--ait-m-primary));' }, v);
      }
      if (isMarkdownText) {
        return renderMarkdownInto(el('div', { style: 'font-size: 0.85rem;' }), v);
      }
      return el('div', { style: 'white-space: pre-wrap; word-break: break-word; font-size: 0.85rem;' }, v);
    }
    if (Array.isArray(v)) {
      return el('div', { class: 'flex flex-col gap-1' }, ...v.map(item => renderValue(item)));
    }
    return el('pre', { style: 'font-size: 0.75rem; white-space: pre-wrap; word-break: break-word;' }, JSON.stringify(v, null, 2));
  };
  body.appendChild(renderValue(exposed));
  return body;
}

/* ---------------- Model picker ---------------- */

// Maps a registry cost.unit to the media family it produces. Used as a fallback
// when a model has no media tag (e.g. lucataco/faceswap has no tags but bills
// per image) so it doesn't wrongly land in the Text tab.
const COST_UNIT_TYPE = {
  image: 'image', edit: 'image',
  video_sec: 'video',
  audio_sec: 'audio', podcast: 'audio', transcription: 'audio',
  tokens: 'text',
};

// The media family a model outputs. First a matching family tag wins (mirrors
// the outputTypes inference in recomputeDerived); if no tag matches, the
// billing unit decides; only then does it fall back to text.
function modelOutputType(model) {
  for (const t of (model.tags || [])) {
    if (/^video/.test(t)) return 'video';
    if (/^image/.test(t)) return 'image';
    if (/^audio/.test(t)) return 'audio';
  }
  const byCost = COST_UNIT_TYPE[model.cost?.unit];
  if (byCost) return byCost;
  return 'text';
}

// Turn a model's `ui.specs` object into a flat list of readable chip strings.
// Dynamic: any key on `specs` becomes a chip, so new spec fields show up with
// no code change here. Skips empty/false values; booleans render as a label
// instead of "true" (e.g. hasAudio → "🔊 Audio").
const SPEC_BOOL_LABELS = { hasAudio: '🔊 Audio' };
function modelSpecChips(specs) {
  if (!specs || typeof specs !== 'object') return [];
  const chips = [];
  Object.entries(specs).forEach(([key, value]) => {
    if (!value) return;
    if (typeof value === 'boolean') {
      chips.push(SPEC_BOOL_LABELS[key] || key);
    } else {
      chips.push(String(value));
    }
  });
  return chips;
}


// ---------------------------------------------------------------------------
// Model picker — LIVE (paged + filtered) against /api/models/compact
// ---------------------------------------------------------------------------
// The picker no longer renders a boot-time list baked into /config. It queries
// the live model catalog as the author searches/filters, so the boot payload
// stays small and the list is always current. Search + type tabs map straight
// onto the endpoint's `q` + `type` params; paging is "load more" via `offset`.

const MODEL_PICKER_PAGE = 48;

// Active output-type tab in the model picker. 'all' shows everything.
let modelPickerType = 'all';
// Non-null while the picker is restricted to one media kind (model-selector).
let modelPickerLock = null;
// In-flight picker query state — bumped on every new search/tab so a slow
// earlier response can't clobber the grid after a newer query started.
let _modelQueryToken = 0;
let _modelOffset = 0;
let _modelHasMore = false;
let _modelLoading = false;
let _modelSearchDebounce = null;

// Build a picker card for one live model row. When the model carries `ui.specs`
// (resolution, duration, aspect ratios, hasAudio) we render the same spec chips
// the picker always showed; the credit estimate rides alongside as a chip using
// the marketplace credit icon (no "cr" text). Tier-fallback estimates (registry
// has no exact price) are dimmed so they read as approximate.
function modelPickCard(m) {
  const outType = m.mediaType || modelOutputType(m);
  const specChips = modelSpecChips(m.ui?.specs);
  const ce = m.creditsEstimated || null;
  let creditNode = null;
  if (ce && Number.isFinite(ce.credits)) {
    const chip = creditsChip(ce.credits, { dim: ce.source === 'tier-fallback' });
    chip.classList.add('pick-spec');
    creditNode = chip;
  }
  const specNode = (specChips.length || creditNode)
    ? el('div', { class: 'pick-specs' },
        ...specChips.map(s => el('span', { class: 'pick-spec' }, s)),
        creditNode,
      )
    : null;
  return el('div', {
    class: 'ab-catalog-pick',
    onclick: () => onPickModel(m),
  },
    el('div', { class: 'pick-head' },
      el('div', { class: 'pick-title' }, m.displayName || m.id),
      el('span', { class: 'pick-out pick-out-' + outType }, outType),
    ),
    el('div', { class: 'pick-id' }, m.id),
    m.description
      ? el('div', { class: 'pick-desc' }, m.description)
      : null,
    specNode,
  );
}

const AGENT_PICKER_PAGE = 24;
let agentPickerType = 'all';
let agentPickerTarget = null;
let _agentRows = null;
let _agentLoading = false;
let _agentShown = 0;
let _agentSearchDebounce = null;

/** Same card as a model pick, so both pickers read as one surface. */
function agentPickCard(a) {
  const id = a.id || a.slug;
  const outType = a.mediaType || 'text';
  const credits = Number(a.creditsEstimated?.min ?? 0) || 0;
  const chip = credits > 0 ? creditsChip(credits) : null;
  if (chip) chip.classList.add('pick-spec');
  return el('div', { class: 'ab-catalog-pick', onclick: () => onPickAgent(a) },
    el('div', { class: 'pick-head' },
      el('div', { class: 'pick-title' }, a.name || id),
      el('span', { class: 'pick-out pick-out-' + outType }, outType),
    ),
    el('div', { class: 'pick-id' }, id),
    a.description ? el('div', { class: 'pick-desc' }, a.description) : null,
    chip ? el('div', { class: 'pick-specs' }, chip) : null,
  );
}

/** One fetch per open; the list is small, so filtering stays client-side. */
async function loadAgentRows() {
  if (_agentRows) return _agentRows;
  const res = await fetchHelper('https://aitopia.ai/api/agents/all?limit=-1');
  if (!res.ok) throw new Error('status ' + res.status);
  const json = await res.json();
  _agentRows = (Array.isArray(json.agents) ? json.agents : []).filter(a => a.id || a.slug);
  return _agentRows;
}

function agentPickerMatches(rows) {
  const q = ($('#ab-agent-search')?.value || '').trim().toLowerCase();
  return rows.filter((a) => {
    if (agentPickerType !== 'all' && (a.mediaType || 'text') !== agentPickerType) return false;
    if (!q) return true;
    return `${a.name || ''} ${a.id || a.slug || ''} ${a.description || ''}`.toLowerCase().includes(q);
  });
}

function renderAgentPage({ append } = {}) {
  const grid = $('#ab-agent-grid');
  if (!grid || !_agentRows) return;
  const matches = agentPickerMatches(_agentRows);
  if (!append) { grid.innerHTML = ''; _agentShown = 0; }
  grid.querySelector('.ab-model-more')?.remove();

  const next = matches.slice(_agentShown, _agentShown + AGENT_PICKER_PAGE);
  for (const a of next) grid.appendChild(agentPickCard(a));
  _agentShown += next.length;

  if (matches.length === 0) {
    grid.appendChild(el('div', { class: 'pick-id', style: 'grid-column:1/-1; padding:0.4rem 0.2rem;' }, 'No agents match.'));
  } else if (_agentShown < matches.length) {
    grid.appendChild(el('div', {
      class: 'ab-model-more pick-id',
      style: 'grid-column:1/-1; padding:0.5rem 0.2rem; text-align:center; opacity:0.6; cursor:pointer;',
      onclick: () => renderAgentPage({ append: true }),
    }, `Loading more… (${matches.length - _agentShown} more)`));
  }
}

function onAgentPickerScroll() {
  if (_agentLoading || !_agentRows) return;
  const scroller = $('#ab-agent-grid')?.closest('.ab-modal');
  if (!scroller) return;
  const remaining = scroller.scrollHeight - scroller.scrollTop - scroller.clientHeight;
  if (remaining < scroller.clientHeight * 1.5) renderAgentPage({ append: true });
}

function wireAgentTabs() {
  const bar = $('#ab-agent-tabs');
  if (bar && !bar.dataset.wired) {
    bar.dataset.wired = '1';
    bar.addEventListener('click', (e) => {
      const btn = e.target.closest('[data-agent-type]');
      if (!btn) return;
      agentPickerType = btn.dataset.agentType;
      for (const t of bar.querySelectorAll('[data-agent-type]')) {
        t.classList.toggle('active', t.dataset.agentType === agentPickerType);
      }
      renderAgentPage({ append: false });
    });
  }
  const search = $('#ab-agent-search');
  if (search && !search.dataset.wired) {
    search.dataset.wired = '1';
    search.addEventListener('input', () => {
      clearTimeout(_agentSearchDebounce);
      _agentSearchDebounce = setTimeout(() => renderAgentPage({ append: false }), 200);
    });
  }
  const scroller = $('#ab-agent-grid')?.closest('.ab-modal');
  if (scroller && !scroller.dataset.agentScrollWired) {
    scroller.dataset.agentScrollWired = '1';
    scroller.addEventListener('scroll', onAgentPickerScroll, { passive: true });
  }
}

/** `target` receives the pick: { step, field, onChange }. */
export function openAgentPicker(target) {
  agentPickerTarget = target || null;
  wireAgentTabs();
  agentPickerType = 'all';
  const search = $('#ab-agent-search');
  if (search) search.value = '';
  const bar = $('#ab-agent-tabs');
  if (bar) for (const t of bar.querySelectorAll('[data-agent-type]')) {
    t.classList.toggle('active', t.dataset.agentType === 'all');
  }
  const grid = $('#ab-agent-grid');
  const scroller = grid?.closest('.ab-modal');
  if (scroller) scroller.scrollTop = 0;
  if (grid) {
    grid.innerHTML = '';
    grid.appendChild(el('div', { class: 'pick-id', style: 'grid-column:1/-1; padding:0.4rem 0.2rem;' }, 'Loading agents…'));
  }
  openModal('ab-modal-agent');
  _agentLoading = true;
  loadAgentRows()
    .then(() => { _agentLoading = false; renderAgentPage({ append: false }); })
    .catch((err) => {
      _agentLoading = false;
      if (grid) {
        grid.innerHTML = '';
        grid.appendChild(el('div', { class: 'pick-id', style: 'grid-column:1/-1; padding:0.4rem 0.2rem;' }, 'Could not load agents: ' + err.message));
      }
    });
}

function onPickAgent(entry) {
  const t = agentPickerTarget;
  agentPickerTarget = null;
  closeModal('ab-modal-agent');
  if (!t) return;
  t.onPick(entry);
}

// Fetch one page of models from the live endpoint for the current type/search.
// `append=true` adds to the grid (load-more); otherwise it replaces it.
async function fetchModelPage({ append } = {}) {
  const grid = $('#ab-model-grid');
  if (!grid) return;
  const token = append ? _modelQueryToken : ++_modelQueryToken;
  const q = ($('#ab-model-search')?.value || '').trim();
  const offset = append ? _modelOffset : 0;
  _modelLoading = true;

  if (!append) {
    grid.innerHTML = '';
    grid.appendChild(el('div', { class: 'pick-id', style: 'grid-column:1/-1; padding:0.4rem 0.2rem;' }, 'Loading models…'));
  }

  const params = new URLSearchParams({ sort: 'newest', limit: String(MODEL_PICKER_PAGE), offset: String(offset) });
  if (modelPickerType !== 'all') params.set('type', modelPickerType);
  if (q) params.set('q', q);

  let json = null;
  try {
    const res = await fetchHelper(`https://aitopia.ai/api/models/compact?${params.toString()}`);
    if (!res.ok) throw new Error('status ' + res.status);
    json = await res.json();
  } catch (err) {
    if (token === _modelQueryToken) {
      grid.innerHTML = '';
      grid.appendChild(el('div', { class: 'pick-id', style: 'grid-column:1/-1; padding:0.4rem 0.2rem;' }, 'Could not load models: ' + err.message));
    }
    _modelLoading = false;
    return;
  }

  // A newer query started while this was in flight — drop the stale response.
  if (token !== _modelQueryToken) { _modelLoading = false; return; }

  const models = Array.isArray(json.models) ? json.models : [];
  _modelOffset = offset + models.length;
  _modelHasMore = !!json.hasMore;

  if (!append) grid.innerHTML = '';
  // Drop any prior end-of-list marker before appending fresh cards.
  grid.querySelector('.ab-model-more')?.remove();

  for (const m of models) grid.appendChild(modelPickCard(m));

  if (!append && models.length === 0) {
    grid.appendChild(el('div', { class: 'pick-id', style: 'grid-column:1/-1; padding:0.4rem 0.2rem;' }, 'No models match.'));
  } else if (_modelHasMore) {
    // Infinite scroll: no button. A small marker row sits at the bottom; the
    // scroll handler (wireModelTabs) loads the next page as it nears the
    // viewport. The marker doubles as a manual fallback if scroll never fires.
    grid.appendChild(el('div', {
      class: 'ab-model-more pick-id',
      style: 'grid-column:1/-1; padding:0.5rem 0.2rem; text-align:center; opacity:0.6; cursor:pointer;',
      onclick: () => { if (!_modelLoading) fetchModelPage({ append: true }); },
    }, `Loading more… (${json.total - _modelOffset} more)`));
  }

  _modelLoading = false;
}

// Scroll container for the picker grid (the modal body scrolls, not the grid).
function modelPickerScroller() {
  return $('#ab-model-grid')?.closest('.ab-modal') || null;
}

// Load the next page when the user scrolls near the bottom of the picker.
// Guards: a query must be in a "has more" state and not already loading.
function onModelPickerScroll() {
  if (_modelLoading || !_modelHasMore) return;
  const scroller = modelPickerScroller();
  if (!scroller) return;
  const remaining = scroller.scrollHeight - scroller.scrollTop - scroller.clientHeight;
  // Trigger ~1.5 viewport-heights early so the next page is usually ready
  // before the user reaches the end (no visible stall).
  if (remaining < scroller.clientHeight * 1.5) {
    fetchModelPage({ append: true });
  }
}

// Wire the output-type filter tabs + search box. Tab/search changes re-query
// the live endpoint (search is debounced). Idempotent (guards on dataset.wired).
function wireModelTabs() {
  const bar = $('#ab-model-tabs');
  if (bar && !bar.dataset.wired) {
    bar.dataset.wired = '1';
    bar.addEventListener('click', (e) => {
      const btn = e.target.closest('[data-model-type]');
      if (!btn) return;
      // Inert rather than hidden, so the reason stays visible.
      if (modelPickerLock && btn.dataset.modelType !== modelPickerLock) return;
      modelPickerType = btn.dataset.modelType;
      for (const t of bar.querySelectorAll('[data-model-type]')) {
        t.classList.toggle('active', t.dataset.modelType === modelPickerType);
      }
      fetchModelPage({ append: false });
    });
  }
  const search = $('#ab-model-search');
  if (search && !search.dataset.wired) {
    search.dataset.wired = '1';
    search.addEventListener('input', () => {
      clearTimeout(_modelSearchDebounce);
      _modelSearchDebounce = setTimeout(() => fetchModelPage({ append: false }), 250);
    });
  }
  // Infinite scroll: load the next page as the modal body nears its bottom.
  const scroller = modelPickerScroller();
  if (scroller && !scroller.dataset.modelScrollWired) {
    scroller.dataset.modelScrollWired = '1';
    scroller.addEventListener('scroll', onModelPickerScroll, { passive: true });
  }
}

// Open the model picker fresh: clear the search, reset the type filter to All,
// re-sync the tab highlight, fetch the first page, then show the modal.
function openModelPicker(lockedType) {
  wireModelTabs();
  // Locked to the first model's media kind: every option must match it.
  modelPickerLock = lockedType || null;
  modelPickerType = lockedType || 'all';
  const search = $('#ab-model-search');
  if (search) search.value = '';
  const bar = $('#ab-model-tabs');
  if (bar) {
    for (const t of bar.querySelectorAll('[data-model-type]')) {
      const blocked = !!modelPickerLock && t.dataset.modelType !== modelPickerType;
      t.classList.toggle('active', t.dataset.modelType === modelPickerType);
      t.style.opacity = blocked ? '0.35' : '';
      t.style.pointerEvents = blocked ? 'none' : '';
      t.title = blocked
        ? `This step already offers ${modelPickerLock} models, so every option must be ${modelPickerLock}.`
        : '';
    }
  }
  // Reset scroll to the top so a prior session's scroll position doesn't
  // immediately retrigger paging on the fresh list.
  const scroller = modelPickerScroller();
  if (scroller) scroller.scrollTop = 0;
  fetchModelPage({ append: false });
  openModal('ab-modal-model');
}

async function onPickModel(model) {
  if (!modelPickerMode) return;

  // Cache the picked model's pricing/output metadata so the per-step cost +
  // output-type lookups resolve immediately (the picker row carries cost,
  // tags, mediaType, creditsEstimated from /api/models/compact).
  rememberModel(model);

  closeModal('ab-modal-model');

  let addedFieldIds = [];

  if (modelPickerMode.kind === 'new') {
    // Cap is server-owned (env AGENT_BUILDER_MAX_STEPS) via state.config.maxSteps —
    // never a literal, which would disagree with what publish accepts.
    const maxSteps = Number(state.config?.maxSteps);
    if (Number.isFinite(maxSteps) && maxSteps > 0 && state.agent.steps.length >= maxSteps) {
      toast(`Maximum ${maxSteps} steps.`, 'error');
      return;
    }
    const step = {
      soul: '',
      schema: {},
      model_id: model.id,
      output_id: 'output_' + (state.agent.steps.length + 1),
      step: false,
      // Newly created step opens expanded so the author lands directly on the
      // schema editor — no second click required after picking a model.
      __expanded: true,
    };
    state.agent.steps.push(step);
    notify();
    addedFieldIds = await loadAndApplySchema(step);
  } else if (modelPickerMode.kind === 'add-model') {
    const step = state.agent.steps[modelPickerMode.stepIndex];
    if (!step) { modelPickerMode = null; return; }
    const rows = Array.isArray(step.models) ? step.models : (step.models = []);
    // Told apart by `key`: the same model may be offered more than once.
    const optionKey = nextOptionKey(rows, model.id);
    // Fetched for the mapping suggestions and the publish gate's required keys.
    let suggested = {};
    let requiredKeys = [];
    let modelKeys = [];
    let referenceKeys = [];
    let supportsReference = false;
    let enums = {};
    try {
      const schema = await fetchModelSchema(model.id);
      // Prompt slots come from the step soul, so they are never unmapped.
      requiredKeys = Array.isArray(schema?.required)
        ? schema.required.filter(k => typeof k === 'string' && !RESERVED_SCHEMA_KEYS.has(k))
        : [];
      const props = schema?.properties || {};
      const usable = Object.keys(props).filter(k => !RESERVED_SCHEMA_KEYS.has(k));
      // Standard keys for i2v, reference keys for r2v; neutral keys serve both.
      modelKeys = usable.filter(k => referenceModeClassOf(props[k]) !== 'reference');
      supportsReference = schema?.supportsReference === true;
      referenceKeys = supportsReference
        ? usable.filter(k => referenceModeClassOf(props[k]) !== 'standard')
        : [];
      enums = collectModelEnums(props, usable);
      suggested = suggestRemap(step.schema, schema);
    } catch { /* a schema miss only costs the suggestions; the author can map by hand */ }
    rows.push({
      key: optionKey,
      id: model.id,
      // Editor-only, so the type lock needs no second lookup.
      __mediaKind: model.mediaType || modelOutputType(model),
      label: model.displayName || model.id,
      soul: '',
      remap: suggested.remap || {},
      requiredKeys,
      // Editor-only, stripped before export.
      __modelKeys: modelKeys,
      __referenceKeys: referenceKeys,
      __supportsReference: supportsReference,
      // Published so the buyer's form can re-offer the picked model's own
      // choices; a closed list per key, keyed by that model's key name.
      enums,
      __suggestedRemap: suggested.hints || {},
    });
    const isFirst = !step.default_model;
    if (isFirst) {
      step.default_model = optionKey;
      // The step schema is wired from this model, so a mapping onto itself
      // would only restate it.
      delete rows[rows.length - 1].remap;
    }
    // The option list drives the price, so a new model invalidates the preview.
    invalidatePreviewFrom(modelPickerMode.stepIndex);
    notify();
    // The first pick defines the step's inputs, wired as on a model step.
    if (isFirst) addedFieldIds = await loadAndApplySchema(step);
    syncSelectorPickerFields();
    if (typeof modelPickerMode.onPick === 'function') modelPickerMode.onPick(model);
  } else if (modelPickerMode.kind === 'change') {
    const step = state.agent.steps[modelPickerMode.stepIndex];
    if (!step) return;
    step.model_id = model.id;
    // Model swap invalidates this step's cached output (different model means
    // a different result) and everything downstream that depended on it.
    invalidatePreviewFrom(modelPickerMode.stepIndex);
    notify();
    addedFieldIds = await loadAndApplySchema(step);
    // Model swap may leave fields that no remaining schema key references.
    // Drop auto-added orphans so the form doesn't accumulate ghosts.
    pruneOrphanAutoAddedFields();
    notify();
  }

  modelPickerMode = null;
  announceAddedFields(addedFieldIds);
}

/** Auto-created fields detour the author to Pass 4 so they see the new rows. */
function announceAddedFields(addedFieldIds) {
  if (!addedFieldIds || !addedFieldIds.length) return;
  toast(`Added ${addedFieldIds.length} required field${addedFieldIds.length === 1 ? '' : 's'} to your form.`, 'success', 4000);
  state.pass = 4;
  notify();
}

/* ---------------- Step renderer ---------------- */

function insertAtCaret(textarea, text) {
  const start = textarea.selectionStart ?? textarea.value.length;
  const end = textarea.selectionEnd ?? textarea.value.length;
  const before = textarea.value.slice(0, start);
  const after = textarea.value.slice(end);
  textarea.value = before + text + after;
  textarea.focus();
  const caret = start + text.length;
  textarea.setSelectionRange(caret, caret);
  textarea.dispatchEvent(new Event('input', { bubbles: true }));
}

/**
 * Find the form field this schema key is currently wired to, if any.
 *
 * Returns the field object reference (mutable) when `step.schema[key]` is
 * exactly `${field_id}` and that field exists in `state.agent.fields`.
 * Returns `null` for literal values, mixed strings (e.g. text with `${id}`
 * inside), or placeholders that point at upstream output ids.
 */
/**
 * Apply a free-form string value into `step.schema[key]`.
 *
 * No auto-promotion: an earlier version of this helper synthesized a form
 * field for every `${id}` it spotted, even mid-keystroke (typing `${shadow`
 * created a `shadow` field that turned into a stray once the author finished
 * `${shadowPrompt}`). That was too aggressive. The author may instead want
 * to add a catalog field, pick a different name, or wire to an upstream
 * output — none of which are possible if the wizard has already pushed a
 * custom textarea field onto Pass 3 on their behalf.
 *
 * Unresolved `${id}` references are surfaced as warnings in the soul card
 * (see `unresolvedPlaceholderIds` below). The author can act on them or
 * ignore them; nothing is mutated outside `step.schema[key]`.
 */
function applyStringValue(step, key, newValue) {
  step.schema[key] = newValue;
}

function boundFieldFor(step, key) {
  const value = step.schema[key];
  if (typeof value !== 'string') return null;
  const m = /^\$\{([a-zA-Z0-9_-]+)\}$/.exec(value.trim());
  if (!m) return null;
  return state.agent.fields.find(f => f.id === m[1]) || null;
}

/**
 * Promote a schema key into a CUSTOM form field — even when the catalog has a
 * matching concept. Author explicitly chose "Custom" → they want to design the
 * field from scratch (catalog defaults don't flow through).
 *
 * If a custom field with the desired id already exists, reuse it. If a CATALOG
 * field with the same id exists (from a prior "From input-mapping" round), we
 * detach it: drop the catalog entry and write a fresh custom field with the
 * same effective shape. `step.schema[key]` is rewritten to `${fieldId}`.
 */
function promoteKeyToCustomField(step, key, prop) {
  const resolved = resolveSchemaControl(key, prop);
  // CUSTOM means "detach from the catalog and own the field outright", so the
  // field id is the schema KEY itself — never the resolved conceptId. Using the
  // conceptId here was the bug behind the unfixable `${prompt}` wiring: a
  // text-to-speech model's `text` key maps (via mapped_to) to the reserved
  // `prompt` concept, so Custom kept re-wiring `step.schema.text = "${prompt}"`
  // no matter what the author picked. The author must ALWAYS be able to make any
  // key a plain custom field; keying off the schema key guarantees that and
  // never collides with the reserved `prompt`.
  const fieldId = key; // schema key, verbatim — not resolved.conceptId

  const existingIdx = state.agent.fields.findIndex(f => f.id === fieldId);
  if (existingIdx >= 0) {
    const existing = state.agent.fields[existingIdx];
    if (existing.__custom) {
      existing.__expanded = true;
      step.schema[key] = '${' + fieldId + '}';
      return existing;
    }
    // Catalog field exists — detach into custom with the same effective shape.
    const concept = state.config.catalog.find(c => c.id === fieldId);
    // Defaults MUST be literals (string/number/boolean/JSON). A placeholder
    // like `${image}` is a wiring artefact, never a default; if one slipped
    // onto `existing.default` from a previous bug, drop it during detachment
    // so the Custom panel's default input doesn't surface it.
    const literalDefault = (v) => (typeof v === 'string' && /\$\{[a-zA-Z0-9_-]+\}/.test(v)) ? null : v;
    const detached = {
      __custom: true,
      __autoAdded: true,
      __expanded: true,
      id: fieldId,
      title: existing.title || concept?.title || fieldId,
      description: existing.description || concept?.description || '',
      type: existing.type || concept?.type || prop?.type || 'string',
      ui_component: existing.ui_component || concept?.ui_component || resolved.uiComponent,
      default: literalDefault(existing.default) ?? literalDefault(concept?.default) ?? null,
      visible: existing.visible !== false,
      advanced: existing.advanced === true,
      step: existing.step === true,
    };
    const eff = existing.enum ?? concept?.enum;
    if (Array.isArray(eff) && eff.length) detached.enum = [...eff];
    const effRange = existing.range ?? concept?.range;
    if (effRange) detached.range = { ...effRange };
    state.agent.fields[existingIdx] = detached;
    step.schema[key] = '${' + fieldId + '}';
    return detached;
  }

  // No existing field — synthesize one from the resolver's view of the schema.
  const field = buildCustomField(fieldId, key, prop, resolved, { expanded: true });
  // Carry a literal the author already typed into the field's default so
  // switching to Custom doesn't silently discard it.
  const prior = step.schema[key];
  if (typeof prior === 'string' && prior && !/\$\{[a-zA-Z0-9_-]+\}/.test(prior)) {
    field.default = prior;
  }
  state.agent.fields.push(field);
  step.schema[key] = '${' + fieldId + '}';
  return field;
}

/**
 * Promote a schema key into a CATALOG form field (compact `{ id }` entry).
 * Used by the "From input-mapping" radio. Falls back to a custom field when
 * the key has no catalog match — author told us "use the mapping" but the
 * mapping doesn't exist, so we synthesize a custom field with the same id as
 * the schema key (no catalog defaults flow through in that case, but author
 * can refine the row in Pass 4).
 *
 * If a field with the target id already exists (catalog OR custom), we reuse
 * it. Existing custom field gets converted back to catalog only when a catalog
 * concept exists for the id — otherwise it stays custom (catalog-less id).
 */
function promoteKeyToMappingField(step, key, prop) {
  const resolved = resolveSchemaControl(key, prop);
  const fieldId = resolved.conceptId || key;

  const existingIdx = state.agent.fields.findIndex(f => f.id === fieldId);
  if (existingIdx >= 0) {
    const existing = state.agent.fields[existingIdx];
    // Already a catalog field — nothing to do beyond wiring.
    if (!existing.__custom) {
      step.schema[key] = '${' + fieldId + '}';
      return existing;
    }
    // Custom field exists but author wants mapping. Replace with compact
    // catalog entry IF the concept exists; otherwise keep the custom field
    // (no mapping available — the radio still wired the placeholder).
    if (resolved.conceptId && state.config.catalog.find(c => c.id === resolved.conceptId)) {
      state.agent.fields[existingIdx] = { id: resolved.conceptId, visible: true, __autoAdded: true };
    }
    step.schema[key] = '${' + fieldId + '}';
    return state.agent.fields[existingIdx];
  }

  // No existing field. Catalog match → compact entry. No match → custom
  // (same shape `ensureFieldForRequiredKey` builds for catalog-less keys).
  if (resolved.conceptId) {
    const compact = { id: resolved.conceptId, visible: true, __autoAdded: true };
    state.agent.fields.push(compact);
    step.schema[key] = '${' + resolved.conceptId + '}';
    return compact;
  }
  return promoteKeyToCustomField(step, key, prop);
}

/**
 * @deprecated use promoteKeyToCustomField / promoteKeyToMappingField instead.
 * Kept as a thin alias because earlier callers (auto-detour path, schema-load
 * fallback) call this name; both new helpers preserve the same return contract.
 */
function promoteKeyToField(step, key, prop) {
  const resolved = resolveSchemaControl(key, prop);
  const fieldId = resolved.conceptId || key;
  let field = state.agent.fields.find(f => f.id === fieldId);
  if (!field) {
    // Synthesize a new custom field. Title falls back to a humanized key;
    // ui_component / enum / range / default seed from the resolver so the
    // field starts at the same effective shape the author was seeing.
    //
    // `__expanded: true` is intentional. The author just clicked Custom on
    // a schema key to edit this field's properties; landing on Pass 3 with
    // the row collapsed would force a second click ("Edit") for no payoff.
    // Auto-promote during prompt typing keeps rows collapsed (no edit
    // intent expressed) — this is the explicit-intent path.
    field = {
      __custom: !resolved.conceptId,
      __autoAdded: true,
      __expanded: true,
      id: fieldId,
      title: prop?.title || key.replace(/[_-]+/g, ' ').replace(/\b\w/g, c => c.toUpperCase()),
      description: prop?.description || '',
      type: prop?.type || 'string',
      ui_component: resolved.uiComponent,
      default: prop?.default ?? null,
      visible: true,
      advanced: false,
      step: false,
    };
    if (Array.isArray(resolved.enum) && resolved.enum.length) field.enum = [...resolved.enum];
    if (prop?.minimum != null || prop?.maximum != null) {
      field.range = { min: prop?.minimum ?? null, max: prop?.maximum ?? null };
    }
    state.agent.fields.push(field);
  } else {
    // Existing field — expand it too so the author lands in edit mode.
    field.__expanded = true;
  }
  step.schema[key] = '${' + fieldId + '}';
  return field;
}

/**
 * Humanize a `ui_component` value for the picker. The internal ids are fine
 * for code, but readers see the wizard.
 */
function uiComponentLabelInline(uic) {
  return inlineUiComponents().find(c => c.id === uic)?.label || uic;
}

/** Components this inline editor offers, in registry order. */
function inlineUiComponents() {
  return COMPONENT_META.filter(c => c.inlineEditor);
}

// What an option is called anywhere the builder lists it back to the author.
// Values are often whole sentences (visual-picker feeds them to the model), so
// showing the raw value makes every list unreadable — prefer the label. Same
// precedence the runtime uses, via optionLabelsFor.
export function optionDisplayLabel(field, value, index) {
  const shim = { enum: field?.enum, 'x-uap': { optionLabels: field?.optionLabels } };
  return optionLabelsFor(shim, field)(value, index);
}

/**
 * Reusable row-based enum editor for a field.
 *
 * Layout per option: [ Title input ] [ Value input ] [ × multiplier ] [ × remove ]
 * Footer: [ + Add option ]
 *
 * - `field.enum`        — array of values, the only required shape for the
 *                         underlying mapper/validator contract.
 * - `field.enumLabels`, `field.optionImages`, `field.optionCategories`,
 *   `field.optionSteps`, `field.costMultiplier` — parallel arrays, one entry
 *   per option at the same index as `enum`. Docs written before this carry
 *   value-keyed objects; optionListOf reads either.
 *
 * Returns a DOM node. Caller decides whether to also render a Default picker
 * underneath (it's still useful as a single-pick).
 */
/**
 * @param {object} field
 * @param {object} [opts]
 * @param {boolean} [opts.inlineCost=false]
 *   When true, each option row carries a per-option cost-multiplier input —
 *   used by the step's Custom config panel (Pass 2), where there's no
 *   separate Cost multiplier section. When false (default) the row is just
 *   Title + Value + remove; the dedicated Cost multiplier panel underneath
 *   handles per-value multipliers — used by Pass 3 field editor to avoid
 *   showing the same cost input twice.
 * @param {boolean} [opts.withImages=false]
 *   When true, each option row also carries an Image URL input, landing on
 *   `field.optionImages[i]`. Used by the `prompt-picker` and `visual-picker`
 *   ui_components — the runner renders each value as a visual card.
 * @param {boolean} [opts.withCategories=false]
 *   When true, each option row carries an additional Category input, landing
 *   on `field.optionCategories[i]`. Used by the `visual-picker` ui_component —
 *   categories drive the chip filter row above the modal grid.
 */
export function renderEnumOptionsEditor(field, opts = {}) {
  const inlineCost = !!opts.inlineCost;
  const withImages = !!opts.withImages;
  const withCategories = !!opts.withCategories;
  const wrap = el('div', { class: 'field mb-2' });
  wrap.appendChild(el('label', {}, 'Options'));

  // Every per-option list is held as an array aligned with `values`, so a row
  // carries its own data at one index and reordering cannot desync them.
  // optionListOf accepts the value-keyed objects older docs still hold.
  const values = Array.isArray(field.enum) ? [...field.enum] : [];
  const labels = optionListOf(field.enumLabels, field.enum).slice();
  while (labels.length < values.length) labels.push('');
  const images = optionListOf(field.optionImages, field.enum).slice();
  const categories = withCategories ? optionListOf(field.optionCategories, field.enum).slice() : [];
  // Per-option step prompts — only relevant for prompt-picker (`withImages`).
  // One array of step prompts per option. Kept up here (above rebuild()) so the
  // closure captures a defined binding.
  const optionSteps = withImages ? optionListOf(field.optionSteps, field.enum).slice() : [];
  const stepCount = withImages ? Math.max(0, (state.agent.steps || []).length) : 0;

  // Expand/collapse state for each option's "Step prompts" section. Kept on
  // the field as a __-prefixed Set so cleanAgentForExport strips it (never
  // reaches JSON / localStorage / publish). Rename + remove keep this Set in
  // sync with `values` the same way `optionSteps` does.
  if (withImages && !(field.__expandedOptions instanceof Set)) {
    field.__expandedOptions = new Set();
  }
  const expanded = withImages ? field.__expandedOptions : null;

  // Inline cost editing only kicks in when the field uses the per-option shape.
  // A scalar `costMultiplier: 1.5` is edited elsewhere; this UI never
  // overwrites it.
  const cmMapEditable = inlineCost && (!field.costMultiplier || typeof field.costMultiplier === 'object');
  const cmList = optionListOf(field.costMultiplier, field.enum).slice();

  // Trailing blanks carry no information, so a list that is empty after
  // trimming is dropped rather than published as [null, null].
  const packList = (list, keep) => {
    const out = values.map((_, i) => (keep(list[i]) ? list[i] : null));
    while (out.length && out[out.length - 1] == null) out.pop();
    return out.length ? out : null;
  };
  const isFilled = (v) => typeof v === 'string' && v.trim() !== '';

  const rebuild = () => {
    field.enum = values.length ? [...values] : null;
    field.enumLabels = packList(labels, isFilled);
    if (cmMapEditable) {
      field.costMultiplier = packList(cmList, (v) => typeof v === 'number' && Number.isFinite(v));
    }
    if (withImages) {
      field.optionImages = packList(images, isFilled);
      if (withCategories) {
        field.optionCategories = packList(categories, isFilled);
      }
      // Per-option step prompts, one array per option, sized to
      // state.agent.steps.length. Trailing empty slots are trimmed.
      const trimmedSteps = values.map((_, i) => {
        const v = optionSteps[i];
        if (!Array.isArray(v)) return null;
        const out = [...v];
        while (out.length && (out[out.length - 1] == null || out[out.length - 1] === '')) out.pop();
        return out.length ? out : null;
      });
      field.optionSteps = packList(trimmedSteps, Array.isArray);
    }
    if (field.default != null && values.length && !values.map(String).includes(String(field.default))) {
      field.default = null;
    }
    notify();
  };

  const list = el('div', { class: withImages ? 'flex flex-col gap-3' : 'flex flex-col gap-2' });
  values.forEach((value, idx) => {
    const valueStr = String(value);
    const labelStr = labels[idx] || '';
    const cmVal = typeof cmList[idx] === 'number' ? String(cmList[idx]) : '';

    // prompt-picker → vertical card layout (top row: meta, then a step-prompt
    // repeater sized to state.agent.steps.length). select/radio-group keep the
    // compact single-row layout.
    const card = withImages
      ? el('div', {
          style: 'padding: 0.6rem; border: 1px solid rgba(127,127,127,0.18); border-radius: 8px; '
            + 'background: rgba(127,127,127,0.04);',
        })
      : null;
    const row = el('div', { class: 'flex items-center gap-2' });

    row.appendChild(el('input', {
      type: 'text', value: labelStr,
      placeholder: 'Title (shown to the user)',
      style: 'flex: 1 1 0; min-width: 0;',
      oninput: (e) => { labels[idx] = e.target.value; rebuild(); },
    }));
    row.appendChild(el('input', {
      type: 'text', value: valueStr,
      placeholder: 'Value (sent to the model)',
      style: 'flex: 1 1 0; min-width: 0;',
      // Renaming a value no longer has to re-key anything: every per-option
      // list is addressed by this row's index.
      oninput: (e) => {
        values[idx] = e.target.value;
        rebuild();
      },
    }));
    if (withImages) {
      const imgUrl = typeof images[idx] === 'string' ? images[idx] : '';
      const thumb = el('div', {
        style: 'width: 36px; height: 36px; flex-shrink: 0; border-radius: 6px; background: rgba(0,0,0,0.05); '
          + 'overflow: hidden; display: flex; align-items: center; justify-content: center; '
          + 'border: 1px solid rgba(0,0,0,0.08); font-size: 0.65rem; color: hsl(var(--ait-m-muted-foreground));',
      });
      const renderThumb = (url) => {
        thumb.innerHTML = '';
        if (url && url.trim()) {
          const img = el('img', {
            src: url,
            alt: '',
            style: 'width: 100%; height: 100%; object-fit: cover;',
          });
          img.onerror = () => { thumb.innerHTML = ''; thumb.textContent = '!'; };
          thumb.appendChild(img);
        } else {
          thumb.textContent = '·';
        }
      };
      renderThumb(imgUrl);
      row.appendChild(thumb);
      row.appendChild(el('input', {
        type: 'text', value: imgUrl,
        placeholder: 'Image URL',
        style: 'flex: 1 1 0; min-width: 0;',
        oninput: (e) => {
          images[idx] = e.target.value;
          renderThumb(e.target.value);
          rebuild();
        },
      }));
      if (withCategories) {
        const catVal = typeof categories[idx] === 'string' ? categories[idx] : '';
        row.appendChild(el('input', {
          type: 'text', value: catVal,
          placeholder: 'Category (chip filter)',
          style: 'flex: 0 1 9rem; min-width: 0;',
          oninput: (e) => { categories[idx] = e.target.value; rebuild(); },
        }));
      }
    }
    if (cmMapEditable) {
      row.appendChild(el('input', {
        type: 'number', step: 'any', value: cmVal,
        placeholder: 'cost',
        style: 'width: 5rem; flex-shrink: 0;',
        oninput: (e) => {
          cmList[idx] = e.target.value === '' ? null : Number(e.target.value);
          rebuild();
        },
      }));
    }
    row.appendChild(el('button', {
      class: 'ab-row-iconbtn ab-cr-remove', type: 'button', style: 'flex-shrink: 0;',
      title: 'Remove this option',
      onclick: () => {
        // Every per-option list shifts with the row, so the rest stay aligned.
        for (const list of [values, labels, images, categories, optionSteps, cmList]) {
          list.splice(idx, 1);
        }
        if (expanded) {
          const next = new Set();
          for (const i of expanded) {
            if (i === idx) continue;
            next.add(i > idx ? i - 1 : i);
          }
          field.__expandedOptions = next;
        }
        rebuild();
      },
    }, '×'));

    if (card) {
      card.appendChild(row);
      // Step-prompt repeater. One textarea per agent step. The author writes
      // what each step should do *when this option is selected*; the agent
      // looks up `field.optionSteps[i]` server-side and feeds each entry
      // into the matching step's prompt. Empty trailing entries are trimmed
      // on save (rebuild()).
      if (stepCount === 0) {
        card.appendChild(el('div', {
          style: 'margin-top: 0.5rem; font-size: 0.75rem; color: hsl(var(--ait-m-muted-foreground));',
        }, 'Add steps on the Steps pass - a prompt slot for each step will appear here.'));
      } else {
        const isOpen = expanded && expanded.has(idx);
        const stepsWrap = el('div', { style: 'margin-top: 0.55rem; display: flex; flex-direction: column; gap: 0.4rem;' });

        // Clickable header — toggles the collapsible body below.
        const header = el('button', {
          type: 'button',
          style: 'display: flex; align-items: center; gap: 0.4rem; width: 100%; padding: 0.25rem 0.2rem; '
            + 'background: transparent; border: none; cursor: pointer; text-align: left; '
            + 'font-size: 0.72rem; font-weight: 600; color: hsl(var(--ait-m-muted-foreground)); '
            + 'text-transform: uppercase; letter-spacing: 0.04em;',
          onclick: () => {
            if (!expanded) return;
            if (expanded.has(idx)) expanded.delete(idx);
            else expanded.add(idx);
            notify();
          },
        });
        header.appendChild(el('span', {
          style: 'display: inline-block; width: 0.7rem; transition: transform 0.15s; '
            + `transform: rotate(${isOpen ? 90 : 0}deg);`,
        }, '▶'));
        header.appendChild(el('span', {}, `Step prompts for "${labelStr || valueStr || '(unnamed)'}"`));
        stepsWrap.appendChild(header);

        if (isOpen) {
          const body = el('div', { style: 'display: flex; flex-direction: column; gap: 0.4rem; padding-left: 0.2rem;' });
          const current = Array.isArray(optionSteps[idx]) ? optionSteps[idx] : [];
          for (let stepIdx = 0; stepIdx < stepCount; stepIdx++) {
            const stepRef = state.agent.steps[stepIdx];
            const stepLabel = stepRef?.output_id || `step ${stepIdx + 1}`;
            const promptVal = typeof current[stepIdx] === 'string' ? current[stepIdx] : '';
            const stepRow = el('div', { style: 'display: flex; flex-direction: column; gap: 0.2rem;' });
            stepRow.appendChild(el('label', {
              style: 'font-size: 0.7rem; color: hsl(var(--ait-m-muted-foreground));',
            }, `${stepIdx + 1}. ${stepLabel}`));
            const stepTa = el('textarea', {
              rows: 2,
              placeholder: `Prompt fed into step ${stepIdx + 1} when "${valueStr || '(value)'}" is picked`,
              style: 'width: 100%; resize: vertical; min-height: 38px; font-size: 0.85rem;',
              oninput: (e) => {
                const arr = Array.isArray(optionSteps[idx]) ? [...optionSteps[idx]] : [];
                while (arr.length <= stepIdx) arr.push('');
                arr[stepIdx] = e.target.value;
                optionSteps[idx] = arr;
                rebuild();
              },
            });
            // <textarea> ignores a `value` attribute — its content is the
            // `.value` property. Set it after creation, the same way every
            // other textarea in this file does (template/soul/schema editors).
            stepTa.value = promptVal;
            stepRow.appendChild(stepTa);
            body.appendChild(stepRow);
          }
          stepsWrap.appendChild(body);
        }
        card.appendChild(stepsWrap);
      }
      list.appendChild(card);
    } else {
      list.appendChild(row);
    }
  });
  wrap.appendChild(list);

  wrap.appendChild(el('button', {
    class: 'btn', type: 'button', style: 'margin-top: 0.5rem;',
    onclick: () => {
      values.push('');
      labels.push('');
      // A new prompt-picker option opens its Step prompts section straight
      // away — the author fills those textareas next.
      if (withImages && expanded) expanded.add(values.length - 1);
      rebuild();
    },
  }, '+ Add option'));

  return wrap;
}

/**
 * Render the type-specific config panel for the schema key in Custom mode.
 * The panel mutates the bound field's own properties (enum / range / default
 * / ui_component) — schema-key Custom mode is just a contextualized field
 * editor that always promotes through `${field_id}`.
 *
 * Layout follows the field's current `ui_component`:
 *   - select / radio-group   → enum editor + default-from-enum picker
 *   - slider / input(number) → min/max + default
 *   - toggle                 → default true/false
 *   - file-upload            → no extra config (default URL via the value editor)
 *   - textarea / input(text) → default text
 *   - json-input             → default JSON
 *
 * The ui_component itself is editable via a small picker at the top.
 */
function renderCustomConfigPanel(field) {
  const panel = el('div', {
    class: 'ab-cfg-panel mt-2 mb-2',
    style: 'border: 1px solid hsl(var(--ait-m-border)); border-radius: 12px; padding: 0.6rem 0.75rem; background: hsl(var(--ait-m-secondary) / 0.25);',
  });

  // Heading + the field's id badge (so the author knows which field is being
  // edited — relevant when the key is wired to a shared field).
  panel.appendChild(el('div', { class: 'flex items-center gap-2 mb-2' },
    el('span', { class: 'text-xs font-bold uppercase tracking-wide', style: 'color: hsl(var(--ait-m-muted-foreground));' }, 'Custom config'),
    el('span', { class: 'ab-badge', style: 'background: transparent;' }, field.id),
    field.__custom
      ? el('span', { class: 'ab-badge custom' }, 'custom field')
      : el('span', { class: 'ab-badge catalog' }, 'catalog field'),
  ));

  // ui_component picker — type-aware downstream UI follows this choice.
  panel.appendChild(el('div', { class: 'field mb-2' },
    el('label', {}, 'Control type'),
    (() => {
      const sel = el('select', {
        onchange: (e) => {
          const newUi = e.target.value;
          if (newUi === field.ui_component) return;
          // Type transitions: when the new control no longer accepts enum
          // (e.g. select → slider), drop the stale enum so it doesn't show
          // up in stale validators. Same for range when leaving numeric.
          if (newUi !== 'select' && newUi !== 'radio-group' && newUi !== 'pill-toggle' && newUi !== 'agent-selector') field.enum = null;
          if (newUi !== 'slider' && newUi !== 'input') field.range = null;
          field.ui_component = newUi;
          // type heuristic for the underlying JSON-Schema type
          if (newUi === 'toggle') field.type = 'boolean';
          else if (newUi === 'slider' || (newUi === 'input' && typeof field.default === 'number')) field.type = 'number';
          else field.type = 'string';
          notify();
        },
      });
      for (const c of inlineUiComponents()) {
        const opt = el('option', { value: c.id }, c.label || c.id);
        if (field.ui_component === c.id) opt.selected = true;
        sel.appendChild(opt);
      }
      return sel;
    })(),
  ));

  // Pass 2's Custom config panel has no separate Cost-multiplier section,
  // so per-value cost inputs live inline in each option row.
  appendTypeSpecificConfig(panel, field, { inlineCost: true });

  return panel;
}

/**
 * Append the interactive-prompt config editor: template textarea + slot list
 * (one row per slot with name, enum options, default) + assembledTarget input.
 *
 * The widget at runtime (public/js/components/form/interactive-prompt.js)
 * renders the template as inline text with one clickable pill per slot. Each
 * slot needs an enum list of options; the chosen value substitutes into the
 * template, and the assembled string lands on `assembledTarget` (defaults to
 * the field id so step.schema can reference it with `${fieldId}`).
 */
// Tabs and kinds both come from asset-sources.js, so a source added there shows
// up here with no edit. An empty assetSources means "every source for this kind".
function appendAssetPickerEditor(panel, field) {
  if (typeof field.assetKind !== 'string') field.assetKind = 'image';
  if (!Array.isArray(field.assetSources)) field.assetSources = [];
  if (typeof field.defaultSource !== 'string') field.defaultSource = null;

  const kindWrap = el('div', { class: 'field mb-3' },
    el('label', {},
      'Asset kind ',
      el('span', { class: 'text-xs text-muted-foreground font-normal' }, '(which files the picker lists)')),
    (() => {
      const sel = el('select', {
        onchange: (e) => {
          field.assetKind = e.target.value;
          // Sources that cannot serve the new kind would silently vanish at runtime.
          field.assetSources = field.assetSources.filter(
            (id) => ASSET_SOURCES.find((s) => s.id === id)?.mediaKinds.includes(field.assetKind));
          notify();
          renderSources();
        },
      });
      for (const kind of ['image', 'video', 'audio']) {
        const o = el('option', { value: kind }, kind);
        if (field.assetKind === kind) o.selected = true;
        sel.appendChild(o);
      }
      return sel;
    })(),
  );
  panel.appendChild(kindWrap);

  const sourcesWrap = el('div', { class: 'field mb-3' },
    el('label', {},
      'Sources ',
      el('span', { class: 'text-xs text-muted-foreground font-normal' },
        '(leave all unchecked to offer every source that fits the kind)')),
  );
  const sourcesBox = el('div', { class: 'flex flex-wrap gap-3' });
  sourcesWrap.appendChild(sourcesBox);
  panel.appendChild(sourcesWrap);

  function renderSources() {
    sourcesBox.innerHTML = '';
    for (const source of ASSET_SOURCES) {
      if (!source.mediaKinds.includes(field.assetKind)) continue;
      const cb = el('input', {
        type: 'checkbox',
        onchange: (e) => {
          const on = e.target.checked;
          const list = field.assetSources.filter((id) => id !== source.id);
          field.assetSources = on ? [...list, source.id] : list;
          notify();
          renderDefaultSource();
        },
      });
      cb.checked = field.assetSources.includes(source.id);
      sourcesBox.appendChild(el('label', { class: 'flex items-center gap-1.5 text-sm font-normal' },
        cb, source.label));
    }
    renderDefaultSource();
  }

  const defaultWrap = el('div', { class: 'field mb-3' },
    el('label', {},
      'Opens on ',
      el('span', { class: 'text-xs text-muted-foreground font-normal' }, '(which tab is active when the picker opens)')),
  );
  const defaultBox = el('div');
  defaultWrap.appendChild(defaultBox);
  panel.appendChild(defaultWrap);

  // Choosable tabs are the checked sources, or every fitting source when none
  // is checked — the same rule the runtime applies.
  function offeredSources() {
    const fitting = ASSET_SOURCES.filter((s) => s.mediaKinds.includes(field.assetKind));
    if (!field.assetSources.length) return fitting;
    return field.assetSources.map((id) => fitting.find((s) => s.id === id)).filter(Boolean);
  }

  function renderDefaultSource() {
    const offered = offeredSources();
    // A source that is no longer offered cannot stay the default.
    if (field.defaultSource && !offered.some((s) => s.id === field.defaultSource)) {
      field.defaultSource = null;
    }
    defaultBox.innerHTML = '';
    const sel = el('select', {
      onchange: (e) => { field.defaultSource = e.target.value || null; notify(); },
    });
    sel.appendChild(el('option', { value: '' }, `- first offered (${offered[0]?.label || 'none'}) -`));
    for (const source of offered) {
      const o = el('option', { value: source.id }, source.label);
      if (field.defaultSource === source.id) o.selected = true;
      sel.appendChild(o);
    }
    defaultBox.appendChild(sel);
  }

  renderSources();

  panel.appendChild(el('div', { class: 'field mb-2' },
    el('label', {},
      'Trigger label ',
      el('span', { class: 'text-xs text-muted-foreground font-normal' }, '(optional - shown on the closed picker card)')),
    el('input', {
      type: 'text',
      value: typeof field.triggerLabel === 'string' ? field.triggerLabel : '',
      placeholder: 'Choose asset',
      oninput: (e) => {
        const v = e.target.value.trim();
        field.triggerLabel = v ? v : null;
        notify();
      },
    }),
  ));
}

function appendInteractivePromptEditor(panel, field) {
  // Ensure shape: template (string), slotFields ({name, enum[], default}[]),
  // assembledTarget (string).
  if (typeof field.template !== 'string') field.template = '';
  if (!Array.isArray(field.slotFields)) field.slotFields = [];
  // Normalise legacy shapes — slotFields can arrive as ["name"] string array
  // (from a raw JSON paste). Convert to the object shape the editor expects.
  field.slotFields = field.slotFields.map((s) => {
    if (typeof s === 'string') return { name: s, enum: [], default: '' };
    if (s && typeof s === 'object') {
      return {
        name: typeof s.name === 'string' ? s.name : '',
        enum: Array.isArray(s.enum) ? s.enum.map(String) : [],
        default: typeof s.default === 'string' ? s.default : '',
      };
    }
    return { name: '', enum: [], default: '' };
  });
  if (typeof field.assembledTarget !== 'string' || !field.assembledTarget) {
    field.assembledTarget = field.id;
  }

  // ---- Template editor ----
  const tmplWrap = el('div', { class: 'field mb-3' },
    el('label', {},
      'Template ',
      el('span', { class: 'text-xs text-muted-foreground font-normal' },
        '(use {slotName} for each interactive pill, e.g. "A {mood} cat in a {setting}.")'),
    ),
    (() => {
      const ta = el('textarea', {
        rows: 3,
        spellcheck: 'false',
        placeholder: 'A {mood} {style} cat in a {setting} at {timeOfDay}.',
        oninput: (e) => { field.template = e.target.value; notify(); },
      });
      ta.value = field.template || '';
      return ta;
    })(),
  );
  panel.appendChild(tmplWrap);

  // ---- Slot list ----
  const slotsWrap = el('div', { class: 'field mb-3' });
  slotsWrap.appendChild(el('label', {}, 'Slots'));

  const slotsContainer = el('div', { class: 'flex flex-col gap-2' });
  slotsWrap.appendChild(slotsContainer);

  const renderSlotRow = (slot, slotIdx) => {
    const row = el('div', {
      class: 'rounded-lg',
      style: 'padding: 0.6rem; background: hsl(var(--ait-m-muted) / 0.4); border: 1px solid hsl(var(--ait-m-border));',
    });

    const head = el('div', { class: 'flex gap-2 items-center mb-2' },
      el('span', { class: 'text-xs text-muted-foreground', style: 'min-width: 3rem;' }, 'Name'),
      el('input', {
        type: 'text',
        value: slot.name || '',
        placeholder: 'slotName',
        style: 'flex: 1; min-height: 32px;',
        oninput: (e) => {
          // Only [a-zA-Z0-9_] keeps it valid as a {placeholder} key.
          slot.name = String(e.target.value || '').replace(/[^a-zA-Z0-9_]/g, '');
          notify();
        },
      }),
      el('button', {
        type: 'button',
        class: 'ab-row-iconbtn ab-cr-remove',
        title: 'Remove slot',
        onclick: () => { field.slotFields.splice(slotIdx, 1); notify(); },
      }, '×'),
    );
    row.appendChild(head);

    const optsWrap = el('div', { class: 'flex flex-col gap-1' });
    optsWrap.appendChild(el('div', { class: 'text-xs text-muted-foreground' },
      'Options (one per line - each becomes a pill choice)'));
    const optsTa = el('textarea', {
      rows: 3,
      spellcheck: 'false',
      placeholder: 'cozy\nmoody\nplayful',
      oninput: (e) => {
        const lines = String(e.target.value || '')
          .split('\n')
          .map(s => s.trim())
          .filter(Boolean);
        slot.enum = lines;
        // If the current default is no longer in the enum, drop it.
        if (slot.default && !lines.includes(slot.default)) slot.default = '';
        notify();
      },
    });
    optsTa.value = Array.isArray(slot.enum) ? slot.enum.join('\n') : '';
    optsWrap.appendChild(optsTa);

    const defaultWrap = el('div', { class: 'flex items-center gap-2 mt-1' },
      el('span', { class: 'text-xs text-muted-foreground', style: 'min-width: 3rem;' }, 'Default'),
      (() => {
        const sel = el('select', {
          style: 'flex: 1;',
          onchange: (e) => { slot.default = e.target.value || ''; notify(); },
        });
        sel.appendChild(el('option', { value: '' }, '- first option -'));
        (slot.enum || []).forEach((opt, i) => {
          const o = el('option', { value: String(opt) }, optionDisplayLabel(slot, opt, i));
          if (slot.default === String(opt)) o.selected = true;
          sel.appendChild(o);
        });
        return sel;
      })(),
    );
    optsWrap.appendChild(defaultWrap);
    row.appendChild(optsWrap);

    return row;
  };

  for (let i = 0; i < field.slotFields.length; i++) {
    slotsContainer.appendChild(renderSlotRow(field.slotFields[i], i));
  }

  slotsWrap.appendChild(el('button', {
    type: 'button',
    class: 'btn',
    style: 'margin-top: 0.5rem;',
    onclick: () => {
      field.slotFields.push({ name: '', enum: [], default: '' });
      notify();
    },
  }, '+ Add slot'));

  panel.appendChild(slotsWrap);

  // ---- Assembled target ----
  panel.appendChild(el('div', { class: 'field mb-2' },
    el('label', {},
      'Assembled target ',
      el('span', { class: 'text-xs text-muted-foreground font-normal' },
        '(the assembled sentence lands on this key - defaults to the field id)'),
    ),
    el('input', {
      type: 'text',
      value: field.assembledTarget || field.id || '',
      placeholder: field.id || 'assembled',
      oninput: (e) => {
        const v = String(e.target.value || '').trim();
        field.assembledTarget = v || field.id;
        notify();
      },
    }),
  ));
}

/**
 * Append the type-aware config rows for a field to a parent node.
 *
 * Owns everything that the field's `ui_component` determines:
 *   - select / radio-group  → options array editor + default picker
 *   - slider / numeric input → range (min, max) + default
 *   - toggle                → default true/false
 *   - json-input            → default (JSON, falls back to raw)
 *   - textarea / input(text) / file-upload → default (plain text)
 *
 * Shared by the step's Custom config panel (Pass 2) and the Pass 3 field-row
 * editor so the two surfaces handle every type identically. Anything outside
 * the type-specific shape (title, description, visible/advanced flags,
 * costMultiplier) is the caller's responsibility — this helper is strictly
 * about "what shape does this widget take and what does its default look
 * like?".
 */
/**
 * @param {HTMLElement} panel
 * @param {object} field
 * @param {object} [config]
 * @param {boolean} [config.inlineCost=false]
 *   Forwarded to `renderEnumOptionsEditor` for select/radio fields. Pass 2's
 *   Custom config panel passes `true` (no separate cost section exists
 *   there); Pass 3's field row editor passes `false` because it renders its
 *   own dedicated "Cost multiplier" section beneath the options — keeping
 *   the per-value inputs in both places would duplicate the same control.
 *
 * (Parameter named `config` not `opts` on purpose — the select branch below
 *  has a local `const opts = ...` for the enum value list. Same name would
 *  trigger a temporal-dead-zone ReferenceError under strict mode.)
 */
export function appendTypeSpecificConfig(panel, field, config = {}) {
  const uic = field.ui_component;

  if (uic === 'interactive-prompt') {
    appendInteractivePromptEditor(panel, field);
    return;
  }

  if (uic === 'asset-picker') {
    appendAssetPickerEditor(panel, field);
    return;
  }

  if (uic === 'select' || uic === 'radio-group' || uic === 'pill-toggle' || uic === 'prompt-picker' || uic === 'visual-picker'
      || uic === 'multi-select' || uic === 'editable-select' || uic === 'agent-selector') {
    // prompt-picker + visual-picker both render image thumbs per option;
    // visual-picker additionally surfaces a per-option category input (chip
    // filter in the runner modal) and a top-level trigger-label field. The
    // shared options editor (renderEnumOptionsEditor) toggles these via
    // withImages / withCategories. multi-select and editable-select use the
    // same enum-driven editor (plain options, no images / no categories).
    // See public/js/components/form/visual-picker.js for the runner-side
    // consumer of the image / category fields.
    const withImages = uic === 'prompt-picker' || uic === 'visual-picker';
    const withCategories = uic === 'visual-picker';
    panel.appendChild(renderEnumOptionsEditor(field, {
      inlineCost: !!config.inlineCost,
      withImages,
      withCategories,
    }));
    // agent-selector only — how the buyer's mode switch looks.
    if (uic === 'agent-selector') {
      panel.appendChild(el('div', { class: 'field mb-2' },
        el('label', {}, 'Selector style'),
        (() => {
          const sel = el('select', {
            onchange: (e) => { field.selectorStyle = e.target.value; notify(); },
          });
          for (const [value, label] of [['tab', 'Tabs (side by side)'], ['select', 'Dropdown']]) {
            const o = el('option', { value }, label);
            if ((field.selectorStyle === 'select' ? 'select' : 'tab') === value) o.selected = true;
            sel.appendChild(o);
          }
          return sel;
        })(),
      ));
    }
    // visual-picker only — trigger-label text shown on the empty card BEFORE
    // the user opens the picker. Optional; falls back to the field's title.
    if (uic === 'visual-picker') {
      panel.appendChild(el('div', { class: 'field mb-2' },
        el('label', {},
          'Trigger label ',
          el('span', { class: 'text-xs text-muted-foreground font-normal' }, '(optional - shown on the closed picker card)')),
        el('input', {
          type: 'text',
          value: typeof field.triggerLabel === 'string' ? field.triggerLabel : '',
          placeholder: 'Choose Option',
          oninput: (e) => {
            const v = e.target.value.trim();
            field.triggerLabel = v ? v : null;
            notify();
          },
        }),
      ));
    }
    const opts = Array.isArray(field.enum) ? field.enum : [];
    if (opts.length) {
      panel.appendChild(el('div', { class: 'field mb-2' },
        el('label', {}, 'Default'),
        (() => {
          const sel = el('select', {
            onchange: (e) => { field.default = e.target.value === '' ? null : e.target.value; notify(); },
          });
          sel.appendChild(el('option', { value: '' }, '- none -'));
          opts.forEach((opt, i) => {
            const o = el('option', { value: String(opt) }, optionDisplayLabel(field, opt, i));
            if (field.default != null && String(field.default) === String(opt)) o.selected = true;
            sel.appendChild(o);
          });
          return sel;
        })(),
      ));
    }
  } else if (uic === 'slider' || (uic === 'input' && (field.type === 'number' || field.type === 'integer'))) {
    panel.appendChild(el('div', { class: 'field mb-2' },
      el('label', {}, 'Range (min, max)'),
      el('div', { class: 'flex gap-2' },
        el('input', {
          type: 'number',
          value: field.range?.min ?? '',
          placeholder: 'min',
          oninput: (e) => {
            const v = e.target.value === '' ? null : Number(e.target.value);
            field.range = { ...(field.range || {}), min: v };
            notify();
          },
        }),
        el('input', {
          type: 'number',
          value: field.range?.max ?? '',
          placeholder: 'max',
          oninput: (e) => {
            const v = e.target.value === '' ? null : Number(e.target.value);
            field.range = { ...(field.range || {}), max: v };
            notify();
          },
        }),
      ),
    ));
    panel.appendChild(el('div', { class: 'field mb-2' },
      el('label', {}, 'Default'),
      el('input', {
        type: 'number',
        value: field.default == null ? '' : String(field.default),
        placeholder: '(none)',
        oninput: (e) => { field.default = e.target.value === '' ? null : Number(e.target.value); notify(); },
      }),
    ));
  } else if (uic === 'toggle') {
    panel.appendChild(el('div', { class: 'field mb-2' },
      el('label', {}, 'Default'),
      (() => {
        const sel = el('select', {
          onchange: (e) => { field.default = e.target.value === 'true'; notify(); },
        });
        for (const v of ['false', 'true']) {
          const o = el('option', { value: v }, v);
          if (String(field.default ?? false) === v) o.selected = true;
          sel.appendChild(o);
        }
        return sel;
      })(),
    ));
  } else if (uic === 'json-input') {
    const wrap = el('div', { class: 'field mb-2' },
      el('label', {}, 'Default (JSON)'),
    );
    const ta = el('textarea', {
      rows: 2,
      spellcheck: 'false',
      oninput: (e) => {
        try { field.default = JSON.parse(e.target.value); }
        catch { field.default = e.target.value || null; }
        notify();
      },
    });
    ta.value = field.default == null ? '' : (typeof field.default === 'string' ? field.default : JSON.stringify(field.default));
    wrap.appendChild(ta);
    panel.appendChild(wrap);
  } else if (uic === 'color-picker') {
    // Default is a hex string. The runner widget accepts any CSS color string
    // but the picker UI starts in hex mode, so we validate loosely here.
    panel.appendChild(el('div', { class: 'field mb-2' },
      el('label', {}, 'Default (hex color, e.g. #FFFFFF)'),
      el('input', {
        type: 'text',
        value: field.default == null ? '' : String(field.default),
        placeholder: '#FFFFFF',
        oninput: (e) => { field.default = e.target.value === '' ? null : e.target.value; notify(); },
      }),
    ));
  } else if (uic === 'image-pair') {
    // image-pair has no editable defaults — the runner widget collects two
    // image URLs at run time. Surface a short helper note so the row editor
    // isn't blank.
    panel.appendChild(el('div', { class: 'field mb-2 text-xs text-muted-foreground' },
      'Image-pair fields collect two image URLs (start + end frames) at run time. No defaults.',
    ));
  } else {
    // textarea / input (text) / file-upload — single default text input
    panel.appendChild(el('div', { class: 'field mb-2' },
      el('label', {}, 'Default'),
      el('input', {
        type: 'text',
        value: field.default == null ? '' : String(field.default),
        placeholder: '(none)',
        oninput: (e) => { field.default = e.target.value === '' ? null : e.target.value; notify(); },
      }),
    ));
  }
}

/**
 * Render the SOUL textarea — the wizard's top-level prompt for the step.
 *
 * Soul is always shown. Every keystroke runs the auto-promote pass against
 * `state.agent.fields`, so the moment the author types `${shadowPrompt}` a
 * matching field appears on Pass 3. The card styling mirrors the prompt card
 * (`.ab-schema-prompt`) so the SOUL section reads as the step's spine.
 */
/** The SOUL card. `opts.read`/`opts.write` retarget it at another string on
 *  the step, such as an option's prompt override. */
function renderSoulEditor(step, stepIdx, opts = {}) {
  // Upstream steps as full objects (not just ids) so the tag row can also offer
  // a content-research step's structured sub-fields (${research.priceTrend}).
  const upstreamSteps = state.agent.steps.slice(0, stepIdx).filter(s => s && s.output_id);
  const upstreamOutputs = upstreamSteps.map(s => s.output_id);
  // Defensive filter: `prompt` is a reserved id (soul owns the prompt-shaped
  // text). Even if a stray field with that id slipped through migration, the
  // SOUL card refuses to suggest it as a tag.
  const fieldIds = state.agent.fields.map(f => f.id).filter(id => id !== 'prompt');

  const block = el('div', { class: 'ab-schema-prompt' });
  block.appendChild(opts.hint
    ? el('div', { class: 'text-xs text-muted-foreground mb-2' }, opts.hint)
    : el('div', { class: 'text-xs text-muted-foreground mb-2' },
      'Describe what this step does. Click a tag below to insert a placeholder ',
      el('code', {}, '${id}'),
      ", or type one by hand. Names that aren't yet on the Fields pass will be flagged so you can add them how you like.",
    ));

  // The warning row is a separate node we live-patch on every keystroke so
  // the unresolved-placeholder feedback updates without waiting for a full
  // list rebuild. The focus-aware skip in `renderStepsPass` blocks rebuild
  // while the textarea has focus (that's how we keep caret + AltGr working);
  // patching this single node here keeps the warning responsive without
  // touching anything else.
  const readText = typeof opts.read === 'function' ? opts.read : () => step.soul;
  const writeText = typeof opts.write === 'function' ? opts.write : (v) => { step.soul = v; };

  const warnSlot = el('div', { class: 'ab-soul-warning-slot' });
  const repaintWarning = () => {
    warnSlot.innerHTML = '';
    const ids = unresolvedPlaceholderIds(readText(), upstreamOutputs);
    if (!ids.length) return;
    const warn = el('div', {
      class: 'ab-soul-warning',
      style: 'margin-top: 0.6rem; padding: 0.55rem 0.75rem; border-radius: 10px; '
        + 'background: rgba(245,158,11,0.08); border: 1px solid rgba(245,158,11,0.35); '
        + 'color: hsl(var(--ait-m-foreground)); font-size: 0.78rem; line-height: 1.5;',
    });
    warn.appendChild(el('div', { style: 'font-weight: 700; margin-bottom: 0.2rem;' },
      'These placeholders aren\'t on the Fields pass yet:',
    ));
    const tagWrap = el('div', { class: 'flex flex-wrap gap-1' });
    for (const id of ids) {
      tagWrap.appendChild(el('span', {
        class: 'ab-tag',
        style: 'background: rgba(245,158,11,0.18); border-color: rgba(245,158,11,0.45);',
      }, '${' + id + '}'));
    }
    warn.appendChild(tagWrap);
    warn.appendChild(el('div', { style: 'margin-top: 0.35rem; color: hsl(var(--ait-m-muted-foreground));' },
      'Add them on the Fields pass (catalog or custom) before publishing, or remove the references here.',
    ));
    warnSlot.appendChild(warn);
  };

  const ta = el('textarea', {
    rows: opts.rows || 6,
    spellcheck: 'false',
    placeholder: opts.placeholder || '',
    oninput: (e) => {
      writeText(e.target.value);
      // Live-patch the warning row before delegating to notify(). The full
      // list rebuild from notify() will be skipped while the textarea owns
      // focus, but this DOM mutation lands immediately so the author sees
      // unresolved ids as they type.
      repaintWarning();
      notify();
    },
  });
  ta.value = readText() || '';
  block.appendChild(ta);
  appendTagRows(block, ta, fieldIds, upstreamOutputs, upstreamSteps);
  block.appendChild(warnSlot);
  repaintWarning();

  return block;
}

/**
 * Walk a string for `${id}` placeholders and return the ids that don't
 * resolve against either an existing form field or an upstream step output.
 * Excludes the reserved `prompt` id — it's runtime-substituted from soul,
 * never represented as a field.
 */
function unresolvedPlaceholderIds(text, upstreamOutputIds) {
  if (typeof text !== 'string' || !text) return [];
  const known = new Set([
    ...state.agent.fields.map(f => f.id),
    ...(upstreamOutputIds || []).filter(Boolean),
    'prompt',
  ]);
  const seen = new Set();
  const out = [];
  // Allow dot-paths (${research.priceTrend}); only the ROOT must be known,
  // since a content-research output's sub-fields aren't fields/outputs of
  // their own.
  const re = /\$\{([a-zA-Z0-9_.-]+)\}/g;
  let m;
  while ((m = re.exec(text)) !== null) {
    const id = m[1];
    const root = id.split('.')[0];
    if (known.has(root) || seen.has(id)) continue;
    seen.add(id);
    out.push(id);
  }
  return out;
}

// True when the step's model exposes the r2v routing flag (union schema carried
// `supportsReference`). Read off the rehydrated meta, not the live network.
function stepSupportsReference(step) {
  return step.__supportsReference === true;
}

// Whether reference mode is currently ON for this step. The flag lives in
// step.schema so it persists into the published agent JSON and reaches the
// runtime router untouched.
function isReferenceModeOn(step) {
  return step.schema?.[REFERENCE_MODE_KEY] === true;
}

// Hide a key from the editor when it doesn't apply to the active mode. Thin
// wrapper over the shared classifier (refModeHides) gated on this step's state.
function stepHidesKey(step, prop) {
  if (!stepSupportsReference(step)) return false;
  return refModeHides(prop, isReferenceModeOn(step));
}

// Remove wired keys that don't belong to the active mode, so the schema never
// ships both `image` (i2v) and `image_urls` (r2v). ON drops standard keys, OFF
// drops reference keys; neutral keys stay.
function pruneReferenceModeKeys(step, on) {
  const props = step.__schemaMeta?.properties || {};
  for (const key of Object.keys(step.schema)) {
    if (key === REFERENCE_MODE_KEY) continue;
    const cls = referenceModeClassOf(props[key]);
    if (cls === null) continue;
    if (on ? cls === 'standard' : cls === 'reference') delete step.schema[key];
  }
}

// The "Reference mode" toggle row. Shown only when the model advertises an r2v
// endpoint (supportsReference). Flipping it writes step.schema.referenceMode and
// re-renders so the mode-gated field visibility updates. Styled to match the
// model page playground toggle.
function renderReferenceModeToggle(step) {
  const on = isReferenceModeOn(step);
  const row = el('label', {
    class: 'flex items-center justify-between gap-3 rounded-lg p-3 mb-3 cursor-pointer select-none',
    style: 'background: var(--ab-surface); border: 1px solid var(--ab-hair);',
  });
  const text = el('div', { class: 'min-w-0' },
    el('div', { class: 'text-sm font-medium' }, 'Reference mode'),
    el('div', { class: 'text-xs text-muted-foreground' },
      'Route to the reference-to-* endpoint: reference media arrays are used; the start-frame image is ignored.'),
  );
  const checkbox = el('input', {
    type: 'checkbox',
    role: 'switch',
    checked: on,
    onchange: (e) => {
      const checked = e.target.checked;
      if (checked) step.schema[REFERENCE_MODE_KEY] = true;
      else delete step.schema[REFERENCE_MODE_KEY];
      pruneReferenceModeKeys(step, checked);
      notify();
    },
  });
  row.appendChild(text);
  row.appendChild(checkbox);
  return row;
}

function renderSchemaKeyEditor(step, stepIdx, key, isRequired, { headless = false } = {}) {
  const prop = step.__schemaMeta?.properties?.[key] || {};
  const value = step.schema[key];
  const isPrompt = key === 'prompt';

  const upstreamOutputs = state.agent.steps.slice(0, stepIdx).map(s => s.output_id).filter(Boolean);
  // `prompt` is reserved (soul owns prompt-shaped text); never suggest it as
  // a tag, even if a stray field with that id survived migration.
  const fieldIds = state.agent.fields.map(f => f.id).filter(id => id !== 'prompt');

  // Prompt gets a fully styled card (`.ab-schema-prompt`); it lives in its own
  // section above Required/Optional and never shares visual language with
  // ordinary schema rows. The card already supplies its own padding/border,
  // so we leave its inline style blank here.
  //
  // Every other key gets a flat row — no left border, no accent tint — so
  // nothing else can be mistaken for the prompt. The "required" badge in the
  // header carries the only signal of required-ness for non-prompt keys.
  const blockClass = isPrompt
    ? 'ab-schema-prompt'
    : 'mb-3 pl-1';
  const blockStyle = '';

  const block = el('div', { class: blockClass, style: blockStyle });

  // The header row differs for prompt vs other keys.
  //
  // Prompt: the section above the card already carries the "PROMPT" heading;
  //         repeating "✦ prompt [required] [string]" inside the same card is
  //         visual noise. We render only the short helper line.
  //
  // Other keys: checkbox (locked on for required, toggleable for optional)
  //         + key name + required/optional badge + type badge.
  if (isPrompt) {
    block.appendChild(el('div', { class: 'text-xs text-muted-foreground mb-2' },
      'The prompt is where every form value wires into the model. Click a tag below to insert it at the caret. Type ',
      el('code', {}, '${anything}'),
      ' and the builder turns "anything" into a form field for you.',
    ));
  } else if (!headless) {
    const header = el('div', { class: 'flex items-center gap-2 mb-1' },
      (() => {
        const cb = el('input', {
          type: 'checkbox',
          checked: true,
          disabled: isRequired,
          onchange: (e) => {
            if (isRequired) return;
            if (!e.target.checked) {
              delete step.schema[key];
              if (!step.__optionalAvailable) step.__optionalAvailable = [];
              if (!step.__optionalAvailable.includes(key)) step.__optionalAvailable.push(key);
              pruneOrphanAutoAddedFields();
              notify();
            }
          },
        });
        return cb;
      })(),
      el('span', { class: 'font-mono text-sm font-bold' }, key),
      isRequired
        ? el('span', { class: 'ab-badge', style: 'background: hsl(var(--ait-m-primary) / 0.12); color: hsl(var(--ait-m-primary)); border-color: hsl(var(--ait-m-primary) / 0.35);' }, 'required')
        : el('span', { class: 'ab-badge' }, 'optional'),
      prop.type ? el('span', { class: 'ab-badge' }, String(prop.type)) : null,
    );
    block.appendChild(header);
    if (prop.description) {
      block.appendChild(el('div', { class: 'text-xs text-muted-foreground mb-1' }, prop.description));
    }
  }

  // Mode model — From input-mapping vs Custom. BOTH branches produce a form
  // field; the difference is who owns the field's shape:
  //
  //   - **From input-mapping** → the catalog (`AGENT_INPUT_MAP`) owns the
  //     defaults. Field is a compact `{ id: conceptId }` entry; catalog
  //     supplies ui_component / enum / range / default at runtime. When the
  //     key has no catalog match, falls back to a custom field with the same
  //     schema-key id (the radio is still meaningful — the placeholder gets
  //     wired either way).
  //
  //   - **Custom** → the AGENT owns the shape. Field is a fully-spec'd
  //     `__custom: true` entry; catalog defaults are NOT inherited even if
  //     a concept with the same id exists. Author tunes ui_component, enum,
  //     range, default by hand.
  //
  // In both modes `step.schema[key]` is `${fieldId}` — never a literal. The
  // earlier "literal value in step.schema" path was wrong for required keys:
  // a literal "" silently shipped to the model, causing 422s. Defaults now
  // live on the FIELD (visible in Pass 4), not on the step.
  const resolved = resolveSchemaControl(key, prop);
  const boundField = boundFieldFor(step, key);
  const mode = boundField && boundField.__custom ? 'custom' : 'mapping';

  // enumLabels/optionLabels ride along so the picker below can name an option
  // by its label rather than a sentence-long value.
  const effective = boundField
    ? {
        uiComponent: boundField.ui_component || resolved.uiComponent,
        enum: Array.isArray(boundField.enum) && boundField.enum.length ? boundField.enum : null,
        enumLabels: boundField.enumLabels,
        optionLabels: boundField.optionLabels,
      }
    : {
        uiComponent: resolved.uiComponent,
        enum: Array.isArray(prop.enum) && prop.enum.length
          ? prop.enum
          : (Array.isArray(resolved.enum) ? resolved.enum : null),
        enumLabels: prop.enumLabels ?? prop['x-uap']?.enumLabels,
        optionLabels: prop['x-uap']?.optionLabels,
      };
  const effectiveControl = effective.uiComponent;
  const effectiveEnum = effective.enum;

  const valueLooksLikePlaceholder = typeof value === 'string' && /\$\{[a-zA-Z0-9_-]+\}/.test(value);
  const structuredControls = new Set(['select', 'radio-group', 'toggle', 'slider', 'file-upload']);
  // Placeholder mode is the textarea+tags fallback for a key whose resolved
  // widget is structured (select / toggle / slider / file-upload) but the
  // author wants to wire to a `${...}` reference instead of picking a literal.
  //
  // Three triggers, in priority order:
  //   1. Explicit toggle flag — the author clicked "Use placeholder instead",
  //      which sets `step.__placeholderMode[key] = true`. Clicking it again
  //      flips the flag off and snaps back to the structured widget. This is
  //      the toggle the author asked for; it survives partial placeholder
  //      typing (`${`, `${ab`) that wouldn't otherwise match the regex.
  //   2. Implicit — the value already looks like a real placeholder
  //      (`${something}`). The structured widget can't represent that, so we
  //      drop to textarea automatically.
  //   3. Canonical bound field — handled by the Custom panel, not this path.
  const explicitPlaceholderMode = !!(step.__placeholderMode && step.__placeholderMode[key]);
  const useTextareaForPlaceholder = !boundField && structuredControls.has(effectiveControl) && (
    explicitPlaceholderMode || valueLooksLikePlaceholder
  );

  // Mode toggle row — only meaningful for schema keys that *could* be
  // a structured form input. The prompt is a free-form template (it carries
  // ${...} placeholders, not a literal value the end user picks), so the
  // Custom panel's concepts of "options / range / default" do not apply.
  // We skip the entire Source toggle on prompt rows.
  if (!isPrompt) {
    const segButton = (label, active, onPick) => el('button', {
      type: 'button',
      class: 'ab-seg-btn' + (active ? ' active' : ''),
      role: 'radio',
      'aria-checked': active ? 'true' : 'false',
      onclick: () => { if (!active) { onPick(); notify(); } },
    }, label);

    const modeRow = el('div', {
      class: 'flex items-center gap-3 mt-1 mb-2 flex-wrap text-xs',
      style: 'white-space: nowrap;',
    },
      el('div', { class: 'ab-seg', role: 'radiogroup', 'aria-label': 'Source' },
        (() => {
          const hasMapping = !!(resolved.conceptId && state.config.catalog.find(c => c.id === resolved.conceptId));
          const btn = segButton('From input-mapping', mode === 'mapping', () => {
            if (hasMapping) { promoteKeyToMappingField(step, key, prop); return; }
            step.schema[key] = typeof boundField?.default === 'string' ? boundField.default : '';
            pruneOrphanAutoAddedFields();
          });
          if (!hasMapping) btn.title = 'No catalog mapping — switches back to a literal value';
          return btn;
        })(),
        segButton('Custom', mode === 'custom',
          () => promoteKeyToCustomField(step, key, prop)),
      ),
      resolved.conceptId && mode === 'mapping' && boundField
        ? el('span', { class: 'ab-badge', title: 'Resolved from AGENT_INPUT_MAP' },
            'via ', resolved.conceptId, ' (', resolved.source.replace('catalog-', ''), ')')
        : null,
    );
    block.appendChild(modeRow);

    if (mode === 'custom' && boundField) {
      block.appendChild(renderCustomConfigPanel(boundField));
      // Custom config panel already owns the entire shape (control type +
      // type-aware default/options/range). `step.schema[key]` is wired to
      // `${boundField.id}` — there is no literal-value editor to render
      // underneath. Skip the widget renderers below so we don't surface a
      // second textarea + tag-rows that would write into step.schema[key]
      // and break the wiring on the first keystroke.
      return block;
    }

    // Mapping mode: field lives in Pass 4 (Fields), edited there. Surface a
    // short pointer + the wired placeholder so the author knows the wiring
    // is in place. No widget here — the actual input control belongs to the
    // end-user form on Pass 4.
    if (mode === 'mapping' && boundField) {
      const conceptHint = resolved.conceptId
        ? `catalog field "${resolved.conceptId}"`
        : `custom field "${boundField.id}" (no catalog match for this key)`;
      const note = el('div', {
        class: 'text-xs text-muted-foreground mt-1',
        style: 'padding: 0.45rem 0.7rem; border-radius: 8px; background: hsl(var(--ait-m-secondary) / 0.4); border-left: 3px solid hsl(var(--ait-m-primary) / 0.6);',
      },
        'Wired to ', conceptHint, ' as ',
        el('code', {}, '${' + boundField.id + '}'),
        '. Edit title / default / enum / range on the ',
        el('a', {
          href: '#', style: 'color: hsl(var(--ait-m-primary)); font-weight: 600; text-decoration: underline;',
          onclick: (e) => { e.preventDefault(); state.pass = 4; notify(); },
        }, 'Fields tab'),
        '.',
      );
      block.appendChild(note);
      // The author must always be able to drop this key to a free-form dynamic
      // placeholder (`${anyField}` / `${upstreamOutput}`) WITHOUT being forced
      // through a form field. Offer an explicit escape from mapping mode: detach
      // the auto-wired field and flip into placeholder (textarea + tags) mode.
      block.appendChild(el('button', {
        class: 'btn', type: 'button', style: 'margin-top: 0.4rem;',
        onclick: () => {
          if (!step.__placeholderMode) step.__placeholderMode = {};
          step.__placeholderMode[key] = true;
          step.schema[key] = '';
          // Drop the auto-added field this key used to reference (manual fields
          // are never touched by the prune).
          pruneOrphanAutoAddedFields();
          notify();
        },
      }, 'Use placeholder instead'));
      // Skip the literal widget renderers below — value is already a
      // `${placeholder}`, not a literal the author types here.
      return block;
    }
  }

  /* ----------- Widget renderers ----------- */

  if (useTextareaForPlaceholder) {
    // Placeholder mode (textarea + tags). The same button that flipped us
    // here flips us back: clear the explicit-mode flag and reset the value
    // to a sensible literal for the resolved widget. This is the toggle UX
    // the author asked for — one button, two states.
    const ta = el('textarea', {
      rows: 2, spellcheck: 'false',
      oninput: (e) => { applyStringValue(step, key, e.target.value); notify(); },
    });
    ta.value = typeof value === 'string' ? value : '';
    block.appendChild(ta);
    appendTagRows(block, ta, fieldIds, upstreamOutputs);
    block.appendChild(el('button', {
      class: 'btn primary', type: 'button', style: 'margin-top: 0.4rem;',
      onclick: () => {
        if (step.__placeholderMode) delete step.__placeholderMode[key];
        if (effectiveControl === 'toggle') step.schema[key] = false;
        else if (effectiveControl === 'select' || effectiveControl === 'radio-group') step.schema[key] = effectiveEnum?.[0] ?? '';
        else step.schema[key] = '';
        notify();
      },
    }, 'Back to ', uiComponentLabelInline(effectiveControl)));

  } else if (effectiveControl === 'toggle') {
    // Literal on/off value shipped to the model. Wrap the checkbox in a label
    // so it isn't an orphaned, unexplained checkbox in the form.
    const cb = el('input', {
      type: 'checkbox',
      onchange: (e) => { step.schema[key] = e.target.checked; notify(); },
    });
    if (value === true) cb.checked = true;
    block.appendChild(el('label', { class: 'flex items-center gap-2 cursor-pointer text-sm' },
      cb, 'Send ', el('code', {}, key + ' = ' + (value === true ? 'true' : 'false')),
    ));
    if (fieldIds.length || upstreamOutputs.length) {
      block.appendChild(el('button', {
        class: 'btn', type: 'button', style: 'margin-top: 0.4rem;',
        onclick: () => {
          if (!step.__placeholderMode) step.__placeholderMode = {};
          step.__placeholderMode[key] = true;
          step.schema[key] = '';
          pruneOrphanAutoAddedFields();
          notify();
        },
      }, 'Use placeholder instead'));
    }

  } else if (effectiveControl === 'select' || effectiveControl === 'radio-group') {
    const choices = effectiveEnum || [];
    if (!choices.length) {
      // Catalog hinted at a select but no enum is available — fall back to a
      // text input so the author can at least type a value.
      const inp = el('input', {
        type: 'text', value: value == null ? '' : String(value),
        oninput: (e) => { applyStringValue(step, key, e.target.value); notify(); },
      });
      block.appendChild(inp);
    } else {
      const sel = el('select', {
        onchange: (e) => { step.schema[key] = e.target.value; notify(); },
      });
      if (value === '' || value == null) sel.appendChild(el('option', { value: '' }, '- pick -'));
      choices.forEach((opt, i) => {
        const o = el('option', { value: String(opt) }, optionDisplayLabel(effective, opt, i));
        if (value != null && String(value) === String(opt)) o.selected = true;
        sel.appendChild(o);
      });
      block.appendChild(sel);
    }
    if (fieldIds.length || upstreamOutputs.length) {
      block.appendChild(el('button', {
        class: 'btn', type: 'button', style: 'margin-top: 0.4rem;',
        onclick: () => {
          // Flip the explicit placeholder-mode flag on so the next render
          // drops to the textarea+tags editor. We clear the value so the
          // author starts from a clean slate; they pick a tag from the row
          // underneath to insert the actual `${id}`.
          if (!step.__placeholderMode) step.__placeholderMode = {};
          step.__placeholderMode[key] = true;
          step.schema[key] = '';
          // Clearing the wire may have orphaned the auto-added field this key
          // used to reference. Drop it from the form unless another step still
          // points at it (manual fields are never touched by the prune).
          pruneOrphanAutoAddedFields();
          notify();
        },
      }, 'Use placeholder instead'));
    }

  } else if (effectiveControl === 'slider' || effectiveControl === 'input' && (prop.type === 'integer' || prop.type === 'number')) {
    // Slider and numeric `input` collapse to the same renderer in the editor:
    // a numeric input with min/max hints. We don't render an actual range
    // slider because the author is setting a fixed value, not exposing the
    // slider to the end user (the runner does that based on `ui_component`).
    const inp = el('input', {
      type: 'number',
      value: typeof value === 'number' ? String(value) : '',
      min: prop.minimum != null ? String(prop.minimum) : undefined,
      max: prop.maximum != null ? String(prop.maximum) : undefined,
      oninput: (e) => {
        step.schema[key] = e.target.value === '' ? null : Number(e.target.value);
        notify();
      },
    });
    block.appendChild(inp);

  } else if (effectiveControl === 'file-upload') {
    // The wizard authoring surface doesn't actually upload — at design time
    // the author is wiring this key to either a form-field placeholder
    // (`${background}`) or pasting a known URL. Show a URL input with the
    // tag rows underneath so the wiring stays one click away.
    const inp = el('input', {
      type: 'text',
      value: value == null ? '' : String(value),
      placeholder: 'Paste an image/video/audio URL, or click a tag below',
      oninput: (e) => { applyStringValue(step, key, e.target.value); notify(); },
    });
    block.appendChild(inp);
    appendTagRows(block, inp, fieldIds, upstreamOutputs);

  } else if (effectiveControl === 'json-input' || Array.isArray(value) || (prop.type === 'array' || prop.type === 'object')) {
    // Arrays/objects are stored as JSON in this branch to preserve nested
    // shapes. But the author must ALSO be able to wire this key to a dynamic
    // `${field}` / `${output}` placeholder instead of pasting a literal — the
    // same freedom every other control gives. A bare `${id}` (or an array
    // literal of them) is kept as a string so the runtime resolver sees the
    // placeholder; only genuine JSON literals get parsed.
    const ta = el('textarea', {
      rows: 2, spellcheck: 'false',
      placeholder: 'Paste JSON, or click a tag below to wire a ${placeholder}',
      oninput: (e) => {
        const raw = e.target.value;
        // Preserve placeholder wiring verbatim — never JSON.parse a value that
        // carries a `${...}` reference (that's how `audio_urls`, `image_input`,
        // etc. get a dynamic field/output instead of a hardcoded literal).
        if (/\$\{[a-zA-Z0-9_.-]+\}/.test(raw)) { step.schema[key] = raw; notify(); return; }
        try { step.schema[key] = JSON.parse(raw); }
        catch { step.schema[key] = raw; }
        notify();
      },
    });
    ta.value = typeof value === 'string' ? value : JSON.stringify(value);
    block.appendChild(ta);
    // Tag rows so a field/output can be wired with one click — without this,
    // array/object keys (e.g. audio_urls, reference_images) had no UI path to
    // a dynamic placeholder and forced the author to add a form field.
    appendTagRows(block, ta, fieldIds, upstreamOutputs);

  } else {
    // Textarea — the workhorse for prompt templates and any free-form string.
    // `applyStringValue` runs the auto-promote pass on every keystroke: type
    // `${shadowPrompt}` in the prompt and a custom textarea field
    // `shadowPrompt` appears in Pass 3 the same moment. Upstream output ids
    // and existing fields are recognised, so they're not duplicated.
    const initial = (value == null) ? '' : String(value);
    const ta = el('textarea', {
      rows: isPrompt ? 6 : 2,
      spellcheck: 'false',
      oninput: (e) => { applyStringValue(step, key, e.target.value); notify(); },
    });
    ta.value = initial;
    block.appendChild(ta);
    appendTagRows(block, ta, fieldIds, upstreamOutputs);
  }

  // Range hint — surfaced for any numeric widget that has bounds.
  if (prop.minimum != null || prop.maximum != null) {
    block.appendChild(el('div', { class: 'text-xs text-muted-foreground mt-1' },
      'Range: ', String(prop.minimum ?? '-∞'), ' … ', String(prop.maximum ?? '+∞')));
  }

  return block;
}

function appendTagRows(container, textarea, fieldIds, upstreamOutputs, upstreamSteps) {
  if (fieldIds.length) {
    container.appendChild(el('div', { class: 'ab-tags' },
      el('span', { class: 'text-xs text-muted-foreground mr-1' }, 'Fields:'),
      ...fieldIds.map(id => el('span', {
        class: 'ab-tag',
        onclick: () => insertAtCaret(textarea, `\${${id}}`),
      }, '${', id, '}'))
    ));
  }
  if (upstreamOutputs.length) {
    // Build the upstream tag list. For a content-research step that declares an
    // outputSchema, also offer each top-level field as ${output_id.field} so the
    // author can wire a specific piece of the structured result, not just the
    // whole object.
    const tags = [];
    const stepsById = new Map((upstreamSteps || []).map(s => [s.output_id, s]));
    for (const id of upstreamOutputs) {
      tags.push({ token: id, label: '${' + id + '}' });
      const up = stepsById.get(id);
      // Asks the kind: a format check alone offered unresolvable pills.
      const props = up ? objectSchemaPropsOf(up) : null;
      if (props) {
        for (const key of Object.keys(props)) {
          tags.push({ token: `${id}.${key}`, label: '${' + id + '.' + key + '}' });
        }
      }
    }
    container.appendChild(el('div', { class: 'ab-tags' },
      el('span', { class: 'text-xs text-muted-foreground mr-1' }, 'Upstream:'),
      ...tags.map(t => el('span', {
        class: 'ab-tag output',
        onclick: () => insertAtCaret(textarea, `\${${t.token}}`),
      }, t.label))
    ));
  }
}

function renderSchemaEditor(step, stepIdx) {
  const container = el('div', { class: 'mt-3' });

  const spec = stepKindSpec(kindOfStep(step)) || {};
  // A selector is "picked" once it has a default; its schema comes from that.
  const picked = spec.picksFirst
    ? step[spec.picksFirst]
    : (step.model_id || defaultSelectorModelId(step));
  if (step.__schemaLoading) {
    container.appendChild(el('div', { class: 'text-sm text-muted-foreground p-3' }, 'Loading input schema…'));
    return container;
  }
  if (!picked) {
    const what = spec.picksFirst ? (spec.label || 'an agent') : 'a model';
    container.appendChild(el('div', { class: 'text-sm text-muted-foreground p-3' },
      `Pick ${what === 'a model' ? 'a model' : 'an agent'} to load its input schema.`));
    return container;
  }
  if (!step.__schemaMeta) {
    // The boot pass fetches it on first render, so this is either in flight or
    // the fetch failed — say which, and only then offer the retry.
    const pending = !_rehydratedSchemaSteps.has(step);
    container.appendChild(el('div', { class: 'text-sm text-muted-foreground p-3' },
      pending ? 'Loading input schema…' : 'Could not load the input schema. ',
      pending ? null : el('button', {
        class: 'btn', type: 'button', style: 'margin-left: 0.5rem;',
        onclick: () => {
          _rehydratedSchemaSteps.delete(step);
          return spec.picksFirst ? loadAndApplyPickedSchema(step, spec) : loadAndApplySchema(step);
        },
      }, 'Retry'),
    ));
    return container;
  }

  const required = step.__schemaMeta.required || [];
  const requiredSet = new Set(required);
  const props = step.__schemaMeta.properties || {};

  // SOUL — the wizard's top-level prompt. Always present, regardless of
  // whether the model schema declares a `prompt` property. The author types
  // here; at publish/runtime, the resolver substitutes soul into
  // `schema.prompt` when the model accepts one and the schema's own prompt
  // key is left empty. When the model doesn't take a prompt at all (a
  // background remover, an upscaler), soul is still useful as an authoring
  // note + as the placeholder discovery surface — every `${id}` the author
  // writes here auto-promotes a field on Pass 3.
  if ((spec.ownFields || ['soul']).includes('soul')) {
    if (typeof step.soul !== 'string') step.soul = '';
    const soulSection = el('div', { class: 'mb-4' });
    soulSection.appendChild(
      el('h4', {
        class: 'text-xs font-bold uppercase tracking-wide mb-2',
        style: 'color: hsl(var(--ait-m-primary)); letter-spacing: 0.08em;',
        title: "Soul is the wizard's top-level prompt. Every ${placeholder} you write becomes a form field.",
      },
        'Soul ',
        el('span', { style: 'font-weight: 600; color: hsl(var(--ait-m-muted-foreground)); text-transform: none; letter-spacing: 0;' },
          '- top-level prompt for this step',
        ),
      )
    );
    soulSection.appendChild(renderSoulEditor(step, stepIdx));
    container.appendChild(soulSection);
    container.appendChild(el('hr', { style: 'border: 0; border-top: 1px dashed hsl(var(--ait-m-border)); margin: 0.25rem 0 0.75rem;' }));
  }

  // Reference-mode toggle (only for models with an r2v endpoint). Sits at the
  // top because it gates which inputs apply, mirroring the model page.
  if (stepSupportsReference(step)) {
    container.appendChild(renderReferenceModeToggle(step));
  }

  // The model's own `prompt` key (if it declares one) is intentionally hidden
  // from the editor: the runtime substitutes soul into it when it's blank, so
  // exposing two prompt-shaped textareas would just create confusion. The key
  // stays in step.schema as `""` and is filtered out of both blocks below.
  // Reference-mode also gates visibility: keys that belong only to the inactive
  // route (reference-only while OFF, singular-frame while ON) are filtered out.
  const hidden = (k) => stepHidesKey(step, props[k]);
  const requiredOthers = required.filter(k => !RESERVED_SCHEMA_KEYS.has(k) && !hidden(k));
  const enabledOptionalKeys = Object.keys(step.schema).filter(k => !requiredSet.has(k) && !RESERVED_SCHEMA_KEYS.has(k) && !hidden(k));
  const stillAvailable = (step.__optionalAvailable || []).filter(k => !(k in step.schema) && !RESERVED_SCHEMA_KEYS.has(k) && !hidden(k));

  // Required block (without prompt — already in its own section above)
  if (requiredOthers.length) {
    container.appendChild(el('h4', { class: 'text-xs font-bold uppercase tracking-wide mt-3 mb-3', style: 'color: hsl(var(--ait-m-muted-foreground));' }, 'Required'));
    for (const key of requiredOthers) {
      container.appendChild(renderSchemaKeyEditor(step, stepIdx, key, true));
    }
  }

  if (enabledOptionalKeys.length || stillAvailable.length) {
    const enableOptionalKey = (key) => {
      const prop = step.__schemaMeta?.properties?.[key];
      const rawDefault = prop && Object.prototype.hasOwnProperty.call(prop, 'default') ? prop.default : undefined;
      const isEmptyDefault =
        rawDefault === undefined ||
        rawDefault === null ||
        rawDefault === '' ||
        (Array.isArray(rawDefault) && rawDefault.length === 0) ||
        (typeof rawDefault === 'object' && !Array.isArray(rawDefault) && Object.keys(rawDefault).length === 0);
      if (!isEmptyDefault) {
        step.schema[key] = rawDefault;
      } else {
        const fieldId = ensureFieldForRequiredKey(key, prop);
        step.schema[key] = '${' + fieldId + '}';
      }
      step.__optionalAvailable = (step.__optionalAvailable || []).filter(k => k !== key);
      notify();
    };

    const titleFor = (key) => {
      const prop = props[key] || {};
      const title = typeof prop.title === 'string' ? prop.title.trim() : '';
      if (title && title !== key) return title;
      return key.replace(/[_-]+/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
    };
    const valueSummaryFor = (key) => {
      const v = step.schema[key];
      if (typeof v === 'string' && /^\$\{[^}]+\}$/.test(v)) return '';
      if (v === '' || v == null || typeof v === 'object') return '';
      return String(v);
    };

    const section = el('div', { class: 'ab-opt-section' });
    section.appendChild(el('div', { class: 'ab-opt-head' }, el('span', { class: 'ab-opt-title' }, 'Optional Inputs')));
    const GHOST_LIMIT = 10;
    const showAll = step.__optionalShowAll === true;
    const ghosts = showAll ? stillAvailable : stillAvailable.slice(0, GHOST_LIMIT);
    const hiddenCount = stillAvailable.length - ghosts.length;

    if (enabledOptionalKeys.length || stillAvailable.length) {
      const grid = el('div', { class: 'ab-opt-grid' });
      for (const key of enabledOptionalKeys) {
        const isOpen = step.__optionalOpen === key;
        const summary = valueSummaryFor(key);
        grid.appendChild(el('div', { class: 'ab-opt-card' + (isOpen ? ' open' : '') },
          el('button', {
            class: 'ab-opt-check', type: 'button',
            title: 'Disable this input',
            onclick: () => {
              delete step.schema[key];
              if (!step.__optionalAvailable) step.__optionalAvailable = [];
              if (!step.__optionalAvailable.includes(key)) step.__optionalAvailable.push(key);
              if (step.__optionalOpen === key) delete step.__optionalOpen;
              pruneOrphanAutoAddedFields();
              notify();
            },
          }, iconSpan('<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="#C084FC" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="20 6 9 17 4 12"></polyline></svg>')),
          el('span', { class: 'ab-opt-name', title: key }, titleFor(key)),
          summary ? el('span', { class: 'ab-opt-value', title: summary }, summary) : null,
          el('button', {
            class: 'ab-opt-config', type: 'button',
            title: isOpen ? 'Close settings' : 'Configure this input',
            onclick: () => {
              if (isOpen) delete step.__optionalOpen;
              else step.__optionalOpen = key;
              notify();
            },
          }, iconSpan('<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><line x1="8" y1="4" x2="8" y2="20"></line><line x1="16" y1="4" x2="16" y2="20"></line><circle cx="8" cy="9" r="2.2" fill="currentColor" stroke="none"></circle><circle cx="16" cy="15" r="2.2" fill="currentColor" stroke="none"></circle></svg>')),
        ));
      }
      for (const key of ghosts) {
        grid.appendChild(el('button', {
          class: 'ab-opt-card ghost', type: 'button', title: 'Enable this input',
          onclick: () => enableOptionalKey(key),
        },
          el('span', { class: 'ab-opt-check off' }),
          el('span', { class: 'ab-opt-name', title: key }, titleFor(key)),
        ));
      }
      if (hiddenCount > 0 || (showAll && stillAvailable.length > GHOST_LIMIT)) {
        grid.appendChild(el('button', {
          class: 'ab-opt-card ghost more', type: 'button',
          onclick: () => { step.__optionalShowAll = !showAll; notify(); },
        }, showAll ? 'Show less' : `Show all (${stillAvailable.length})`));
      }
      section.appendChild(grid);
      const openKey = enabledOptionalKeys.find(k => step.__optionalOpen === k);
      if (openKey) {
        const openProp = props[openKey] || {};
        mountOptionalKeyModal({
          title: titleFor(openKey),
          badges: ['optional', openProp.type ? String(openProp.type) : null].filter(Boolean),
          description: typeof openProp.description === 'string' ? openProp.description : '',
          body: renderSchemaKeyEditor(step, stepIdx, openKey, false, { headless: true }),
        });
      }
    }

    container.appendChild(section);
  }

  // Placeholder validation summary
  const refs = placeholdersInSchema(step.schema);
  if (refs.length) {
    const fieldIds = new Set(state.agent.fields.map(f => f.id));
    const allOutputs = new Set(state.agent.steps.map(s => s.output_id).filter(Boolean));
    const bad = refs.filter(r => !fieldIds.has(r) && !allOutputs.has(r));
    if (bad.length) {
      container.appendChild(el('div', { class: 'ab-error mt-3' }, 'Unresolved: ' + bad.map(b => `\${${b}}`).join(', ')));
    }
  }

  return container;
}

// ---------------------------------------------------------------------------
// Output fields editor (content-research) — visual, not raw JSON
// ---------------------------------------------------------------------------

// Scalar types only — research output schema is flat so downstream
// `${output_id.field}` dot-paths always resolve (nested object/array fields
// the model often emits as a string, breaking the deep path).
const CR_OUTPUT_TYPES = [
  { value: 'string', label: 'Text' },
  { value: 'number', label: 'Number' },
  { value: 'boolean', label: 'Yes/No' },
];

/** Read step.outputSchema → a flat field list the editor renders. */
function outputSchemaToFields(schema) {
  if (!schema || typeof schema !== 'object' || !schema.properties) return [];
  const required = Array.isArray(schema.required) ? schema.required : [];
  return Object.entries(schema.properties).map(([name, def]) => {
    const d = def && typeof def === 'object' ? def : {};
    const type = d.type || 'string';
    return {
      name,
      type: CR_OUTPUT_TYPES.some(t => t.value === type) ? type : 'string',
      description: typeof d.description === 'string' ? d.description : '',
      required: required.includes(name),
    };
  });
}

/** Write a field list back into step.outputSchema as a JSON Schema. */
function fieldsToOutputSchema(fields) {
  const named = fields.filter(f => f.name && f.name.trim());
  if (named.length === 0) return {}; // no fields → free-form text output
  const properties = {};
  const required = [];
  for (const f of named) {
    const key = f.name.trim();
    const prop = { type: f.type };
    if (f.description && f.description.trim()) prop.description = f.description.trim();
    properties[key] = prop;
    if (f.required) required.push(key);
  }
  const schema = { type: 'object', properties };
  if (required.length) schema.required = required;
  return schema;
}

/**
 * Visual editor for a content-research step's structured output. The author
 * adds named fields with a type instead of writing JSON; we compile to a JSON
 * Schema in step.outputSchema. No fields = text output.
 */
function renderOutputFieldsEditor(step, idx) {
  const wrap = el('div', { class: 'field mt-3' });
  wrap.appendChild(el('label', {}, 'Output fields (optional)'));
  wrap.appendChild(el('div', { class: 'text-xs text-muted-foreground mb-2' },
    'Leave empty for a plain text answer. Add fields to get structured output you can reference downstream as ',
    el('code', {}, '${' + (step.output_id || 'output') + '.fieldName}'), '.'));

  // Working list is a draft on the step, not re-derived from outputSchema each
  // render — so a freshly added, still-unnamed field persists (the schema drops
  // nameless fields). Seeded once from the saved schema.
  if (!Array.isArray(step.__outputFields)) {
    step.__outputFields = outputSchemaToFields(step.outputSchema);
  }
  const fields = step.__outputFields;

  const commit = (next) => {
    step.__outputFields = next;
    step.outputSchema = fieldsToOutputSchema(next);
    invalidatePreviewFrom(idx);
    notify();
  };

  const listBox = el('div', { class: 'ab-cr-fields' });
  fields.forEach((f, fi) => {
    const rowEl = el('div', { class: 'ab-cr-field-row' });
    // Name
    rowEl.appendChild(el('input', {
      value: f.name,
      placeholder: 'field name',
      oninput: (e) => { fields[fi].name = e.target.value; commit(fields); },
    }));
    // Type
    const typeSel = el('select', {
      onchange: (e) => { fields[fi].type = e.target.value; commit(fields); },
    });
    for (const t of CR_OUTPUT_TYPES) {
      const opt = el('option', { value: t.value }, t.label);
      if (t.value === f.type) opt.selected = true;
      typeSel.appendChild(opt);
    }
    rowEl.appendChild(typeSel);
    // Description
    rowEl.appendChild(el('input', {
      value: f.description,
      placeholder: 'description (optional)',
      oninput: (e) => { fields[fi].description = e.target.value; commit(fields); },
    }));
    // Required toggle
    const reqWrap = el('label', { class: 'ab-cr-req', title: 'Required field' });
    const reqCb = el('input', {
      type: 'checkbox',
      oninput: (e) => { fields[fi].required = e.target.checked; commit(fields); },
    });
    if (f.required) reqCb.checked = true;
    reqWrap.appendChild(reqCb);
    reqWrap.appendChild(el('span', {}, 'Required'));
    rowEl.appendChild(reqWrap);
    // Remove
    rowEl.appendChild(el('button', {
      class: 'ab-row-iconbtn ab-cr-remove', type: 'button', title: 'Remove field',
      onclick: () => { fields.splice(fi, 1); commit(fields); },
    }, '×'));
    listBox.appendChild(rowEl);
  });
  wrap.appendChild(listBox);

  wrap.appendChild(el('button', {
    class: 'btn', type: 'button',
    onclick: () => { fields.push({ name: '', type: 'string', description: '', required: false }); commit(fields); },
  }, '+ Add field'));

  return wrap;
}

// ---------------------------------------------------------------------------
// Shared step-row shell (used by BOTH model and content-research rows)
// ---------------------------------------------------------------------------
//
// The row shell — drag-to-reorder, the Run/Edit/Remove button cluster, and the
// output_id + checkpoint meta block — is identical across step kinds. These
// helpers are the single source for it so the two row renderers only differ in
// their editor body, not in their plumbing.

/** Drop-target attrs for a step row. Not draggable itself — only the handle is
 * (stepDragHandleHandlers), so row text stays selectable. */
function stepRowDragHandlers(idx, getRow) {
  return {
    'data-step-idx': String(idx),
    ondragover: (e) => { e.preventDefault(); e.dataTransfer.dropEffect = 'move'; getRow().classList.add('drag-over'); },
    ondragleave: () => getRow().classList.remove('drag-over'),
    ondrop: (e) => {
      e.preventDefault();
      getRow().classList.remove('drag-over');
      const fromIdx = Number(e.dataTransfer.getData('text/plain'));
      if (!Number.isInteger(fromIdx) || fromIdx === idx) return;
      const ss = state.agent.steps;
      const [moved] = ss.splice(fromIdx, 1);
      ss.splice(idx, 0, moved);
      // Reorder shuffles which output_id is at which index and which step is
      // "final" — clear the whole preview cache to keep cache→index honest;
      // the renderer rewrites step:false on the new last step automatically.
      invalidatePreviewFrom(0);
      notify();
    },
  };
}

/** Drag-source attrs for the ⋮⋮ handle. Only the handle starts a drag. */
function stepDragHandleHandlers(idx, getRow) {
  // While dragging, hide the row's body (everything but the header) so an open
  // step is easy to move. Cosmetic only — restored on dragend, never touches
  // step.__expanded. Deferred a frame so the drag-image snapshot stays intact.
  const hideBody = (row) => {
    for (const child of Array.from(row.children)) {
      if (child === row.firstElementChild) continue;
      child.dataset.dragHidden = '1';
      child.style.display = 'none';
    }
  };
  const showBody = (row) => {
    for (const child of Array.from(row.children)) {
      if (child.dataset.dragHidden === '1') {
        delete child.dataset.dragHidden;
        child.style.display = '';
      }
    }
  };
  // Collapse ALL rows, not just the dragged one, so the list reads cleanly.
  const eachRow = (row, fn) => { for (const r of row.parentElement?.children || []) fn(r); };
  return {
    draggable: 'true',
    ondragstart: (e) => {
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/plain', String(idx));
      const row = getRow();
      row.classList.add('dragging');
      requestAnimationFrame(() => { if (row.classList.contains('dragging')) eachRow(row, hideBody); });
    },
    ondragend: () => {
      const row = getRow();
      row.classList.remove('dragging');
      eachRow(row, showBody);
    },
  };
}

/** The Run button — cached run state, credits chip, pipeline-busy guard. */
/** Inline SVG wrapped in a span so el() can nest it as a child node. */
export function iconSpan(svgMarkup) {
  const s = document.createElement('span');
  s.style.display = 'inline-flex';
  s.innerHTML = svgMarkup;
  return s;
}

export const GEAR_SVG = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h.01a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51h.01a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82v.01a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>';
export const CHEVRON_SVG = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="6 9 12 15 18 9"></polyline></svg>';
const COMMAND_SQUARE_SVG = '<svg width="18" height="18" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M9.59945 6.3999H6.39941V9.59989H9.59945V6.3999Z" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"/><path d="M5.19999 12.0001C5.85999 12.0001 6.39998 11.4601 6.39998 10.8001V9.6001H5.19999C4.53999 9.6001 4 10.1401 4 10.8001C4 11.4601 4.53999 12.0001 5.19999 12.0001Z" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"/><path d="M5.19999 6.4H6.39998V5.19999C6.39998 4.53999 5.85999 4 5.19999 4C4.53999 4 4 4.53999 4 5.19999C4 5.85999 4.53999 6.4 5.19999 6.4Z" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"/><path d="M9.60059 6.4H10.8006C11.4606 6.4 12.0006 5.85999 12.0006 5.19999C12.0006 4.53999 11.4606 4 10.8006 4C10.1406 4 9.60059 4.53999 9.60059 5.19999V6.4Z" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"/><path d="M10.8006 12.0001C11.4606 12.0001 12.0006 11.4601 12.0006 10.8001C12.0006 10.1401 11.4606 9.6001 10.8006 9.6001H9.60059V10.8001C9.60059 11.4601 10.1406 12.0001 10.8006 12.0001Z" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"/><path d="M5.99967 14.6668H9.99967C13.333 14.6668 14.6663 13.3335 14.6663 10.0002V6.00016C14.6663 2.66683 13.333 1.3335 9.99967 1.3335H5.99967C2.66634 1.3335 1.33301 2.66683 1.33301 6.00016V10.0002C1.33301 13.3335 2.66634 14.6668 5.99967 14.6668Z" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"/></svg>';
export const TRASH_SVG = '<svg width="18" height="18" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M14 3.98714C11.78 3.76714 9.54667 3.65381 7.32 3.65381C6 3.65381 4.68 3.72048 3.36 3.85381L2 3.98714" stroke="#E94242" stroke-linecap="round" stroke-linejoin="round"/><path d="M5.66699 3.3135L5.81366 2.44016C5.92033 1.80683 6.00033 1.3335 7.12699 1.3335H8.87366C10.0003 1.3335 10.087 1.8335 10.187 2.44683L10.3337 3.3135" stroke="#E94242" stroke-linecap="round" stroke-linejoin="round"/><path d="M12.5669 6.09326L12.1336 12.8066C12.0603 13.8533 12.0003 14.6666 10.1403 14.6666H5.86026C4.00026 14.6666 3.94026 13.8533 3.86693 12.8066L3.43359 6.09326" stroke="#E94242" stroke-linecap="round" stroke-linejoin="round"/><path d="M6.88672 11H9.10672" stroke="#E94242" stroke-linecap="round" stroke-linejoin="round"/><path d="M6.33301 8.3335H9.66634" stroke="#E94242" stroke-linecap="round" stroke-linejoin="round"/></svg>';
/** The bolt-and-amount chip on a Run button; null when there is no amount. */
function runCreditsChip(label) {
  return label ? el('span', { class: 'ab-menu-credits' }, iconSpan(BOLT_SVG), label) : null;
}

const BOLT_SVG = '<svg style="width:0.9em;height:0.9em;" fill="currentColor" viewBox="0 0 14 14" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M4.48963 7.68204H5.79855V11.5184C5.79855 12.0831 6.3577 12.3496 6.65422 11.9233L9.86088 7.34104C10.1405 6.94142 9.91595 6.31802 9.49235 6.31802H8.18342V2.48171C8.18342 1.91692 7.62426 1.65051 7.32774 2.07676L4.1211 6.65903C3.84576 7.05864 4.07026 7.68204 4.48963 7.68204Z"/></svg>';

// Row menus anchor to a right-edge icon button, hence the right alignment.
export function placeFixedPopover(pop, anchor) {
  placeFixedPopoverShared(pop, anchor, { align: 'right', gap: 6 });
}

function stepRowControls(step, idx, expanded) {
  const cached = state.previewOutputs?.[idx];
  const isRunning = !!cached?.running;
  const pipelineBusy = isRunInFlight();
  const runDisabled = isRunning || pipelineBusy;
  const creditsLabel = stepKindOf(step) === 'agent-group'
    ? agentGroupCreditsLabel()
    : String(estimateStepCredits(step) || '');

  const menu = el('div', { class: 'ab-row-menu', hidden: true },
    el('button', {
      type: 'button', class: 'danger', title: 'Remove this step',
      onclick: () => {
        state.agent.steps.splice(idx, 1);
        // Indexes shift after a splice — clearing everything is simpler and
        // safer than re-indexing. Author re-runs steps from scratch.
        invalidatePreviewFrom(0);
        pruneOrphanAutoAddedFields();
        notify();
      },
    }, iconSpan(TRASH_SVG), 'Delete Step'),
  );

  const gear = el('button', {
    class: 'ab-row-iconbtn', type: 'button', title: 'Step actions',
    onclick: (e) => {
      e.stopPropagation();
      const wasHidden = menu.hidden;
      document.querySelectorAll('.ab-row-menu').forEach(m => { m.hidden = true; });
      if (wasHidden) placeFixedPopover(menu, gear);
      else menu.hidden = true;
    },
  }, iconSpan(GEAR_SVG));

  const chevron = el('button', {
    class: 'ab-row-iconbtn ab-row-chevron' + (expanded ? ' open' : ''),
    type: 'button', title: expanded ? 'Collapse' : 'Expand',
    onclick: () => { step.__expanded = !expanded; notify(); },
  }, iconSpan(CHEVRON_SVG));

  const hasResult = cached && !cached.running && !cached.error;
  const run = el('button', {
    class: 'ab-row-run', type: 'button',
    disabled: runDisabled ? 'disabled' : null,
    title: pipelineBusy && !isRunning
      ? 'Another step is running - wait for it to finish before starting this one.'
      : 'Run this step against live models. Upstream cached outputs are reused; missing ones run first.',
    onclick: (e) => { e.stopPropagation(); if (!runDisabled) requestRunStep(idx); },
  },
    el('span', {}, isRunning ? 'Running…' : (hasResult ? 'Re-run' : 'Run')),
    runCreditsChip(creditsLabel),
  );

  return el('div', { class: 'ab-step-controls flex gap-1 shrink-0', style: 'position: relative;' },
    run, gear, chevron, menu,
  );
}

/**
 * output_id input + checkpoint toggle. Identical contract for model and
 * content-research steps; the checkpoint toggle is suppressed on the final
 * step (final is silent by definition — the user just sees its output).
 * Every non-final step also gets the "include in final output" opt-in. The
 * final step is always included, so it never shows one.
 */
function stepMetaBlock(step, idx, isFinal, idPlaceholder) {
  const canInclude = !isFinal;
  return el('div', { class: isFinal ? '' : 'grid grid-cols-1 md:grid-cols-2 gap-3' },
    el('div', { class: 'field' },
      el('label', {}, 'Output ID (used as ${output_id} downstream)'),
      el('input', {
        value: step.output_id || '',
        placeholder: idPlaceholder || 'e.g. start_image',
        oninput: (e) => { step.output_id = e.target.value.trim(); notify(); },
      }),
    ),
    isFinal ? null : el('div', { class: 'field' },
      el('label', {}, 'Step mode'),
      (() => {
        const wrap = el('div', { class: 'ab-check-row' });
        const cb = el('input', { type: 'checkbox', id: `ab-step-flag-${idx}`,
          oninput: (e) => { step.step = e.target.checked; notify(); } });
        if (step.step === true) cb.checked = true;
        wrap.appendChild(cb);
        wrap.appendChild(el('label', { for: `ab-step-flag-${idx}`, class: 'text-sm' },
          'Show user this step (checkpoint)'));
        return wrap;
      })(),
    ),
    !canInclude ? null : el('div', { class: 'field md:col-span-2' },
      el('label', {}, 'Final output'),
      (() => {
        const wrap = el('div', { class: 'ab-check-row' });
        const cb = el('input', { type: 'checkbox', id: `ab-step-include-${idx}`,
          oninput: (e) => {
            // Routing-only flag: the step's own output is unchanged, so cached
            // Run results and a passing preview stay valid.
            if (e.target.checked) step.include_in_output = true;
            else delete step.include_in_output;
            notify();
          } });
        if (step.include_in_output === true) cb.checked = true;
        wrap.appendChild(cb);
        wrap.appendChild(el('label', { for: `ab-step-include-${idx}`, class: 'text-sm' },
          'Include this step’s output in the final result'));
        return wrap;
      })(),
      el('p', { class: 'text-xs text-muted-foreground mt-1' },
        'The last step is always shown. Tick this to also show this one - image, video, audio or text - and the user browses them in a slider.'),
    ),
  );
}

function stepTypeLabel(step, model) {
  const kind = stepKindOf(step);
  if (kind !== 'model') return stepKindSpec(kind)?.label || kind;
  if (!model) return '';
  const t = modelOutputType(model);
  return t ? t.charAt(0).toUpperCase() + t.slice(1) : '';
}

/** Row for any kind that ships only editorFields - no client code at all. */
function renderDeclarativeRow(step, idx, isFinal, spec) {
  const row = el('div', { class: 'ab-step-row', ...stepRowDragHandlers(idx, () => row) });
  const expanded = !!step.__expanded;

  row.appendChild(el('div', { class: 'ab-step-head flex items-center justify-between gap-2' },
    el('div', { class: 'ab-step-head-info flex items-center gap-2 min-w-0' },
      el('span', { class: 'ab-drag-handle', title: 'Drag to reorder', ...stepDragHandleHandlers(idx, () => row) }, '⋮⋮'),
      el('span', { class: 'ab-step-num' }, String(idx + 1)),
      el('span', { class: 'ab-step-num-name' },
        (spec.nameField && readStepField(step, spec.nameField))
          || (spec.picksFirst && readStepField(step, spec.picksFirst))
          || pickedManyName(step)
          || spec.label || spec.kind),
      el('span', { class: 'ab-step-type' }, stepTypeLabel(step, null)),
      step.step === true
        ? el('span', {
            class: 'ab-badge',
            style: 'background: hsl(var(--ait-m-primary) / 0.14); color: hsl(var(--ait-m-primary)); border-color: hsl(var(--ait-m-primary) / 0.35);',
            title: 'Checkpoint - runner pauses and shows this step output.',
          }, 'checkpoint')
        : null,
    ),
    stepRowControls(step, idx, expanded),
  ));

  const outputPanel = renderStepOutputPanel(idx);
  if (outputPanel) row.appendChild(outputPanel);

  if (expanded) {
    const body = el('div', { class: 'mt-3 pt-3', style: 'border-top:1px dashed hsl(var(--ait-m-border));' });
    if (spec.description) {
      body.appendChild(el('p', { class: 'text-xs text-muted-foreground mb-3' }, spec.description));
    }
    const rewire = (target) => openAgentPicker({
      onPick: async (entry) => {
        target.onPick(entry);
        const added = await loadAndApplyPickedSchema(step, spec);
        pruneOrphanAutoAddedFields();
        invalidatePreviewFrom(idx);
        notify();
        announceAddedFields(added);
      },
    });
    // Input fields as well as prior outputs — a vision row often points at an
    // uploaded image, not at an earlier step.
    const upstreamTokens = [
      ...state.agent.fields.map(f => f.id).filter(Boolean),
      ...state.agent.steps.slice(0, idx).map(s => s.output_id).filter(Boolean),
    ];
    const openModelPickerForStep = async ({ onPick } = {}) => {
      modelPickerMode = { kind: 'add-model', stepIndex: idx, onPick };
      // Resolve first, or the picker opens unlocked and takes a wrong kind.
      const rows = Array.isArray(step.models) ? step.models.filter(r => r && r.id) : [];
      const first = rows[0];
      if (first && !first.__mediaKind && !(state.config?.models || []).some(m => m && m.id === first.id)) {
        try { await fetchModelSchema(first.id); } catch { /* opens unlocked */ }
      }
      openModelPicker(selectorMediaKind(step));
    };
    const declared = renderDeclarativeEditor(
      step, spec, () => { invalidatePreviewFrom(idx); notify(); }, rewire,
      {
        upstreamTokens,
        isFinal,
        // An agent group reads its modes off the selector field it is bound to.
        docFields: state.agent.fields,
        // A mindmap needs its hidden helper fields before it can publish.
        optionEffects: { 'outputFormat:mindmap': ensureMindMapHelperFields },
        openModelPicker: openModelPickerForStep,
        // Lets an option's prompt override reuse the step's SOUL card.
        renderSoul: (soulOpts) => renderSoulEditor(step, idx, soulOpts),
        // Editor-only: refill it or the mapping degrades to free text.
        loadModelKeys: async (row) => {
          if (!row?.id) return false;
          // `enums` is stored, so a draft written before it existed has keys but
          // no choice lists; either gap is worth the fetch.
          const hasKeys = Array.isArray(row.__modelKeys);
          const hasEnums = !!row.enums && Object.keys(row.enums).length > 0;
          if (hasKeys && hasEnums) return false;
          try {
            const schema = await fetchModelSchema(row.id);
            const props = schema?.properties || {};
            const usable = Object.keys(props).filter(k => !RESERVED_SCHEMA_KEYS.has(k));
            row.__modelKeys = usable.filter(k => referenceModeClassOf(props[k]) !== 'reference');
            row.__supportsReference = schema?.supportsReference === true;
            row.__referenceKeys = row.__supportsReference
              ? usable.filter(k => referenceModeClassOf(props[k]) !== 'standard')
              : [];
            if (!row.enums || !Object.keys(row.enums).length) {
              row.enums = collectModelEnums(props, usable);
            }
            if (!row.requiredKeys || !row.requiredKeys.length) {
              row.requiredKeys = Array.isArray(schema?.required)
                ? schema.required.filter(k => typeof k === 'string' && !RESERVED_SCHEMA_KEYS.has(k))
                : [];
            }
            return true;
          } catch {
            return false;
          }
        },
        // A new default means new step inputs, as on a model swap.
        onSelectorDefaultChange: async () => {
          const added = await loadAndApplySchema(step);
          pruneOrphanAutoAddedFields();
          invalidatePreviewFrom(idx);
          notify();
          announceAddedFields(added);
        },
      },
    );
    const meta = stepMetaBlock(step, idx, isFinal, 'e.g. ' + (spec.kind || 'output'));
    meta.classList.add('mb-3');

    // renderSchemaEditor draws its own SOUL card; never draw a second.
    const ownsSoul = (spec.ownFields || []).includes('soul')
      || (spec.placeholderFields || []).includes('soul');
    const soulNode = (ownsSoul && !spec.schemaTarget) ? renderSoulEditor(step, idx) : null;
    const schemaNode = spec.schemaTarget ? renderSchemaEditor(step, idx) : null;

    // A selector reads top-down: prompt and inputs, then the models. An agent
    // step keeps its picker on top; its inputs exist only once one is chosen.
    const soulFirst = spec.kind === 'model-selector';
    if (soulFirst && declared) {
      if (soulNode) body.appendChild(soulNode);
      if (schemaNode) body.appendChild(schemaNode);
      body.appendChild(meta);
      body.appendChild(declared);
    } else {
      if (declared) body.appendChild(declared);
      body.appendChild(meta);
      if (soulNode) body.appendChild(soulNode);
      if (schemaNode) body.appendChild(schemaNode);
    }
    row.appendChild(body);
  }
  return row;
}

// The map UI's research-deeper / translate runs send these keys; publish rejects a mindmap agent without them.
function ensureMindMapHelperFields() {
  const added = [];
  for (const id of MINDMAP_HELPER_FIELDS) {
    if (state.agent.fields.some(f => f.id === id)) continue;
    state.agent.fields.push({ __custom: true, __autoAdded: true, id, title: id, description: 'Filled in by the mind map viewer.', type: 'string', ui_component: 'textarea', default: '', visible: false, advanced: false, step: false, required: false });
    added.push(id);
  }
  if (added.length) toast(`Added hidden mind map fields: ${added.join(', ')}`);
}

function renderStepRow(step, idx) {
  const isFinal = idx === state.agent.steps.length - 1;
  if (isFinal) step.step = false;

  const kind = stepKindOf(step);
  if (kind !== 'model') {
    const spec = stepKindSpec(kind);
    if (spec) return renderDeclarativeRow(step, idx, isFinal, spec);
  }

  const model = state.config.models.find(m => m.id === step.model_id);

  const row = el('div', {
    class: 'ab-step-row',
    ...stepRowDragHandlers(idx, () => row),
  });

  const expanded = !!step.__expanded;

  // Collapsed-state summary line on the head — model + output_id + checkpoint
  // badge — so the author can scan the pipeline without opening every row.
  const head = el('div', { class: 'ab-step-head flex items-center justify-between gap-2' },
    el('div', { class: 'ab-step-head-info flex items-center gap-2 min-w-0' },
      el('span', {
        class: 'ab-drag-handle',
        title: 'Drag to reorder this step',
        ...stepDragHandleHandlers(idx, () => row),
      }, '⋮⋮'),
      el('span', { class: 'ab-step-num' }, String(idx + 1)),
      el('span', { class: 'ab-step-num-name' }, model ? model.displayName : '(no model selected)'),
      el('span', { class: 'ab-step-type' }, stepTypeLabel(step, model)),
      step.step === true
        ? el('span', {
            class: 'ab-badge',
            style: 'background: hsl(var(--ait-m-primary) / 0.14); color: hsl(var(--ait-m-primary)); border-color: hsl(var(--ait-m-primary) / 0.35);',
            title: 'Checkpoint - runner pauses and shows the user this step\'s output.',
          }, 'checkpoint')
        : null,
    ),
    stepRowControls(step, idx, expanded),
  );
  row.appendChild(head);

  // Output panel — shows cached run state (running / error / success). Sits
  // below the head so it's visible whether the editor body is expanded or not.
  const outputPanel = renderStepOutputPanel(idx);
  if (outputPanel) row.appendChild(outputPanel);

  if (expanded) {
    const body = el('div', { class: 'mt-3 pt-3', style: 'border-top: 1px dashed hsl(var(--ait-m-border));' });

    // Model display + change button.
    const modelBox = el('div', { class: 'flex items-center gap-2 mb-3 flex-wrap' },
      el('button', {
        class: 'btn', type: 'button',
        onclick: async () => {
          const ok = await confirmModal({
            title: 'Change model?',
            message: 'Changing the model will refresh this step\'s schema. Values you\'ve already set for keys the new model also accepts will be preserved; the rest will be reset.',
            confirmLabel: 'Continue',
          });
          if (!ok) return;
          modelPickerMode = { kind: 'change', stepIndex: idx };
          openModelPicker();
        },
      }, model ? '⟳ Change model' : '+ Pick model'),
      el('span', { class: 'text-sm font-mono' }, model ? model.displayName : '(no model selected)'),
      model ? el('span', { class: 'ab-badge' }, model.id) : null,
    );
    body.appendChild(modelBox);

    // output_id + step toggle. Output ID is always editable. The Step-mode
    // (checkpoint) toggle is suppressed on the final step (final is silent
    // by definition; the user just sees its output).
    body.appendChild(stepMetaBlock(step, idx, isFinal, 'e.g. start_image'));

    body.appendChild(renderSchemaEditor(step, idx));
    row.appendChild(body);
  }

  return row;
}

function mountOptionalKeyModal({ title, badges = [], description = '', body }) {
  const back = $('#ab-modal-optkey');
  if (!back) return;
  const titleEl = $('#ab-optkey-title');
  const badgeEl = $('#ab-optkey-badges');
  const descEl = $('#ab-optkey-desc');
  const bodyEl = $('#ab-optkey-body');
  if (titleEl) titleEl.textContent = title;
  if (badgeEl) {
    badgeEl.innerHTML = '';
    for (const b of badges) badgeEl.appendChild(el('span', { class: 'ab-badge' }, b));
  }
  if (descEl) {
    descEl.textContent = description || '';
    descEl.hidden = !description;
  }
  if (bodyEl) { bodyEl.innerHTML = ''; bodyEl.appendChild(body); }
  back.classList.add('visible');
  back.setAttribute('aria-hidden', 'false');
}

function hideOptionalKeyModal() {
  const back = $('#ab-modal-optkey');
  if (!back) return;
  back.classList.remove('visible');
  back.setAttribute('aria-hidden', 'true');
  const bodyEl = $('#ab-optkey-body');
  if (bodyEl) bodyEl.innerHTML = '';
}

function closeOptionalKeyModal() {
  let changed = false;
  for (const s of state.agent.steps || []) {
    if (s.__optionalOpen) { delete s.__optionalOpen; changed = true; }
  }
  hideOptionalKeyModal();
  if (changed) notify();
}

export function renderStepsPass() {
  const list = $('#ab-steps-list');
  const empty = $('#ab-steps-empty');
  if (!list) return;

  // Preview opens straight from this pass, so refresh the row here too.
  syncSelectorPickerFields();
  // Persisted out of band: render() must not call notify() (it would recurse),
  // but a step born here has to reach storage or preview never sees it.
  if (syncAgentGroupSteps()) queueMicrotask(notify);

  // Focus-aware skip. Every keystroke inside a schema textarea/text-input
  // fires `oninput` → `notify()` → `render()` → this function. If we blow
  // the whole list away (`innerHTML = ''`) and rebuild it, the editable
  // element the author is typing into is replaced by a brand-new DOM node,
  // focus leaves, and every modifier-keypress (AltGr in particular) lands
  // on the body instead of the field.
  //
  // Only continuous-typing inputs qualify for the skip:
  //   - `<textarea>` (always)
  //   - `<input type=text|number|search|email|url|tel|password>` and the
  //     no-type default (which is also text)
  //
  // Radio, checkbox, button, and `<select>` are explicitly excluded. Each
  // of those triggers a one-shot state change where the *next* state is
  // supposed to introduce or remove rows in the editor (Control type:
  // Dropdown reveals the Options input; Source: Custom opens the config
  // panel). Skipping rebuild on those would freeze the UI mid-flow.
  const active = document.activeElement;
  const TEXTLIKE_INPUT_TYPES = new Set(['text', 'number', 'search', 'email', 'url', 'tel', 'password', '']);
  const isTypingFocus = active && (
    active.tagName === 'TEXTAREA' ||
    (active.tagName === 'INPUT' && TEXTLIKE_INPUT_TYPES.has(active.type))
  );
  const optModal = $('#ab-modal-optkey');
  if (isTypingFocus && (list.contains(active) || optModal?.contains(active))) {
    if (!state.agent.steps.some(s => s.__optionalOpen)) hideOptionalKeyModal();
    syncStepsToolbar();
    return;
  }
  hideOptionalKeyModal();

  list.innerHTML = '';
  if (state.agent.steps.length === 0) {
    empty.hidden = false;
    syncStepsToolbar();
    return;
  }
  empty.hidden = true;
  state.agent.steps.forEach((s, i) => list.appendChild(renderStepRow(s, i)));
  syncStepsToolbar();

  // After a restore from localStorage, steps will have a model_id but no
  // __schemaMeta in memory. Fetch them in the background so the editor renders
  // properly without forcing the author to re-pick. Older snapshots may also
  // be missing the `soul` field — default it to an empty string so the editor
  // never falls back to undefined.
  //
  // Migration: an earlier version of the auto-wire path could write
  // `${prompt}` into schema.prompt and create a stray `prompt` form field.
  // Soul now owns prompt entirely; collapse any such residue on load.
  for (const s of state.agent.steps) {
    if (typeof s.soul !== 'string') s.soul = '';
    if (s.schema && typeof s.schema === 'object' && s.schema.prompt && s.schema.prompt !== '') {
      // Hoist any old prompt template up to soul if soul is still empty.
      if (!s.soul) s.soul = String(s.schema.prompt);
      s.schema.prompt = '';
    }
    // Re-merge the model schema on boot. A step restored from localStorage
    // carries a STALE `__schemaMeta`/`__optionalAvailable` snapshot (persist
    // keeps `__`-prefixed flags so a mid-edit refresh doesn't lose picker
    // state). That snapshot can lag the live schema — e.g. a key that's since
    // been deduped away (gpt-image-2: `image_urls` collapsed into `images`)
    // would still render as an "Enable optional" chip. Re-fetching and
    // re-applying refreshes the derived meta (added keys appear, removed keys
    // drop) while applySchemaToStep preserves the author's real choices
    // (everything they wired lives in `step.schema`, not the meta). Done once
    // per page load, tracked in a module-level set that resets on refresh.
    // A model-selector step has no model_id of its own; its schema comes from
    // the default option, so a doc Studio just wrote loads without a Retry.
    const boots = s.model_id || defaultSelectorModelId(s);
    if (boots && !s.__schemaLoading && !_rehydratedSchemaSteps.has(s)) {
      _rehydratedSchemaSteps.add(s);
      loadAndApplySchema(s);
    }
  }
  // Drop any stray `prompt` field the earlier auto-wire left behind. Nothing
  // should reference it now — schema.prompt is always `""` and soul owns the
  // prompt-shaped text.
  state.agent.fields = state.agent.fields.filter(f => f.id !== 'prompt');
}

// Update the Steps-section toolbar (Add step + Run all). Called every render.
function syncStepsToolbar() {
  const steps = state.agent.steps;
  // Server-owned cap. Until /config lands it's unknown — don't fall back to a
  // literal, which would lock the button below the real limit.
  const maxSteps = Number(state.config?.maxSteps);
  const hasCap = Number.isFinite(maxSteps) && maxSteps > 0;
  const capNote = $('#ab-steps-cap');
  if (capNote) capNote.textContent = hasCap ? ` (up to ${maxSteps})` : '';
  const addBtn = $('#ab-add-step');
  if (addBtn) {
    addBtn.disabled = hasCap && steps.length >= maxSteps;
    addBtn.textContent = '+ Add Step';
  }
  // Shown only once the run-prep modal has collected values — nothing to reset
  // before that. Handled ahead of the early returns below so it always syncs.
  const resetBtn = $('#ab-reset-fields');
  if (resetBtn) {
    const filled = Object.keys(state.testInputs || {}).filter(fieldHasValue).length;
    resetBtn.hidden = filled === 0;
    resetBtn.disabled = _runInFlight;
    resetBtn.textContent = `Reset fields (${filled})`;
  }

  const runAllBtn = $('#ab-run-all');
  if (!runAllBtn) return;
  runAllBtn.hidden = steps.length === 0;
  if (steps.length === 0) return;
  // Single credits source: floorCredits() — same number Pass 5 displays as
  // "Floor (credits)" and the same number the server clamps publish against.
  // Per-step Run chips can still floor-at-1-credit individually (their
  // policy: "every Play costs at least 1 credit"), but the TOTAL must
  // match the floor — otherwise authors see three different numbers
  // (Run all chip / Pass 5 floor / published agent costEstimate) for the
  // same agent.
  const total = floorCredits();
  const totalLabel = agentGroupCreditsLabel() ?? (total > 0 ? String(total) : '');
  // Only an incomplete MODEL step blocks Run; other kinds validate themselves.
  runAllBtn.disabled = _runInFlight || steps.some(s => stepKindOf(s) === 'model' && !s?.model_id);
  runAllBtn.innerHTML = '';
  runAllBtn.append(el('span', {}, 'Run all'), runCreditsChip(totalLabel) || '');
}

export function wireStepsPass() {
  document.addEventListener('click', (e) => {
    if (!e.target.closest?.('.ab-step-controls')) {
      document.querySelectorAll('.ab-row-menu').forEach(m => { m.hidden = true; });
    }
  });

  const optBack = $('#ab-modal-optkey');
  if (optBack) {
    optBack.querySelectorAll('[data-optkey-close]').forEach(b => {
      b.addEventListener('click', () => closeOptionalKeyModal());
    });
    optBack.addEventListener('click', (e) => {
      if (e.target === optBack) closeOptionalKeyModal();
    });
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && optBack.classList.contains('visible')) closeOptionalKeyModal();
    });
  }

  // Run all = wipe every cached step output, then kick the last step.
  // runStepBuilder walks 0..target; with the cache empty every step
  // actually runs (vs. the default "reuse fresh cache" path that single-
  // step Play uses). On success recordStepEstimate persists the learned
  // durations because the last step ran.
  $('#ab-run-all')?.addEventListener('click', () => {
    const last = state.agent.steps.length - 1;
    if (last < 0) return;
    invalidatePreviewFrom(0);
    void requestRunStep(last);
  });

  // Clear the values the run-prep modal collected, so the next Run asks for
  // them again. Cached step outputs are left alone — they belong to the run,
  // not the form.
  $('#ab-reset-fields')?.addEventListener('click', () => {
    if (_runInFlight) return;
    state.testInputs = {};
    toast('Fields reset.', 'success', 2000);
    notify();
  });

  $('#ab-add-step')?.addEventListener('click', () => {
    // The cap is server-owned (env: AGENT_BUILDER_MAX_STEPS), fetched into
    // state.config.maxSteps on boot. We refuse to fall back to a literal —
    // if config hasn't loaded yet, the click waits rather than silently
    // applying a stale default.
    const maxSteps = Number(state.config?.maxSteps);
    if (!Number.isFinite(maxSteps) || maxSteps <= 0) {
      toast('Builder config still loading - try again in a moment.', 'error');
      return;
    }
    if (state.agent.steps.length >= maxSteps) {
      toast(`Maximum ${maxSteps} steps.`, 'error');
      return;
    }
    // A model-picking kind defers to the model picker, so no orphan step.
    openStepKindPicker();
  });
  // Model picker search is wired (debounced, live-fetch) inside wireModelTabs(),
  // called from openModelPicker(). No separate listener here.

  // Run-prep modal submit. Cancel and X buttons are wired by the shared
  // `[data-close-modal]` handler in wireFieldsPass.
  $('#ab-run-prep-submit')?.addEventListener('click', () => { submitRunPrep(); });

  // Resume any step whose persisted cache says it was `running` when the
  // page was closed/refreshed. The DB is authoritative — we look the jobId
  // up via /api/jobs/:id and either re-attach a poller or hydrate the
  // completed/failed result without spending credits again.
  resumeStepPollingOnBoot();
}

/**
 * On page boot, walk `state.previewOutputs` for any entry the persistent
 * cache restored with `running: true && jobId set`. For each one, fire-and-
 * forget a poll that mirrors the in-line runStepBuilder behavior. Multiple
 * runners can run in parallel here (the global `_runInFlight` guard only
 * applies to *new* clicks; resuming an existing job doesn't reserve new
 * credits and shouldn't block other rows).
 */
async function resumeStepPollingOnBoot() {
  const entries = Object.entries(state.previewOutputs || {});
  const tasks = [];
  for (const [key, entry] of entries) {
    if (!entry || !entry.running || !entry.jobId) continue;
    const stepIndex = Number(key);
    if (!Number.isInteger(stepIndex) || stepIndex < 0) continue;

    // Re-anchor startedAt to client wall-clock using the server's elapsedMs.
    // The persisted startedAt was set in a previous session and the user's
    // clock may have changed (sleep/resume, daylight saving) or — more
    // commonly — the server returns elapsedMs against its own clock. We
    // probe /preview-step-job once, then convert the server's "elapsed
    // since I started the job" into "Date.now() minus that, expressed in
    // this tab's clock". Falls back to the persisted value if the probe
    // fails or the job already settled.
    try {
      const probeRes = await fetchHelper(`https://aitopia.ai/api/agent-builder/preview-step-job/${encodeURIComponent(entry.jobId)}`, {
        method: 'GET',
        headers: { Accept: 'application/json' },
      });
      if (probeRes.ok) {
        const probeJson = await probeRes.json().catch(() => null);
        if (probeJson?.ok && probeJson.status === 'running') {
          const elapsedMs = Number(probeJson.elapsedMs) || 0;
          entry.startedAt = Date.now() - Math.max(0, elapsedMs);
          if (Number(probeJson.estimatedDurationMs) > 0) {
            entry.estimatedDurationMs = Number(probeJson.estimatedDurationMs);
          }
        }
      }
    } catch { /* keep persisted values */ }

    tasks.push(resumeOneStepPoll(stepIndex, entry.jobId));
  }
  if (tasks.length === 0) return;
  // Kick off the ticker so the progress bar animates immediately on boot.
  startStepProgressTicker();
  notify(); // re-render with the re-anchored startedAt values
  // Let them run in parallel; each updates `state.previewOutputs[i]` and
  // calls notify() on its own.
  await Promise.allSettled(tasks);
}

async function resumeOneStepPoll(stepIndex, jobId) {
  try {
    const json = await pollPreviewStepJob(jobId, {
      onProgress: (running) => applyRunningTick(stepIndex, running),
    });
    applyStepResultToCache(stepIndex, json);
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    state.previewOutputs[stepIndex] = { running: false, error: msg, ranAt: Date.now() };
  }
  notify();
  refreshCreditsBalance();
}
