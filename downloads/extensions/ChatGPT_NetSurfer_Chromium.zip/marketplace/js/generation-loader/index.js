/**
 * <generation-loader> — the one in-progress view for a generation run.
 *
 * Surfaces render the tag with what they know (attributes below) and update the
 * attributes as the run moves; the active design draws everything inside a
 * shadow root. Which design is shown comes from GENERATION_LOADER through
 * /api/config/generation-loader: one design, or an A/B split (see chooseDesign).
 *
 *   run       creation/run id — instances with the same id share one run entry,
 *             so a re-rendered card or a stage mirror clone carries on where the
 *             previous element was
 *   status    product status text: "Uploading (12%)", "In Queue", "Running (45%)", "Failed"
 *   pct       0..100, overrides the % parsed from status
 *   estimate  estimated run duration (ms)
 *   started   run start (ms epoch or ISO) the estimate counts from
 *   created   when the creation was made; anchors elapsed time for a run picked
 *             up after a refresh
 *   model     model name
 *   prompt    the prompt, for designs that show it
 *   error     failure reason
 *   no-hint   leave out the "keep this page open / you can leave" line
 */
import { escapeHtml } from '../shared/input-rendering.js';
import { push as gtagPush } from '../shared/gtag-events.js';
import pixelLine from './pixel-line.js';
import pixelFill from './pixel-fill.js';
import windowDesign from './window.js';

const DESIGNS = { 'pixel-line': pixelLine, 'pixel-fill': pixelFill, window: windowDesign };
const DEFAULT_DESIGN = 'pixel-line';

// Only `running` may promise a notification: the upload runs in this tab and the
// queue beat covers the hand-off before the server owns the run.
const WAITING_HINTS = {
  uploading: 'Your files are still uploading - please keep this page open until the generation starts',
  queued: 'Your generation is on its way to the model - please keep this page open until it starts',
  running: 'You can leave this page and continue working on other generations. We’ll notify you when this generation is ready',
};
const LEAVE_HINT_DELAY_MS = 2000;

// Past this the start anchor is a skewed DB timestamp, not an hour-overdue run.
const ANCHOR_TRUST_MS = 60 * 60_000;
const QUEUE_RAMP_MS = 8000;
const ENTRY_TTL_MS = 5 * 60_000;

// Test overrides, strongest first (as chain-chips does): ?loader=<id>, then
// localStorage 'aitopia:generation-loader'.
const OVERRIDE_KEY = 'aitopia:generation-loader';
// The variant this browser drew in an A/B split, so it keeps seeing the same one.
const VARIANT_KEY = 'aitopia:generation-loader-variant';

function storage(use) {
  try { return use(window.localStorage); } catch { return null; } // no storage (private mode, sandboxed iframe)
}

function overrideDesign() {
  let id = null;
  try { id = new URLSearchParams(window.location.search).get('loader'); } catch { /* no location */ }
  if (!DESIGNS[id]) id = storage((s) => s.getItem(OVERRIDE_KEY));
  return DESIGNS[id] ? id : null;
}

// variants = [{ design, weight }] from GENERATION_LOADER. One design: everyone
// sees it. Several: an A/B split, drawn once per browser by weight and kept.
function chooseDesign(variants) {
  const known = variants.filter((v) => DESIGNS[v.design]);
  if (known.length < variants.length) console.warn('[generation-loader] unknown design in GENERATION_LOADER', variants);
  if (known.length < 2) return { design: known[0]?.design || DEFAULT_DESIGN, experiment: false };
  let design = storage((s) => s.getItem(VARIANT_KEY));
  if (!known.some((v) => v.design === design)) {
    let roll = Math.random() * known.reduce((sum, v) => sum + v.weight, 0);
    design = (known.find((v) => (roll -= v.weight) < 0) || known[known.length - 1]).design;
    storage((s) => s.setItem(VARIANT_KEY, design));
  }
  return { design, experiment: true };
}

let active = null;
let activePromise = null;
function resolveDesign() {
  if (!activePromise) {
    const forced = overrideDesign();
    activePromise = (forced
      ? Promise.resolve({ design: forced, experiment: false })
      : fetch('https://aitopia.ai/api/config/generation-loader', { signal: AbortSignal.timeout?.(3000) })
        .then((res) => (res.ok ? res.json() : null))
        .then((json) => chooseDesign(Array.isArray(json?.variants) ? json.variants : []))
        .catch(() => ({ design: DEFAULT_DESIGN, experiment: false })))
      .then((choice) => { active = choice; return choice; });
  }
  return activePromise;
}
// Ask while the page is idle, so a loader shown later mounts without waiting.
if (typeof window !== 'undefined') {
  if (window.requestIdleCallback) window.requestIdleCallback(resolveDesign, { timeout: 3000 });
  else setTimeout(resolveDesign, 1000);
}

export function loaderPhase(status) {
  const lower = String(status || '').toLowerCase();
  if (/fail|error|cancel/.test(lower)) return 'failed';
  if (lower.includes('upload')) return 'uploading';
  if (lower.includes('queue') || lower.includes('pending')) return 'queued';
  return 'running';
}

const runs = new Map();
function newEntry() {
  return { inputs: {}, firstSeen: Date.now(), marks: {}, shown: 0, lastPct: null, seed: (Math.random() * 1e6) | 0, users: 0, dropTimer: null };
}

function readInputs(el) {
  const num = (name) => {
    const raw = el.getAttribute(name);
    if (raw == null || raw === '') return null;
    const n = Number(raw);
    return Number.isFinite(n) ? n : null;
  };
  const status = el.getAttribute('status') || '';
  const parsed = /\((\d+(?:\.\d+)?)%\)/.exec(status);
  // 0 is "no % reported yet", not progress.
  const pct = num('pct') || (parsed ? Number(parsed[1]) : null) || null;
  const time = (name) => {
    const raw = el.getAttribute(name) || '';
    const t = /^\d+$/.test(raw) ? Number(raw) : Date.parse(raw);
    return Number.isFinite(t) ? t : null;
  };
  return {
    status,
    pct: pct == null ? null : Math.min(100, Math.max(0, pct)),
    // A % only counts for the phase that reported it (an upload % is not a run %).
    pctPhase: pct == null ? null : loaderPhase(status),
    estimate: num('estimate') > 0 ? num('estimate') : 0,
    started: time('started'),
    created: time('created'),
    model: el.getAttribute('model') || '',
    prompt: el.getAttribute('prompt') || '',
    error: el.getAttribute('error') || '',
    noHint: el.hasAttribute('no-hint') || null,
  };
}

// Elements of one run (a card and the stage loader) each know part of it, so
// what one leaves out does not blank what another said.
function mergeInputs(entry, next) {
  for (const [k, v] of Object.entries(next)) if (v != null && v !== '') entry.inputs[k] = v;
}

function label(phase, overrun) {
  if (phase === 'failed') return 'Failed';
  if (phase === 'uploading') return 'Uploading';
  if (phase === 'queued') return 'In queue';
  return overrun ? 'Taking longer than usual' : 'Generating';
}

// Everything a design draws, derived from one run entry in one place.
function deriveState(entry, now) {
  const { inputs, marks } = entry;
  const phase = loaderPhase(inputs.status);
  if (!marks[phase]) marks[phase] = now;
  if (inputs.model && !marks.model) marks.model = now;
  const estimateMs = inputs.estimate;
  const trusted = (t) => t != null && now - t >= 0 && now - t <= estimateMs + ANCHOR_TRUST_MS;
  const runFrom = trusted(inputs.started) ? inputs.started : (marks.queued || marks.running || entry.firstSeen);
  const elapsedMs = Math.max(0, now - runFrom);
  // The run's first known moment: a run resumed after a refresh is older than
  // this tab's first sight of it; a live one started before its estimate anchor.
  const shownFrom = Math.min(entry.firstSeen,
    trusted(inputs.created) ? inputs.created : Infinity,
    trusted(inputs.started) ? inputs.started : Infinity);
  const pct = inputs.pctPhase === phase ? inputs.pct : null;
  const overrun = phase === 'running' && estimateMs > 0 && elapsedMs > estimateMs;

  // Upload, queue and run share one 0→100, so the bar never goes back: the
  // upload fills 0–6 (its own % is shown as text), the queue 6–10, the run 10–99.
  let target = null;
  if (phase === 'uploading') target = (6 * Math.min(100, pct ?? 0)) / 100;
  else if (phase === 'queued') target = 6 + 4 * Math.min(1, (now - marks.queued) / QUEUE_RAMP_MS);
  else if (phase === 'running') {
    // A real % that falls well back is a new step of a multi-step run (or a
    // regenerate), not jitter: start the bar over instead of holding near 99.
    if (pct != null && entry.lastPct != null && pct < entry.lastPct - 8) entry.shown = 0;
    if (pct != null) entry.lastPct = pct;
    if (pct != null) target = 10 + pct * 0.89;
    if (estimateMs > 0) {
      const f = elapsedMs / estimateMs;
      target = Math.max(target ?? 0, f <= 1 ? 10 + 81 * f : 91 + 6 * (1 - Math.exp(1 - f)));
    }
  }
  if (target != null) entry.shown = Math.max(entry.shown, Math.min(99, target));
  const known = target != null || (phase === 'failed' && entry.shown > 0);
  const uploadPct = phase === 'uploading' ? Math.round(pct ?? 0) : null;

  const estimate = Math.round(estimateMs / 1000);
  return {
    phase,
    label: label(phase, overrun),
    pct: known ? entry.shown : null,
    elapsed: Math.round(Math.max(0, now - shownFrom) / 1000),
    estimate,
    remaining: estimateMs > 0 ? Math.max(0, Math.ceil((estimateMs - elapsedMs) / 1000)) : null,
    overrun,
    range: estimate > 0 ? [Math.max(1, Math.round(estimate * 0.8)), Math.round(estimate * 1.2)] : null,
    // Time-axis designs: ms from the run's first known moment.
    runStart: (trusted(inputs.started) ? inputs.started : (marks.running || runFrom)) - shownFrom,
    marks: { queued: marks.queued ? marks.queued - shownFrom : null, running: marks.running ? marks.running - shownFrom : null },
    since: now - shownFrom,
    // As before the loader: the hint waits for the model name, then a beat, so
    // the two don't compete for attention.
    hint: phase !== 'failed' && !inputs.noHint && marks.model && now - marks.model >= LEAVE_HINT_DELAY_MS ? WAITING_HINTS[phase] : '',
    model: inputs.model,
    prompt: inputs.prompt,
    error: inputs.error || 'This run failed to produce a result.',
    uploadPct,
    seed: entry.seed,
    dark: document.documentElement.classList.contains('dark'),
    reducedMotion: reducedMotion.matches,
  };
}

const reducedMotion = typeof window !== 'undefined' && typeof window.matchMedia === 'function'
  ? window.matchMedia('(prefers-reduced-motion: reduce)')
  : { matches: false };

// One animation clock for the loaders still moving: off-screen ones skip their
// frame, and a settled one (a failed run once its fade has played) leaves it.
const mounted = new Set();
const live = new Set();
let raf = 0;
let lastFrame = 0;
function frame(t) {
  raf = 0;
  const dt = lastFrame ? Math.min(100, t - lastFrame) : 16;
  lastFrame = t;
  const now = Date.now();
  for (const el of live) {
    if (!el.visible) continue;
    try { el.tick(now, dt); } catch (err) { console.warn('[generation-loader]', err); }
  }
  if (live.size) raf = requestAnimationFrame(frame);
  else lastFrame = 0;
}
function wake(el) {
  live.add(el);
  if (!raf) raf = requestAnimationFrame(frame);
}
// A theme switch repaints settled loaders too.
let themeWatch = null;
function watchTheme() {
  if (themeWatch || typeof MutationObserver !== 'function') return;
  themeWatch = new MutationObserver(() => { for (const el of mounted) { el.restFor = 0; wake(el); } });
  themeWatch.observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });
}
const visibility = typeof IntersectionObserver === 'function'
  ? new IntersectionObserver((items) => { for (const it of items) it.target.visible = it.isIntersecting; })
  : null;

// Lets a non-browser import (tests, SSR) load the module without defining the tag.
const Base = typeof HTMLElement === 'undefined' ? class {} : HTMLElement;

const HOST_CSS = ':host{display:block;position:relative;flex:1 1 auto;align-self:stretch;width:100%;min-height:0;overflow:hidden;contain:content}'
  + '.gl{position:absolute;inset:0;font-family:Inter,ui-sans-serif,system-ui,sans-serif}';

// The designs' light weights and mono face; pages ship Inter 400+ only. A font
// face has to live in the document, not in a shadow root.
function loadFonts() {
  if (document.getElementById('generation-loader-fonts')) return;
  const link = document.createElement('link');
  link.id = 'generation-loader-fonts';
  link.rel = 'stylesheet';
  link.href = '/assets/css/vendor/google-fonts-aHR0cHM6Ly9mb250cy5n.css';
  document.head.appendChild(link);
}

class GenerationLoader extends Base {
  static get observedAttributes() { return ['status', 'pct', 'estimate', 'started', 'created', 'model', 'prompt', 'error']; }

  connectedCallback() {
    const id = this.getAttribute('run');
    if (id) {
      this.entry = runs.get(id) || newEntry();
      runs.set(id, this.entry);
    } else {
      this.entry = this.entry || newEntry();
    }
    this.entry.users += 1;
    clearTimeout(this.entry.dropTimer);
    mergeInputs(this.entry, readInputs(this));
    this.setAttribute('role', 'progressbar');
    this.setAttribute('aria-label', 'Generation progress');
    if (active) this.mount();
    else resolveDesign().then(() => { if (this.isConnected && !this.view) this.mount(); });
  }

  mount() {
    const design = DESIGNS[active.design];
    loadFonts();
    const shadow = this.shadowRoot || this.attachShadow({ mode: 'open' });
    shadow.innerHTML = `<style>${HOST_CSS}${design.css}</style><div class="gl"></div>`;
    this.wrap = shadow.querySelector('.gl');
    this.view = design.create(this.wrap);
    this.visible = true;
    this.restFor = 0;
    mounted.add(this);
    watchTheme();
    visibility?.observe(this);
    if (active.experiment && !this.entry.impressed) {
      this.entry.impressed = true;
      gtagPush('generation_loader_impression', { variant: active.design });
    }
    this.tick(Date.now(), 16);
    wake(this);
  }

  disconnectedCallback() {
    mounted.delete(this);
    live.delete(this);
    visibility?.unobserve(this);
    this.view?.destroy?.();
    this.view = null;
    const entry = this.entry;
    if (!entry) return;
    entry.users -= 1;
    const id = this.getAttribute('run');
    if (id && entry.users <= 0) {
      entry.dropTimer = setTimeout(() => { if (runs.get(id) === entry && entry.users <= 0) runs.delete(id); }, ENTRY_TTL_MS);
    }
  }

  attributeChangedCallback() {
    if (this.entry && this.isConnected) {
      mergeInputs(this.entry, readInputs(this));
      this.restFor = 0;
      if (this.view) wake(this);
    }
  }

  tick(now, dt) {
    if (!this.view) return;
    const s = deriveState(this.entry, now);
    // A failed run is a still picture once its fade has played.
    this.restFor = s.phase === 'failed' ? (this.restFor || 0) + dt : 0;
    if (this.restFor > 1500) { live.delete(this); return; }
    const whole = s.pct == null ? null : Math.floor(s.pct);
    if (whole !== this.ariaPct) {
      this.ariaPct = whole;
      if (whole == null) this.removeAttribute('aria-valuenow');
      else this.setAttribute('aria-valuenow', String(whole));
    }
    this.wrap.toggleAttribute('data-dark', s.dark);
    // Children of a progressbar are not read out; the label carries the phase.
    if (s.label !== this.ariaText) {
      this.ariaText = s.label;
      this.setAttribute('aria-valuetext', s.label);
    }
    this.view.update(s, dt);
  }
}

if (typeof customElements !== 'undefined' && !customElements.get('generation-loader')) {
  customElements.define('generation-loader', GenerationLoader);
}

/** The tag as an HTML string; empty/nullish/false values are left out, `true` is a bare attribute. */
export function loaderHtml(attrs = {}) {
  const parts = Object.entries(attrs)
    .filter(([, v]) => v != null && v !== '' && v !== false && !(typeof v === 'number' && !Number.isFinite(v)))
    .map(([k, v]) => (v === true ? ` ${k}` : ` ${k}="${escapeHtml(v)}"`));
  return `<generation-loader${parts.join('')}></generation-loader>`;
}

/** Update a mounted tag in place; nullish values remove the attribute. */
export function setLoaderAttrs(el, attrs = {}) {
  if (!el) return;
  for (const [k, v] of Object.entries(attrs)) {
    if (v == null || v === '' || v === false) el.removeAttribute(k);
    else if (el.getAttribute(k) !== (v === true ? '' : String(v))) el.setAttribute(k, v === true ? '' : String(v));
  }
}
