// Pixel Line: one hairline of square pixels; lit pixels are the progress and a
// comet runs along the lit part every beat, landing on the edge with a glint.
import { easeShownPct, el } from './shared.js';

const css = `
.l{--bg:#f6f6f6;--ink:#0e0e10;--soft:rgba(14,14,16,.6);--faint:rgba(14,14,16,.4);
  --big:96px;--pad:40px;--meta:13px;--hint:13.5px;--mono:11px;--liney:50%;--gap:20px;position:absolute;inset:0;background:var(--bg);color:var(--ink)}
[data-dark] .l{--bg:#09090a;--ink:#f5f5f6;--soft:rgba(245,245,246,.6);--faint:rgba(245,245,246,.36)}
.l canvas{position:absolute;inset:0;width:100%;height:100%}
.l-above{position:absolute;left:var(--pad);right:var(--pad);bottom:calc(100% - var(--liney) + var(--gap));display:flex;align-items:flex-end;justify-content:space-between;gap:16px}
.l-pct{font-size:var(--big);line-height:.78;font-weight:200;letter-spacing:-.06em;font-variant-numeric:tabular-nums;white-space:nowrap;margin-left:-.06em;color:var(--ink)}
.l-pct i{font-style:normal;font-weight:300;font-size:.3em;letter-spacing:0;color:var(--faint);margin-left:-.05em}
.l-eta{font:400 var(--meta)/1 "JetBrains Mono",ui-monospace,monospace;letter-spacing:-.02em;color:var(--soft);font-variant-numeric:tabular-nums;white-space:nowrap;padding-bottom:.1em}
.l-below{position:absolute;left:var(--pad);right:var(--pad);top:calc(var(--liney) + var(--gap))}
.l-row{display:flex;align-items:baseline;justify-content:space-between;gap:16px}
.l-word{font-size:var(--meta);line-height:1.2;font-weight:500;letter-spacing:-.01em;white-space:nowrap;color:var(--ink)}
.l-model{min-width:0;font:400 var(--mono)/1.2 "JetBrains Mono",ui-monospace,monospace;color:var(--faint);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.l-hint{max-width:500px;margin:10px 0 0;font-size:var(--hint);line-height:1.5;color:var(--soft);opacity:0;transition:opacity .4s ease;text-wrap:pretty}
.l-hint[data-on]{opacity:1}
.l-err{display:none;max-width:560px;margin:10px 0 0;font-size:var(--hint);line-height:1.45;color:var(--soft);overflow-wrap:anywhere}
.l[data-failed] .l-err{display:block}
.l[data-failed] .l-hint{display:none}
.l[data-failed] .l-pct{color:var(--soft)}
.l[data-tall] .l-row{flex-direction:column;align-items:flex-start;gap:6px}
.l[data-tiny] .l-hint{margin-top:6px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.l[data-tiny] .l-model{display:none}
.l[data-tiny] .l-err{margin-top:6px;display:none}
.l[data-tiny][data-failed] .l-err{display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}
`;

function create(host) {
  const root = el(`
    <div class="l">
      <canvas></canvas>
      <div class="l-above"><div class="l-pct"><span>0</span><i>%</i></div><div class="l-eta"></div></div>
      <div class="l-below">
        <div class="l-row"><div class="l-word"></div><div class="l-model"></div></div>
        <p class="l-hint" aria-live="polite"></p>
        <p class="l-err"></p>
      </div>
    </div>`);
  host.appendChild(root);
  const q = (s) => root.querySelector(s);
  const cv = q('canvas');
  const g = cv.getContext('2d');
  const num = q('.l-pct span');
  const unit = q('.l-pct i');
  const eta = q('.l-eta');
  const word = q('.l-word');
  const model = q('.l-model');
  const hint = q('.l-hint');
  const err = q('.l-err');
  const last = {};
  const pctState = { dp: null };
  let beat = 0;
  let dim = null;
  let geo = null;

  function resize() {
    const r = root.getBoundingClientRect();
    const W = r.width;
    const H = r.height;
    if (!W || !H) { geo = null; return; }
    const tiny = H < 300;
    root.toggleAttribute('data-tiny', tiny);
    root.toggleAttribute('data-tall', W / H < 0.8);
    const pad = tiny ? 16 : Math.round(Math.max(22, Math.min(56, Math.min(W, H) * 0.08)));
    const big = tiny ? 44 : Math.round(Math.max(56, Math.min(W * 0.2, H * 0.2, 120)));
    const st = root.style;
    st.setProperty('--pad', `${pad}px`);
    st.setProperty('--big', `${big}px`);
    st.setProperty('--meta', `${tiny ? 11.5 : 13}px`);
    st.setProperty('--hint', `${(tiny ? 10.5 : Math.max(12.5, Math.min(14, W * 0.016))).toFixed(1)}px`);
    st.setProperty('--mono', `${tiny ? 10 : 11}px`);
    st.setProperty('--gap', `${tiny ? 10 : Math.round(Math.max(16, Math.min(26, H * 0.035)))}px`);
    // The line sits on the middle, nudged down just enough to clear the % on short frames.
    const ly = Math.round(Math.max(H * 0.5, pad + big * 0.78 + (tiny ? 10 : 26)));
    st.setProperty('--liney', `${ly}px`);
    const px = tiny ? 2 : 3;
    const pitch = px + (tiny ? 1.5 : 2);
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    cv.width = Math.round(W * dpr);
    cv.height = Math.round(H * dpr);
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    geo = { W, H, ly, px, pitch, dpr, x0: pad, n: Math.floor((W - 2 * pad + (pitch - px)) / pitch) };
  }
  const ro = new ResizeObserver(resize);
  ro.observe(root);

  function set(key, node, value, html) {
    if (last[key] === value) return;
    last[key] = value;
    if (html) node.innerHTML = value; else node.textContent = value;
  }

  function etaText(s) {
    if (s.phase === 'failed') return 'Stopped';
    if (s.phase === 'uploading') return `upload ${s.uploadPct}%`;
    if (s.remaining != null) return s.remaining > 0 ? `~${s.estimate}s · ${s.remaining}s left` : `${s.elapsed}s`;
    return s.pct == null ? '' : `${s.elapsed}s`;
  }

  function draw(s) {
    const { W, H, n, px, pitch, dpr, x0 } = geo;
    g.clearRect(0, 0, W, H);
    const failed = s.phase === 'failed';
    const rm = s.reducedMotion;
    const indeterminate = s.pct == null;
    const y = Math.round((geo.ly - px / 2) * dpr) / dpr;
    const lit = indeterminate ? 0 : ((pctState.dp ?? 0) / 100) * n;
    const span = indeterminate ? n : lit;
    const edge = Math.max(0, Math.ceil(lit) - 1);
    const base = failed ? [0, 0, s.dark ? 58 : 52] : s.dark ? [270, 95, 75] : [271, 83, 57];
    const hiL = s.dark ? 95 : 36;
    const off = s.dark ? 'rgba(255,255,255,0.14)' : 'rgba(12,12,16,0.13)';
    const u = beat;
    const k = Math.min(1, u / 0.72);
    const ease = k < 0.5 ? 4 * k * k * k : 1 - ((-2 * k + 2) ** 3) / 2;
    const head = ease * Math.max(0, span - 1);
    const travelling = !rm && !failed && u < 0.72 && span > 2;
    const tail = Math.max(6, Math.min(26, span * 0.35));
    const land = rm || failed || indeterminate ? 0
      : (u >= 0.66 ? Math.exp(-Math.max(0, u - 0.72) / 0.09) * Math.min(1, (u - 0.66) / 0.06) : 0);
    const breathe = rm && !failed ? 0.5 + 0.5 * Math.sin(u * 6.2832) : 0;
    const X = (i) => Math.round((x0 + i * pitch) * dpr) / dpr;

    for (let i = 0; i < n; i += 1) {
      const x = X(i);
      const f = Math.max(0, Math.min(1, lit - i));
      let gl = 0;
      if (travelling) {
        const d = head - i;
        if (d >= -0.5 && d <= tail) gl = d < 0.5 ? 1 : (1 - d / tail) ** 1.8;
        gl *= dim;
      }
      if (f < 1 && !(indeterminate && gl > 0)) { g.fillStyle = off; g.fillRect(x, y, px, px); }
      if (f <= 0 && !(indeterminate && gl > 0)) continue;
      if (!indeterminate && i === edge) gl = Math.max(gl, land * dim, breathe * 0.6);
      const L = base[2] + (hiL - base[2]) * gl;
      const a = failed ? 0.5 : indeterminate ? gl : (0.7 + 0.3 * dim) * (f < 1 ? 0.3 + 0.7 * f : 1);
      g.fillStyle = `hsla(${base[0]},${base[1]}%,${L}%,${Math.min(1, a + 0.2 * gl)})`;
      g.fillRect(x, y, px, px);
    }
    const glowAt = (i, strength) => {
      if (strength <= 0.02) return;
      const cx = X(i) + px / 2;
      const cy = y + px / 2;
      const R = px * 5;
      const grd = g.createRadialGradient(cx, cy, 0, cx, cy, R);
      const col = s.dark ? '270,95%,78%' : '271,83%,55%';
      grd.addColorStop(0, `hsla(${col},${(s.dark ? 0.36 : 0.26) * strength})`);
      grd.addColorStop(1, `hsla(${col},0)`);
      g.fillStyle = grd;
      g.fillRect(cx - R, cy - R, R * 2, R * 2);
    };
    if (travelling) glowAt(Math.round(head), dim);
    if (!failed && lit > 0) glowAt(edge, Math.max(land, breathe * 0.5) * dim);
  }

  return {
    update(s, dt) {
      easeShownPct(pctState, s, dt);
      root.toggleAttribute('data-failed', s.phase === 'failed');
      const noPct = s.pct == null || pctState.dp == null;
      set('num', num, noPct ? (s.phase === 'failed' ? '' : `${s.elapsed}`) : `${Math.min(99, Math.floor(pctState.dp + 1e-6))}`);
      set('unit', unit, noPct ? (s.phase === 'failed' ? '' : 's') : '%');
      set('eta', eta, etaText(s));
      set('word', word, s.label);
      set('model', model, s.model);
      if (s.hint) set('hint', hint, s.hint);
      hint.toggleAttribute('data-on', Boolean(s.hint));
      set('err', err, s.phase === 'failed' ? s.error : '');

      // On the wall clock, so every view of a run pulses in step.
      const P = s.phase === 'queued' ? 2800 : s.overrun ? 1300 : 1800;
      beat = (performance.now() / (s.reducedMotion ? P * 2.5 : P)) % 1;
      const target = s.phase === 'failed' ? 0 : s.phase === 'queued' ? 0.5 : 1;
      dim = dim == null ? target : dim + (target - dim) * Math.min(1, dt / 600);
      if (!geo) resize();
      if (geo && geo.n > 0) draw(s);
    },
    destroy() { ro.disconnect(); },
  };
}

export default { css, create };
