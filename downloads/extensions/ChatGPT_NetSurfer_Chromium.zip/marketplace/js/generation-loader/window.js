// Window: instead of a % that guesses the second, a time axis shows the window
// this run is usually ready in and a needle for now moving through it.
import { clock, el } from './shared.js';

const STEP_MS = 250;

const css = `
.w{--bg:#f7f7f8;--ink:#101012;--soft:rgba(16,16,18,.62);--faint:rgba(16,16,18,.36);--line:rgba(16,16,18,.12);
  --acc:hsl(271 83% 57%);--accs:hsla(271,83%,57%,.12);--warn:#a86a10;
  position:absolute;inset:0;container-type:size;overflow:hidden;background:var(--bg);color:var(--ink)}
[data-dark] .w{--bg:#0b0b0d;--ink:#f4f4f5;--soft:rgba(244,244,245,.62);--faint:rgba(244,244,245,.34);--line:rgba(244,244,245,.12);
  --acc:hsl(270 95% 75%);--accs:hsla(270,95%,75%,.16);--warn:#e7b86a}
.w-ui{position:absolute;inset:0;padding:6.5cqmin 7cqmin;display:flex;flex-direction:column}
.w-meta{display:flex;gap:1.6cqmin;align-items:center;min-width:0;font:500 max(10px,1.9cqmin)/1.2 'JetBrains Mono',ui-monospace,monospace;color:var(--faint);letter-spacing:.02em;text-transform:uppercase}
.w-meta b{color:var(--soft);font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.w-prompt{margin-top:1.6cqmin;font-size:max(11px,2.3cqmin);line-height:1.45;color:var(--faint);max-width:62ch;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.w-say{margin-top:auto;display:grid}
.w-say>div{grid-area:1/1;transition:opacity .45s ease,transform .6s cubic-bezier(.2,.8,.2,1)}
.w-say>div[data-out]{opacity:0;transform:translateY(-1.2cqmin)}
.w-big{font-size:clamp(18px,7.4cqmin,60px);line-height:1.04;font-weight:500;letter-spacing:-.035em;text-wrap:balance;color:var(--ink)}
.w-big em{font-style:normal;color:var(--acc)}
.w-sub{margin-top:1.6cqmin;font-size:max(11px,2.5cqmin);line-height:1.45;color:var(--soft);max-width:52ch;overflow-wrap:anywhere}
.w-axis{position:relative;margin-top:6cqmin;height:max(54px,13cqmin)}
.w-axis *{transition:left .25s linear,width .25s linear,opacity .4s ease}
.w-rail{position:absolute;left:0;right:0;top:46%;height:1px;background:var(--line)}
.w-seg{position:absolute;top:calc(46% - .6cqmin);height:1.2cqmin;min-height:5px;border-radius:99px}
.w-up{background:var(--soft);opacity:.55}
.w-q{background:repeating-linear-gradient(90deg,var(--soft) 0 2px,transparent 2px 5px);opacity:.5}
.w-run{background:var(--acc)}
.w[data-failed] .w-run{background:var(--faint)}
.w-band{position:absolute;top:24%;bottom:32%;border-radius:1.2cqmin;background:var(--accs);border:1px dashed color-mix(in srgb,var(--acc) 55%,transparent)}
.w-band span{position:absolute;left:0;right:0;top:-.2cqmin;transform:translateY(-100%);text-align:center;font:500 max(9px,1.7cqmin)/1 'JetBrains Mono',ui-monospace,monospace;color:var(--acc);white-space:nowrap;letter-spacing:.02em}
.w-band b{font-weight:500}
@container (max-width:520px){.w-band b{display:none}}
.w-needle{position:absolute;top:0;bottom:0;width:1px;background:var(--ink)}
.w-needle::after{content:'';position:absolute;left:-.55cqmin;top:calc(46% - .55cqmin);width:1.1cqmin;height:1.1cqmin;min-width:6px;min-height:6px;border-radius:50%;background:var(--ink);box-shadow:0 0 0 .7cqmin var(--bg)}
.w-needle i{position:absolute;bottom:-.4cqmin;left:0;transform:translate(-50%,100%);font:500 max(10px,1.9cqmin)/1 'JetBrains Mono',ui-monospace,monospace;font-style:normal;font-variant-numeric:tabular-nums;white-space:nowrap;color:var(--ink)}
.w[data-failed] .w-needle{display:none}
.w-x{position:absolute;top:46%;width:2.4cqmin;height:2.4cqmin;min-width:12px;min-height:12px;transform:translate(-50%,-50%);color:var(--warn);display:none}
.w[data-failed] .w-x{display:block}
.w-ticks{position:absolute;left:0;right:0;bottom:0;height:2cqmin}
.w-ticks span{position:absolute;bottom:0;transform:translateX(-50%);font:400 max(9px,1.6cqmin)/1 'JetBrains Mono',ui-monospace,monospace;color:var(--faint)}
.w-foot{margin-top:2.4cqmin;display:flex;justify-content:space-between;gap:3cqmin;font:400 max(10px,1.9cqmin)/1.3 'JetBrains Mono',ui-monospace,monospace;color:var(--faint);min-height:1.3em}
@container (max-aspect-ratio:3/4){.w-ui{padding:7cqw 7cqw 9cqw}.w-big{font-size:clamp(18px,9cqw,44px)}.w-sub{font-size:max(11px,3.4cqw)}.w-axis{height:max(56px,16cqw)}}
@media (prefers-reduced-motion:reduce){.w *{transition:none!important}}
@container (max-height:300px){.w-ui{padding:12px 14px}.w-prompt{display:none}.w-sub{display:-webkit-box;-webkit-line-clamp:4;-webkit-box-orient:vertical;overflow:hidden}.w-axis{margin-top:10px;height:44px}.w-foot{display:none}}
`;

const X_ICON = '<svg class="w-x" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>';

function create(host) {
  const root = el(`
    <div class="w">
      <div class="w-ui">
        <div class="w-meta"><b></b><span></span></div>
        <div class="w-prompt"></div>
        <div class="w-say"></div>
        <div class="w-axis">
          <div class="w-rail"></div>
          <div class="w-band"><span></span></div>
          <div class="w-seg w-up"></div><div class="w-seg w-q"></div><div class="w-seg w-run"></div>
          <div class="w-needle"><i></i></div>
          ${X_ICON}
          <div class="w-ticks"></div>
        </div>
        <div class="w-foot"><span data-step></span><span data-time></span></div>
      </div>
    </div>`);
  host.appendChild(root);
  const q = (s) => root.querySelector(s);
  const e = {
    model: q('.w-meta b'), phase: q('.w-meta span'), prompt: q('.w-prompt'), say: q('.w-say'), band: q('.w-band'), bandLabel: q('.w-band span'),
    up: q('.w-up'), queue: q('.w-q'), run: q('.w-run'), needle: q('.w-needle'), needleLabel: q('.w-needle i'),
    x: q('.w-x'), ticks: q('.w-ticks'), step: q('[data-step]'), time: q('[data-time]'),
  };
  const last = {};
  let axis = null;
  let since = STEP_MS;
  let stopAt = null;

  const style = (node, prop, value) => { if (node.style[prop] !== value) node.style[prop] = value; };
  const text = (key, node, value) => { if (last[key] !== value) { last[key] = value; node.textContent = value; } };

  function say(key, big, sub) {
    if (last.say === key && last.sub === sub) return;
    if (last.say === key) {
      const cur = e.say.lastElementChild?.querySelector('.w-sub');
      if (cur) { cur.textContent = sub; last.sub = sub; return; }
    }
    last.say = key;
    last.sub = sub;
    const first = !e.say.firstElementChild;
    [...e.say.children].forEach((ch) => { ch.dataset.out = ''; setTimeout(() => ch.remove(), 600); });
    const d = el(`<div${first ? '' : ' data-out'}><div class="w-big">${big}</div>${sub ? `<div class="w-sub"></div>` : ''}</div>`);
    if (sub) d.querySelector('.w-sub').textContent = sub;
    e.say.appendChild(d);
    if (!first) requestAnimationFrame(() => requestAnimationFrame(() => delete d.dataset.out));
  }

  function words(s, runSec) {
    switch (s.phase) {
      case 'uploading': return say('up', 'Uploading your files', s.hint);
      case 'queued': return say('q', 'Waiting for a free slot', s.hint);
      case 'failed': return say('fail', 'This one didn’t make it', s.error);
      default: break;
    }
    if (!s.range) return say('run', s.overrun ? 'Taking longer than usual' : 'Generating', s.hint);
    const [lo, hi] = s.range;
    if (runSec > hi) return say('over', 'Taking longer than usual', s.hint);
    if (runSec >= lo) return say('in', 'Any moment now', s.hint);
    if (runSec >= lo - 4) return say('soon', 'Almost in the window', s.hint);
    return say(`early${lo}-${hi}`, `Usually ready in <em>${lo}–${hi} seconds</em>`, s.hint);
  }

  function paint(s) {
    const sec = (ms) => ms / 1000;
    const failed = s.phase === 'failed';
    if (failed && stopAt == null) stopAt = sec(s.since);
    if (!failed) stopAt = null;
    const now = stopAt ?? sec(s.since);
    const runStart = sec(s.runStart);
    const band = s.range ? [runStart + s.range[0], runStart + s.range[1]] : null;
    const target = Math.max(band ? band[1] * 1.18 : 0, now * 1.1 + 2, 20);
    axis = axis == null || target > axis ? target : axis + (target - axis) * 0.2;
    const X = (v) => `${(Math.max(0, v) / axis) * 100}%`;
    const W = (a, b) => `${(Math.max(0, b - a) / axis) * 100}%`;

    root.toggleAttribute('data-failed', failed);
    style(e.band, 'opacity', band ? (failed ? '0.25' : '1') : '0');
    if (band) {
      style(e.band, 'left', X(band[0]));
      style(e.band, 'width', W(band[0], band[1]));
      const lbl = `<b>usually ready · </b>${s.range[0]}–${s.range[1]}s`;
      if (last.band !== lbl) { last.band = lbl; e.bandLabel.innerHTML = lbl; }
    }
    const queuedAt = s.marks.queued != null ? sec(s.marks.queued) : null;
    const upEnd = queuedAt ?? (s.phase === 'uploading' ? now : 0);
    style(e.up, 'width', W(0, upEnd));
    style(e.up, 'left', '0%');
    const running = s.phase === 'running' || (failed && s.marks.running != null);
    // A run first seen already running has no queue to draw; its bar starts at 0.
    const qEnd = running ? (queuedAt != null ? Math.max(upEnd, runStart) : upEnd) : (s.phase === 'queued' ? now : upEnd);
    style(e.queue, 'left', X(upEnd));
    style(e.queue, 'width', W(upEnd, qEnd));
    style(e.run, 'left', X(qEnd));
    style(e.run, 'width', running ? W(qEnd, now) : '0%');
    style(e.needle, 'left', X(now));
    style(e.x, 'left', X(now));
    text('needle', e.needleLabel, clock(now));

    const step = axis > 120 ? 30 : axis > 50 ? 10 : 5;
    const n = Math.floor(axis / step);
    if (last.ticks !== `${step}:${n}`) {
      last.ticks = `${step}:${n}`;
      e.ticks.innerHTML = Array.from({ length: n + 1 }, (_, i) => `<span>${i * step}s</span>`).join('');
    }
    [...e.ticks.children].forEach((t, i) => {
      style(t, 'left', X(i * step));
      style(t, 'opacity', i === 0 || Math.abs(i * step - now) / axis < 0.045 ? '0' : '1');
    });

    const runSec = Math.max(0, now - runStart);
    words(s, runSec);
    text('model', e.model, s.model);
    text('prompt', e.prompt, s.prompt);
    text('phase', e.phase, s.label);
    text('step', e.step, s.phase === 'uploading' ? `upload ${s.uploadPct ?? 0}%`
      : s.phase === 'queued' ? 'waiting for a slot'
        : failed ? 'stopped' : `${clock(runSec)} in the model`);
    text('time', e.time, s.remaining != null && !failed ? (s.remaining > 0 ? `~${s.remaining}s left` : 'past the estimate') : '');
  }

  return {
    update(s, dt) {
      since += dt;
      if (since < STEP_MS && last.phase === s.label) return;
      since = 0;
      paint(s);
    },
  };
}

export default { css, create };
