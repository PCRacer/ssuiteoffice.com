// Pixel Fill: a breathing tile grid is the progress bar. Tiles switch on in a
// noise-sorted order so the lit share is always the %, while a ripple keeps rolling.
import { easeShownPct, el } from './shared.js';

const css = `
.pf{position:absolute;inset:0;background:#f1eff5}
[data-dark] .pf{background:#0b0a0e}
.pf canvas{position:absolute;inset:0;width:100%;height:100%;display:block}
.pf-stack{position:absolute;left:14px;bottom:14px;right:14px;display:flex;flex-direction:column;align-items:flex-start;gap:8px;pointer-events:none}
.pf-pill,.pf-hint{display:flex;align-items:center;gap:10px;max-width:100%;border-radius:99px;
  background:rgba(255,255,255,.78);backdrop-filter:blur(14px) saturate(1.4);-webkit-backdrop-filter:blur(14px) saturate(1.4);
  box-shadow:0 0 0 1px rgba(20,13,34,.07),0 10px 28px -14px rgba(60,20,120,.35);color:#140d22}
[data-dark] .pf-pill,[data-dark] .pf-hint{background:rgba(14,12,20,.62);color:#fff;box-shadow:0 0 0 1px rgba(255,255,255,.08),0 10px 28px -12px rgba(0,0,0,.6)}
.pf-pill{height:36px;padding:0 14px 0 12px}
.pf-hint{padding:7px 12px;border-radius:12px;font-size:12px;line-height:1.4;max-width:min(100%,420px);opacity:0;transition:opacity .4s ease}
.pf-hint[data-on]{opacity:1}
.pf-pct{font:600 15px/1 "JetBrains Mono",ui-monospace,monospace;font-variant-numeric:tabular-nums;letter-spacing:-.02em;flex:none;color:hsl(271 83% 50%)}
[data-dark] .pf-pct{color:hsl(270 95% 80%)}
.pf-pct i{font-style:normal;opacity:.6;margin-left:1px}
.pf-sep{width:1px;height:14px;background:currentColor;opacity:.16;flex:none}
.pf-meta{font-size:12.5px;line-height:1;font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;opacity:.82}
.pf-fail{position:absolute;inset:0;display:none;flex-direction:column;align-items:center;justify-content:center;gap:10px;padding:24px;text-align:center;
  background:radial-gradient(60% 55% at 50% 50%,rgba(241,239,245,.94),rgba(241,239,245,.45))}
[data-dark] .pf-fail{background:radial-gradient(60% 55% at 50% 50%,rgba(8,8,10,.8),rgba(8,8,10,.3))}
.pf-fail b{font-size:15px;line-height:1.2;font-weight:600;color:#140d22}
.pf-fail p{margin:0;max-width:340px;font-size:13px;line-height:1.5;color:rgba(20,13,34,.65);overflow-wrap:anywhere}
[data-dark] .pf-fail b{color:#fff}
[data-dark] .pf-fail p{color:rgba(255,255,255,.72)}
.pf[data-failed] .pf-fail{display:flex}
.pf[data-failed] .pf-stack{display:none}
.pf[data-tiny] .pf-stack{left:8px;bottom:8px;right:8px;gap:6px}
.pf[data-tiny] .pf-pill{height:27px;gap:7px;padding:0 10px 0 9px}
.pf[data-tiny] .pf-pct{font-size:12px}
.pf[data-tiny] .pf-meta{font-size:10.5px}
.pf[data-tiny] .pf-sep{height:11px}
.pf[data-tiny] .pf-hint{padding:5px 9px;font-size:10.5px}
.pf[data-tiny] .pf-fail{gap:6px;padding:12px}
.pf[data-tiny] .pf-fail b{font-size:12.5px}
.pf[data-tiny] .pf-fail p{font-size:11px;line-height:1.35;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}
`;

function create(host) {
  const root = el(`
    <div class="pf">
      <canvas></canvas>
      <div class="pf-stack">
        <p class="pf-hint" aria-live="polite"></p>
        <div class="pf-pill"><b class="pf-pct">0<i>%</i></b><i class="pf-sep"></i><span class="pf-meta"></span></div>
      </div>
      <div class="pf-fail"><b>Couldn’t generate</b><p></p></div>
    </div>`);
  host.appendChild(root);
  const cv = root.querySelector('canvas');
  const g = cv.getContext('2d');
  const pctEl = root.querySelector('.pf-pct');
  const meta = root.querySelector('.pf-meta');
  const hint = root.querySelector('.pf-hint');
  const failText = root.querySelector('.pf-fail p');
  // From the run, so every view of one run (a re-rendered card, a stage
  // mirror) lights the same tiles in the same order.
  let seed = 0;
  const last = {};
  const pctState = { dp: null };
  let energy = null;
  let failAt = null;
  let grid = null;
  let sprite = null;
  let core = null;

  const hash = (x, y) => {
    let h = Math.imul(x, 374761393) ^ Math.imul(y, 668265263) ^ Math.imul(seed, 1442695041);
    h = Math.imul(h ^ (h >>> 13), 1274126177);
    return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
  };
  const noise = (x, y) => {
    const xi = Math.floor(x);
    const yi = Math.floor(y);
    const xf = x - xi;
    const yf = y - yi;
    const u = xf * xf * (3 - 2 * xf);
    const v = yf * yf * (3 - 2 * yf);
    const a = hash(xi, yi);
    const b = hash(xi + 1, yi);
    const c = hash(xi, yi + 1);
    const d = hash(xi + 1, yi + 1);
    return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
  };

  function resize() {
    const r = root.getBoundingClientRect();
    if (!r.width || !r.height) { grid = null; return; }
    const W = Math.round(r.width);
    const H = Math.round(r.height);
    if (grid && W === grid.W && H === grid.H) return;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    cv.width = Math.round(W * dpr);
    cv.height = Math.round(H * dpr);
    root.toggleAttribute('data-tiny', H < 300 || W < 360);
    const b = Math.max(W, H) / 18;
    const cols = Math.ceil(W / b);
    const rows = Math.ceil(H / b);
    const ox = (W - cols * b) / 2;
    const oy = (H - rows * b) / 2;
    const tiles = [];
    for (let y = 0; y < rows; y += 1) {
      for (let x = 0; x < cols; x += 1) {
        const cx = ox + (x + 0.5) * b;
        const cy = oy + (y + 0.5) * b;
        // Organic fill order: low-frequency noise grows blobs, a little jitter keeps their edges ragged.
        const key = noise(cx / (b * 3.6), cy / (b * 3.6)) * 0.7 + noise(cx / (b * 1.4) + 40, cy / (b * 1.4)) * 0.2 + hash(x, y + 977) * 0.1;
        tiles.push({ cx, cy, n: hash(x + 311, y), key, litAt: -1e9, was: false });
      }
    }
    [...tiles].sort((a, c) => a.key - c.key).forEach((t, i) => { t.rank = i; t.was = t.rank < Math.floor(tiles.length * (pctState.dp ?? 0) / 100); });
    grid = { W, H, b, dpr, tiles };
    sprite = null;
  }
  const ro = new ResizeObserver(resize);
  ro.observe(root);

  function glowSprite(dark) {
    if (sprite && sprite.dark === dark) return sprite.canvas;
    const s = Math.ceil(grid.b * 2.6 * grid.dpr);
    const k = document.createElement('canvas');
    k.width = s;
    k.height = s;
    const c = k.getContext('2d');
    const gr = c.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s / 2);
    if (dark) { gr.addColorStop(0, 'hsla(272,95%,62%,.34)'); gr.addColorStop(0.45, 'hsla(272,95%,58%,.12)'); gr.addColorStop(1, 'hsla(272,95%,55%,0)'); } else { gr.addColorStop(0, 'hsla(271,83%,57%,.26)'); gr.addColorStop(0.5, 'hsla(271,83%,60%,.08)'); gr.addColorStop(1, 'hsla(271,83%,60%,0)'); }
    c.fillStyle = gr;
    c.fillRect(0, 0, s, s);
    sprite = { canvas: k, dark };
    return k;
  }

  function coreSprite() {
    if (core) return core;
    core = document.createElement('canvas');
    core.width = 96;
    core.height = 96;
    const c = core.getContext('2d');
    const gr = c.createRadialGradient(48, 40, 0, 48, 44, 48);
    gr.addColorStop(0, 'rgba(255,255,255,.26)');
    gr.addColorStop(0.45, 'rgba(255,255,255,.09)');
    gr.addColorStop(0.9, 'rgba(255,255,255,0)');
    c.fillStyle = gr;
    c.fillRect(0, 0, 96, 96);
    return core;
  }

  const rect = (x, y, w, h, r) => {
    if (g.roundRect) { g.beginPath(); g.roundRect(x, y, w, h, r); g.fill(); } else g.fillRect(x, y, w, h);
  };

  function draw(s, now) {
    const { W, H, b, dpr, tiles } = grid;
    const dark = s.dark;
    const rm = s.reducedMotion;
    const t = rm ? 0 : now / 1000;
    const E = energy;
    const N = tiles.length;
    const nLit = s.pct == null || pctState.dp == null ? 0 : Math.min(N, Math.floor(N * pctState.dp / 100 + 1e-6));
    const F = failAt == null ? 0 : Math.min(1, (now - failAt) / 700);
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.fillStyle = dark ? '#0b0a0e' : '#f1eff5';
    g.fillRect(0, 0, W, H);
    const maxD = Math.hypot(W, H);
    const period = 3.6;
    const rr = ((t % period) / period) * maxD * 1.25 - maxD * 0.1;
    const wv = b * 1.6;

    // No % yet (no estimate, no provider %): the ripple lights the tiles it
    // passes, so the run still visibly moves.
    const sweep = s.pct == null && s.phase === 'running';
    for (const p of tiles) {
      p.w = rm ? 0 : Math.exp(-(((Math.hypot(p.cx, H - p.cy) - rr) / wv) ** 2)) * (1 - F);
      p.on = sweep ? p.w > 0.5 : p.rank < nLit;
      if (p.on && !p.was) p.litAt = now;
      p.was = p.on;
      p.sh = rm ? 0 : Math.sin(t * 0.9 + p.n * 6.283) * 0.5 + 0.5;
      p.k = rm ? 1 : Math.min(1, (now - p.litAt) / 440);
    }

    if (F < 1) {
      const sp = glowSprite(dark);
      const sz = b * 2.6;
      g.globalCompositeOperation = dark ? 'lighter' : 'source-over';
      for (const p of tiles) {
        if (!p.on) continue;
        g.globalAlpha = Math.min(1, (0.62 + p.w * 0.5 + (1 - p.k) * 0.9) * (1 - F) * (0.75 + 0.25 * E));
        g.drawImage(sp, p.cx - sz / 2, p.cy - sz / 2, sz, sz);
      }
      g.globalCompositeOperation = 'source-over';
      g.globalAlpha = 1;
    }

    const gap = b > 26 ? 1.6 : 1.2;
    const rad = Math.min(4, b * 0.12);
    for (const p of tiles) {
      const pop = 1 - p.k;
      let L;
      let S;
      if (p.on) {
        if (dark) { L = 41 + p.n * 7 + p.sh * 4 * E + p.w * 16 + pop * 26; S = 80 + p.w * 10; } else { L = 58 + p.n * 6 - p.sh * 3 * E + p.w * 8 + pop * 12; S = 78; }
        if (F) { S *= 1 - F; L += ((dark ? 30 : 74) - L) * F; }
      } else {
        if (dark) { L = 8.5 + p.n * 4.5 + (p.sh * 2.2 + p.w * 6.5) * E - (1 - E) * 1.2; S = 24 + p.w * 22; } else { L = 91 - p.n * 4 - (p.sh * 1.6 + p.w * 5) * E; S = 30 + p.w * 20; }
        if (F) S *= 1 - F * 0.9;
      }
      let sc = 1 - p.w * (p.on ? 0.08 : 0.14);
      if (p.on && p.k < 1) {
        const c1 = 1.9;
        const c3 = c1 + 1;
        sc *= 0.35 + 0.65 * (1 + c3 * (p.k - 1) ** 3 + c1 * (p.k - 1) ** 2);
      }
      g.fillStyle = `hsl(271 ${S}% ${Math.min(96, L)}%)`;
      const sz = (b - gap) * sc;
      rect(p.cx - sz / 2, p.cy - sz / 2, sz, sz, rad);
      if (p.on && F < 1) {
        g.globalAlpha = (1 - F) * (dark ? 1 : 0.8);
        g.drawImage(coreSprite(), p.cx - sz / 2, p.cy - sz / 2, sz, sz);
        g.globalAlpha = 1;
      }
    }
  }

  function metaText(s) {
    if (s.phase === 'uploading') return `Uploading · ${s.uploadPct}%`;
    const time = s.remaining != null
      ? (s.remaining > 0 ? `~${s.estimate}s · ${s.remaining}s left` : 'Taking a bit longer…')
      : `${s.elapsed}s`;
    if (s.overrun) return `${s.label} · ${s.elapsed}s`;
    return s.phase === 'running' ? time : `${s.label} · ${time}`;
  }

  return {
    update(s, dt) {
      if (s.dark !== last.dark) { last.dark = s.dark; sprite = null; }
      // A jump (mounted mid-run, a new step) re-lights the tiles at the shown %.
      if (easeShownPct(pctState, s, dt)) grid = null;
      if (seed !== s.seed) { seed = s.seed; grid = null; }
      // A view mounted mid-run (a re-rendered card, a stage mirror) starts at
      // the run's level instead of fading up from dim.
      const calm = s.phase === 'running' ? 1 : 0.55;
      energy = energy == null ? calm : energy + (calm - energy) * Math.min(1, dt / 600);
      const now = performance.now();
      if (s.phase === 'failed' && failAt == null) failAt = now;
      if (s.phase !== 'failed') failAt = null;
      root.toggleAttribute('data-failed', s.phase === 'failed');

      const shown = s.pct == null || pctState.dp == null ? '—' : String(Math.min(99, Math.floor(pctState.dp + 1e-6)));
      if (shown !== last.shown) { last.shown = shown; pctEl.innerHTML = s.pct == null ? '—' : `${shown}<i>%</i>`; }
      const m = metaText(s);
      if (m !== last.meta) { last.meta = m; meta.textContent = m; }
      if (s.hint && s.hint !== last.hint) { last.hint = s.hint; hint.textContent = s.hint; }
      hint.toggleAttribute('data-on', Boolean(s.hint));
      if (s.phase === 'failed' && s.error !== last.err) { last.err = s.error; failText.textContent = s.error; }

      if (!grid) resize();
      if (grid) draw(s, now);
    },
    destroy() { ro.disconnect(); },
  };
}

export default { css, create };
