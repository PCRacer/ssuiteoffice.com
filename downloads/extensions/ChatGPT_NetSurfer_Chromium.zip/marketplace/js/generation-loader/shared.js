export function el(html) {
  const t = document.createElement('template');
  t.innerHTML = html.trim();
  return t.content.firstElementChild;
}

/**
 * The % a view draws: eases up toward the run's %, and jumps straight to it
 * when the view mounts mid-run (a re-rendered card, a stage mirror) or when a
 * new step starts (a fall of more than 8). `ease` is the view's { dp };
 * returns true on a jump.
 */
export function easeShownPct(ease, s, dt) {
  let jumped = false;
  if (s.pct != null && (ease.dp == null || s.pct < ease.dp - 8)) {
    ease.dp = s.pct;
    jumped = true;
  }
  if (s.pct != null && s.phase !== 'failed') {
    const next = ease.dp + (s.pct - ease.dp) * (1 - Math.exp(-dt / 320));
    ease.dp = Math.max(ease.dp, Math.abs(s.pct - next) < 0.02 ? s.pct : next);
  }
  return jumped;
}

/** 75 → "1:15", 9 → "0:09". */
export function clock(sec) {
  const s = Math.max(0, Math.floor(sec));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}
