(function () {
  var START = 4;
  var still = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var videos = Array.prototype.slice.call(document.querySelectorAll('main video'));
  var ratio = new Map(), hovered = null, active = null;
  var play = function (v) { v.muted = true; if (v.currentTime < START) v.currentTime = START; var p = v.play(); if (p) p.catch(function () {}); };

  // One video at a time: the hovered one, else the most visible one.
  var pick = function () {
    var next = hovered;
    if (!next) videos.forEach(function (v) { if ((ratio.get(v) || 0) > (ratio.get(next) || 0.4)) next = v; });
    if (next === active) return;
    if (active) active.pause();
    active = next;
    if (active && !still) play(active);
  };
  var io = new IntersectionObserver(function (entries) {
    entries.forEach(function (e) { ratio.set(e.target, e.isIntersecting ? e.intersectionRatio : 0); });
    pick();
  }, { threshold: [0, 0.25, 0.5, 0.75, 1] });
  videos.forEach(function (v) {
    v.addEventListener('ended', function () { v.currentTime = START; play(v); });
    v.parentElement.addEventListener('mouseenter', function () { hovered = v; pick(); });
    v.parentElement.addEventListener('mouseleave', function () { hovered = null; pick(); });
    io.observe(v);
  });

  var reveal = new IntersectionObserver(function (entries) {
    entries.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('in'); reveal.unobserve(e.target); } });
  }, { rootMargin: '0px 0px -10% 0px' });
  document.querySelectorAll('.ext-reveal').forEach(function (el) { reveal.observe(el); });

  var subnav = document.querySelector('.ext-subnav');
  if (subnav) {
    var onScroll = function () { subnav.classList.toggle('scrolled', window.scrollY > 8); };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  var sticky = document.querySelector('.ext-sticky');
  if (!sticky) return;
  var heroGone = false, finalIn = false;
  var sync = function () { var on = heroGone && !finalIn; sticky.classList.toggle('show', on); sticky.setAttribute('aria-hidden', String(!on)); sticky.inert = !on; };
  new IntersectionObserver(function (e) { heroGone = !e[0].isIntersecting && e[0].boundingClientRect.top < 0; sync(); }).observe(document.querySelector('.ext-hero .ext-ctas'));
  new IntersectionObserver(function (e) { finalIn = e[0].isIntersecting; sync(); }).observe(document.querySelector('.ext-final'));
})();
