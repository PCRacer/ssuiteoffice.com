import {
      loadAcademy, readProgress, resumeLesson, resumeInCourse, courseCompletion,
      lessonKey, courseHref, lessonHref, formatDuration, formatReadingTime, lessonSeconds, hasVideo, escapeHtml, ICONS,
    } from '/marketplace/js/agent-builder/academy.js';

    const rowsEl = document.getElementById('acad-rows');
    const noteEl = document.getElementById('acad-note');
    const titleEl = document.getElementById('acad-title');
    const subtitleEl = document.getElementById('acad-subtitle');
    const resumeEl = document.getElementById('acad-resume');

    // history.back() can leave the site entirely when the Academy was opened in
    // a new tab, so only trust it for a same-origin referrer.
    const back = document.getElementById('acad-back');
    back.innerHTML = ICONS.arrowLeft;
    back.addEventListener('click', () => {
      let sameOrigin = false;
      try { sameOrigin = !!document.referrer && new URL(document.referrer).origin === location.origin; } catch { /* opaque */ }
      if (sameOrigin) history.back();
      else location.href = '/agent-builder';
    });

    // Skeleton rows match the course count seen last time, so the list never
    // pretends to know how many courses there are before the API answers.
    const COURSE_COUNT_KEY = 'aitopia.academy.courseCount';
    function rememberedCourseCount() {
      let n = 0;
      try { n = Number(localStorage.getItem(COURSE_COUNT_KEY)); } catch { /* storage blocked */ }
      return Number.isInteger(n) && n > 0 ? n : 3;
    }

    function skeleton() {
      rowsEl.innerHTML = Array.from({ length: rememberedCourseCount() }, () => `
        <li class="acad-row">
          <div class="acad-skel acad-skel-media acad-pulse"></div>
          <div>
            <div class="acad-skel acad-skel-line acad-pulse" style="width:70%;height:1.6rem"></div>
            <div class="acad-skel acad-skel-line acad-pulse" style="margin-top:1rem;width:100%"></div>
            <div class="acad-skel acad-skel-line acad-pulse" style="margin-top:0.5rem;width:85%"></div>
          </div>
        </li>`).join('');
    }

    function note({ title, message, onRetry }) {
      rowsEl.innerHTML = '';
      rowsEl.removeAttribute('aria-busy');
      noteEl.hidden = false;
      noteEl.innerHTML = `<h2>${escapeHtml(title)}</h2><p>${escapeHtml(message)}</p>`;
      if (onRetry) {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.textContent = 'Try again';
        btn.addEventListener('click', onRetry);
        noteEl.appendChild(btn);
      }
    }

    const lessonCount = (n) => `${n} ${n === 1 ? 'lesson' : 'lessons'}`;
    // A course of written lessons is read, not watched; the card must not promise a video.
    const courseHasVideo = (course) => course.lessons.some(hasVideo);

    // Reading time counts too, so a course of written lessons does not say "0:00";
    // and with no video in it, the total is a reading time, not a clock.
    function courseLength(course) {
      const seconds = course.lessons.reduce((sum, l) => sum + lessonSeconds(l), 0);
      return courseHasVideo(course) ? formatDuration(seconds) : formatReadingTime(seconds);
    }

    /** `Play Video` says something different in each of the three states, and
     *  each one lands on a different lesson of the course. */
    function cta(course, progress) {
      const done = courseCompletion(course, progress);
      const video = courseHasVideo(course);
      if (done === course.lessons.length) return { label: video ? 'Replay' : 'Read again', href: lessonHref(course, course.lessons[0]) };
      const touched = done > 0 || course.lessons.some((l) => lessonKey(course, l) === progress.lastWatched);
      if (touched) return { label: 'Resume', href: lessonHref(course, resumeInCourse(course, progress)) };
      return { label: video ? 'Play Video' : 'Start Reading', href: courseHref(course) };
    }

    /** Whole course watched → check; part-way → ring, so the glyph carries the
     *  same meaning it has in the lesson rail. */
    function progressChip(course, progress) {
      const done = courseCompletion(course, progress);
      if (!done) return '';
      const [whole, part] = courseHasVideo(course) ? ['Watched', 'watched'] : ['Read', 'read'];
      const text = done === course.lessons.length ? whole : `${done} of ${course.lessons.length} ${part}`;
      return `<span class="acad-sep">·</span><span class="acad-done">${done === course.lessons.length ? ICONS.check : ICONS.ring}${text}</span>`;
    }

    function renderResume(courses, progress) {
      resumeEl.innerHTML = '';
      if (!progress.completed.length && !progress.lastWatched) return;
      const next = resumeLesson(courses, progress);
      const box = document.createElement('div');
      box.className = 'acad-resume';
      if (!next) {
        box.innerHTML = `<span>You have finished every lesson. <strong>Nicely done.</strong></span>`
          + `<a href="https://aitopia.ai/agent-builder">Back to the builder</a>`;
      } else {
        const position = next.course.lessons.indexOf(next.lesson) + 1;
        box.innerHTML = `<span>Pick up at <strong>${escapeHtml(next.course.title)}</strong> · Lesson ${position} of ${next.course.lessons.length}: ${escapeHtml(next.lesson.title)}</span>`
          + `<a href="${lessonHref(next.course, next.lesson)}">Continue</a>`;
      }
      resumeEl.appendChild(box);
    }

    function renderRows(courses, progress) {
      noteEl.hidden = true;
      rowsEl.removeAttribute('aria-busy');
      try { localStorage.setItem(COURSE_COUNT_KEY, String(courses.length)); } catch { /* private mode */ }
      rowsEl.innerHTML = courses.map((course, i) => {
        const href = courseHref(course);
        const action = cta(course, progress);
        // A course of written lessons has no image anywhere: a title tile beats an empty box.
        const image = course.cardUrl || course.lessons.find((l) => l.posterUrl)?.posterUrl || '';
        return `
          <li class="acad-row">
            ${image ? `<a class="acad-row-media" href="${href}" tabindex="-1" aria-hidden="true">
              <img src="${escapeHtml(image)}" alt="" loading="${i === 0 ? 'eager' : 'lazy'}" decoding="async" width="828" height="482">
            </a>` : `<span class="acad-row-media is-tile" aria-hidden="true">${escapeHtml(course.title)}</span>`}
            <div>
              <h2 class="acad-row-title"><a href="${href}">${escapeHtml(course.title)}</a></h2>
              <p class="acad-row-desc">${escapeHtml(course.description || '')}</p>
              <p class="acad-row-meta">
                <span>${lessonCount(course.lessons.length)}</span>
                <span class="acad-sep">·</span>
                <span>${courseLength(course)}</span>
                ${progressChip(course, progress)}
              </p>
              <a class="acad-cta" href="${action.href}">${action.label}</a>
            </div>
          </li>`;
      }).join('');
    }

    async function render() {
      noteEl.hidden = true;
      rowsEl.setAttribute('aria-busy', 'true');
      skeleton();
      let academy;
      try {
        academy = await loadAcademy();
      } catch (err) {
        console.error('[academy] course load failed', err);
        note({
          title: 'Could not load the courses',
          message: 'The course list did not load. Check your connection and try again.',
          onRetry: render,
        });
        return;
      }
      titleEl.textContent = academy.title;
      subtitleEl.textContent = academy.subtitle;
      if (!academy.courses.length) {
        // No resume banner here: with nothing to resume, stale progress would
        // otherwise print "you finished every lesson" above "no courses yet".
        resumeEl.innerHTML = '';
        note({ title: 'No courses yet', message: 'Lessons are on their way. Check back soon.' });
        return;
      }
      const progress = readProgress();
      renderResume(academy.courses, progress);
      renderRows(academy.courses, progress);
    }

    render();