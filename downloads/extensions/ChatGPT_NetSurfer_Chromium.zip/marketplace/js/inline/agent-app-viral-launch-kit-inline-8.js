window.__AITOPIA_AGENT_RUN__ = {
    agentId: 'app-viral-launch-kit',
    useModelSelector: true
  };