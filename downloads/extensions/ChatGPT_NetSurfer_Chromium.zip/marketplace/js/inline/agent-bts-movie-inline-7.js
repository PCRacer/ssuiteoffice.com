window.__AITOPIA_AGENT_RUN__ = {
    agentId: 'bts-movie',
    useModelSelector: true
  };