window.__AITOPIA_AGENT_RUN__ = {
    agentId: 'bugatti-realistic-shot',
    useModelSelector: true
  };