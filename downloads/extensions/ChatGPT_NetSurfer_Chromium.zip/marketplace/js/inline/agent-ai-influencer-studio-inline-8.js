window.__AITOPIA_AGENT_RUN__ = {
    agentId: 'ai-influencer-studio',
    useModelSelector: true
  };