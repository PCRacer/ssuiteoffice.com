window.__AITOPIA_AGENT_RUN__ = {
    agentId: '3d-christian-cinematic-story',
    useModelSelector: true
  };