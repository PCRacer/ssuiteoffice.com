window.__AITOPIA_AGENT_RUN__ = {
    agentId: 'before-you-buy',
    useModelSelector: true
  };