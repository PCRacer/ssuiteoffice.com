import {
      loadAcademy, findLesson, readProgress, markComplete, markWatching, isComplete,
      courseCompletion, resumeInCourse, lessonKey, courseHref, lessonHref,
      createPlayer, renderLessonBody, formatDuration, escapeHtml,
      hasVideo, doneWord, lessonSeconds, formatReadingTime, observeEnd,
      ICONS, ACADEMY_URL,
    } from '/marketplace/js/agent-builder/academy.js';

    const detailEl = document.getElementById('acad-detail');
    const noteEl = document.getElementById('acad-note');
    const headerTitle = document.getElementById('acad-header-title');

    const back = document.getElementById('acad-back');
    back.innerHTML = ICONS.arrowLeft;
    back.addEventListener('click', () => {
      let sameOrigin = false;
      try { sameOrigin = !!document.referrer && new URL(document.referrer).origin === location.origin; } catch { /* opaque */ }
      if (sameOrigin) history.back();
      else location.href = ACADEMY_URL;
    });

    /** `/academy/:course/:lesson`: the server serves this shell
     *  for any pair, so the segments only mean something once the JSON is in. */
    function currentSlugs() {
      // A malformed escape would throw and leave the skeleton up; kept raw it matches nothing and redirects.
      const decode = (part) => { try { return decodeURIComponent(part); } catch { return part; } };
      const parts = location.pathname.split('/').filter(Boolean).map(decode);
      const base = ACADEMY_URL.split('/').filter(Boolean).length;
      return { courseSlug: parts[base] || '', lessonSlug: parts[base + 1] || '' };
    }

    const STUDIO_URL = '/agent-builder/edit/_new';
    /** How long a reader has to have the end in view before the lesson counts as read. */
    const READ_DWELL_MS = 15000;
    const doneChip = (lesson) => `<span class="acad-sep">·</span><span class="acad-done">${ICONS.check}${hasVideo(lesson) ? 'Watched' : 'Read'}</span>`;
    const plural = (n, word) => `${n} ${word}${n === 1 ? '' : 's'}`;

    function go(target) { location.href = lessonHref(target.course, target.lesson); }

    /** The button that closes a lesson: the next one in this course, the next
     *  course's first, or, once the academy is done, the Studio. */
    function stepLink(next) {
      if (!next) return `<a class="acad-next" href="${STUDIO_URL}">Open the Studio${ICONS.arrowRight}</a>`;
      const label = next.sameCourse ? 'Next Lesson' : 'Next Course';
      return `<a class="acad-next" href="${lessonHref(next.course, next.lesson)}">${label}${ICONS.arrowRight}</a>`;
    }

    function note({ title, message, onRetry }) {
      detailEl.innerHTML = '';
      noteEl.hidden = false;
      noteEl.innerHTML = `<h2>${escapeHtml(title)}</h2><p>${escapeHtml(message)}</p>`;
      if (onRetry) {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.textContent = 'Try again';
        btn.addEventListener('click', onRetry);
        noteEl.appendChild(btn);
      }
    }

    function skeleton() {
      detailEl.innerHTML = `
        <div class="acad-skel acad-pulse" style="aspect-ratio:16/9;border-radius:var(--radius-3xl)"></div>
        <div class="acad-skel acad-pulse" style="height:220px;border-radius:var(--radius-3xl)"></div>`;
    }

    /** The rail is the course: its lessons, where you are in it, and how much
     *  of it is watched. Other courses never show here. */
    function railMarkup(course, lessonIndex, progress) {
      const total = course.lessons.length;
      const done = courseCompletion(course, progress);
      const rows = course.lessons.map((l, i) => {
        const finished = isComplete(course, l, progress);
        const current = i === lessonIndex;
        // Two states, never conflated: the ring marks where you are, the check
        // marks what you finished.
        const glyph = finished ? ICONS.check : ICONS.ring;
        const thumb = l.posterUrl || course.cardUrl || '';
        return `
          <li>
            <a class="acad-rail-row${finished ? ' is-done' : ''}" href="${lessonHref(course, l)}"${current ? ' aria-current="true"' : ''}>
              <span class="acad-rail-thumb">${thumb ? `<img src="${escapeHtml(thumb)}" alt="" loading="lazy" decoding="async">` : ''}</span>
              <span>
                <span class="acad-rail-eyebrow"><span class="acad-rail-status">${glyph}</span>Lesson ${i + 1}${finished ? ` · ${doneWord(l)}` : ''}</span>
                <span class="acad-rail-name">${escapeHtml(l.title)}</span>
              </span>
            </a>
          </li>`;
      }).join('');
      const pct = Math.round((done / total) * 100);
      return `
        <aside class="acad-rail" aria-label="Lessons in this course">
          <div class="acad-rail-head">
            <span class="acad-rail-current">Lesson ${lessonIndex + 1}</span>
            <span class="acad-rail-total">${plural(total, 'Lesson')}</span>
          </div>
          <div class="acad-progress" role="progressbar" aria-label="Lessons completed in this course"
               aria-valuemin="0" aria-valuemax="${total}" aria-valuenow="${done}"
               aria-valuetext="${done} of ${total} lessons completed">
            <i style="width:${pct}%"></i>
          </div>
          <ul class="acad-rail-list">${rows}</ul>
        </aside>`;
    }

    function endCardMarkup(next) {
      if (!next) {
        return `<div class="acad-endcard-inner">
             <div class="acad-endcard-eyebrow">Academy complete</div>
             <p class="acad-endcard-title">That is every lesson. Time to build one.</p>
             <div class="acad-endcard-actions">
               <button type="button" data-act="replay">Replay</button>
               ${stepLink(null)}
             </div>
           </div>`;
      }
      const eyebrow = next.sameCourse ? 'Next' : 'Course complete · up next';
      const title = next.sameCourse ? next.lesson.title : next.course.title;
      return `<div class="acad-endcard-inner">
             <div class="acad-endcard-eyebrow">${eyebrow}</div>
             <p class="acad-endcard-title">${escapeHtml(title)}</p>
             <div class="acad-endcard-actions">
               <button type="button" data-act="replay">Replay</button>
               ${stepLink(next)}
             </div>
           </div>`;
    }

    /** Resolve the URL to a lesson. Unknown course → the list; unknown lesson →
     *  the course; a bare course URL → where you left off, made canonical so a
     *  reload and the rail's current marker agree. */
    function resolve(academy) {
      const { courseSlug, lessonSlug } = currentSlugs();
      const course = academy.courses.find((c) => c.slug === courseSlug);
      if (!course) { location.replace(ACADEMY_URL); return null; }
      if (!lessonSlug) {
        const lesson = resumeInCourse(course, readProgress());
        history.replaceState(null, '', lessonHref(course, lesson));
        return findLesson(academy.courses, course.slug, lesson.slug);
      }
      const found = findLesson(academy.courses, courseSlug, lessonSlug);
      if (!found) { location.replace(courseHref(course)); return null; }
      return found;
    }

    function render(found, playerSettings) {
      const { course, lesson, lessonIndex, next, previous } = found;
      const progress = readProgress();
      const key = lessonKey(course, lesson);

      document.title = `${lesson.title} | ${course.title} | Academy | AITOPIA`;
      headerTitle.textContent = course.title;
      markWatching(key);

      noteEl.hidden = true;
      detailEl.className = hasVideo(lesson) ? 'acad-detail' : 'acad-detail is-notes';
      detailEl.innerHTML = '';

      const video = hasVideo(lesson);

      function completeLesson() {
        markComplete(key);
        const fresh = readProgress();
        const done = courseCompletion(course, fresh);
        const total = course.lessons.length;
        const bar = detailEl.querySelector('.acad-progress');
        if (bar) {
          bar.setAttribute('aria-valuenow', String(done));
          bar.setAttribute('aria-valuetext', `${done} of ${total} lessons completed`);
          bar.querySelector('i').style.width = `${Math.round((done / total) * 100)}%`;
        }
        // Exact href, not a suffix match: a slug can be the tail of another.
        const row = detailEl.querySelector(`.acad-rail-row[href="${lessonHref(course, lesson)}"]`);
        if (row && !row.classList.contains('is-done')) {
          row.classList.add('is-done');
          row.querySelector('.acad-rail-status').innerHTML = ICONS.check;
        }
        const metaRow = detailEl.querySelector('.acad-body .acad-row-meta');
        if (metaRow && !metaRow.querySelector('.acad-done')) metaRow.insertAdjacentHTML('beforeend', doneChip(lesson));
      }

      // Player column. A lesson without a video is its notes: no player, no end card.
      const column = document.createElement('div');
      if (video) {
        const endCard = document.createElement('div');
        endCard.className = 'acad-endcard';
        endCard.hidden = true;
        endCard.innerHTML = endCardMarkup(next);

        const player = createPlayer({
          lesson,
          player: playerSettings,
          endCard,
          onComplete: completeLesson,
        });
        endCard.querySelector('[data-act="replay"]').addEventListener('click', () => {
          player.reset();
          player.activate();
        });
        column.appendChild(player.root);
      }

      // Title row, divider, write-up.
      const titleRow = document.createElement('div');
      titleRow.className = 'acad-titlerow';
      titleRow.innerHTML = `<h2 class="acad-lesson-title">${escapeHtml(lesson.title)}</h2>`;
      column.appendChild(titleRow);
      column.insertAdjacentHTML('beforeend', '<hr class="acad-divider">');

      const body = document.createElement('div');
      body.className = 'acad-body';
      const length = video ? formatDuration(lesson.durationSeconds) : formatReadingTime(lessonSeconds(lesson));
      const meta = `<p class="acad-row-meta"><span>Lesson ${lessonIndex + 1} of ${course.lessons.length}</span>`
        + `<span class="acad-sep">·</span><span>${length}</span>`
        + `${isComplete(course, lesson, progress) ? doneChip(lesson) : ''}</p>`;
      const statusChip = lesson.bodyStatus === 'placeholder'
        ? '<span class="acad-body-status">Summary: full lesson notes coming soon</span>'
        : '';
      body.innerHTML = meta + statusChip + renderLessonBody(lesson.bodyMarkdown) + stepLink(next);
      column.appendChild(body);

      detailEl.appendChild(column);
      detailEl.insertAdjacentHTML('beforeend', railMarkup(course, lessonIndex, progress));

      // Read to the end, and stay there: the end of a short lesson is on screen from the start.
      if (!video && !isComplete(course, lesson, progress)) {
        observeEnd(body.querySelector('.acad-next'), { dwellMs: READ_DWELL_MS }, completeLesson);
      }

      // Keyboard: arrows move between lessons unless focus is inside the
      // player, where they seek (the skin's own hotkeys; focus in its shadow
      // tree retargets to the host, so the check is by ancestor, not tag).
      document.addEventListener('keydown', (e) => {
        if (e.metaKey || e.ctrlKey || e.altKey) return;
        const active = document.activeElement;
        const tag = active?.tagName;
        if (tag === 'INPUT' || tag === 'TEXTAREA' || active?.closest?.('.acad-player')) return;
        if (e.key === 'ArrowRight' && next) go(next);
        if (e.key === 'ArrowLeft' && previous) go(previous);
      });
    }

    async function boot() {
      skeleton();
      let academy;
      try {
        academy = await loadAcademy();
      } catch (err) {
        console.error('[academy] course load failed', err);
        note({
          title: 'Could not load this lesson',
          message: 'The course did not load. Check your connection and try again.',
          onRetry: boot,
        });
        return;
      }
      if (!academy.courses.length) {
        note({ title: 'No courses yet', message: 'Lessons are on their way. Check back soon.' });
        return;
      }
      const found = resolve(academy);
      if (found) render(found, academy.player);
    }

    boot();