window.__AITOPIA_AGENT_RUN__ = {
    agentId: 'arabic-product-ad-video',
    useModelSelector: true
  };