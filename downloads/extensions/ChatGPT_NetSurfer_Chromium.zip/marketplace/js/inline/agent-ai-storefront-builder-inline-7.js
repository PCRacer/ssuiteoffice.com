window.__AITOPIA_AGENT_RUN__ = {
    agentId: 'ai-storefront-builder',
    useModelSelector: true
  };