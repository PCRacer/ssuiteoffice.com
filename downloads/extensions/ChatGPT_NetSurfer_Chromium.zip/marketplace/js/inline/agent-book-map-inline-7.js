window.__AITOPIA_AGENT_RUN__ = {
    agentId: 'book-map',
    useModelSelector: true
  };