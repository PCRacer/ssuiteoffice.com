/**
 * Generation Dock — site-wide visibility for in-flight generations, living in
 * the navbar's bell slot.
 *
 * Self-contained IIFE (navbar.js conventions): exposes `window.GenerationDock`.
 * Structured as swappable roles:
 *   - DataSource : produces DockJob[] (FixtureDataSource / LiveDataSource).
 *   - Store      : job map keyed by jobId, monotonic-progress clamp, dismissed
 *                  set, seen set. Notifies View on change.
 *   - Social     : the user's social alerts (remix / comment / follow / like),
 *                  read from /api/notifications for logged-in users only.
 *   - View       : the trigger button rendered into the navbar's slots
 *                  (the bell, ringed + badged while there is activity), the panel
 *                  (desktop dropdown anchored to the trigger, mobile bottom
 *                  sheet) with keyed row rendering. addEventListener only
 *                  (CSP-safe); user strings rendered via textContent.
 *
 * Mount contract: navbar.js renders `<span data-gen-dock-slot="desktop">` and
 * `<span data-gen-dock-slot="mobile">`; the dock owns everything inside them.
 * The panel, scrim and sheet stay on the body-level root (#genDock): the
 * header's backdrop-filter would make it the containing block for a fixed
 * panel. Without slots the dock runs dormant — store, poll and favicon keep
 * working, the panel is simply unreachable.
 *
 * DockJob contract (§5.2 — field names are frozen; later phases depend on them):
 *   jobId, queueItemId, agentId, displayName, kind, status, progress,
 *   etaDeadline?, createdAt, prompt?, creditsCharged?, thumbnailUrl?, deepLinkUrl, error?
 *   plus the additive optional `retrying?` boolean — a queue `retrying` row maps to
 *   status:'processing' + retrying:true so the View can show the "Retrying…" metric
 *   without overloading the frozen status enum (A3) — and `finishedAt?` (queue
 *   completedAt) for "time since completion" on settled rows.
 */
(function () {
  'use strict';

  const DOCK_VERSION = 'gen-dock-v1';
  if (window.__AITOPIA_GEN_DOCK__ === DOCK_VERSION) return;
  window.__AITOPIA_GEN_DOCK__ = DOCK_VERSION;

  const LS = { dismissed: 'genDock.dismissed', seen: 'genDock.seen' };
  const OUTPUTS_URL = '/marketplace/outputs.html?tab=mine';        // /outputs redirects here (apps/web/src/server.js); tab=mine opens "My creations"
  const ACTIVE_STATUSES = ['queued', 'processing', 'waiting_input'];
  const MOBILE_QUERY = '(max-width: 720px)';

  // Phase C (live data + lifecycle) constants.
  const POLL_MS = 3000;                             // ~3s while ≥1 active job (§3.2)
  const HIDDEN_POLL_MS = 15000;                     // slower background cadence while hidden (keeps the favicon live)
  const WAKE_DELAY_MS = 1500;                       // 202 lands after the generate click; re-fetch late
  const RETENTION_MS = 30 * 24 * 60 * 60 * 1000;    // queue retention window (src/jobs/cleanup.ts DEFAULT_RETENTION_DAYS)
  const CATALOG_FRESH_MS = 5 * 60 * 1000;           // matches the endpoints' Cache-Control max-age
  const SNAPSHOT_KEY = 'genDock.snapshot';          // sessionStorage — instant first paint, reconciled by first fetch
  const CATALOG_KEY = 'genDock.catalog';            // sessionStorage — cached name/kind lookups
  // One request; the server's max limit, so hidden builder rows rarely starve the window (newest 100 of any status).
  const QUEUE_QUERY = 'status=pending,processing,retrying,completed,failed,dead,cancelled&limit=100';
  const QUEUE_ACTIVE = ['pending', 'processing', 'retrying'];
  const SETTLED_VISIBLE_MAX = 10;                   // settled rows shown, newest finished first

  // First run without a genDock.seen key (deploy day, fresh browser): results
  // older than this are seeded as seen so nobody gets a ring for last week.
  const SEEN_SEED_AGE_MS = 24 * 60 * 60 * 1000;

  // Social alerts (logged-in only). Job rows still exist server-side for now;
  // the dock is their only surface, so both requests leave them out.
  const SOCIAL_EXCLUDE = 'job_completed,job_failed,job_dead';
  const SOCIAL_LIST_URL = `https://aitopia.ai/api/notifications?limit=20&exclude=${SOCIAL_EXCLUDE}`;
  const SOCIAL_COUNT_URL = `https://aitopia.ai/api/notifications/unread-count?exclude=${SOCIAL_EXCLUDE}`;
  const SOCIAL_READ_URL = 'https://aitopia.ai/api/notifications/read';
  const SOCIAL_POLL_MS = 60000;
  const READ_VISIBLE_MS = 600;                      // an unread row on screen this long is read
  const READ_DEBOUNCE_MS = 1000;                    // batch the ids into one POST
  const PREVIEW_HEIGHT_PX = 124;
  const PREVIEW_VIDEO_DELAY_MS = 200;               // a pass-over hover never starts a video
  const PEEK_MS = 6000;                             // finish card lingers this long; hover / focus / hidden tab pause it
  const PEEK_LEAVE_MS = 220;                        // the card's fade-out when its countdown runs down

  // ---------------------------------------------------------------------------
  // Utilities
  // ---------------------------------------------------------------------------
  // Strip only the characters that could break out of a double-quoted CSS url("...").
  function cssUrl(url) {
    return 'url("' + String(url ?? '').replace(/["\\\n\r]/g, '') + '")';
  }

  function fmtTime(seconds) {
    const s = Math.max(0, Math.round(Number(seconds) || 0));
    return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
  }

  function timeAgo(value) {
    const ms = Date.parse(value || '');
    if (!Number.isFinite(ms)) return '';
    const diff = Math.max(0, Date.now() - ms);
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);
    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    if (days < 30) return `${days}d ago`;
    return new Date(ms).toLocaleDateString();
  }

  function isActive(job) {
    return ACTIVE_STATUSES.includes(job.status);
  }

  function isMobile() {
    try { return window.matchMedia(MOBILE_QUERY).matches; } catch { return false; }
  }

  // Kind resolution with snapshot back-compat: old sessionStorage snapshots
  // carry thumbnailUrl but no thumbnailKind.
  const VIDEO_URL_RE = /\.(mp4|webm|mov|m4v)([?#]|$)/i;
  function thumbKind(job) {
    if (job.thumbnailKind) return job.thumbnailKind;
    return VIDEO_URL_RE.test(String(job.thumbnailUrl || '')) ? 'video' : 'image';
  }

  // Finished tile: real media when paintable — image thumbnail, or the video's
  // own first frame — otherwise the static glyph tile. Never a gradient, never
  // motion: settled rows are completely still.
  function applyDoneMedia(el, job) {
    const thumb = el.querySelector('.thumb');
    const url = job.thumbnailUrl;
    const kind = url ? thumbKind(job) : null;
    if (kind === 'image') {
      const staleVideo = thumb.querySelector('video');
      if (staleVideo) staleVideo.remove();       // kind corrected video→image: don't let the old frame cover the thumbnail
      thumb.style.background = `${cssUrl(window.AitopiaMedia ? window.AitopiaMedia.image(url, 48) : url)} center/cover no-repeat`;
      el.classList.add('has-media');
      return;
    }
    if (kind === 'video') {
      // display:none does not stop a <video> from fetching — hold off until the
      // panel is open (open() renders again), or every page load would pull
      // metadata for each finished video in the dock.
      if (!panelOpen) { el.classList.remove('has-media'); return; }
      if (thumb.dataset.failedSrc === url) { el.classList.remove('has-media'); return; }   // latched: don't refetch a dead URL every poll
      let video = thumb.querySelector('video');
      if (!video || video.dataset.src !== url) {
        thumb.textContent = '';
        video = document.createElement('video');
        video.dataset.src = url;
        video.muted = true;
        video.playsInline = true;
        video.preload = 'metadata';
        video.addEventListener('error', () => {
          thumb.dataset.failedSrc = url;
          video.remove();
          el.classList.remove('has-media');
        }, { once: true });
        const poster = window.AitopiaMedia ? window.AitopiaMedia.poster(url, 48) : '';
        if (poster) video.poster = poster;
        video.src = (window.AitopiaMedia ? window.AitopiaMedia.preview(url, 48) : url) + '#t=0.1';
        thumb.appendChild(video);
      }
      el.classList.add('has-media');
      return;
    }
    el.classList.remove('has-media');            // audio / no URL → glyph floor
  }

  const GLYPHS = {
    video: '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="5" width="14" height="14" rx="3"/><path d="m16 10 6-3v10l-6-3"/></svg>',
    image: '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="9" cy="9" r="2"/><path d="m21 15-4-4-8 8"/></svg>',
    audio: '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>',
    text: '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7V5h16v2M9 5v14M7 19h4"/></svg>',
    builder: '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2 2 7l10 5 10-5-10-5Z"/><path d="m2 17 10 5 10-5M2 12l10 5 10-5"/></svg>',
    other: '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 8v4l3 2"/></svg>',
  };

  // Social alert glyphs — the notification modal's icon set at dock tile size.
  const SOCIAL_GLYPHS = {
    remix: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>',
    comment: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>',
    like_milestone: '<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg>',
    follow: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="8.5" cy="7" r="4"/><path d="M20 8v6M23 11h-6"/></svg>',
    other: '<span class="social-dot"></span>',
  };

  // The Generate button's filled credit bolt — shared credit-badge language.
  const CREDIT_BOLT = '<svg width="9" height="9" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>';

  // 16px at stroke-width 2 on a 24 viewBox renders the design's 1.33px stroke.
  const chevron = (d) => `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="${d}"/></svg>`;
  const CHEVRON_RIGHT = chevron('m9 18 6-6-6-6');
  const CLOSE_ICON = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M6 18L18 6M6 6l12 12"/></svg>';
  // Row glyphs as SVG too: Inter has no ✕ / ↻ / ▶ / ✓, so as text they'd sit
  // wherever each browser's fallback font puts them.
  const RETRY_ICON = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/></svg>';
  const PLAY_ICON = '<svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M8 5v14l11-7z"/></svg>';
  const FAIL_ICON = '<svg width="8" height="8" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M6 18L18 6M6 6l12 12"/></svg>';
  const CHECK_ICON = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12 5 5L20 7"/></svg>';
  // The navbar's bell, so the idle trigger reads as "alerts" to a user with no generations.
  const BELL_ICON = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8a6 6 0 10-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>';

  // ---------------------------------------------------------------------------
  // Styles (injected once — follows countdown-banner.js convention)
  // ---------------------------------------------------------------------------
  function injectStyles() {
    if (document.getElementById('gen-dock-styles')) return;
    const style = document.createElement('style');
    style.id = 'gen-dock-styles';
    style.textContent = STYLE_TEXT;
    document.head.appendChild(style);
  }

  const STYLE_TEXT = `
  @property --gd-angle { syntax: '<angle>'; inherits: false; initial-value: 0deg; }
  /* Dock-local tokens: --success/--warning/--info are not defined site-wide, so the
     dock supplies namespaced --gd-* versions (light + dark). Everything else comes from
     the brand palette (--primary/--card/--border/--secondary/--muted-foreground/--ait-m-foreground).
     The trigger lives in the header, outside the root, so it carries them too. */
  .gen-dock, .gd-trigger {
    --gd-success: 128 45% 28%;
    --gd-warning: 45 93% 47%;
    --gd-info: 199 89% 48%;
    --gd-danger: 0 84.2% 60.2%;
  }
  .dark .gen-dock, .dark .gd-trigger {
    --gd-success: 128 45% 56%;
    --gd-warning: 45 93% 58%;
    --gd-info: 199 89% 60%;
    --gd-danger: 0 72% 58%;
  }

  /* -------------------------------------------------------------------------
     Navbar slots + trigger. Tailwind in public/ is precompiled and its lg:flex
     outranks hidden in the cascade, so slot visibility is owned here: the
     desktop slot shows ≥1024px, the mobile one below, both only while .gd-on.
     ------------------------------------------------------------------------- */
  [data-gen-dock-slot] { display: none; align-items: center; justify-content: center; }
  @media (min-width: 1024px) { [data-gen-dock-slot="desktop"].gd-on { display: inline-flex; } }
  @media (max-width: 1023.98px) { [data-gen-dock-slot="mobile"].gd-on { display: inline-flex; } }

  /* The bell never leaves. Generation state rides around it: a ring at the
     button's rim plus a small count badge at the bottom-right corner. Unread
     alerts keep the header's original badge (18px red, top-right, count). */
  .gd-trigger {
    position: relative; width: 40px; height: 40px; padding: 0; border-radius: 999px;
    border: none; background: transparent; color: hsl(var(--nav-muted, var(--ait-m-muted-foreground)));
    display: inline-flex; align-items: center; justify-content: center; cursor: pointer;
    font-family: 'Inter', system-ui, sans-serif; transition: background .15s;
  }
  .gd-trigger:hover { background: hsl(var(--ait-m-secondary)); }
  .gd-trigger:focus-visible { outline: 2px solid hsl(var(--ait-m-primary)); outline-offset: 2px; }
  .gd-trigger .gd-bell { display: flex; }
  .gd-trigger .gd-ring {
    position: absolute; inset: 0; pointer-events: none;
    opacity: 0; transform: scale(.85); transition: opacity .18s, transform .25s cubic-bezier(.2,1.1,.35,1);
  }
  .gd-trigger .gd-ring svg { position: absolute; inset: 0; width: 100%; height: 100%; transform: rotate(-90deg); overflow: visible; }
  /* Track = muted-foreground: --secondary is near-invisible on the white light header (U3). */
  .gd-trigger .gd-track { fill: none; stroke: hsl(var(--ait-m-muted-foreground) / .25); stroke-width: 2.5; }
  .gd-trigger .gd-bar {
    fill: none; stroke: hsl(var(--ait-m-primary)); stroke-width: 2.5; stroke-linecap: round;
    stroke-dasharray: 100; stroke-dashoffset: calc(100 - var(--p, 0));
    transition: stroke-dashoffset .6s ease, stroke .3s; transform-box: fill-box; transform-origin: center;
  }
  .gd-trigger:not([data-state="idle"]) .gd-ring { opacity: 1; transform: scale(1); }
  /* Nothing reports progress yet: spin a 26% arc rather than show an empty ring (B4). */
  .gd-trigger.indeterminate .gd-bar { stroke-dasharray: 26 100; stroke-dashoffset: 0; animation: gdRingSpin 1.1s linear infinite; }
  @keyframes gdRingSpin { to { transform: rotate(360deg); } }
  .gd-trigger .gd-n, .gd-trigger .gd-sdot {
    position: absolute; border-radius: 999px; display: none; align-items: center; justify-content: center;
    font-size: 10px; font-weight: 800; line-height: 1; font-variant-numeric: tabular-nums; letter-spacing: -.02em;
    color: #fff; box-shadow: 0 0 0 2px hsl(var(--ait-m-background)); pointer-events: none;
  }
  .gd-trigger .gd-n { right: -1px; bottom: -1px; min-width: 16px; height: 16px; padding: 0 4px; background: hsl(var(--ait-m-primary)); }
  .gd-trigger:not([data-state="idle"]) .gd-n:not(:empty) { display: inline-flex; }
  .gd-trigger.gd-nocount .gd-n:not(:empty) { display: none; }
  .gd-trigger[data-state="attention"] .gd-bar { stroke: hsl(var(--gd-info)); }
  .gd-trigger[data-state="attention"] .gd-n { background: hsl(var(--gd-info)); }
  .gd-trigger[data-state="ready"] .gd-bar { stroke: hsl(var(--gd-success)); }
  .gd-trigger[data-state="ready"] .gd-n { background: hsl(var(--gd-success)); }
  .gd-trigger[data-state="failed"] .gd-bar { stroke: hsl(var(--gd-danger)); }
  .gd-trigger[data-state="failed"] .gd-n { background: hsl(var(--gd-danger)); }
  .gd-trigger .gd-sdot { top: -2px; right: -2px; min-width: 18px; height: 18px; padding: 0 4px; background: hsl(var(--gd-danger)); }
  .gd-trigger.has-social .gd-sdot { display: inline-flex; }
  .gd-trigger.pulse { animation: gdTrigPulse 1.2s ease-out 1; }
  @keyframes gdTrigPulse {
    0%   { box-shadow: 0 0 0 0 hsl(var(--gd-success) / .5); }
    70%  { box-shadow: 0 0 0 10px hsl(var(--gd-success) / 0); }
    100% { box-shadow: 0 0 0 0 hsl(var(--gd-success) / 0); }
  }

  /* -------------------------------------------------------------------------
     Body-level root: a zero-size fixed anchor whose fixed children (scrim,
     panel / sheet) are viewport-relative. It never needs a box of its own.
     ------------------------------------------------------------------------- */
  .gen-dock { position: fixed; top: 0; left: 0; width: 0; height: 0; z-index: 200; font-family: 'Inter', system-ui, sans-serif; }

  .dock-surface {
    background: hsl(var(--ait-m-card));
    border: 1px solid hsl(var(--ait-m-border));
  }

  /* Transparent click-catcher on desktop; the dimmed scrim on mobile below. */
  .dock-scrim { display: none; position: fixed; inset: 0; z-index: 1; background: transparent; }
  .gen-dock.open .dock-scrim { display: block; }

  /* Desktop dropdown, anchored to the trigger's rect on open + resize (B2). */
  .dock-panel {
    display: none; position: fixed; z-index: 2;
    top: var(--gd-top, 64px); right: var(--gd-right, 24px);
    width: min(380px, calc(100vw - 24px));
    max-height: min(70vh, 600px, calc(100vh - var(--gd-top, 64px) - 16px));
    flex-direction: column;
    border-radius: 16px;
    box-shadow: 0 24px 56px -24px rgb(0 0 0 / .45), 0 0 0 1px rgb(0 0 0 / .02);
    transform-origin: top right;
  }
  .gen-dock.open .dock-panel { display: flex; animation: gdPanelIn .22s cubic-bezier(.22,1,.36,1); }
  @keyframes gdPanelIn { from { opacity: 0; transform: scale(.96) translateY(-6px); } }
  .dock-panel:focus { outline: none; }
  .dock-grabber { display: none; }

  .dock-head { position: relative; display: flex; align-items: center; gap: 10px; padding: 16px 20px 15px; flex-shrink: 0; }
  .dock-head::after {
    content: ''; position: absolute; left: 20px; right: 20px; bottom: 0; height: 1px;
    background: hsl(var(--ait-m-muted-foreground) / .18);
  }
  .dock-title { font-size: 15px; font-weight: 600; line-height: 18px; color: hsl(var(--ait-m-foreground)); }
  .dock-sub { margin-top: 2px; font-size: 12px; line-height: 16px; color: hsl(var(--ait-m-muted-foreground)); font-variant-numeric: tabular-nums; }
  .dock-close {
    margin: 0 -4px 0 auto; padding: 0;
    border: none; background: transparent; color: hsl(var(--ait-m-muted-foreground));
    width: 26px; height: 26px; border-radius: 8px;
    display: flex; align-items: center; justify-content: center;
    cursor: pointer; font-family: inherit; transition: background .15s, color .15s;
  }
  .dock-close:hover { background: hsl(var(--ait-m-secondary) / .8); color: hsl(var(--ait-m-foreground)); }

  .dock-rows { overflow-y: auto; padding: 4px 0 8px; min-height: 0; flex: 1 1 auto; scrollbar-width: thin; }
  .dock-rows::-webkit-scrollbar { width: 6px; }
  .dock-rows::-webkit-scrollbar-thumb { background: hsl(var(--ait-m-muted-foreground) / .25); border-radius: 999px; }

  /* Section label: name · count ........ contextual batch action */
  .sec { display: flex; align-items: baseline; gap: 6px; padding: 12px 20px 4px; }
  .sec-t { font-size: 13px; font-weight: 600; line-height: 20px; color: hsl(var(--ait-m-muted-foreground)); }
  .sec-n { font-size: 11px; font-weight: 700; color: hsl(var(--ait-m-muted-foreground) / .65); font-variant-numeric: tabular-nums; }
  /* Negative margins grow the hit target without moving the label. */
  .sec-act {
    margin: -4px -8px -4px auto; border: none; background: transparent; padding: 4px 8px; cursor: pointer;
    font-family: inherit; font-size: 12px; font-weight: 600; line-height: 20px;
    color: hsl(var(--ait-m-muted-foreground)); opacity: .85; transition: color .15s; border-radius: 6px;
  }
  .sec-act:hover { color: hsl(var(--ait-m-foreground)); opacity: 1; }

  .dock-footer { display: flex; justify-content: center; padding: 12px 20px 14px; flex-shrink: 0; border-top: 1px solid hsl(var(--ait-m-muted-foreground) / .12); }
  .dock-footer a {
    font-size: 12px; font-weight: 600; line-height: 18px;
    color: hsl(var(--ait-m-primary)); text-decoration: none;
  }
  .dock-footer a:hover { text-decoration: underline; }

  /* Rows — edge-to-edge so a row's hover bleeds the full panel width. The whole
     row is the route into the run; the chevron stays as the visible affordance. */
  .dock-row {
    position: relative; display: flex; align-items: center; gap: 10px; padding: 8px 20px; cursor: pointer;
    transition: background .15s, opacity .3s, transform .3s;
  }
  .dock-row:hover { background: hsl(var(--ait-m-secondary) / .35); }
  .dock-row.removing { opacity: 0; transform: translateX(30px); }

  .row-media {
    position: relative; width: 48px; height: 48px; border-radius: 16px; flex-shrink: 0;
    display: flex; align-items: center; justify-content: center;
    background: hsl(var(--ait-m-secondary)); overflow: hidden;
  }
  .row-media .type-glyph { position: relative; z-index: 1; color: hsl(var(--ait-m-muted-foreground) / .9); display: flex; }
  .row-media .thumb {
    position: absolute; inset: 0; z-index: 2; opacity: 0; transform: scale(1.3);
    transition: opacity .5s, transform .8s cubic-bezier(.2,1.1,.35,1);
  }
  .row-media .thumb video { width: 100%; height: 100%; object-fit: cover; display: block; }
  /* Solid play badge — centered chip on real media, green corner chip on the glyph floor. */
  .row-media .play {
    position: absolute; z-index: 3; display: none; align-items: center; justify-content: center;
    left: 50%; top: 50%; transform: translate(-50%, -50%);
    width: 20px; height: 20px; border-radius: 999px;
    background: rgb(0 0 0 / .55); color: #fff;
    box-shadow: 0 1px 6px rgb(0 0 0 / .35);
  }
  .dock-row[data-status="done"].is-video:not(.has-media) .row-media .play {
    left: auto; top: auto; right: 4px; bottom: 4px; transform: none;
    width: 16px; height: 16px;
    background: hsl(var(--gd-success) / .9);
  }
  .dock-row[data-status="done"].is-video:not(.has-media) .row-media .play svg { width: 8px; height: 8px; }
  /* Failure speaks from the tile corner; the kind glyph stays visible. */
  .row-media .fail-x {
    position: absolute; right: 4px; bottom: 4px; z-index: 3;
    width: 16px; height: 16px; border-radius: 999px;
    display: none; align-items: center; justify-content: center;
    background: hsl(var(--gd-danger) / .92); color: #fff;
    box-shadow: 0 1px 4px rgb(0 0 0 / .35);
  }

  /* Two text lines in the first column; the metric fills the second column
     across both, so it centres on the row like the action buttons beside it. */
  .row-body { flex: 1; min-width: 0; display: grid; grid-template-columns: minmax(0, 1fr) auto; align-items: center; }
  .row-top, .row-sub { grid-column: 1; }
  .row-top { display: flex; align-items: center; gap: 6px; }
  .row-name { min-width: 0; font-size: 14px; font-weight: 500; line-height: 18px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; color: hsl(var(--ait-m-foreground)); }
  .row-metric, .row-credits { grid-column: 2; grid-row: 1 / span 2; justify-self: end; margin-left: 6px; font-size: 12px; line-height: 18px; color: hsl(var(--ait-m-muted-foreground)); white-space: nowrap; font-variant-numeric: tabular-nums; }
  .row-metric:empty { display: none; }
  .row-sub { display: flex; align-items: center; gap: 6px; margin-top: 2px; font-size: 12px; line-height: 18px; color: hsl(var(--ait-m-muted-foreground)); white-space: nowrap; overflow: hidden; }
  .row-sub .prompt { overflow: hidden; text-overflow: ellipsis; }
  /* A failed row states its reason where the prompt was; tooltip stays as backup. */
  .row-sub .err { display: none; color: hsl(var(--gd-danger) / .9); overflow: hidden; text-overflow: ellipsis; }
  /* Credits sit under the metric, right-aligned, so every row lines up the same way. */
  .dock-row.has-credits .row-metric { grid-row: 1; }
  .row-credits { grid-row: 2; margin-top: 2px; display: inline-flex; align-items: center; gap: 2px; }
  .row-credits svg { color: hsl(var(--ait-m-primary)); }

  /* Ink, not pills: the only settled word left is an actionable one. */
  .row-metric.tone-info { color: hsl(var(--gd-info)); }

  /* Row actions */
  .row-action { flex-shrink: 0; display: flex; align-items: center; gap: 2px; margin-right: -6px; }
  .btn-open, .btn-dismiss, .btn-retry {
    width: 24px; height: 24px; padding: 0; border: none; background: transparent; border-radius: 8px;
    display: flex; align-items: center; justify-content: center;
    color: hsl(var(--ait-m-muted-foreground)); cursor: pointer; font-family: inherit;
    transition: opacity .15s, background .15s, color .15s;
  }
  /* The chevron is the row's route into the run, and non-destructive — so it stays
     on screen rather than hiding behind a hover like the ✕ next to it. */
  .btn-dismiss { opacity: 0; }
  .dock-row:hover .btn-dismiss { opacity: 1; }
  /* Touch devices have no hover — keep row actions visible and comfortably tappable. */
  @media (hover: none) {
    .btn-dismiss { opacity: 1; }
    .btn-open, .btn-dismiss, .btn-retry { width: 32px; height: 32px; }
  }
  .btn-open:hover, .btn-dismiss:hover, .btn-retry:hover { background: hsl(var(--ait-m-secondary) / .8); color: hsl(var(--ait-m-foreground)); }
  .dock-row[data-status="cancelled"] .btn-dismiss { opacity: .8; }
  /* Compact: this row also carries the "Needs input" metric, and both compete
     with the name for the same 380px. */
  .btn-continue {
    border: none; background: hsl(var(--gd-info) / .14); color: hsl(var(--gd-info));
    font-family: inherit; font-size: 11.5px; font-weight: 700; line-height: 18px;
    padding: 3px 8px; margin-left: 2px; border-radius: 999px; cursor: pointer; transition: background .15s;
  }
  .btn-continue:hover { background: hsl(var(--gd-info) / .22); }

  /* In-flight tile: the type glyph stays visible (the tile says WHAT is coming);
     a thin light tracing the rim says it's being worked on. Known progress
     fills the same ring instead of spinning it. */
  .dock-row[data-status="queued"] .row-media::before,
  .dock-row[data-status="processing"] .row-media::before { content: ''; }
  .row-media::before {
    content: none; position: absolute; inset: 0; z-index: 1;
    border-radius: inherit; padding: 1.5px;
    background: conic-gradient(from var(--gd-angle, 0deg), transparent 0turn .58turn, hsl(var(--ait-m-primary) / .95) .8turn, transparent .96turn);
    -webkit-mask: linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0);
    -webkit-mask-composite: xor;
    mask: linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0);
    mask-composite: exclude;
    animation: gdTrace 2.6s linear infinite;
  }
  @keyframes gdTrace { to { --gd-angle: 360deg; } }
  .dock-row[data-status="processing"].has-p .row-media::before {
    background: conic-gradient(hsl(var(--ait-m-primary)) calc(var(--p) * 1%), hsl(var(--ait-m-muted-foreground) / .18) 0);
    animation: none;
  }
  /* Queued — same placeholder, parked: dimmed tile, trace not moving. */
  .dock-row[data-status="queued"] .row-media { opacity: .5; }
  .dock-row[data-status="queued"] .row-media::before { animation-play-state: paused; }
  .dock-row[data-status="queued"] .row-metric { color: hsl(var(--gd-warning)); }

  /* Done */
  .dock-row[data-status="done"] .row-media .thumb { opacity: 1; transform: scale(1); }
  .dock-row[data-status="done"].has-media .row-media .type-glyph { display: none; }
  .dock-row[data-status="done"].is-video .row-media .play { display: flex; }
  .dock-row.just-done { animation: gdDonePulse 1.15s ease-out 1; }
  @keyframes gdDonePulse {
    0%   { box-shadow: inset 0 0 0 0 hsl(var(--gd-success) / .5); }
    70%  { box-shadow: inset 0 0 0 3px hsl(var(--gd-success) / 0); }
    100% { box-shadow: inset 0 0 0 0 hsl(var(--gd-success) / 0); }
  }

  /* Failed + dead */
  .dock-row[data-status="failed"] .row-media .fail-x,
  .dock-row[data-status="dead"] .row-media .fail-x { display: flex; }
  .dock-row[data-status="failed"] .prompt, .dock-row[data-status="dead"] .prompt { display: none; }
  .dock-row[data-status="failed"] .err, .dock-row[data-status="dead"] .err { display: inline; }

  /* Waiting for input (checkpoint-paused builder runs) — distinct, never a spinner */
  .dock-row[data-status="waiting_input"] .row-media { background: hsl(var(--gd-info) / .12); }
  .dock-row[data-status="waiting_input"] .row-media .type-glyph { color: hsl(var(--gd-info)); }

  /* Cancelled — neutral gray */
  .dock-row[data-status="cancelled"] { opacity: .75; }
  .dock-row[data-status="cancelled"] .row-media { color: hsl(var(--ait-m-muted-foreground) / .6); }
  .dock-row[data-status="cancelled"] .row-name { color: hsl(var(--ait-m-muted-foreground)); }

  /* All caught up */
  .all-done { display: flex; flex-direction: column; align-items: center; gap: 6px; padding: 30px 0 26px; color: hsl(var(--ait-m-muted-foreground)); }
  .all-done .big {
    width: 28px; height: 28px; border-radius: 999px; display: flex; align-items: center; justify-content: center;
    background: hsl(var(--gd-success) / .14); color: hsl(var(--gd-success));
  }
  .all-done .msg { font-size: 12.5px; font-weight: 600; }

  /* Social rows: same anatomy, the alert's colored icon at dock size. Unread
     styling holds until the panel closes, even after the row has been read. */
  .dock-row.social .row-media { border-radius: 14px; }
  .dock-row.social .row-media.remix { background: hsl(var(--ait-m-primary) / .12); color: hsl(var(--ait-m-primary)); }
  .dock-row.social .row-media.comment { background: rgb(234 179 8 / .12); color: #eab308; }
  .dock-row.social .row-media.like_milestone { background: rgb(236 72 153 / .12); color: #ec4899; }
  .dock-row.social .row-media.follow { background: rgb(59 130 246 / .12); color: #3b82f6; }
  .dock-row.social .social-dot { width: 6px; height: 6px; border-radius: 999px; background: currentColor; }
  .dock-row.social .row-name { white-space: normal; line-height: 17px; }
  .dock-row.social.unread .row-name { font-weight: 600; }
  .dock-row.social .udot { width: 7px; height: 7px; border-radius: 999px; background: hsl(var(--ait-m-primary)); flex-shrink: 0; visibility: hidden; }
  .dock-row.social.unread .udot { visibility: visible; }
  .dock-row.social:not(.unread) { opacity: .75; }

  /* Hover preview for finished rows — owned by the panel so the scroll box
     cannot clip it. */
  .hover-preview {
    display: none; position: absolute; right: calc(100% + 12px); width: 200px; height: ${PREVIEW_HEIGHT_PX}px;
    border-radius: 14px; background-size: cover; background-position: center;
    box-shadow: 0 20px 48px -20px rgb(0 0 0 / .6); border: 1px solid hsl(var(--ait-m-border)); z-index: 5;
    animation: gdPanelIn .18s ease-out; pointer-events: none;
  }
  .hover-preview.show { display: block; }
  .hover-preview.is-video { background: hsl(var(--ait-m-secondary)); }
  .hover-preview canvas, .hover-preview video { display: none; position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; border-radius: inherit; }
  .hover-preview.has-frame canvas { display: block; }
  /* The row's first frame shows at once; the video fades in over it once it actually plays. */
  .hover-preview.is-video video { display: block; opacity: 0; transition: opacity .2s; }
  .hover-preview.is-playing video { opacity: 1; }
  /* Touch fires mouseover on tap and never mouseleave — the preview would stick. */
  @media (hover: none) { .hover-preview { display: none !important; } }

  /* Finish card — bottom-right, only when no trigger is in view (the header
     scrolls away with the page), so a finish still has exactly one visible
     cue. Lingers PEEK_MS, hover pauses it, opening the panel removes it. */
  .dock-peek {
    display: none; position: fixed; right: 20px; bottom: 20px; z-index: 3;
    width: 320px; max-width: calc(100vw - 28px);
    align-items: center; gap: 10px; padding: 10px 8px 10px 12px; border-radius: 14px; overflow: hidden;
    box-shadow: 0 24px 56px -24px rgb(0 0 0 / .45), 0 0 0 1px rgb(0 0 0 / .02);
    cursor: pointer; animation: gdPeekIn .28s cubic-bezier(.22,1,.36,1);
    transition: box-shadow .2s, transform .2s;
  }
  .gen-dock.peek-on .dock-peek { display: flex; }
  .dock-peek:hover { transform: translateY(-1px); box-shadow: 0 28px 60px -24px rgb(0 0 0 / .55), 0 0 0 1px rgb(0 0 0 / .03); }
  .dock-peek.leaving { animation: gdPeekOut .22s ease-in forwards; pointer-events: none; }
  @keyframes gdPeekIn { from { opacity: 0; transform: translateY(10px); } }
  @keyframes gdPeekOut { to { opacity: 0; transform: translateY(8px); } }
  /* Countdown: drains left→right over PEEK_MS; frozen while paused. Driven by
     script (not a CSS animation) so pause/resume keeps it exact. */
  .peek-bar {
    position: absolute; left: 0; right: 0; bottom: 0; height: 2px; pointer-events: none;
    background: hsl(var(--gd-success) / .7); transform-origin: left; transform: scaleX(1);
  }
  .dock-peek.failed .peek-bar { background: hsl(var(--gd-danger) / .7); }
  .peek-media {
    width: 40px; height: 40px; border-radius: 12px; flex-shrink: 0;
    display: flex; align-items: center; justify-content: center;
    background: hsl(var(--ait-m-secondary)) center/cover no-repeat; color: hsl(var(--ait-m-muted-foreground) / .9);
  }
  .peek-media.has-media .type-glyph { display: none; }
  .peek-media .type-glyph { display: flex; }
  .peek-text { flex: 1; min-width: 0; }
  .peek-state { display: flex; align-items: center; gap: 5px; font-size: 11px; font-weight: 700; line-height: 14px; color: hsl(var(--gd-success)); }
  .peek-state::before { content: ''; width: 6px; height: 6px; border-radius: 999px; background: currentColor; }
  .dock-peek.failed .peek-state { color: hsl(var(--gd-danger)); }
  .peek-name { font-size: 13px; font-weight: 600; line-height: 17px; color: hsl(var(--ait-m-foreground)); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .peek-open {
    flex-shrink: 0; border: none; background: hsl(var(--ait-m-primary) / .12); color: hsl(var(--ait-m-primary));
    font-family: inherit; font-size: 12px; font-weight: 700; line-height: 18px; padding: 5px 11px; border-radius: 999px; cursor: pointer;
    transition: background .15s;
  }
  .peek-open:hover { background: hsl(var(--ait-m-primary) / .2); }
  .peek-close {
    flex-shrink: 0; width: 24px; height: 24px; padding: 0; border: none; background: transparent; border-radius: 8px;
    display: flex; align-items: center; justify-content: center; color: hsl(var(--ait-m-muted-foreground)); cursor: pointer;
    transition: background .15s, color .15s;
  }
  .peek-close:hover { background: hsl(var(--ait-m-secondary) / .8); color: hsl(var(--ait-m-foreground)); }
  /* Clears the global bottom tab bar (<1024px) and the phone's home indicator. */
  @media (max-width: 1023.98px) {
    body.has-bottom-tabs .dock-peek { bottom: calc(61px + 16px + env(safe-area-inset-bottom)); }
  }

  /* -------------------------------------------------------------------------
     Mobile (≤720px): the same panel as a bottom sheet — scrim, grabber,
     drag-to-dismiss, body-scroll lock.
     ------------------------------------------------------------------------- */
  .gd-sheet-lock { overflow: hidden; }

  @media (max-width: 720px) {
    .dock-scrim {
      display: block; background: rgb(0 0 0 / .5); opacity: 0; pointer-events: none;
      transition: opacity .3s ease;
    }
    .gen-dock.open .dock-scrim { opacity: 1; pointer-events: auto; }

    .dock-panel, .gen-dock.open .dock-panel {
      display: flex; top: auto; right: 0; left: 0; bottom: 0;
      width: 100%; max-width: 100%; max-height: 88vh; max-height: 88dvh;
      border-radius: 16px 16px 0 0;
      padding-bottom: env(safe-area-inset-bottom);
      transform: translateY(110%);
      transition: transform .34s cubic-bezier(.32,.72,0,1);
      animation: none;
      will-change: transform; pointer-events: none;
    }
    .gen-dock.open .dock-panel { transform: translateY(0); pointer-events: auto; }

    /* Drag handle (only meaningful inside the sheet). */
    .dock-grabber {
      display: flex; align-items: center; justify-content: center;
      height: 22px; flex-shrink: 0; touch-action: none; cursor: grab;
    }
    .dock-grabber::before {
      content: ''; width: 40px; height: 4px; border-radius: 999px;
      background: hsl(var(--ait-m-muted-foreground) / .4);
    }
    .hover-preview { display: none !important; }

    .dock-peek { left: 14px; right: 14px; width: auto; max-width: none; bottom: calc(14px + env(safe-area-inset-bottom)); }
    body.has-bottom-tabs .dock-peek { bottom: calc(61px + 14px + env(safe-area-inset-bottom)); }
  }

  /* Narrow phones: the 20px gutters and 12px tile gap eat the name column. */
  @media (max-width: 360px) {
    .dock-head { padding: 14px 16px 13px; }
    .dock-head::after { left: 16px; right: 16px; }
    .sec { padding: 10px 16px 4px; }
    .dock-row { padding: 8px 16px; }
    .row-media { width: 44px; height: 44px; border-radius: 14px; }
    /* The blue Continue pill already says it; the name needs the room here. */
    .dock-row[data-status="waiting_input"] .row-metric { display: none; }
    .dock-footer { padding: 10px 16px 12px; }
  }

  @media (prefers-reduced-motion: reduce) {
    .gen-dock, .gen-dock *, .gen-dock *::before, .gen-dock *::after,
    .gd-trigger, .gd-trigger * { animation: none !important; transition: none !important; }
    /* A static three-quarter arc stands in for the spinning one. */
    .gd-trigger.indeterminate .gd-bar { stroke-dasharray: 75 100; }
  }
  `;

  const TRIGGER_TEMPLATE = `
    <span class="gd-bell" aria-hidden="true">${BELL_ICON}</span>
    <span class="gd-ring" aria-hidden="true">
      <svg viewBox="0 0 36 36"><circle class="gd-track" cx="18" cy="18" r="16"/><circle class="gd-bar" cx="18" cy="18" r="16" pathLength="100"/></svg>
    </span>
    <span class="gd-n" aria-hidden="true"></span>
    <span class="gd-sdot" aria-hidden="true"></span>`;

  const PANEL_TEMPLATE = `
    <div class="dock-scrim" data-act="close-panel"></div>
    <div class="dock-panel dock-surface" id="genDockPanel" role="dialog" aria-label="Generations" tabindex="-1">
      <div class="dock-grabber" aria-hidden="true"></div>
      <div class="dock-head">
        <div>
          <div class="dock-title">Generations</div>
          <div class="dock-sub" id="gdSub"></div>
        </div>
        <button type="button" class="dock-close" id="gdClose" data-act="close-panel" title="Close" aria-label="Close">${CLOSE_ICON}</button>
      </div>
      <div class="dock-rows" id="gdRows">
        <div class="sec" id="gdActiveSec"><span class="sec-t">In progress</span><span class="sec-n"></span></div>
        <div id="gdActiveList"></div>
        <div class="sec" id="gdReadySec"><span class="sec-t">Ready</span><span class="sec-n"></span><button type="button" class="sec-act" data-act="clear-ready" title="Clear finished">Clear</button></div>
        <div id="gdReadyList"></div>
        <div class="sec" id="gdFailedSec"><span class="sec-t">Failed</span><span class="sec-n"></span><button type="button" class="sec-act" data-act="clear-failed" title="Clear failed">Clear</button></div>
        <div id="gdFailedList"></div>
        <div class="all-done" id="gdEmpty"><span class="big">${CHECK_ICON}</span><span class="msg">All caught up</span></div>
        <div class="sec" id="gdSocialSec"><span class="sec-t">Activity</span><span class="sec-n" id="gdSocialNew"></span><button type="button" class="sec-act" id="gdMarkRead" data-act="mark-all-read">Mark all read</button></div>
        <div id="gdSocialList"></div>
      </div>
      <div class="dock-footer">
        <a href="${OUTPUTS_URL}">View all generations →</a>
      </div>
      <div class="hover-preview" id="gdPreview" aria-hidden="true"><canvas></canvas><video muted loop playsinline preload="none"></video></div>
    </div>
    <div class="dock-peek dock-surface" id="gdPeek" role="status" aria-live="polite" data-act="open-panel">
      <div class="peek-media"><span class="type-glyph"></span></div>
      <div class="peek-text"><div class="peek-state" id="gdPeekState"></div><div class="peek-name" id="gdPeekName"></div></div>
      <button type="button" class="peek-open" data-act="peek-open">Open</button>
      <button type="button" class="peek-close" data-act="peek-close" title="Dismiss" aria-label="Dismiss">${CLOSE_ICON}</button>
      <span class="peek-bar" aria-hidden="true"></span>
    </div>
  `;

  const ROW_SKELETON = `
    <div class="row-media">
      <span class="type-glyph"></span>
      <span class="thumb"></span>
      <span class="play">${PLAY_ICON}</span>
      <span class="fail-x">${FAIL_ICON}</span>
    </div>
    <div class="row-body">
      <div class="row-top"><span class="row-name"></span></div>
      <div class="row-sub"><span class="prompt"></span><span class="err"></span></div>
      <span class="row-metric"></span>
      <span class="row-credits"></span>
    </div>
    <span class="row-action"></span>`;

  const SOCIAL_ROW_SKELETON = `
    <div class="row-media"><span class="type-glyph"></span></div>
    <div class="row-body">
      <div class="row-top"><span class="row-name"></span></div>
      <span class="row-metric"></span>
    </div>
    <span class="udot" aria-hidden="true"></span>`;

  // ---------------------------------------------------------------------------
  // Store
  // ---------------------------------------------------------------------------
  function clampProgress(store, job) {
    const out = { ...job };
    let p = Number(out.progress);
    if (!Number.isFinite(p)) p = 0;
    p = Math.min(100, Math.max(0, p));
    if (isActive(out)) {
      const seen = store.maxProgress.get(out.jobId) || 0;
      p = Math.max(seen, p);                       // monotonic per job — never render a lower %
      store.maxProgress.set(out.jobId, p);
    } else if (out.status === 'done') {
      p = 100;
      store.maxProgress.set(out.jobId, 100);
    }
    out.progress = p;
    return out;
  }

  // Shared shape for the two persisted id sets (dismissed, seen): { ids, at }
  // with per-id timestamps, pruned against the queue retention window on load
  // (their queue rows are purged, so they can never reappear — no need to keep
  // remembering them). Returns whether anything was pruned.
  function readIdSet(key, ids, at) {
    ids.clear();
    at.clear();
    const raw = JSON.parse(localStorage.getItem(key) || 'null');
    if (!raw || !Array.isArray(raw.ids)) return { present: raw != null, pruned: false, watermark: 0 };
    const stamps = (raw.at && typeof raw.at === 'object') ? raw.at : {};
    const cutoff = Date.now() - RETENTION_MS;
    let pruned = false;
    raw.ids.forEach((id) => {
      const t = Number(stamps[id]);
      if (Number.isFinite(t) && t < cutoff) { pruned = true; return; }
      ids.add(id);
      if (Number.isFinite(t)) at.set(id, t);
    });
    return { present: true, pruned, watermark: Number(raw.watermark) || 0 };
  }

  function writeIdSet(key, ids, at, extra) {
    const stamps = {};
    for (const [id, t] of at) stamps[id] = t;
    localStorage.setItem(key, JSON.stringify({ ids: [...ids], at: stamps, ...(extra || {}) }));
  }

  const Store = {
    jobs: new Map(),          // jobId -> DockJob
    maxProgress: new Map(),   // jobId -> highest progress seen (monotonic clamp)
    dismissed: new Set(),
    dismissedAt: new Map(),   // jobId -> dismiss time (ms); pruned against RETENTION_MS on load
    dismissWatermark: 0,      // Phase C prunes this against the queue retention window
    seen: new Set(),          // settled jobIds the user has looked at (S2)
    seenAt: new Map(),
    _seedSeen: false,         // no genDock.seen key at load → the first live reconcile seeds it
    live: false,              // set by initLiveMode — gates sessionStorage snapshot writes
    _miss: new Map(),         // jobId -> consecutive fetch-misses (active→settled handoff grace)
    _subs: [],

    load() {
      this._loadDismissed();
      this._loadSeen();
    },

    _loadDismissed() {
      try {
        const { pruned, watermark } = readIdSet(LS.dismissed, this.dismissed, this.dismissedAt);
        this.dismissWatermark = watermark;
        if (pruned) this._persistDismissed();
      } catch {}
    },

    _loadSeen() {
      try {
        const { present, pruned } = readIdSet(LS.seen, this.seen, this.seenAt);
        this._seedSeen = !present;
        if (pruned) this._persistSeen();
      } catch {}
    },

    subscribe(fn) { this._subs.push(fn); },
    _emit() { this._subs.forEach((fn) => fn()); },

    get(id) { return this.jobs.get(id); },
    firstActive() { for (const j of this.jobs.values()) if (isActive(j)) return j; return null; },

    upsert(job) {
      if (!job || !job.jobId || this.dismissed.has(job.jobId)) return;
      this.jobs.set(job.jobId, clampProgress(this, job));
      this._emit();
    },

    upsertMany(list) {
      (list || []).forEach((job) => {
        if (job && job.jobId && !this.dismissed.has(job.jobId)) {
          this.jobs.set(job.jobId, clampProgress(this, job));
        }
      });
      this._emit();
    },

    // Phase C refines active-vs-settled precedence + dedupe; Phase A merges by jobId.
    reconcile(list) { this.upsertMany(list); },

    dismiss(id) {
      this._forget(id);
      this._recordDismissed(id);
      this._persistDismissed();
      this.saveSnapshot();
      this._emit();
    },

    // Batch clears: Ready dismisses every done row, Failed every failed / dead /
    // cancelled row (S4). Cleared rows are still on /creations.
    clearReady() { this._dismissWhere((job) => job.status === 'done'); },
    clearFailed() { this._dismissWhere((job) => !isActive(job) && job.status !== 'done'); },

    _dismissWhere(predicate) {
      for (const [id, job] of [...this.jobs]) {
        if (!predicate(job)) continue;
        this._forget(id);
        this._recordDismissed(id);
      }
      this._persistDismissed();
      this.saveSnapshot();
      this._emit();
    },

    _forget(id) {
      this.jobs.delete(id);
      this.maxProgress.delete(id);
      this._miss.delete(id);
    },

    _recordDismissed(id) {
      const now = Date.now();
      this.dismissed.add(id);
      this.dismissedAt.set(id, now);
      this.dismissWatermark = now;
    },

    isSeen(id) { return this.seen.has(id); },

    // Persists without emitting: callers render afterwards, and render itself
    // marks rows seen while the panel is open.
    markSeen(ids) {
      const now = Date.now();
      let changed = false;
      for (const id of ids || []) {
        if (this.seen.has(id)) continue;
        this.seen.add(id);
        this.seenAt.set(id, now);
        changed = true;
      }
      if (changed) this._persistSeen();
      return changed;
    },

    // Needs-input rows are pinned first inside In progress; Ready is done only;
    // Failed is everything else settled (failed / dead / cancelled).
    getGrouped() {
      const time = (value) => Date.parse(value || '') || 0;
      const active = [];
      const settled = [];
      for (const job of this.jobs.values()) (isActive(job) ? active : settled).push(job);
      active.sort((a, b) => Number(b.status === 'waiting_input') - Number(a.status === 'waiting_input')
        || time(b.createdAt) - time(a.createdAt));
      settled.sort((a, b) => time(b.finishedAt || b.createdAt) - time(a.finishedAt || a.createdAt));
      const recent = settled.slice(0, SETTLED_VISIBLE_MAX);
      return { active, ready: recent.filter((j) => j.status === 'done'), failed: recent.filter((j) => j.status !== 'done') };
    },

    _persistDismissed() {
      try { writeIdSet(LS.dismissed, this.dismissed, this.dismissedAt, { watermark: this.dismissWatermark }); } catch {}
    },

    _persistSeen() {
      try { writeIdSet(LS.seen, this.seen, this.seenAt); } catch {}
    },

    // -----------------------------------------------------------------------
    // Phase C — live reconciliation, snapshot, multi-tab sync
    // -----------------------------------------------------------------------

    // Merge the two live fetches into the job map (§5.1 / D10). Dedupe by jobId:
    // a completing job can appear in BOTH lists for one cycle — active wins so
    // the row stays processing until settled is confirmed the next cycle, giving
    // a single clean active→done flip (the finish-pulse). Jobs that vanish from
    // both lists are pruned: active ones after a short grace (bridges the
    // active→settled handoff), settled ones persist until dismissed (R7 purge
    // happens on reload via retention).
    reconcileLive(active, settled, complete = true) {
      const incoming = new Map();
      (settled || []).forEach((j) => { if (j && j.jobId) incoming.set(j.jobId, j); });
      (active || []).forEach((j) => { if (j && j.jobId) incoming.set(j.jobId, j); });

      // A poll with a failed fetch cannot seed: an empty settled list would
      // write an empty key and every old result would light the ring later.
      if (this._seedSeen && complete) this._seedSeenFrom(settled);

      for (const job of incoming.values()) {
        if (this.dismissed.has(job.jobId)) continue;
        this.jobs.set(job.jobId, clampProgress(this, job));
        this._miss.delete(job.jobId);
      }

      // A failed fetch says nothing about what is gone: only a complete poll
      // may count misses, or a network blip would clear In progress and park
      // the poll with it.
      if (complete) {
        for (const [id, job] of [...this.jobs]) {
          if (incoming.has(id)) continue;
          if (isActive(job)) {
            const n = (this._miss.get(id) || 0) + 1;
            if (n >= 2) { this._forget(id); }
            else this._miss.set(id, n);
          }
        }
      }

      this._emit();
    },

    // First run (B5): results older than 24h are seen, newer ones stay unseen so
    // a result that finished while the user was away still lights the ring.
    // The key is written even when nothing qualifies, so later loads never re-seed.
    _seedSeenFrom(settled) {
      this._seedSeen = false;
      const cutoff = Date.now() - SEEN_SEED_AGE_MS;
      // Rows from before completed_at was written fall back to their creation time.
      const stale = (settled || [])
        .filter((j) => j && j.jobId && !isActive(j) && Date.parse(j.finishedAt || j.createdAt || '') < cutoff)
        .map((j) => j.jobId);
      if (!this.markSeen(stale)) this._persistSeen();
    },

    saveSnapshot() {
      if (!this.live) return;
      try { sessionStorage.setItem(SNAPSHOT_KEY, JSON.stringify([...this.jobs.values()])); } catch {}
    },

    restoreSnapshot() {
      try {
        const arr = JSON.parse(sessionStorage.getItem(SNAPSHOT_KEY) || 'null');
        if (Array.isArray(arr)) {
          arr.forEach((j) => {
            if (j && j.jobId && !this.dismissed.has(j.jobId)) this.jobs.set(j.jobId, clampProgress(this, j));
          });
        }
      } catch {}
    },

    // storage-event handlers (another tab dismissed/cleared or looked at results).
    reloadDismissed() {
      this._loadDismissed();
      for (const id of this.dismissed) this._forget(id);
      this._emit();
    },
    reloadSeen() {
      this._loadSeen();
      this._emit();
    },

    // Fixtures-only: wipe everything (incl. persistence) so scenarios reload cleanly.
    reset() {
      this.jobs.clear();
      this.maxProgress.clear();
      this.dismissed.clear();
      this.dismissedAt.clear();
      this.seen.clear();
      this.seenAt.clear();
      this._miss.clear();
      try { localStorage.removeItem(LS.dismissed); localStorage.removeItem(LS.seen); } catch {}
      this._emit();
    },
  };

  // ---------------------------------------------------------------------------
  // Social alerts — remix / comment / follow / like_milestone for the logged-in
  // user. Guests never hit /api/notifications* (they 401). The list loads on
  // panel open; the unread count polls on a slow cadence while the tab is
  // visible. Reading is per row: an unread row on screen for READ_VISIBLE_MS
  // inside an open panel is read, ids batched into one POST; "Mark all read"
  // posts without ids. Rows keep their unread styling until the panel closes.
  // ---------------------------------------------------------------------------
  const Social = {
    loggedIn: false,
    unread: 0,
    items: [],
    loaded: false,
    stub: null,               // fixtures: { items, unread } instead of the network
    _timer: null,
    _observer: null,
    _visibleSince: new Map(), // notification id -> timer handle while on screen
    _pendingRead: new Set(),  // ids read on screen, waiting for the debounced POST
    _readTimer: null,
    _readIds: new Set(),      // read this session; styling is applied on close

    setLoggedIn(value) {
      const next = !!value;
      if (next === this.loggedIn) return;
      this.loggedIn = next;
      if (next) {
        this._startCountPoll();
        if (panelOpen) this.fetchList();           // the open panel would otherwise wait for the next open
      } else {
        this._stopCountPoll();
        this._disconnect();
        this._pendingRead.clear();
        this._readIds.clear();
        if (this._readTimer) { clearTimeout(this._readTimer); this._readTimer = null; }
        this.unread = 0;
        this.items = [];
        this.loaded = false;
      }
      render();
    },

    _startCountPoll() {
      this.fetchCount();
      if (this._timer) return;
      this._timer = setInterval(() => { if (!document.hidden) this.fetchCount(); }, SOCIAL_POLL_MS);
    },

    _stopCountPoll() {
      if (this._timer) { clearInterval(this._timer); this._timer = null; }
    },

    fetchCount() {
      if (!this.loggedIn) return;
      if (this.stub) { this.unread = this.stub.unread; render(); return; }
      const afterCritical = window.aitopiaLoadOrder ? window.aitopiaLoadOrder.wait('critical') : Promise.resolve();
      afterCritical.then(() => jsonFetch(SOCIAL_COUNT_URL)).then((json) => {
        if (!this.loggedIn || !json || typeof json.count !== 'number') return;   // landed after a logout
        this.unread = json.count;
        render();
      });
    },

    fetchList() {
      if (!this.loggedIn) return;
      if (this.stub) { this._absorb(this.stub.items); return; }
      jsonFetch(SOCIAL_LIST_URL).then((json) => {
        if (!json || !Array.isArray(json.notifications)) return;
        this._absorb(json.notifications);
      });
    },

    _absorb(list) {
      if (!this.loggedIn) return;                  // landed after a logout
      this.items = list.map((n) => ({ ...n }));
      this.loaded = true;
      render();
      this._observe();
    },

    onPanelOpen() { this.fetchList(); },

    onPanelClose() {
      this._disconnect();
      this.items.forEach((n) => { if (this._readIds.has(n.id)) n.isRead = true; });
      this._readIds.clear();
    },

    isUnread(n) { return !n.isRead && !this._readIds.has(n.id); },

    // Per-row read: ≥50% visible for READ_VISIBLE_MS inside the open panel.
    _observe() {
      this._disconnect();
      if (!panelOpen || typeof IntersectionObserver !== 'function') return;
      this._observer = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
          const id = entry.target.getAttribute('data-notif-id');
          if (!id) return;
          const visible = entry.isIntersecting && entry.intersectionRatio >= 0.5;
          const pending = this._visibleSince.get(id);
          if (visible && !pending) {
            this._visibleSince.set(id, setTimeout(() => { this._visibleSince.delete(id); this._readOnScreen(id); }, READ_VISIBLE_MS));
          } else if (!visible && pending) {
            clearTimeout(pending);
            this._visibleSince.delete(id);
          }
        });
      }, { root: els.rows, threshold: [0.5] });
      for (const [id, el] of socialRowEls) {
        const n = this.items.find((item) => item.id === id);
        if (n && this.isUnread(n)) this._observer.observe(el);
      }
    },

    _disconnect() {
      if (this._observer) { this._observer.disconnect(); this._observer = null; }
      for (const handle of this._visibleSince.values()) clearTimeout(handle);
      this._visibleSince.clear();
    },

    _readOnScreen(id) {
      if (document.hidden) return;                 // geometry says visible, the tab is not; re-armed on return
      const n = this.items.find((item) => item.id === id);
      if (!n || !this.isUnread(n)) return;
      this._readIds.add(id);
      this.unread = Math.max(0, this.unread - 1);
      this._pendingRead.add(id);
      if (this._observer) { const el = socialRowEls.get(id); if (el) this._observer.unobserve(el); }
      if (this._readTimer) clearTimeout(this._readTimer);
      this._readTimer = setTimeout(() => this._flushRead(), READ_DEBOUNCE_MS);
      render();
    },

    _flushRead() {
      if (this._readTimer) { clearTimeout(this._readTimer); this._readTimer = null; }
      const ids = [...this._pendingRead];
      this._pendingRead.clear();
      if (ids.length) this._post({ ids });
    },

    markAllRead() {
      if (!this.loggedIn) return;
      this.items.forEach((n) => { if (!n.isRead) this._readIds.add(n.id); });
      this._pendingRead.clear();
      this.unread = 0;
      this._disconnect();
      this._post({});
      render();
    },

    // Row click: that one alert is read, then navigate to it. Reads still
    // waiting in the debounce ride along — the navigation would drop them.
    openRow(id) {
      const n = this.items.find((item) => item.id === id);
      if (!n) return;
      if (this.isUnread(n)) {
        this._readIds.add(id);
        this.unread = Math.max(0, this.unread - 1);
        this._pendingRead.add(id);
        render();
      }
      this._flushRead();
      if (typeof n.url === 'string' && n.url) { try { window.location.assign(n.url); } catch {} }
    },

    // keepalive: the POST may be sent as the page unloads (row click, pagehide).
    _post(body) {
      if (this.stub) return;
      fetch(SOCIAL_READ_URL, {
        method: 'POST', credentials: 'include', keepalive: true,
        headers: { Accept: 'application/json', 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      }).catch(() => {});
    },
  };

  // ---------------------------------------------------------------------------
  // View
  // ---------------------------------------------------------------------------
  const els = {};
  const rowEls = new Map();         // jobId -> row element (keyed rendering enables the in-place done-flip)
  const socialRowEls = new Map();   // notification id -> row element
  const triggers = [];              // { slot, button } per navbar slot
  let panelOpen = false;
  let lastTrigger = null;           // the button that opened the panel; focus returns to it

  function mount() {
    if (els.root) return;
    injectStyles();
    const root = document.createElement('div');
    root.className = 'gen-dock';
    root.id = 'genDock';
    root.innerHTML = PANEL_TEMPLATE;
    document.body.appendChild(root);

    els.root = root;
    els.panel = root.querySelector('#genDockPanel');
    els.scrim = root.querySelector('.dock-scrim');
    els.grabber = root.querySelector('.dock-grabber');
    els.sub = root.querySelector('#gdSub');
    els.close = root.querySelector('#gdClose');
    els.rows = root.querySelector('#gdRows');
    els.activeSec = root.querySelector('#gdActiveSec');
    els.activeList = root.querySelector('#gdActiveList');
    els.readySec = root.querySelector('#gdReadySec');
    els.readyList = root.querySelector('#gdReadyList');
    els.failedSec = root.querySelector('#gdFailedSec');
    els.failedList = root.querySelector('#gdFailedList');
    els.empty = root.querySelector('#gdEmpty');
    els.socialSec = root.querySelector('#gdSocialSec');
    els.socialNew = root.querySelector('#gdSocialNew');
    els.markRead = root.querySelector('#gdMarkRead');
    els.socialList = root.querySelector('#gdSocialList');
    els.preview = root.querySelector('#gdPreview');
    els.previewVideo = els.preview.querySelector('video');
    els.previewFrame = els.preview.querySelector('canvas');
    els.previewVideo.addEventListener('playing', () => { if (els.preview.dataset.src) els.preview.classList.add('is-playing'); });
    els.peek = root.querySelector('#gdPeek');
    els.peekState = root.querySelector('#gdPeekState');
    els.peekName = root.querySelector('#gdPeekName');
    els.peekMedia = root.querySelector('#gdPeek .peek-media');
    els.peekBar = root.querySelector('#gdPeek .peek-bar');

    // Single delegated click listener (CSP-safe: no inline handlers).
    root.addEventListener('click', onClick);
    // Enter / Space on a focusable non-button control (the social rows) acts like a click.
    root.addEventListener('keydown', (event) => {
      if (event.key !== 'Enter' && event.key !== ' ') return;
      const el = event.target;
      if (!(el instanceof Element) || !el.hasAttribute('data-act') || el.matches('button, a')) return;
      event.preventDefault();
      el.click();
    });
    els.rows.addEventListener('mouseover', onRowHover);
    els.rows.addEventListener('mouseleave', hidePreview);
    // The countdown waits while the user is on the card (pointer or keyboard)
    // and while the tab is hidden; it resumes from where it stopped.
    els.peek.addEventListener('mouseenter', pausePeekClock);
    els.peek.addEventListener('mouseleave', resumePeekClock);
    els.peek.addEventListener('touchstart', pausePeekClock, { passive: true });   // no hover on phones: a resting finger holds it
    els.peek.addEventListener('touchend', resumePeekClock);
    els.peek.addEventListener('touchcancel', resumePeekClock);
    els.peek.addEventListener('focusin', pausePeekClock);
    els.peek.addEventListener('focusout', (event) => { if (!els.peek.contains(event.relatedTarget)) resumePeekClock(); });
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) { pausePeekClock(); return; }
      resumePeekClock();
      // A finish while the tab was hidden shows its card once the user is back.
      if (!pendingPeekId) return;
      const job = Store.get(pendingPeekId);
      pendingPeekId = null;
      if (job && !isActive(job)) maybePeek(job);
    });
    document.addEventListener('keydown', (event) => { if (event.key === 'Escape' && panelOpen) close(); });
    window.addEventListener('resize', () => {
      if (panelOpen && !isMobile()) positionPanel();
      if (peekJobId) liftPeekAboveOverlap();
    });
    window.addEventListener('pagehide', () => Social._flushRead());   // reads still in the debounce when the user leaves
    setupMobileSheet();
  }

  // The navbar's slots receive the 40px button only (see the mount contract).
  function mountTriggers() {
    const slots = document.querySelectorAll('[data-gen-dock-slot]');
    slots.forEach((slot) => {
      if (slot.querySelector('.gd-trigger')) return;
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'gd-trigger';
      button.id = slot.getAttribute('data-gen-dock-slot') === 'mobile' ? 'genDockTriggerMobile' : 'genDockTrigger';
      button.dataset.state = 'idle';
      button.setAttribute('aria-expanded', 'false');
      button.setAttribute('aria-controls', 'genDockPanel');
      button.setAttribute('aria-label', 'Generations & notifications');
      button.innerHTML = TRIGGER_TEMPLATE;                 // static markup only
      button.addEventListener('click', () => toggle(button));
      slot.appendChild(button);
      triggers.push({ slot, button });
    });
    return triggers.length > 0;
  }

  function onClick(event) {
    const el = event.target.closest('[data-act]');
    if (!el || !els.root.contains(el)) return;
    const act = el.getAttribute('data-act');
    const rowEl = el.closest('[data-job-id]');
    const notifEl = el.closest('[data-notif-id]');
    handleAction(act, rowEl ? rowEl.getAttribute('data-job-id') : null, notifEl ? notifEl.getAttribute('data-notif-id') : null);
  }

  function ensureRow(job) {
    let el = rowEls.get(job.jobId);
    if (!el) {
      el = document.createElement('div');
      el.className = 'dock-row';
      el.setAttribute('data-job-id', job.jobId);
      el.setAttribute('data-act', 'open');             // the whole row opens the run (S5)
      el.innerHTML = ROW_SKELETON;                     // static markup only — no user data here
      rowEls.set(job.jobId, el);
    }
    return el;
  }

  // Longest believable in-flight run — past this the anchor is a skewed DB
  // timestamp, not an hour-old generation; show nothing over a bogus clock.
  const ELAPSED_TRUST_MS = 60 * 60_000;

  // Time left to the ETA deadline, else elapsed time counting up. The row
  // already sits under "In progress" — a "Generating…" label would say nothing.
  function etaMetric(job) {
    const leftMs = job.etaDeadline - Date.now();
    if (leftMs > 0) return '~' + fmtTime(leftMs / 1000);
    const startMs = Date.parse(job.startedAt || job.createdAt || '');
    if (!Number.isFinite(startMs)) return '';
    const elapsedMs = Date.now() - startMs;
    return elapsedMs > ELAPSED_TRUST_MS ? '' : fmtTime(elapsedMs / 1000);
  }

  function metricText(job) {
    switch (job.status) {
      case 'queued': return 'Queued';
      case 'processing': return job.retrying ? 'Retrying…' : etaMetric(job);
      case 'waiting_input': return 'Needs input';
      case 'done':
      case 'failed':
      case 'dead': return timeAgo(job.finishedAt);
      case 'cancelled': return 'Cancelled';
      default: return '';
    }
  }

  // Only the state that asks something of the user gets colored ink; every other metric stays plain.
  const METRIC_TONE = { waiting_input: 'info' };

  function metricClass(job) {
    const tone = METRIC_TONE[job.status];
    return tone ? `row-metric tone-${tone}` : 'row-metric';
  }

  function actionHtml(job) {
    const dismiss = `<button type="button" class="btn-dismiss" data-act="dismiss" title="Dismiss" aria-label="Dismiss">${CLOSE_ICON}</button>`;
    const retry = `<button type="button" class="btn-retry" data-act="retry" title="Retry" aria-label="Retry">${RETRY_ICON}</button>`;
    // Jumps to the run's own waiting card (`?jobId=` force-opens the agent's
    // History tab). Stays rightmost so every row has the same route in.
    const open = `<button type="button" class="btn-open" data-act="open" title="Open this generation" aria-label="Open this generation">${CHEVRON_RIGHT}</button>`;
    const cont = '<button type="button" class="btn-continue" data-act="open">Continue</button>';
    switch (job.status) {
      // No cancel affordance: store runs execute fire-and-forget at submission
      // (jobs row is 'processing' within ~30ms), so the server refuses almost
      // every cancel (400 CANNOT_CANCEL / INVALID_STATUS) — a ✕ here would be
      // a broken promise. Active rows only offer the way into the run.
      case 'queued':
      case 'processing': return open;
      // A waiting_input row's job is already completed and its run idle — the
      // one ACTIVE state the user can acknowledge away. Abandoned checkpoints
      // cannot be cancelled server-side, so without ✕ the ring would stay blue
      // forever (B3).
      case 'waiting_input': return dismiss + cont;
      case 'done':
      case 'failed': return dismiss + open;
      case 'dead': return dismiss + retry + open;
      case 'cancelled': return dismiss;
      default: return '';
    }
  }

  function updateRow(job) {
    const el = ensureRow(job);
    const prev = el.dataset.status;
    el.dataset.status = job.status;
    // A finished row's badge follows what it produced: builder agents and apps can output video too.
    el.classList.toggle('is-video', job.thumbnailUrl ? thumbKind(job) === 'video' : job.kind === 'video');

    const kind = GLYPHS[job.kind] ? job.kind : 'other';
    if (el.dataset.kind !== kind) {
      el.dataset.kind = kind;
      el.querySelector('.type-glyph').innerHTML = GLYPHS[kind];
    }

    // User-originated strings via textContent (the escaping mechanism — never innerHTML).
    el.querySelector('.row-name').textContent = job.displayName || prettifyId(job.agentId);

    const promptEl = el.querySelector('.prompt');
    if (job.prompt) { promptEl.textContent = job.prompt; promptEl.style.display = ''; }
    else promptEl.style.display = 'none';

    const creditsEl = el.querySelector('.row-credits');
    // The server's recorded charge only, and never on a row that produced nothing.
    const showCredits = typeof job.creditsCharged === 'number' && (isActive(job) || job.status === 'done');
    if (showCredits) creditsEl.innerHTML = `${+job.creditsCharged.toFixed(2)}${CREDIT_BOLT}`;
    creditsEl.style.display = showCredits ? '' : 'none';
    el.classList.toggle('has-credits', showCredits);

    if (job.status === 'done') applyDoneMedia(el, job);
    else el.classList.remove('has-media');

    // Known progress fills the tile ring; unknown (or a retry) keeps the trace spinning.
    const hasProgress = job.status === 'processing' && job.progress > 0 && !job.retrying;
    el.classList.toggle('has-p', hasProgress);
    el.style.setProperty('--p', String(hasProgress ? Math.round(job.progress) : 0));

    if (job.status === 'failed' || job.status === 'dead') el.title = job.error || 'Generation failed';
    else el.removeAttribute('title');

    el.querySelector('.err').textContent =
      (job.status === 'failed' || job.status === 'dead') ? (job.error || 'Generation failed') : '';

    const metricEl = el.querySelector('.row-metric');
    metricEl.className = metricClass(job);
    metricEl.textContent = metricText(job);

    // Controls depend on status alone. Rebuilt every poll, the button under a
    // pressed pointer would be swapped out before mouseup and the click would
    // land on the row (open) instead.
    if (prev !== job.status) el.querySelector('.row-action').innerHTML = actionHtml(job);

    // Finish moment: same jobId-keyed element flips to thumbnail with a green
    // double-pulse; the trigger pulses too when the panel is closed (S8).
    if (job.status === 'done' && prev && prev !== 'done') {
      el.classList.add('just-done');
      setTimeout(() => el.classList.remove('just-done'), 2500);
      if (!panelOpen) pulseTrigger();
    }
    const settledNow = ACTIVE_STATUSES.includes(prev) && (job.status === 'done' || job.status === 'failed' || job.status === 'dead');
    if (settledNow) maybePeek(job);
    return el;
  }

  // ---------------------------------------------------------------------------
  // Finish card. The ring is the finish cue when it can be seen; the header
  // scrolls away with the page, so a settle with no trigger in view (or none
  // at all) gets a bottom-right card instead. One card at a time: the newest.
  // ---------------------------------------------------------------------------
  let peekJobId = null;
  let peekTimer = null;
  let peekDeadline = 0;           // when the running countdown ends (ms epoch)
  let peekRemaining = 0;          // time left while paused
  let peekPaused = false;
  let peekFrame = 0;
  let peekLeaveTimer = null;
  let pendingPeekId = null;       // settled while the tab was hidden; shown on return
  let peekForced = false;         // fixtures: show the card regardless of the ring
  const nextFrame = (fn) => (typeof requestAnimationFrame === 'function' ? requestAnimationFrame(fn) : setTimeout(fn, 16));
  const cancelFrame = (id) => (typeof cancelAnimationFrame === 'function' ? cancelAnimationFrame(id) : clearTimeout(id));

  function triggerInView() {
    return triggers.some(({ button }) => {
      const r = button.getBoundingClientRect();
      return r.width > 0 && r.bottom > 0 && r.top < window.innerHeight;
    });
  }

  function maybePeek(job) {
    if (panelOpen) return;
    if (document.hidden) { pendingPeekId = job.jobId; return; }
    const force = peekForced;
    peekForced = false;
    if (triggerInView() && !force) return;
    showPeek(job);
  }

  function showPeek(job) {
    if (!els.peek) return;
    peekJobId = job.jobId;
    els.peek.setAttribute('data-job-id', job.jobId);
    const failed = job.status !== 'done';
    els.peek.classList.toggle('failed', failed);
    els.peekState.textContent = failed ? 'Failed' : 'Ready';
    els.peekName.textContent = job.displayName || prettifyId(job.agentId);   // textContent: user-originated
    els.peekMedia.querySelector('.type-glyph').innerHTML = GLYPHS[job.kind] || GLYPHS.other;
    const image = !failed && job.thumbnailUrl && thumbKind(job) === 'image';
    els.peekMedia.style.backgroundImage = image ? cssUrl(window.AitopiaMedia ? window.AitopiaMedia.image(job.thumbnailUrl, 40) : job.thumbnailUrl) : '';
    els.peekMedia.classList.toggle('has-media', !!image);
    clearTimeout(peekLeaveTimer);
    els.peek.classList.remove('leaving');
    els.root.classList.add('peek-on');
    liftPeekAboveOverlap();
    // Banners animate in late; look again while the card is still up.
    [400, 1200].forEach((ms) => setTimeout(() => { if (peekJobId === job.jobId) liftPeekAboveOverlap(); }, ms));
    peekRemaining = PEEK_MS;
    peekPaused = true;                             // resume() starts the clock from the full duration
    resumePeekClock();
    if (document.hidden) pausePeekClock();
  }

  function pausePeekClock() {
    if (!peekJobId || peekPaused) return;
    peekPaused = true;
    peekRemaining = Math.max(0, peekDeadline - Date.now());
    clearTimeout(peekTimer);
    peekTimer = null;
    cancelFrame(peekFrame);
  }

  function resumePeekClock() {
    if (!peekJobId || !peekPaused) return;
    peekPaused = false;
    peekDeadline = Date.now() + peekRemaining;
    clearTimeout(peekTimer);
    peekTimer = setTimeout(() => hidePeek(), peekRemaining);
    tickPeekBar();
  }

  function tickPeekBar() {
    cancelFrame(peekFrame);
    const fraction = Math.max(0, Math.min(1, (peekDeadline - Date.now()) / PEEK_MS));
    els.peekBar.style.transform = `scaleX(${fraction.toFixed(3)})`;
    if (fraction > 0 && !peekPaused) peekFrame = nextFrame(tickPeekBar);
  }

  // Marketing widgets pin their own banners to the bottom edge with a z-index
  // we cannot beat. If something else is on top of the card's centre, sit the
  // card just above that element's box instead.
  function liftPeekAboveOverlap() {
    els.peek.style.bottom = '';
    if (typeof document.elementsFromPoint !== 'function') return;
    const r = els.peek.getBoundingClientRect();
    if (!(r.width > 0)) return;
    const x = r.left + r.width / 2;
    const y = r.top + r.height / 2;
    const stack = document.elementsFromPoint(x, y);
    const blocker = stack.find((el) => el !== document.documentElement && el !== document.body && !els.root.contains(el));
    if (!blocker || stack.indexOf(blocker) > stack.indexOf(els.peek)) return;   // ours is on top
    // Widgets render inside a shadow root on a static, zero-size host: look
    // through it for the element actually under the point.
    let inner = blocker;
    if (blocker.shadowRoot && typeof blocker.shadowRoot.elementsFromPoint === 'function') {
      inner = blocker.shadowRoot.elementsFromPoint(x, y)[0] || blocker;
    }
    let box = inner;
    for (let el = inner; el && el !== document.body; el = el.parentElement || (el.parentNode && el.parentNode.host) || null) {
      if (getComputedStyle(el).position === 'fixed') { box = el; break; }
    }
    const top = box.getBoundingClientRect().top;
    if (top <= 0 || top >= r.bottom) return;
    els.peek.style.bottom = `${Math.round(window.innerHeight - top + 12)}px`;
  }

  // Expiry fades the card out; a user action (✕, Open, opening the panel,
  // dismissing the job) removes it at once.
  function hidePeek(options) {
    const immediate = !!(options && options.immediate);
    clearTimeout(peekTimer);
    peekTimer = null;
    cancelFrame(peekFrame);
    peekPaused = false;
    if (!peekJobId || !els.root) return;
    peekJobId = null;
    clearTimeout(peekLeaveTimer);
    if (immediate) { els.root.classList.remove('peek-on'); els.peek.classList.remove('leaving'); return; }
    els.peek.classList.add('leaving');
    peekLeaveTimer = setTimeout(() => { els.root.classList.remove('peek-on'); els.peek.classList.remove('leaving'); }, PEEK_LEAVE_MS);
  }

  // Only move a row that is out of place — re-inserting restarts its animations.
  function placeAfter(container, el, prev) {
    const want = prev ? prev.nextSibling : container.firstChild;
    if (el !== want) container.insertBefore(el, want);
    return el;
  }

  function syncGroup(list, container) {
    let prev = null;
    list.forEach((job) => { prev = placeAfter(container, updateRow(job), prev); });
  }

  function removeStaleRows(validIds) {
    for (const [id, el] of [...rowEls]) {
      if (validIds.has(id)) continue;
      el.classList.add('removing');
      setTimeout(() => el.remove(), 300);
      rowEls.delete(id);
    }
  }

  function setSection(sec, count) {
    sec.style.display = count ? '' : 'none';
    sec.querySelector('.sec-n').textContent = count ? String(count) : '';
  }

  function summaryText(active, ready, failed) {
    const bits = [];
    if (active.length) bits.push(`${active.length} in progress`);
    if (ready.length) bits.push(`${ready.length} ready`);
    if (failed.length) bits.push(`${failed.length} failed`);
    return bits.length ? bits.join(' · ') : 'All caught up';
  }

  // Pure state → trigger descriptor (S1). Priority: working > attention
  // (needs input only) > failed-unseen > ready-unseen > idle. The ring fills
  // with the average progress of the processing jobs that report one and
  // spins while none does; the social dot rides on top of any state.
  function triggerState() {
    const { active, ready, failed } = Store.getGrouped();
    const state = { state: 'idle', count: 0, progress: 0, indeterminate: false, social: Social.unread > 0, summary: summaryText(active, ready, failed) };
    if (active.length) {
      const waitingOnly = active.every((j) => j.status === 'waiting_input');
      const reporting = active.filter((j) => j.status === 'processing' && j.progress > 0);
      state.state = waitingOnly ? 'attention' : 'working';
      state.count = active.length;
      if (waitingOnly) state.progress = 100;
      else if (reporting.length) state.progress = Math.round(reporting.reduce((sum, j) => sum + j.progress, 0) / reporting.length);
      else state.indeterminate = true;
      return state;
    }
    // Until the first live reconcile has seeded the seen set, a restored
    // snapshot cannot say what is new — hold the bell rather than flash green.
    if (Store._seedSeen) return state;
    const unseenFailed = failed.filter((j) => (j.status === 'failed' || j.status === 'dead') && !Store.isSeen(j.jobId)).length;
    const unseenDone = ready.filter((j) => !Store.isSeen(j.jobId)).length;
    if (unseenFailed) Object.assign(state, { state: 'failed', count: unseenFailed, progress: 100 });
    else if (unseenDone) Object.assign(state, { state: 'ready', count: unseenDone, progress: 100 });
    return state;
  }

  // Guests see the trigger only while they have jobs (S7); the panel is still
  // mounted either way.
  function renderTrigger() {
    if (!triggers.length) return;
    const s = triggerState();
    const visible = Social.loggedIn || Store.jobs.size > 0;
    const title = s.state === 'idle' ? 'Generations & notifications' : s.summary;
    triggers.forEach(({ slot, button }) => {
      slot.classList.toggle('gd-on', visible);
      button.dataset.state = s.state;
      button.classList.toggle('indeterminate', s.indeterminate);
      button.classList.toggle('has-social', s.social);
      button.style.setProperty('--p', String(s.progress));
      button.querySelector('.gd-n').textContent = s.count ? String(s.count) : '';
      button.querySelector('.gd-sdot').textContent = Social.unread > 99 ? '99+' : String(Social.unread);
      button.title = title;
      button.setAttribute('aria-label', title);
      button.setAttribute('aria-expanded', panelOpen ? 'true' : 'false');
    });
  }

  function pulseTrigger() {
    triggers.forEach(({ button }) => {
      button.classList.remove('pulse');
      void button.offsetWidth;                     // reflow so the animation restarts
      button.classList.add('pulse');
    });
  }

  function ensureSocialRow(n) {
    let el = socialRowEls.get(n.id);
    if (!el) {
      el = document.createElement('div');
      el.className = 'dock-row social';
      el.setAttribute('data-notif-id', n.id);
      el.setAttribute('data-act', 'social-open');
      el.setAttribute('role', 'button');           // no inner button here, unlike job rows — the row itself is the control
      el.setAttribute('tabindex', '0');
      el.innerHTML = SOCIAL_ROW_SKELETON;             // static markup only
      socialRowEls.set(n.id, el);
    }
    return el;
  }

  function updateSocialRow(n) {
    const el = ensureSocialRow(n);
    const type = SOCIAL_GLYPHS[n.type] ? n.type : 'other';
    const media = el.querySelector('.row-media');
    media.className = `row-media ${type}`;
    media.querySelector('.type-glyph').innerHTML = SOCIAL_GLYPHS[type];
    el.querySelector('.row-name').textContent = n.message || 'Notification';
    el.querySelector('.row-metric').textContent = timeAgo(n.createdAt);
    el.classList.toggle('unread', !n.isRead);      // read-on-screen restyles on close, not now
    return el;
  }

  function renderSocial() {
    const show = Social.loggedIn && Social.items.length > 0;
    els.socialSec.style.display = show ? '' : 'none';
    if (!show) {
      for (const el of socialRowEls.values()) el.remove();
      socialRowEls.clear();
      return;
    }
    els.socialNew.textContent = Social.unread ? `${Social.unread} new` : '';
    els.markRead.style.display = Social.unread ? '' : 'none';
    const valid = new Set();
    let prev = null;
    Social.items.forEach((n) => {
      valid.add(n.id);
      prev = placeAfter(els.socialList, updateSocialRow(n), prev);
    });
    for (const [id, el] of [...socialRowEls]) {
      if (valid.has(id)) continue;
      el.remove();
      socialRowEls.delete(id);
    }
  }

  function render() {
    if (!els.root) return;
    const { active, ready, failed } = Store.getGrouped();
    // Whatever is on screen inside an open panel is seen — at open time and the
    // moment a row flips while open (S2). A hidden tab shows nothing; the poll
    // that fires on return re-renders and marks then.
    if (panelOpen && !document.hidden) Store.markSeen([...ready, ...failed].map((j) => j.jobId));

    els.sub.textContent = summaryText(active, ready, failed);
    setSection(els.activeSec, active.length);
    setSection(els.readySec, ready.length);
    setSection(els.failedSec, failed.length);
    els.empty.style.display = (active.length + ready.length + failed.length) ? 'none' : '';

    syncGroup(active, els.activeList);
    syncGroup(ready, els.readyList);
    syncGroup(failed, els.failedList);
    removeStaleRows(new Set([...active, ...ready, ...failed].map((j) => j.jobId)));
    if (peekJobId && !Store.get(peekJobId)) hidePeek({ immediate: true });   // dismissed or cleared

    renderSocial();
    renderTrigger();
    // Opened before any trigger was visible (deep link ahead of the profile
    // fetch, guest whose first job just landed): anchor as soon as one is.
    if (panelOpen && !isMobile() && !els.panel.style.getPropertyValue('--gd-top')) positionPanel();
  }

  function prettifyId(id) {
    return String(id || 'Generation')
      .replace(/^.*\//, '')
      .replace(/[-_]+/g, ' ')
      .replace(/\b\w/g, (c) => c.toUpperCase());
  }

  // ---------------------------------------------------------------------------
  // Panel open / close — desktop dropdown anchored to the trigger, mobile
  // bottom sheet; same body, same open state.
  // ---------------------------------------------------------------------------
  function visibleTrigger() {
    const hit = triggers.find(({ button }) => button.getBoundingClientRect().width > 0);
    return (hit || triggers[0] || {}).button || null;
  }

  function positionPanel() {
    // Crossing the 1024px slot breakpoint while open hides the pinned trigger
    // and shows the other one — re-anchor (and return focus) to the visible one.
    const pinnedVisible = lastTrigger && lastTrigger.getBoundingClientRect().width > 0;
    const anchor = pinnedVisible ? lastTrigger : visibleTrigger();
    if (!anchor) return;
    lastTrigger = anchor;
    const rect = anchor.getBoundingClientRect();
    // No visible trigger (guest without jobs on the deep link), or one scrolled
    // out of view (the header is not pinned): the rect would put the panel
    // off-screen — fall back to the stylesheet defaults.
    if (!(rect.width > 0) || rect.bottom < 0 || rect.top > window.innerHeight) {
      els.panel.style.removeProperty('--gd-top');
      els.panel.style.removeProperty('--gd-right');
      return;
    }
    // clientWidth, not innerWidth: `right:` on a fixed box excludes the scrollbar.
    const viewportWidth = document.documentElement.clientWidth || window.innerWidth;
    els.panel.style.setProperty('--gd-top', `${Math.round(rect.bottom + 8)}px`);
    els.panel.style.setProperty('--gd-right', `${Math.max(12, Math.round(viewportWidth - rect.right))}px`);
  }

  function lockBody(on) {
    document.documentElement.classList.toggle('gd-sheet-lock', on);
  }

  function open(fromTrigger) {
    if (panelOpen || !els.root) return;
    hidePeek({ immediate: true });
    panelOpen = true;
    lastTrigger = fromTrigger || visibleTrigger();
    positionPanel();
    els.root.classList.add('open');
    lockBody(isMobile());
    render();                                      // marks the listed settled rows seen
    Social.onPanelOpen();
    try { els.close.focus({ preventScroll: true }); } catch {}
  }

  function close() {
    if (!panelOpen) return;
    panelOpen = false;
    els.root.classList.remove('open');
    lockBody(false);
    hidePreview();
    Social.onPanelClose();
    render();
    // preventScroll: with the header scrolled away, a plain focus() would jump the page to the top.
    if (lastTrigger) { try { lastTrigger.focus({ preventScroll: true }); } catch {} }
  }

  function toggle(fromTrigger) {
    if (panelOpen) close(); else open(fromTrigger);
  }

  let previewTimer = null;

  // Copy the tile's already-decoded first frame (capped at 480px wide) into the card.
  function drawFirstFrame(video) {
    const ctx = video && video.readyState >= 2 && els.previewFrame.getContext('2d');
    if (!ctx) return false;
    const scale = Math.min(1, 480 / video.videoWidth);
    els.previewFrame.width = Math.round(video.videoWidth * scale);
    els.previewFrame.height = Math.round(video.videoHeight * scale);
    try { ctx.drawImage(video, 0, 0, els.previewFrame.width, els.previewFrame.height); return true; } catch { return false; }
  }

  function onRowHover(event) {
    const row = event.target.closest('.dock-row.has-media');
    const job = row ? Store.get(row.getAttribute('data-job-id')) : null;
    const kind = job && job.thumbnailUrl ? thumbKind(job) : null;
    if (kind !== 'image' && kind !== 'video') { hidePreview(); return; }
    if (els.preview.dataset.src === job.thumbnailUrl) return;   // mouseover repeats per child; keep the video playing
    hidePreview();
    els.preview.dataset.src = job.thumbnailUrl;
    els.preview.classList.toggle('is-video', kind === 'video');
    els.preview.style.backgroundImage = kind === 'image' ? cssUrl(window.AitopiaMedia ? window.AitopiaMedia.image(job.thumbnailUrl, 200) : job.thumbnailUrl) : '';
    els.preview.style.top = `${row.offsetTop - els.rows.scrollTop + (row.offsetHeight - PREVIEW_HEIGHT_PX) / 2}px`;
    if (kind === 'image') { els.preview.classList.add('show'); return; }
    if (window.matchMedia?.('(hover: none)')?.matches) return;    // a tap is not a hover: never fetch the video
    if (drawFirstFrame(row.querySelector('.thumb video'))) els.preview.classList.add('has-frame', 'show');
    previewTimer = setTimeout(() => {
      els.previewVideo.src = window.AitopiaMedia ? window.AitopiaMedia.preview(job.thumbnailUrl, 200) : job.thumbnailUrl;
      els.preview.classList.add('show');
      els.previewVideo.play()?.catch(() => {});
    }, PREVIEW_VIDEO_DELAY_MS);
  }

  function hidePreview() {
    clearTimeout(previewTimer);
    if (!els.preview) return;
    els.preview.classList.remove('show', 'has-frame', 'is-playing');
    delete els.preview.dataset.src;
    if (!els.previewVideo.getAttribute('src')) return;
    els.previewVideo.pause();
    els.previewVideo.removeAttribute('src');
    els.previewVideo.load();                       // aborts the download
  }

  // Mobile bottom sheet: drag-down on the grabber dismisses; crossing the
  // breakpoint while open closes so the body-scroll lock never sticks.
  function setupMobileSheet() {
    const panel = els.panel;
    const grabber = els.grabber;
    let dragging = false, startY = 0, dy = 0;
    const CLOSE_PX = 90;
    grabber.addEventListener('pointerdown', (event) => {
      if (!isMobile() || !panelOpen) return;
      dragging = true; startY = event.clientY; dy = 0;
      panel.style.transition = 'none';
      try { grabber.setPointerCapture(event.pointerId); } catch (_) {}
    });
    grabber.addEventListener('pointermove', (event) => {
      if (!dragging) return;
      dy = Math.max(0, event.clientY - startY);
      panel.style.transform = `translateY(${dy}px)`;
    });
    const endDrag = () => {
      if (!dragging) return;
      dragging = false;
      panel.style.transition = '';
      panel.style.transform = '';
      if (dy > CLOSE_PX) close();
    };
    grabber.addEventListener('pointerup', endDrag);
    grabber.addEventListener('pointercancel', endDrag);

    let mq = null;
    try { mq = window.matchMedia(MOBILE_QUERY); } catch {}
    if (!mq) return;
    const onChange = () => { if (panelOpen) close(); };
    if (mq.addEventListener) mq.addEventListener('change', onChange);
    else if (mq.addListener) mq.addListener(onChange);
  }

  // ?openNotifications=1 (the old bell deep-link) opens the panel; the param
  // is stripped from the URL as before.
  function consumeOpenParam() {
    try {
      const url = new URL(window.location.href);
      const value = url.searchParams.get('openNotifications');
      if (value !== '1' && value !== 'true') return false;
      url.searchParams.delete('openNotifications');
      window.history.replaceState({}, '', `${url.pathname}${url.search}${url.hash}`);
      return true;
    } catch { return false; }
  }

  // ---------------------------------------------------------------------------
  // Actions — swappable per mode. Live mode replaces `actions` with real
  // endpoints (POST /api/queue/dead/:id/requeue, deep-link navigation).
  // ---------------------------------------------------------------------------
  let actions = null;
  let liveController = null;   // Phase C poll lifecycle handle (kick/ensure/stop)

  function handleAction(act, jobId, notifId) {
    switch (act) {
      case 'close-panel': close(); return;
      case 'open-panel': open(); return;
      case 'peek-open': hidePeek({ immediate: true }); if (jobId) actions?.open?.(jobId); return;
      case 'peek-close': hidePeek({ immediate: true }); return;
      case 'clear-ready': Store.clearReady(); return;
      case 'clear-failed': Store.clearFailed(); return;
      case 'mark-all-read': Social.markAllRead(); return;
      case 'social-open': if (notifId) Social.openRow(notifId); return;
      case 'retry': if (jobId) actions?.retry?.(jobId); return;
      case 'dismiss': if (jobId) actions?.dismiss?.(jobId); return;
      case 'open': if (jobId) actions?.open?.(jobId); return;
      default: return;
    }
  }

  // ---------------------------------------------------------------------------
  // FixtureDataSource — deterministic fake jobs (Phase A). Extracted from the prototype.
  // Every state is reachable via explicit controls (no timers required for determinism).
  // ---------------------------------------------------------------------------
  function FixtureDataSource() {
    let counter = 0;
    const nextId = () => `fix-${++counter}`;
    const minutesAgo = (m) => new Date(Date.now() - m * 60000).toISOString();

    const PRESETS = {
      image: { kind: 'image', displayName: 'Flux Image Studio', prompt: 'isometric wooden workshop', credits: 2, etaSeconds: 12 },
      video: { kind: 'video', displayName: 'Cinematic Video Pro', prompt: 'neon city flyover at dusk', credits: 12, etaSeconds: 46 },
      audio: { kind: 'audio', displayName: 'Voice Cloner', prompt: 'warm narrator, calm pacing', credits: 4, etaSeconds: 18 },
      builder: { kind: 'builder', displayName: 'Agent Builder', prompt: 'checkpoint: choose a style', credits: undefined, etaSeconds: 0 },
    };

    function make(overrides) {
      const preset = PRESETS[overrides.kind] || PRESETS.image;
      const jobId = overrides.jobId || nextId();
      const settled = !ACTIVE_STATUSES.includes(overrides.status || 'processing');
      return {
        jobId,
        queueItemId: `q-${jobId}`,
        agentId: overrides.agentId || 'demo-agent',
        displayName: preset.displayName,
        kind: preset.kind,
        status: overrides.status || 'processing',
        progress: overrides.progress != null ? overrides.progress : 0,
        etaDeadline: Date.now() + 1000 * (overrides.etaSeconds != null ? overrides.etaSeconds : preset.etaSeconds),
        createdAt: '2026-07-22T00:00:00.000Z',
        finishedAt: settled ? minutesAgo(overrides.minutesAgo != null ? overrides.minutesAgo : 4) : undefined,
        prompt: overrides.prompt != null ? overrides.prompt : preset.prompt,
        creditsCharged: overrides.credits != null ? overrides.credits : preset.credits,
        thumbnailUrl: overrides.thumbnailUrl,
        deepLinkUrl: `/marketplace/agent/${overrides.agentId || 'demo-agent'}?jobId=${jobId}`,
        error: overrides.error,
        retrying: overrides.retrying || false,
      };
    }

    // A tiny inline SVG so the thumbnailUrl path is exercised without a network image.
    const SAMPLE_THUMB = 'data:image/svg+xml,' + encodeURIComponent(
      '<svg xmlns="http://www.w3.org/2000/svg" width="80" height="80"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#7C3AED"/><stop offset="1" stop-color="#DB2777"/></linearGradient></defs><rect width="80" height="80" fill="url(#g)"/></svg>');

    const SOCIAL_ROWS = () => [
      { id: 'n-1', type: 'remix', message: '@mira remixed your creation', createdAt: minutesAgo(2), isRead: false, url: '/creations/out-1' },
      { id: 'n-2', type: 'comment', message: '@deniz commented on your creation', createdAt: minutesAgo(60), isRead: false, url: '/creations/out-2' },
      { id: 'n-3', type: 'like_milestone', message: 'Your creation reached 50 likes', createdAt: minutesAgo(60 * 26), isRead: true, url: '/creations/out-3' },
      { id: 'n-4', type: 'follow', message: '@kai started following you', createdAt: minutesAgo(60 * 50), isRead: true, url: '/u/kai' },
    ];

    const SCENARIOS = {
      gallery: () => [
        make({ status: 'queued', kind: 'image' }),
        make({ status: 'processing', kind: 'video', progress: 72, etaSeconds: 22 }),
        make({ status: 'processing', kind: 'audio', progress: 40, etaSeconds: 15, retrying: true }),
        make({ status: 'waiting_input', kind: 'builder' }),
        make({ status: 'done', kind: 'video', progress: 100, thumbnailUrl: SAMPLE_THUMB, minutesAgo: 2 }),
        make({ status: 'done', kind: 'image', progress: 100, minutesAgo: 9 }),
        make({ status: 'failed', kind: 'image', error: 'Content flagged by the safety filter. Try a different prompt.', minutesAgo: 14 }),
        make({ status: 'dead', kind: 'video', error: 'Provider timed out after 3 attempts.', minutesAgo: 130 }),
        make({ status: 'cancelled', kind: 'image' }),
      ],
      queued: () => [make({ status: 'queued', kind: 'image' })],
      processing: () => [make({ status: 'processing', kind: 'video', progress: 63, etaSeconds: 18 })],
      retrying: () => [make({ status: 'processing', kind: 'audio', progress: 30, etaSeconds: 20, retrying: true })],
      waiting_input: () => [make({ status: 'waiting_input', kind: 'builder' })],
      done: () => [make({ status: 'done', kind: 'video', progress: 100, thumbnailUrl: SAMPLE_THUMB })],
      failed: () => [make({ status: 'failed', kind: 'image', error: 'Content flagged by the safety filter. Try a different prompt.' })],
      dead: () => [make({ status: 'dead', kind: 'video', error: 'Provider timed out after 3 attempts.' })],
      cancelled: () => [make({ status: 'cancelled', kind: 'image' })],
      'all-ready': () => [
        make({ status: 'done', kind: 'video', progress: 100, thumbnailUrl: SAMPLE_THUMB, minutesAgo: 1 }),
        make({ status: 'done', kind: 'image', progress: 100, minutesAgo: 6 }),
      ],
      'needs-input-only': () => [make({ status: 'waiting_input', kind: 'builder' })],
      social: () => [
        make({ status: 'processing', kind: 'video', progress: 55, etaSeconds: 24 }),
        make({ status: 'done', kind: 'image', progress: 100, thumbnailUrl: SAMPLE_THUMB, minutesAgo: 3 }),
      ],
    };

    return {
      make,
      scenarios: SCENARIOS,
      socialRows: SOCIAL_ROWS,
      load(name) {
        Store.reset();
        const build = SCENARIOS[name] || SCENARIOS.gallery;
        Store.upsertMany(build());
      },
      addJob(kind) { Store.upsert(make({ kind, status: 'processing', progress: 8 })); },
    };
  }

  function fixtureActions(source) {
    return {
      retry(jobId) {
        const job = Store.get(jobId);
        if (job) Store.upsert({ ...job, status: 'processing', progress: 5, etaDeadline: Date.now() + 20000, retrying: false, error: undefined });
      },
      open(jobId) {
        const job = Store.get(jobId);
        if (!job) return;
        console.info('[gen-dock] open', job.deepLinkUrl);   // fixtures: no navigation (keeps e2e stable)
      },
      dismiss(jobId) { Store.dismiss(jobId); },
    };
  }

  // ---------------------------------------------------------------------------
  // Bootstrap
  // ---------------------------------------------------------------------------
  function isFixtureMode() {
    try { return new URLSearchParams(window.location.search).has('dockFixtures'); } catch { return false; }
  }

  function initFixtureMode() {
    const source = FixtureDataSource();
    actions = fixtureActions(source);
    Store._seedSeen = false;                       // no live reconcile here; fixtures are deterministic

    // Social alerts come from fixture rows, never the network; the harness
    // flips the guest / logged-in view.
    const socialStub = () => { const items = source.socialRows(); return { items, unread: items.filter((n) => !n.isRead).length }; };
    Social.stub = socialStub();

    // Fixture control surface consumed by public/dock-fixtures.html.
    window.GenerationDock.fixtures = {
      scenario: (name) => {
        source.load(name);
        Social.stub = socialStub();
        Social.items = [];
        Social.loaded = false;
        Social.setLoggedIn(name === 'social' || Social.loggedIn);
        Social.fetchCount();
      },
      addJob: (kind) => source.addJob(kind),
      finishNext: (peek) => {
        const job = Store.firstActive();
        peekForced = peek === true;
        if (job) Store.upsert({ ...job, status: 'done', progress: 100, retrying: false, finishedAt: new Date().toISOString() });
      },
      failNext: (peek) => {
        const job = Store.firstActive();
        peekForced = peek === true;
        if (job) Store.upsert({ ...job, status: 'failed', error: 'The model provider returned an error. Please try again.', finishedAt: new Date().toISOString() });
      },
      clearReady: () => Store.clearReady(),
      clearFailed: () => Store.clearFailed(),
      open: () => open(),
      close: () => close(),
      social: (loggedIn) => { Social.setLoggedIn(loggedIn !== false); Social.fetchCount(); },
      reset: () => Store.reset(),
    };

    source.load('gallery');
  }

  // ---------------------------------------------------------------------------
  // Live mode (Phase C) — DockJob mapping, catalog lookups, poll lifecycle,
  // real actions, wake-up wiring. Fetches only /api/queue (D9) + two read-only
  // catalogs the store pages already load (C3).
  // ---------------------------------------------------------------------------

  function jsonFetch(url) {
    return fetch(url, { method: 'GET', credentials: 'include', headers: { Accept: 'application/json' } })
      .then((r) => (r.ok ? r.json() : null))
      .catch(() => null);
  }

  // Media-type/category token → DockJob kind.
  function mapMediaToKind(value) {
    switch (String(value || '').toLowerCase()) {
      case 'image': return 'image';
      case 'video': return 'video';
      case 'audio':
      case 'audio-voice':
      case 'voice': return 'audio';
      case 'text': return 'text';
      default: return null;
    }
  }

  // Keyword fallback when the catalog hasn't loaded (or lacks the id).
  function inferKind(id) {
    const s = String(id || '').toLowerCase();
    if (/(video|clip|veo|kling|seedance|runway|wan|hunyuan|ltx|animat|motion|minimax\/video)/.test(s)) return 'video';
    if (/(audio|voice|music|speech|tts|sound|eleven|whisper|mmaudio|lyria|suno)/.test(s)) return 'audio';
    if (/(image|img|photo|flux|sdxl|imagen|nano-banana|ideogram|recraft|dall|qwen-image|seedream|kontext)/.test(s)) return 'image';
    if (/(text|gpt|claude|llama|chat|writer|prompt|caption|title|humaniz|translat|summar)/.test(s)) return 'text';
    return 'other';
  }

  function agentKindFromEntry(a) {
    const mods = Array.isArray(a.modalities) ? a.modalities : [];
    return mapMediaToKind(a.primaryCategory)
      || mapMediaToKind(mods.find((m) => m && m !== 'text'))
      || mapMediaToKind(mods[0])
      || inferKind(a.id);
  }

  // Read-only name/kind catalog, populated from the two endpoints the
  // store pages already load, cached in sessionStorage (5-min freshness matching
  // their Cache-Control). Lookups are synchronous against in-memory maps; until
  // the fetch lands, mapping degrades to prettify(id) + keyword kind.
  const Catalog = {
    agents: new Map(),
    models: new Map(),
    primed: false,
    _loading: false,

    prime(onReady) {
      if (this.primed) { if (onReady) onReady(); return; }
      let cached = null;
      try { cached = JSON.parse(sessionStorage.getItem(CATALOG_KEY) || 'null'); } catch {}
      if (cached && cached.ts && (Date.now() - cached.ts) < CATALOG_FRESH_MS) {
        this._absorb(cached);
        this.primed = true;
        if (onReady) onReady();
        return;
      }
      if (cached) this._absorb(cached);   // stale: use immediately, refresh below
      if (this._loading) return;
      this._loading = true;
      Promise.all([
        jsonFetch('https://aitopia.ai/api/store'),
        jsonFetch('https://aitopia.ai/api/models/all?callableOnly=true&limit=-1'),
      ]).then(([store, models]) => {
        const data = { agents: [], models: [], ts: Date.now() };
        if (store && Array.isArray(store.agents)) {
          store.agents.forEach((a) => {
            if (a && a.id) data.agents.push([a.id, { displayName: a.name || prettifyId(a.id), kind: agentKindFromEntry(a) }]);
          });
        }
        if (models && Array.isArray(models.models)) {
          models.models.forEach((m) => {
            if (!m || !m.id) return;
            data.models.push([m.id, { displayName: m.displayName || prettifyId(m.id), kind: mapMediaToKind(m.mediaType) || inferKind(m.id) }]);
          });
        }
        this._absorb(data);
        this.primed = true;
        try { sessionStorage.setItem(CATALOG_KEY, JSON.stringify(data)); } catch {}
        if (onReady) onReady();
      }).finally(() => { this._loading = false; });
    },

    // Cache-only counterpart of prime(): pages with an empty dock never fetch the catalog.
    restore() {
      let cached = null;
      try { cached = JSON.parse(sessionStorage.getItem(CATALOG_KEY) || 'null'); } catch {}
      if (!cached) return;
      this._absorb(cached);
      if (cached.ts && (Date.now() - cached.ts) < CATALOG_FRESH_MS) this.primed = true;
    },

    has(agentId) {
      const id = String(agentId || '');
      return id.includes('/') ? this.models.has(id) : this.agents.has(id.replace(/_step-\d+$/, ''));
    },

    _absorb(data) {
      (data.agents || []).forEach(([id, v]) => this.agents.set(id, v));
      (data.models || []).forEach(([id, v]) => this.models.set(id, v));
    },

    // Resolve { displayName, kind } for a queue row.
    lookup(agentId, input) {
      const inputKind = input && typeof input === 'object' ? input.kind : undefined;
      if (inputKind === 'builder-preview' || inputKind === 'builder-step') {
        const base = String(agentId || '').replace(/_step-\d+$/, '');
        const a = this.agents.get(base);
        return { displayName: (a && a.displayName) || prettifyId(base), kind: 'builder' };
      }
      if (String(agentId || '').includes('/')) {
        const m = this.models.get(agentId);
        return { displayName: (m && m.displayName) || prettifyId(agentId), kind: (m && m.kind) || inferKind(agentId) };
      }
      // `_step-N` is builder-only row naming (resolveBuilderRowAgentId). An
      // orphaned row — its job deleted by the Remove teardown — arrives with no
      // input to say so; strip the suffix anyway so the base agent still names it.
      const base = String(agentId || '').replace(/_step-\d+$/, '');
      const a = this.agents.get(base);
      return { displayName: (a && a.displayName) || prettifyId(base), kind: (a && a.kind) || inferKind(base) };
    },
  };

  // A checkpoint-paused builder run manifests as a `completed` builder-step job
  // whose queue agentId is an INTERMEDIATE step (`<docId>_step-<N+1>`, per
  // resolveBuilderRowAgentId — the final step and single-shot preview use the
  // bare docId). But that row shape alone doesn't mean "paused": the builder's
  // isolated per-step Play produces it too (no run is waiting), and a run that
  // continued past the step leaves it behind as history. The rows of one run
  // share input.parentRunId (Play rows have none), so a row asks for input ONLY
  // when it is its run's newest row and nothing in the run is still executing.
  function isBuilderStepIntermediate(item) {
    return item?.input && item.input.kind === 'builder-step' && /_step-\d+$/.test(String(item.agentId || ''));
  }

  function buildBuilderRunIndex(items) {
    const runs = new Map();
    for (const item of items) {
      const parentRunId = item?.input && item.input.kind === 'builder-step' ? item.input.parentRunId : undefined;
      if (!parentRunId) continue;
      let run = runs.get(parentRunId);
      if (!run) { run = { hasActive: false, newestQueueId: null, newestAt: -Infinity }; runs.set(parentRunId, run); }
      if (item.status === 'pending' || item.status === 'processing' || item.status === 'retrying') run.hasActive = true;
      const at = Date.parse(item.createdAt || '') || 0;
      if (at > run.newestAt) { run.newestAt = at; run.newestQueueId = item.id; }
    }
    return runs;
  }

  function isPausedBuilderCheckpoint(item, runIndex) {
    if (!isBuilderStepIntermediate(item)) return false;
    const run = runIndex.get(item.input.parentRunId);
    return !!run && !run.hasActive && run.newestQueueId === item.id;
  }

  function mapQueueStatus(item, runIndex) {
    switch (item.status) {
      case 'pending': return { status: 'queued' };
      case 'processing': return { status: 'processing' };
      case 'retrying': return { status: 'processing', retrying: true };
      case 'completed': return isPausedBuilderCheckpoint(item, runIndex) ? { status: 'waiting_input' } : { status: 'done' };
      case 'failed': return { status: 'failed' };
      case 'dead': return { status: 'dead' };
      case 'cancelled': return { status: 'cancelled' };
      default: return { status: 'processing' };
    }
  }

  function extractPrompt(input) {
    if (!input || typeof input !== 'object') return undefined;
    for (const key of ['prompt', 'text', 'description']) {
      const v = input[key];
      if (typeof v === 'string' && v.trim()) return v.trim();
    }
    // Builder rows carry the user's fields one level down, in input.userInput.
    const nested = input.userInput;
    if (nested && typeof nested === 'object') {
      for (const key of ['prompt', 'text', 'description']) {
        const v = nested[key];
        if (typeof v === 'string' && v.trim()) return v.trim();
      }
    }
    return undefined;
  }

  // An anchor in the future or absurdly past the estimate is a clock-skewed DB
  // timestamp, not a job running long — show progress-only rather than a bogus clock.
  const ETA_OVERRUN_GRACE_MS = 60 * 60_000;

  function computeEtaDeadline(item) {
    const est = Number(item.estimatedDurationMs);
    if (!Number.isFinite(est) || est <= 0) return undefined;
    const anchor = item.startedAt || item.createdAt;
    const startMs = anchor ? Date.parse(anchor) : NaN;
    if (!Number.isFinite(startMs)) return undefined;
    const elapsed = Date.now() - startMs;
    if (elapsed < 0 || elapsed > est + ETA_OVERRUN_GRACE_MS) return undefined;
    return startMs + est;
  }

  function resolveDeepLink(agentId, jobId) {
    if (String(agentId || '').includes('/')) return OUTPUTS_URL;   // model runs: model.html ignores ?jobId= (Q2) → /creations
    const base = String(agentId || '').replace(/_step-\d+$/, '');  // builder intermediate → base agent/doc page
    // A base id the store catalog doesn't know (builder draft previews,
    // deactivated agents) has no live /agents page — send those to /creations.
    // Only a primed NON-EMPTY catalog can vouch for an id being unknown: a
    // failed catalog fetch primes empty (jsonFetch → null), and before priming
    // we can't tell either — both keep the agent link. Rows are remapped every
    // poll, so this corrects itself once the real catalog lands.
    if (Catalog.primed && Catalog.agents.size > 0 && !Catalog.agents.has(base)) return OUTPUTS_URL;
    return `/marketplace/agent/${encodeURIComponent(base)}?jobId=${encodeURIComponent(jobId)}`;
  }

  // Enriched /api/queue row → DockJob (§5.2). Missing optional fields degrade
  // gracefully: an old dead row with no job record has no input/thumb/error and
  // still renders as glyph + prettified name + deep-link.
  function toDockJob(item, runIndex) {
    const jobId = item.refId;
    const agentId = item.agentId || '';
    const meta = Catalog.lookup(agentId, item.input);
    const { status, retrying } = mapQueueStatus(item, runIndex);

    const job = {
      jobId,
      queueItemId: item.id,
      agentId,
      displayName: meta.displayName,
      kind: meta.kind,
      status,
      progress: Number.isFinite(Number(item.progress)) ? Number(item.progress) : (status === 'done' ? 100 : 0),
      createdAt: item.createdAt,
      deepLinkUrl: resolveDeepLink(item.pageAgentId || agentId, jobId),
    };
    if (retrying) job.retrying = true;
    const prompt = extractPrompt(item.input);
    if (prompt) job.prompt = prompt;
    if (status === 'processing') {
      if (item.startedAt) job.startedAt = item.startedAt;
      const deadline = computeEtaDeadline(item);
      if (deadline != null) job.etaDeadline = deadline;
    }
    if (item.completedAt) job.finishedAt = item.completedAt;   // written for failed/dead/cancelled too (queue-storage.ts)
    if (typeof item.creditsCharged === 'number') job.creditsCharged = item.creditsCharged;
    if (item.thumbnailUrl) job.thumbnailUrl = item.thumbnailUrl;
    if (item.thumbnailKind) job.thumbnailKind = item.thumbnailKind;
    if (item.error) job.error = item.error;
    return job;
  }

  function LiveDataSource() {
    return {
      poll() {
        const order = window.aitopiaLoadOrder;
        const ready = order ? Promise.all([order.wait('critical'), order.wait('dock')]) : Promise.resolve();
        return ready.then(() => jsonFetch(`https://aitopia.ai/api/queue?${QUEUE_QUERY}`))
          .then((json) => {
            const items = json && Array.isArray(json.items) ? json.items : null;   // null = the fetch failed
            const all = items || [];
            const runIndex = buildBuilderRunIndex(all);
            // One generation, one row: a completed intermediate step that is
            // NOT the run's live checkpoint is pipeline history (or an isolated
            // builder Play) — /api/me/creations hides those rows too. What
            // remains: the active step, the frontier, the final bare-id row.
            return {
              active: all.filter((item) => QUEUE_ACTIVE.includes(item.status)).map((item) => toDockJob(item, runIndex)),
              settled: all.filter((item) => !QUEUE_ACTIVE.includes(item.status)
                && (isPausedBuilderCheckpoint(item, runIndex) || !(item.status === 'completed' && isBuilderStepIntermediate(item)))).map((item) => toDockJob(item, runIndex)),
              complete: items !== null,
            };
          });
      },
    };
  }

  function liveActions() {
    return {
      // Dead-letter requeue targets the QUEUE ITEM id (queue.ts:322 / requeueDead).
      retry(jobId) {
        const job = Store.get(jobId);
        const queueItemId = job && job.queueItemId;
        if (!queueItemId) return;
        fetch(`https://aitopia.ai/api/queue/dead/${encodeURIComponent(queueItemId)}/requeue`, {
          method: 'POST', credentials: 'include',
          headers: { Accept: 'application/json', 'Content-Type': 'application/json' }, body: '{}',
        })
          .catch(() => {})
          .finally(() => { liveController && liveController.kick(); });
      },
      // Navigation only — ✕ and the section Clears are the only ways a row leaves the dock.
      open(jobId) {
        const job = Store.get(jobId);
        if (!job || !job.deepLinkUrl) return;
        try { window.location.assign(job.deepLinkUrl); } catch {}
      },
      dismiss(jobId) { Store.dismiss(jobId); },
    };
  }

  // Best-effort smoother progress between polls. The event's jobId is the run's
  // parentRunId (checkpoint driver only) and usually will NOT match a queue
  // refId, so this no-ops for most runs — the 3s poll is the real driver.
  function applyProgressEvent(detail) {
    if (!detail || !detail.jobId) return;
    const job = Store.get(detail.jobId);
    if (!job || !isActive(job)) return;
    let pct = Number(detail.progress);
    if (!Number.isFinite(pct)) {
      const m = /\((\d+)%\)/.exec(String(detail.status || ''));
      if (m) pct = Number(m[1]);
    }
    if (!Number.isFinite(pct)) return;
    Store.upsert({ ...job, status: 'processing', progress: pct });   // monotonic clamp in upsert()
  }

  function initLiveMode() {
    Store.live = true;
    const source = LiveDataSource();
    actions = liveActions();
    Store.restoreSnapshot();          // instant first paint; reconciled by the first fetch

    // Absorb the cached catalog before the first poll maps rows; the network fetch
    // waits until a poll actually returns jobs (see pollOnce).
    Catalog.restore();

    let timer = null;
    let inFlight = false;
    let rerun = false;                // a kick during a poll (catalog landed, submit) must not be lost

    function ensure() {
      if (timer) return;
      // Hidden tabs keep polling, just slower (multi-tab request budget), so the
      // favicon can reflect a finish/failure while the user is on another tab.
      timer = setInterval(() => { pollOnce(); }, document.hidden ? HIDDEN_POLL_MS : POLL_MS);
    }
    function stop() { if (timer) { clearInterval(timer); timer = null; } }

    function pollOnce() {
      if (inFlight) return;
      inFlight = true;
      source.poll().then(({ active, settled, complete }) => {
        Store.reconcileLive(active, settled, complete);
        Store.saveSnapshot();
        // Fetch only for unknown non-builder ids; builder drafts are never in /api/store anyway.
        if (!Catalog.primed && active.concat(settled).some((job) => job.kind !== 'builder' && !Catalog.has(job.agentId))) Catalog.prime(() => { liveController && liveController.kick(); });
      }).catch(() => {}).finally(() => {
        inFlight = false;
        // The first queue answer releases the agent page's remix list.
        if (window.aitopiaLoadOrder) window.aitopiaLoadOrder.open('queue');
        if (rerun) { rerun = false; pollOnce(); }
        if (Store.firstActive()) ensure(); else stop();
      });
    }
    function kick() { if (inFlight) rerun = true; else pollOnce(); ensure(); }

    liveController = { pollOnce, ensure, stop, kick };

    // Switch cadence on visibility change: an active queue keeps polling while
    // hidden (slower) so the favicon stays live; an idle tab parks as before.
    // Coming back refreshes immediately at the normal cadence — and refreshes
    // the social count, whose poll skips hidden ticks.
    document.addEventListener('visibilitychange', () => {
      stop();
      if (document.hidden) { if (Store.firstActive()) ensure(); }
      else { kick(); Social.fetchCount(); Social._observe(); }   // rows on screen while hidden start their read clock now
    });

    // Wake-up: a generate click fires this (pre-202). The queue row only lands
    // after the 202, so re-fetch late, with one retry. Agent pages fire
    // `agent-generate-start` (embed-runner.js:5229); model pages fire
    // `model-generate-start` (model.html:4808) — both are in-scope run surfaces,
    // and without this an idle (non-polling) dock would miss a fresh submit.
    const onGenerateStart = () => { setTimeout(kick, WAKE_DELAY_MS); setTimeout(kick, WAKE_DELAY_MS * 2); };
    document.addEventListener('aitopia:agent-generate-start', onGenerateStart);
    document.addEventListener('aitopia:model-generate-start', onGenerateStart);

    window.addEventListener('aitopia-creation-progress', (e) => { try { applyProgressEvent(e.detail); } catch {} });

    // Multi-tab consistency (best-effort): another tab dismissed/cleared or looked at results.
    window.addEventListener('storage', (e) => {
      if (!e) return;
      if (e.key === LS.dismissed) Store.reloadDismissed();
      else if (e.key === LS.seen) Store.reloadSeen();
    });

    // Login state comes from navbar.js. With a cached profile it resolves
    // before this script runs, so read it now and follow the event after.
    Social.setLoggedIn(window.NavbarComponent?.isLoggedIn?.() === true);
    window.addEventListener('aitopia-auth-changed', (e) => {
      const loggedIn = !!(e.detail && e.detail.loggedIn);
      if (Social.loggedIn && !loggedIn) {                // signed out: the rows belong to the old account
        Store.jobs.clear(); Store._miss.clear(); Store.saveSnapshot(); Store._emit();   // dismissed/seen marks are per browser, not per account
      }
      Social.setLoggedIn(loggedIn);
    });

    kick();   // first fetch also discovers jobs started on a previous page
  }

  // ---------------------------------------------------------------------------
  // Favicon status indicator
  // ---------------------------------------------------------------------------
  // Badges the browser tab so a user working in another tab can watch their
  // generations progress, finish or fail without switching back. Colour priority
  // mirrors the panel's own semantics: error (red) beats active (yellow) beats
  // done (green). It's a while-away cue — a visible tab has the dock itself — so
  // becoming visible restores the default.
  const DEFAULT_FAVICON = '/marketplace/favicon.svg';
  const FAVICON_TINT = { active: '#f5a623', error: '#e5484d', done: '#2fa96b' };

  let faviconBase = null;                   // cached base logo; null → dot-only until it loads
  let faviconBaseLoading = false;
  let faviconDoneCleared = false;           // a visit acknowledged the current "all done" → don't re-green
  let lastFaviconKey = null;

  // Pure state → indicator descriptor. Priority: error > active > done > default.
  function faviconDescriptor({ active, done, failed }) {
    if (failed > 0) return { kind: 'error', count: failed };
    if (active > 0) return { kind: 'active', count: active };
    if (done > 0) return { kind: 'done', count: done };
    return { kind: 'default', count: 0 };
  }

  function faviconCounts() {
    const { active, ready, failed } = Store.getGrouped();
    return {
      active: active.length,
      done: ready.length,
      failed: failed.filter((j) => j.status === 'failed' || j.status === 'dead').length,
    };
  }

  function faviconLink() {
    let link = document.querySelector('link[rel~="icon"]');
    if (!link) {
      link = document.createElement('link');
      link.rel = 'icon';
      document.head.appendChild(link);
    }
    if (!link.dataset.gdDefault) link.dataset.gdDefault = link.getAttribute('href') || DEFAULT_FAVICON;
    return link;
  }

  function restoreDefaultFavicon() {
    const link = faviconLink();
    const def = link.dataset.gdDefault || DEFAULT_FAVICON;
    if (link.getAttribute('href') !== def) link.setAttribute('href', def);
  }

  // Decode the site logo once so paints are synchronous; repaint the current
  // state when it arrives (paints before then are a plain dot on transparent).
  function preloadFaviconBase() {
    if (faviconBase || faviconBaseLoading || typeof Image === 'undefined') return;
    faviconBaseLoading = true;
    const img = new Image();
    img.onload = () => { faviconBase = img; faviconBaseLoading = false; lastFaviconKey = null; updateFavicon(); };
    img.onerror = () => { faviconBaseLoading = false; };
    img.src = faviconLink().dataset.gdDefault || DEFAULT_FAVICON;
  }

  function paintFavicon(descriptor) {
    const size = 64;
    const canvas = document.createElement('canvas');
    canvas.width = size; canvas.height = size;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;                                    // no 2d context (e.g. jsdom)
    if (faviconBase) ctx.drawImage(faviconBase, 0, 0, size, size);
    const r = size * 0.30;
    const cx = size - r - size * 0.02;
    const cy = size - r - size * 0.02;
    ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.fillStyle = FAVICON_TINT[descriptor.kind] || FAVICON_TINT.active;
    ctx.fill();
    ctx.lineWidth = size * 0.05; ctx.strokeStyle = '#ffffff'; ctx.stroke();
    if (descriptor.count > 0) {
      ctx.fillStyle = '#ffffff';
      ctx.font = `bold ${Math.round(r * 1.15)}px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif`;
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(descriptor.count > 9 ? '9+' : String(descriptor.count), cx, cy + size * 0.02);
    }
    try { faviconLink().setAttribute('href', canvas.toDataURL('image/png')); } catch (_) {}
  }

  // Repaint from the live Store. While the tab is visible the dock speaks for
  // itself, so we hold the default favicon (revert-on-visit); while hidden we
  // paint the current state — the "all done" green holds until the user looks.
  function updateFavicon() {
    if (typeof document === 'undefined') return;
    if (document.visibilityState === 'visible') {
      faviconDoneCleared = faviconDescriptor(faviconCounts()).kind === 'done';  // a look acknowledges completion
      lastFaviconKey = 'default';
      restoreDefaultFavicon();
      return;
    }
    const d = faviconDescriptor(faviconCounts());
    if (d.kind === 'done' && faviconDoneCleared) { restoreDefaultFavicon(); return; }
    if (d.kind !== 'done') faviconDoneCleared = false;
    const key = d.kind + ':' + d.count;
    if (key === lastFaviconKey) return;
    lastFaviconKey = key;
    if (d.kind === 'default') { restoreDefaultFavicon(); return; }
    paintFavicon(d);
  }

  function start() {
    mount();
    Store.load();
    Store.subscribe(render);
    Store.subscribe(updateFavicon);
    document.addEventListener('visibilitychange', updateFavicon);
    preloadFaviconBase();
    // navbar.js is a sync script whose header precedes this deferred one; a
    // page that renders the header at DOMContentLoaded gets one more look.
    // Still no slot → dormant: no trigger, everything else runs.
    if (!mountTriggers() && document.readyState !== 'complete') {
      document.addEventListener('DOMContentLoaded', () => {
        mountTriggers();
        render();                                  // shows the slot; only then does the trigger have a rect
        if (panelOpen) { lastTrigger = visibleTrigger(); positionPanel(); }   // ?openNotifications opened it before the header existed
      }, { once: true });
    }
    if (isFixtureMode()) initFixtureMode();
    else initLiveMode();
    render();
    if (consumeOpenParam()) open();

    // The ETA / elapsed metric is a clock — tick it each second between polls so
    // it counts smoothly instead of jumping by POLL_MS; settled rows keep their
    // "time since" fresh the same way. Metric text only.
    setInterval(() => {
      if (document.hidden) return;
      for (const [jobId, el] of rowEls) {
        const job = Store.get(jobId);
        if (!job) continue;
        if (!(job.status === 'processing' && !job.retrying) && !job.finishedAt) continue;
        el.querySelector('.row-metric').textContent = metricText(job);
      }
    }, 1000);
  }

  // ---------------------------------------------------------------------------
  // Public API
  // ---------------------------------------------------------------------------
  window.GenerationDock = {
    // Optional additive hook (C4): nudge a re-fetch right after a 202 submit.
    // The existing `aitopia:agent-generate-start` document event already wakes
    // the dock, so this is a no-op-safe timing refinement, not a dependency.
    notifySubmitted() { try { liveController && liveController.kick(); } catch { /* not in live mode */ } },

    open() { open(); },
    close() { close(); },

    // Seams for tests / fixtures.
    _store: Store,
    _social: Social,
    _triggerState: triggerState,
    _faviconState: () => faviconDescriptor(faviconCounts()),
    setActions(next) { if (next) actions = next; },
    render,
  };

  // Parsed DOM is enough; DOMContentLoaded would also wait for every module script on the page.
  if (document.readyState === 'loading') {
    document.addEventListener('readystatechange', start, { once: true });
  } else {
    start();
  }
})();
