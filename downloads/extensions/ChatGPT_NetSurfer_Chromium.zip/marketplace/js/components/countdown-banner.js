import { getPromoConfig, getPromoEnd, splitRemaining, promoEndedCached, promoHiddenForPlan, cachedPlan } from '/marketplace/js/shared/promo.js';

const CSS = `countdown-banner{display:block}
.bfb{position:relative;z-index:2;display:flex;flex-direction:column;align-items:center;justify-content:center;overflow:hidden;text-align:center;isolation:isolate;padding:46px 16px 56px;background:var(--bfb-bf-bg);border-radius:0 0 24px 24px}
.bfb::before{content:"";position:absolute;left:0;right:0;bottom:0;height:190px;z-index:3;pointer-events:none;background:radial-gradient(ellipse 34% 100% at 18% 100%,var(--bfb-dome1) 0%,var(--bfb-dome2) 42%,transparent 76%),radial-gradient(ellipse 34% 100% at 82% 100%,var(--bfb-dome1) 0%,var(--bfb-dome2) 42%,transparent 76%),radial-gradient(ellipse 30% 70% at 50% 100%,var(--bfb-dome2) 0%,transparent 72%)}
.bfb::after{content:"";position:absolute;inset:0;z-index:4;pointer-events:none;border-radius:inherit;padding:2px;clip-path:inset(calc(100% - 26px) 0 0 0); background:linear-gradient(90deg,transparent 0%,var(--bfb-sl1) 24%,var(--bfb-sl2) 50%,var(--bfb-sl1) 76%,transparent 100%); -webkit-mask:linear-gradient(black 0 0) content-box,linear-gradient(black 0 0);-webkit-mask-composite:xor; mask:linear-gradient(black 0 0) content-box exclude,linear-gradient(black 0 0);mask-composite:exclude}
.bfb .scene{position:absolute;inset:0;z-index:-4;overflow:hidden;opacity:var(--bfb-scene-op)}
.bfb .plane{position:absolute;left:-70%;right:-70%;height:800px;background:var(--bfb-grid) 0 0/24px 24px}
.bfb .plane.floor{top:48%;transform-origin:50% 0;transform:perspective(300px) rotateX(72deg); -webkit-mask-image:linear-gradient(to bottom,transparent 0,black 38%,black 100%);mask-image:linear-gradient(to bottom,transparent 0,black 38%,black 100%)}
.bfb .plane.ceil{bottom:52%;transform-origin:50% 100%;transform:perspective(300px) rotateX(-72deg);opacity:.5; -webkit-mask-image:linear-gradient(to top,transparent 0,black 38%,black 100%);mask-image:linear-gradient(to top,transparent 0,black 38%,black 100%)}
.bfb .plane::before,.bfb .plane::after{content:"";position:absolute;inset:0;pointer-events:none}
.bfb .plane::before{background:linear-gradient(to bottom,transparent 0%,var(--bfb-vg1) 38%,var(--bfb-vg2) 100%); -webkit-mask-image:repeating-linear-gradient(90deg,black 0 1.2px,transparent 1.2px 22.8px,black 22.8px 24px);mask-image:repeating-linear-gradient(90deg,black 0 1.2px,transparent 1.2px 22.8px,black 22.8px 24px);filter:blur(4px)}
.bfb .plane::after{background:linear-gradient(to bottom,transparent 0%,var(--bfb-vc1) 38%,var(--bfb-vc2) 100%); -webkit-mask-image:repeating-linear-gradient(90deg,black 0 1px,transparent 1px 23px,black 23px 24px);mask-image:repeating-linear-gradient(90deg,black 0 1px,transparent 1px 23px,black 23px 24px)}
.bfb .plane.ceil::before{background:linear-gradient(to top,transparent 0%,var(--bfb-vg1) 38%,var(--bfb-vg2) 100%)}
.bfb .plane.ceil::after{background:linear-gradient(to top,transparent 0%,var(--bfb-vc1) 38%,var(--bfb-vc2) 100%)}
.bfb .glow{position:absolute;inset:0;z-index:-3;background:var(--bfb-glow);opacity:var(--bfb-glow-op)}
.bfb .edge-lights{position:absolute;inset:0;z-index:-3;pointer-events:none;overflow:hidden; -webkit-mask-image:linear-gradient(90deg,black 0%,rgb(0 0 0 / .6) 14%,transparent 38%,transparent 62%,rgb(0 0 0 / .6) 86%,black 100%); mask-image:linear-gradient(90deg,black 0%,rgb(0 0 0 / .6) 14%,transparent 38%,transparent 62%,rgb(0 0 0 / .6) 86%,black 100%)}
.bfb .hplane{position:absolute;left:-70%;right:-70%;height:800px}
.bfb .hplane.floor{top:48%;transform-origin:50% 0;transform:perspective(300px) rotateX(72deg); -webkit-mask-image:linear-gradient(to bottom,transparent 0,black 38%,black 100%);mask-image:linear-gradient(to bottom,transparent 0,black 38%,black 100%)}
.bfb .hplane.ceil{bottom:52%;transform-origin:50% 100%;transform:perspective(300px) rotateX(-72deg);opacity:.5; -webkit-mask-image:linear-gradient(to top,transparent 0,black 38%,black 100%);mask-image:linear-gradient(to top,transparent 0,black 38%,black 100%)}
.bfb .hplane .hg{--s:2.4px;position:absolute;inset:0; -webkit-mask-repeat:no-repeat;mask-repeat:no-repeat;-webkit-mask-size:100% var(--s);mask-size:100% var(--s)}
.bfb .hplane.floor .hg{-webkit-mask-image:linear-gradient(black,black),linear-gradient(black,black),linear-gradient(black,black),linear-gradient(black,black); -webkit-mask-position:0 calc(96px - var(--s)/2),0 calc(144px - var(--s)/2),0 calc(192px - var(--s)/2),0 calc(216px - var(--s)/2); mask-image:linear-gradient(black,black),linear-gradient(black,black),linear-gradient(black,black),linear-gradient(black,black); mask-position:0 calc(96px - var(--s)/2),0 calc(144px - var(--s)/2),0 calc(192px - var(--s)/2),0 calc(216px - var(--s)/2)}
.bfb .hplane.ceil .hg{-webkit-mask-image:linear-gradient(black,black),linear-gradient(black,black); -webkit-mask-position:0 calc(696px - var(--s)/2),0 calc(600px - var(--s)/2); mask-image:linear-gradient(black,black),linear-gradient(black,black);mask-position:0 calc(696px - var(--s)/2),0 calc(600px - var(--s)/2)}
.bfb .hplane .g1{--s:8px;background:var(--bfb-hg1);filter:blur(5px)}
.bfb .hplane .g2{background:var(--bfb-hg2)}
.bfb .d4{position:absolute;left:0;right:0;top:0;height:120px;z-index:-1;background:linear-gradient(rgb(var(--bfb-bfc)),rgba(var(--bfb-bfc),.6) 50%,transparent)}
.bfb .d5{position:absolute;inset:0;z-index:-1;pointer-events:none; background:linear-gradient(90deg,transparent 0%,transparent 12%,rgba(var(--bfb-cen),calc(var(--bfb-cen-a)*.5)) 26%,rgba(var(--bfb-cen),var(--bfb-cen-a)) 40%,rgba(var(--bfb-cen),var(--bfb-cen-a)) 60%,rgba(var(--bfb-cen),calc(var(--bfb-cen-a)*.5)) 74%,transparent 88%,transparent 100%)}
.bfb .hero{position:relative;display:inline-block;isolation:isolate;padding:22px 72px 30px;transform:perspective(880px) rotateX(20deg) scale(1.07);transform-origin:50% 85%}
.bfb .plate{position:absolute;inset:0 -120px;z-index:-2;border-radius:40px; background: linear-gradient(118deg,rgb(var(--bfb-edge)) 0%,rgba(var(--bfb-edge),.88) 14%,rgba(var(--bfb-edge),.45) 28%,rgba(var(--bfb-edge),0) 46%,rgba(var(--bfb-edge),0) 54%,rgba(var(--bfb-edge),.45) 72%,rgba(var(--bfb-edge),.88) 86%,rgb(var(--bfb-edge)) 100%), linear-gradient(115deg,transparent 30%,rgba(var(--bfb-sheen),var(--bfb-sheen-a)) 44%,transparent 58%), var(--bfb-plate-bg); border:1px solid var(--bfb-plate-bd); -webkit-backdrop-filter:var(--bfb-plate-bf);backdrop-filter:var(--bfb-plate-bf); box-shadow:var(--bfb-plate-sh)}
.bfb .ttl{position:relative;font-weight:800;text-transform:uppercase;letter-spacing:-.012em;line-height:.95}
.bfb .ttl span{position:relative;display:block;background:var(--bfb-ttl-g);-webkit-background-clip:text;background-clip:text;color:transparent}
.bfb .ttl .l1{font-size:62px}
.bfb .ttl .l2{font-size:104px;margin-top:4px}
.bfb .ttl span::before{content:attr(data-t);position:absolute;left:0;right:0;top:0;z-index:-1;pointer-events:none;-webkit-text-fill-color:var(--bfb-ttl-glow);color:var(--bfb-ttl-glow);filter:blur(24px);opacity:var(--bfb-ttl-glow-op)}
.bfb .ttl span::after{content:attr(data-t);position:absolute;left:0;right:0;top:3px;z-index:-1;pointer-events:none;-webkit-text-fill-color:var(--bfb-ttl-depth);filter:blur(1px);transform:translate(4px,5px)}
.bfb .count{display:flex;justify-content:center;gap:9px;margin-top:22px}
.bfb .unit{display:flex;flex-direction:column;align-items:center}
.bfb .ulb{margin-top:8px;font-size:12px;line-height:14px;font-weight:500;color:var(--bfb-ulb)}
.bfb .fx{position:relative;width:80px;height:84px;font-size:46px;line-height:46px;font-weight:700;letter-spacing:-1.2px;filter:var(--bfb-tile-fx)}
.bfb .fx-u,.bfb .fx-l,.bfb .fx-f,.bfb .fx-b{position:absolute;left:0;width:80px;height:42px;overflow:hidden;border:1px solid var(--bfb-tile-bd)}
.bfb .fx span{position:absolute;left:0;right:0;height:84px;line-height:84px;text-align:center;background:var(--bfb-digit);-webkit-background-clip:text;background-clip:text;color:transparent}
.bfb .fx-u,.bfb .fx-f{top:0;border-radius:14px 14px 0 0;border-bottom:0;background:var(--bfb-tile-t);box-shadow:inset 0 1px 0 var(--bfb-tile-hi)}
.bfb .fx-u span,.bfb .fx-f span{top:0}
.bfb .fx-l,.bfb .fx-b{top:42px;border-radius:0 0 14px 14px;border-top:1px solid var(--bfb-tile-div);background:var(--bfb-tile-b)}
.bfb .fx-l span,.bfb .fx-b span{top:-42px}
.bfb .fx-leaf{position:absolute;inset:0;display:none;pointer-events:none}
.bfb .fx.go .fx-leaf{display:block}
.bfb .fx-f{transform-origin:50% 100%;animation:fxDown .26s cubic-bezier(.55,0,.9,.5) forwards}
.bfb .fx-b{transform-origin:50% 0;animation:fxUp .3s cubic-bezier(.2,.7,.3,1.15) .26s both}
.bfb .fx-f::after,.bfb .fx-b::after{content:"";position:absolute;inset:0;background:linear-gradient(transparent,var(--bfb-flip-shade))}
.bfb .fx-f::after{opacity:0;animation:fxShadeIn .26s forwards}
.bfb .fx-b::after{animation:fxShadeOut .3s .26s both}
@keyframes fxDown{from{transform:perspective(320px) rotateX(0)}to{transform:perspective(320px) rotateX(-90deg)}}
@keyframes fxUp{from{transform:perspective(320px) rotateX(90deg)}to{transform:perspective(320px) rotateX(0)}}
@keyframes fxShadeIn{to{opacity:1}}
@keyframes fxShadeOut{from{opacity:.7}to{opacity:0}}
@media (prefers-reduced-motion:reduce){.bfb .fx-leaf{display:none!important}}
.bfb{font-family:'Inter',sans-serif}
.bfb .sr{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap}
@media (max-width:860px){.bfb .ttl .l1{font-size:52px}.bfb .ttl .l2{font-size:88px}.bfb .hero{padding:18px 40px 24px}}
@media (max-width:700px){.bfb .plate{inset:0 2px;border-radius:28px;background:linear-gradient(115deg,transparent 30%,rgba(var(--bfb-sheen),var(--bfb-sheen-a)) 44%,transparent 58%),var(--bfb-plate-bg)}}
@media (max-width:560px){.bfb .ttl .l1{font-size:clamp(34px,10.4vw,44px)}.bfb .ttl .l2{font-size:clamp(58px,18.4vw,80px)}.bfb .hero{padding:14px 18px 20px;transform:perspective(700px) rotateX(16deg)}.bfb{padding:40px 12px 44px}.bfb .fx,.bfb .fx-u,.bfb .fx-l,.bfb .fx-f,.bfb .fx-b{width:64px}.bfb .count{gap:6px}}`;

const unit = (key, label) => `<div class="unit"><div class="fx" data-u="${key}" aria-hidden="true"><div class="fx-u"><span>00</span></div><div class="fx-l"><span>00</span></div><div class="fx-leaf"><div class="fx-f"><span>00</span></div><div class="fx-b"><span>00</span></div></div></div><small class="ulb">${label}</small></div>`;

const HTML = `
  <section class="bfb">
    <div class="scene" aria-hidden="true"><div class="plane floor"></div><div class="plane ceil"></div></div>
    <div class="glow" aria-hidden="true"></div>
    <div class="edge-lights" aria-hidden="true"><div class="hplane floor"><i class="hg g1"></i><i class="hg g2"></i></div><div class="hplane ceil"><i class="hg g1"></i><i class="hg g2"></i></div></div>
    <div class="d4" aria-hidden="true"></div><div class="d5" aria-hidden="true"></div>
    <div class="hero" style="visibility:hidden">
      <div class="plate" aria-hidden="true"></div>
      <div class="ttl">
        <span class="l1" data-t="">&nbsp;</span>
        <span class="l2" data-t="">&nbsp;</span>
      </div>
    </div>
    <div class="count" role="timer" aria-label="Offer countdown"><span class="sr"></span>
      ${unit('d', 'days')}${unit('h', 'hours')}${unit('m', 'min')}${unit('s', 'sec')}
    </div>
  </section>`;

function injectStyles() {
  if (document.getElementById('countdown-banner-styles')) return;
  const s = document.createElement('style');
  s.id = 'countdown-banner-styles';
  s.textContent = CSS;
  document.head.appendChild(s);
}

class CountdownBanner extends HTMLElement {
  connectedCallback() {
    if (promoEndedCached() || promoHiddenForPlan(cachedPlan())) { this.remove(); return; }
    injectStyles();
    this.innerHTML = HTML;
    Promise.all([getPromoConfig(), getPromoEnd()]).then(([cfg, end]) => {
      if (!this.isConnected) return;
      const { title = '', offer = '' } = cfg.countdownBanner || {};
      if (!title && !offer) { this.remove(); return; }
      [['.l1', title], ['.l2', offer]].forEach(([sel, text]) => {
        const el = this.querySelector(sel);
        el.textContent = text;
        el.dataset.t = text;
      });
      this.querySelector('.hero').style.visibility = '';
      this._start(end);
    });
  }

  disconnectedCallback() {
    clearTimeout(this._timer);
    this._io?.disconnect();
  }

  _start(end) {
    if (end <= Date.now()) { this.remove(); return; }
    const fx = (key) => this.querySelector(`[data-u="${key}"]`);

    const shown = {};
    const setUnit = (key, val) => {
      const el = fx(key);
      const old = shown[key];
      if (old === val) return;
      const face = (sel) => el.querySelector(sel + ' span');
      shown[key] = val;
      if (old === undefined) {
        el.querySelectorAll('span').forEach((s) => { s.textContent = val; });
        return;
      }
      face('.fx-u').textContent = val;
      face('.fx-f').textContent = old;
      face('.fx-b').textContent = val;
      face('.fx-l').textContent = old;
      el.classList.remove('go');
      void el.offsetWidth;
      el.classList.add('go');
      clearTimeout(el._flipTimer);
      el._flipTimer = setTimeout(() => {
        face('.fx-l').textContent = val;
        el.classList.remove('go');
      }, 580);
    };
    const pad = (n) => String(Math.max(0, n)).padStart(2, '0');
    const sr = this.querySelector('.sr');
    let onScreen = false;
    const tick = () => {
      const diff = Math.max(0, end - Date.now());
      const { d, h, m, s } = splitRemaining(diff);
      setUnit('d', pad(d));
      setUnit('h', pad(h));
      setUnit('m', pad(m));
      setUnit('s', pad(s));
      const label = `${d} days, ${h} hours, ${m} minutes remaining`;
      if (sr.textContent !== label) sr.textContent = label;
      if (diff <= 0) this.remove();
      else if (onScreen) this._timer = setTimeout(tick, 1000);
    };
    tick();
    this._io = new IntersectionObserver(([entry]) => {
      clearTimeout(this._timer);
      onScreen = entry.isIntersecting;
      if (onScreen) tick();
    });
    this._io.observe(this);
  }
}

if (!customElements.get('countdown-banner')) customElements.define('countdown-banner', CountdownBanner);
