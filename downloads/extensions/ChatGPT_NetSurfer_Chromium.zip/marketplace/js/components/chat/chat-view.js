import { renderChatMarkdown, markdownReady } from './chat-markdown.js';
import { uploadChatImage, uniqueUploadName, looksLikeImageUrl } from './chat-upload.js';

const FOLLOW_SLACK_PX = 80;
const REVEAL_MAX_PER_FRAME = 26;
const REVEAL_CATCHUP_DIVISOR = 40;

const svgIcon = (size, body, strokeWidth = 2) => `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="${strokeWidth}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${body}</svg>`;
const COPY_PATH = '<rect x="9" y="9" width="13" height="13" rx="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>';
const CHECK_PATH = '<polyline points="20 6 9 17 4 12"></polyline>';
const COPY_SVG = svgIcon(14, COPY_PATH);
const COPY_OK_SVG = svgIcon(14, CHECK_PATH, 2.4);
const ACTION_COPY_SVG = svgIcon(18, COPY_PATH);
const ACTION_COPY_OK_SVG = svgIcon(18, CHECK_PATH, 2.4);
const SHARE_SVG = svgIcon(18, '<path d="M4 12v7a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7"/><path d="M16 6l-4-4-4 4"/><path d="M12 2v13"/>');
const REGENERATE_SVG = svgIcon(18, '<path d="M21 12a9 9 0 1 1-2.64-6.36L21 8"/><path d="M21 3v5h-5"/>');
const MORE_SVG = svgIcon(18, '<circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>', 2.4);
const BRANCH_SVG = svgIcon(16, '<path d="M6 3v12"/><circle cx="18" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M18 9a9 9 0 0 1-9 9"/>');
// Survives host rebuilds that move message nodes into a new log.
const actionMsgs = new WeakMap();
const JUMP_SVG = '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 5v14M5 12l7 7 7-7"/></svg>';
const SEND_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 19V5M5 12l7-7 7 7"/></svg>';
const STOP_SVG = '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><rect x="7" y="7" width="10" height="10" rx="2"/></svg>';

function make(tag, className) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  return node;
}

function blocksText(content) {
  return Array.isArray(content)
    ? content.filter((b) => b?.type === 'text').map((b) => b.text).join('\n')
    : String(content ?? '');
}

function buildDefaultParts(el) {
  const log = make('div', 'chat-log');
  log.setAttribute('aria-live', 'polite');
  const zone = make('div', 'chat-composer-zone');
  const jump = make('button', 'chat-jump');
  jump.type = 'button';
  jump.hidden = true;
  jump.setAttribute('aria-label', 'Jump to the latest reply');
  jump.innerHTML = `${JUMP_SVG}<span class="chat-jump-label">New reply</span>`;
  const form = make('form', 'chat-composer');
  const strip = make('div', 'chat-attachments');
  strip.hidden = true;
  const input = make('textarea', 'chat-input');
  input.rows = 1;
  input.setAttribute('data-gramm', 'false');
  input.setAttribute('data-gramm_editor', 'false');
  input.setAttribute('data-enable-grammarly', 'false');
  const send = make('button', 'chat-send');
  send.type = 'submit';
  send.title = 'Send';
  send.setAttribute('aria-label', 'Send');
  send.innerHTML = SEND_SVG;
  form.append(strip, input, make('span', 'chat-spacer'), send);
  zone.append(jump, form);
  el.append(log, zone);
}

/**
 * Mount a chat into `el`. Existing `.chat-log`, `.chat-jump`, `.chat-composer`, `.chat-input`, `.chat-attachments`,
 * `.chat-attach` and a file input are adopted; otherwise defaults are built.
 * `opts.attachments = { accept, max, upload(file, index) => url }` enables picker, paste and drop.
 * `opts.empty = { title, hint }` adds a greeting shown while the log is empty.
 * `opts.onAttachmentsChange(attachments)` fires whenever the pending attachments change.
 * `opts.messageActions = { copy, share, regenerate(msg), branch(msg), isLast(msg) }` adds a bar under finished assistant replies.
 * `opts.onNotice(text)` reports non-error feedback such as "Copied to clipboard".
 */
export function mountChat(el, opts = {}) {
  if (!el.querySelector('.chat-log')) buildDefaultParts(el);
  const log = el.querySelector('.chat-log');
  const jump = el.querySelector('.chat-jump');
  const form = el.querySelector('.chat-composer');
  const input = form?.querySelector('.chat-input, textarea') || null;
  const strip = el.querySelector('.chat-attachments');
  const sendBtn = form?.querySelector('[type="submit"]') || null;
  if (opts.empty) {
    const empty = make('div', 'chat-empty');
    const title = make('strong');
    title.textContent = opts.empty.title || '';
    const hint = make('span');
    hint.textContent = opts.empty.hint || '';
    empty.append(title, hint);
    log.after(empty);
  }

  let follow = true;
  let lastScrollTop = 0;
  let busy = false;
  let attachments = [];
  let uploadSeq = 0;

  const reportError = (msg) => { if (opts.onError) opts.onError(msg); };
  const distanceFromBottom = () => log.scrollHeight - log.scrollTop - log.clientHeight;

  function refreshJump() {
    if (!jump) return;
    if (distanceFromBottom() <= FOLLOW_SLACK_PX) {
      jump.hidden = true;
      jump.classList.remove('fresh');
    } else {
      jump.hidden = false;
    }
  }

  function markJumpFresh() {
    if (!jump || distanceFromBottom() <= FOLLOW_SLACK_PX) return;
    jump.hidden = false;
    jump.classList.add('fresh');
  }

  // Follow when pinned; otherwise re-measure both ways so the pill never points at nothing.
  function syncScroll() {
    if (follow) { log.scrollTop = log.scrollHeight; return; }
    refreshJump();
    markJumpFresh();
  }

  function pinOrMark() {
    if (follow) log.scrollTop = log.scrollHeight;
    else markJumpFresh();
  }

  function scrollToBottom() {
    follow = true;
    if (jump) { jump.hidden = true; jump.classList.remove('fresh'); }
    log.scrollTop = log.scrollHeight;
  }

  log.addEventListener('scroll', () => {
    const top = log.scrollTop;
    const goingUp = top < lastScrollTop;
    lastScrollTop = top;
    // Asymmetric on purpose: any upward move breaks follow, our own pins only move down.
    if (goingUp) follow = false;
    else if (distanceFromBottom() <= FOLLOW_SLACK_PX) follow = true;
    refreshJump();
  }, { passive: true });
  // Compositor-driven scrolls can be masked by a same-frame pin; input events can't.
  log.addEventListener('wheel', (e) => {
    if (e.deltaY < 0) { follow = false; refreshJump(); }
  }, { passive: true });
  log.addEventListener('touchmove', () => { follow = false; refreshJump(); }, { passive: true });
  // Instant, not smooth: a glide emits scroll events that would flip follow back off.
  jump?.addEventListener('click', () => scrollToBottom());

  function renderFooter(msg) {
    if (!opts.renderMessageFooter) return;
    let footer = null;
    try { footer = opts.renderMessageFooter(msg); } catch (err) { console.error('[chat] renderMessageFooter failed', err); }
    if (footer instanceof Node) msg.wrap.appendChild(footer);
  }

  function renderInto(target, text, streaming) {
    renderChatMarkdown(target, text, { streaming, renderFence: opts.renderFence || null });
  }

  async function copyWithFeedback(btn, text, idleIcon, okIcon) {
    try {
      await navigator.clipboard.writeText(text);
      btn.innerHTML = okIcon;
      setTimeout(() => { btn.innerHTML = idleIcon; }, 1200);
    } catch {
      reportError('Copy failed.');
    }
  }

  async function shareText(text) {
    if (typeof navigator.share === 'function') {
      try {
        await navigator.share({ text });
        return;
      } catch (err) {
        if (err?.name === 'AbortError') return;
      }
    }
    try {
      await navigator.clipboard.writeText(text);
      opts.onNotice?.('Copied to clipboard');
    } catch {
      reportError('Copy failed.');
    }
  }

  const actionOpts = opts.messageActions || null;
  let openMenu = null;

  function closeMenu() {
    if (!openMenu) return;
    const { menu, trigger, onDocClick, onKey } = openMenu;
    openMenu = null;
    menu.remove();
    trigger.setAttribute('aria-expanded', 'false');
    document.removeEventListener('click', onDocClick, true);
    document.removeEventListener('keydown', onKey, true);
  }

  function toggleMenu(trigger, bar, msg) {
    const wasOpen = openMenu?.trigger === trigger;
    closeMenu();
    if (wasOpen) return;
    const menu = make('div', 'chat-msg-menu');
    menu.setAttribute('role', 'menu');
    const branchItem = make('button', 'chat-msg-menu-item');
    branchItem.type = 'button';
    branchItem.setAttribute('role', 'menuitem');
    branchItem.innerHTML = `${BRANCH_SVG}<span>Branch in new chat</span>`;
    branchItem.addEventListener('click', () => {
      closeMenu();
      actionOpts.branch(msg);
    });
    menu.appendChild(branchItem);
    menu.style.left = `${trigger.offsetLeft}px`;
    bar.appendChild(menu);
    // Open upward when the log has no room below the bar.
    const logRect = log.getBoundingClientRect();
    if (bar.getBoundingClientRect().bottom + menu.offsetHeight + 8 > logRect.bottom) menu.classList.add('is-above');
    trigger.setAttribute('aria-expanded', 'true');
    const onDocClick = (e) => {
      if (!menu.contains(e.target) && !trigger.contains(e.target)) closeMenu();
    };
    const onKey = (e) => {
      if (e.key !== 'Escape') return;
      e.stopPropagation();
      closeMenu();
      trigger.focus();
    };
    openMenu = { menu, trigger, onDocClick, onKey };
    document.addEventListener('click', onDocClick, true);
    document.addEventListener('keydown', onKey, true);
    branchItem.focus();
  }

  function actionButton(label, icon, onClick) {
    const btn = make('button', 'chat-msg-action');
    btn.type = 'button';
    btn.title = label;
    btn.setAttribute('aria-label', label);
    btn.innerHTML = icon;
    btn.addEventListener('click', () => onClick(btn));
    return btn;
  }

  // Regenerate is only offered on the last message of the log, and never while a reply is in flight.
  function syncActions() {
    if (!actionOpts) return;
    const last = log.lastElementChild;
    for (const btn of log.querySelectorAll('.chat-msg-action.is-regenerate')) {
      const wrap = btn.closest('.chat-msg');
      const msg = actionMsgs.get(wrap);
      let show = wrap === last && !!msg;
      if (show && actionOpts.isLast) {
        try { show = !!actionOpts.isLast(msg); } catch { show = false; }
      }
      btn.hidden = !show;
      btn.disabled = busy;
    }
  }

  if (actionOpts) new MutationObserver(syncActions).observe(log, { childList: true });

  function renderActions(msg) {
    if (!actionOpts || msg.role !== 'assistant' || !String(msg.text || '').trim()) return;
    msg.wrap.querySelector(':scope > .chat-msg-actions')?.remove();
    const bar = make('div', 'chat-msg-actions');
    bar.setAttribute('role', 'toolbar');
    bar.setAttribute('aria-label', 'Message actions');
    if (actionOpts.copy) {
      bar.appendChild(actionButton('Copy', ACTION_COPY_SVG, (btn) => copyWithFeedback(btn, msg.text, ACTION_COPY_SVG, ACTION_COPY_OK_SVG)));
    }
    if (actionOpts.share) bar.appendChild(actionButton('Share', SHARE_SVG, () => shareText(msg.text)));
    if (typeof actionOpts.regenerate === 'function') {
      const regen = actionButton('Regenerate', REGENERATE_SVG, (btn) => { if (!btn.disabled) actionOpts.regenerate(msg); });
      regen.classList.add('is-regenerate');
      regen.hidden = true;
      bar.appendChild(regen);
    }
    if (typeof actionOpts.branch === 'function') {
      const more = actionButton('More actions', MORE_SVG, (btn) => toggleMenu(btn, bar, msg));
      more.setAttribute('aria-haspopup', 'menu');
      more.setAttribute('aria-expanded', 'false');
      bar.appendChild(more);
    }
    if (!bar.childElementCount) return;
    actionMsgs.set(msg.wrap, msg);
    msg.wrap.appendChild(bar);
    syncActions();
  }

  /** `meta` (e.g. `{ turn }`) is kept on the returned message object that action callbacks receive. */
  function appendMessage(role, content, meta = {}) {
    const wrap = make('div', `chat-msg ${role}`);
    if (opts.messageClass) wrap.classList.add(...String(opts.messageClass).split(/\s+/).filter(Boolean));
    const bubble = make('div', 'chat-msg-bubble');
    const text = blocksText(content);
    if (text) {
      const body = make('div', 'chat-md');
      bubble.appendChild(body);
      renderInto(body, text, false);
    }
    if (Array.isArray(content)) {
      for (const block of content) {
        if (block?.type === 'image' && block.source?.url) {
          const img = make('img', 'chat-msg-img');
          img.src = block.source.url;
          img.alt = 'attached image';
          bubble.appendChild(img);
        }
      }
    }
    wrap.appendChild(bubble);
    if (role === 'user' && text.trim()) {
      const copyBtn = make('button', 'chat-msg-copy');
      copyBtn.type = 'button';
      copyBtn.title = 'Copy message';
      copyBtn.setAttribute('aria-label', 'Copy message');
      copyBtn.innerHTML = COPY_SVG;
      copyBtn.addEventListener('click', () => copyWithFeedback(copyBtn, text, COPY_SVG, COPY_OK_SVG));
      wrap.appendChild(copyBtn);
    }
    log.appendChild(wrap);
    const msg = { ...meta, role, content, text, wrap, bubble };
    if (text) {
      renderFooter(msg);
      renderActions(msg);
    }
    // A whole new message pins the view; only mid-stream growth respects the pause.
    follow = true;
    log.scrollTop = log.scrollHeight;
    return msg;
  }

  function appendNode(node) {
    log.appendChild(node);
    pinOrMark();
    return node;
  }

  /** Assistant bubble with a status line and a steady-typing reveal of streamed tokens. */
  function beginAssistantStream({ status = '' } = {}) {
    const msg = appendMessage('assistant', '');
    const { wrap, bubble } = msg;
    const stage = make('div', 'chat-thinking');
    if (opts.thinkingIcon) {
      const logo = make('span', 'chat-thinking-logo');
      logo.innerHTML = opts.thinkingIcon;
      stage.appendChild(logo);
    }
    const stageText = make('span', 'chat-shimmer-text');
    stageText.textContent = status;
    stage.appendChild(stageText);
    const body = make('div', 'chat-md');
    bubble.append(stage, body);

    let streamed = '';
    let revealed = 0;
    let rafId = 0;
    let onCaughtUp = null;

    // Network bursts are absorbed into a per-frame reveal that speeds up with the backlog.
    const paint = () => {
      rafId = 0;
      const backlog = streamed.length - revealed;
      if (backlog > 0) {
        revealed += Math.max(1, Math.min(REVEAL_MAX_PER_FRAME, Math.ceil(backlog / REVEAL_CATCHUP_DIVISOR)));
        if (revealed > streamed.length) revealed = streamed.length;
        renderInto(body, streamed.slice(0, revealed), true);
        pinOrMark();
      }
      if (revealed < streamed.length) { schedule(); return; }
      if (onCaughtUp) { const done = onCaughtUp; onCaughtUp = null; done(); }
    };
    const schedule = () => { if (!rafId) rafId = requestAnimationFrame(paint); };
    const flush = () => { if (rafId) { cancelAnimationFrame(rafId); rafId = 0; } };

    function render(text, withActions = true) {
      flush();
      onCaughtUp = null;
      stage.remove();
      renderInto(body, text, false);
      msg.content = text;
      msg.text = text;
      renderFooter(msg);
      if (withActions) renderActions(msg);
      syncScroll();
    }

    return {
      wrap,
      bubble,
      msg,
      get text() { return streamed; },
      setStatus(text) { stageText.textContent = text; },
      appendToken(chunk) {
        if (!chunk) return;
        streamed += chunk;
        schedule();
      },
      reset(nextStatus = '') {
        streamed = '';
        revealed = 0;
        onCaughtUp = null;
        flush();
        body.innerHTML = '';
        if (!stage.isConnected) bubble.insertBefore(stage, body);
        stageText.textContent = nextStatus;
        syncScroll();
      },
      render: (text) => render(text),
      fail(message) { render(`⚠️ ${message}`, false); },
      // Lets the reveal catch up before swapping in the full render.
      finish(text) {
        return new Promise((resolve) => {
          const go = () => markdownReady.then(() => { render(text); resolve(); });
          if (revealed >= streamed.length) go();
          else { onCaughtUp = go; schedule(); }
        });
      },
    };
  }

  function renderAttachments() {
    if (!strip) return;
    strip.innerHTML = '';
    strip.hidden = attachments.length === 0;
    for (const att of attachments) {
      const thumb = make('div', 'chat-thumb' + (att.status === 'ready' ? '' : ' loading'));
      if (att.status === 'ready') {
        const img = make('img');
        img.src = att.url;
        img.alt = 'attachment';
        thumb.appendChild(img);
      } else {
        thumb.textContent = att.status === 'error' ? '⚠️' : '…';
        if (att.status === 'error') thumb.title = 'Upload failed';
      }
      const remove = make('button', 'chat-thumb-remove');
      remove.type = 'button';
      remove.textContent = '×';
      remove.title = 'Remove';
      remove.addEventListener('click', () => {
        attachments = attachments.filter((a) => a !== att);
        renderAttachments();
      });
      thumb.appendChild(remove);
      strip.appendChild(thumb);
    }
    opts.onAttachmentsChange?.(attachments.slice());
  }

  function addAttachment(att) {
    attachments.push(att);
    renderAttachments();
    return att;
  }

  const attachOpts = opts.attachments || null;
  const acceptList = String(attachOpts?.accept || 'image/*').split(',').map((s) => s.trim()).filter(Boolean);
  const accepts = (file) => !!file?.type && acceptList.some((a) => (a.endsWith('/*') ? file.type.startsWith(a.slice(0, -1)) : file.type === a));
  const hasRoom = () => {
    if (!attachOpts?.max || attachments.filter((a) => a.status !== 'error').length < attachOpts.max) return true;
    reportError(`You can attach up to ${attachOpts.max} image${attachOpts.max === 1 ? '' : 's'}.`);
    return false;
  };

  async function addFiles(files) {
    const upload = attachOpts.upload || ((file, index) => uploadChatImage(file, uniqueUploadName(file, 'chat', index)));
    for (const file of files) {
      if (!accepts(file)) continue;
      if (!hasRoom()) return;
      const att = addAttachment({ url: '', status: 'uploading' });
      try {
        att.url = await upload(file, ++uploadSeq);
        att.status = 'ready';
      } catch (err) {
        console.error('[chat] upload failed', err);
        att.status = 'error';
        reportError('Upload failed');
      }
      renderAttachments();
    }
  }

  function addImageUrl(url) {
    const clean = String(url || '').trim();
    if (!clean || attachments.some((a) => a.url === clean) || !hasRoom()) return;
    addAttachment({ url: clean, status: 'ready' });
  }

  if (attachOpts && form) {
    let picker = form.querySelector('input[type="file"]');
    if (!picker) {
      picker = make('input');
      picker.type = 'file';
      picker.hidden = true;
      picker.accept = acceptList.join(',');
      picker.multiple = attachOpts.max !== 1;
      form.appendChild(picker);
    }
    let attachBtn = form.querySelector('.chat-attach');
    if (!attachBtn) {
      attachBtn = make('button', 'chat-attach');
      attachBtn.type = 'button';
      attachBtn.textContent = '+';
      attachBtn.title = 'Attach an image (or paste a screenshot)';
      attachBtn.setAttribute('aria-label', 'Attach image');
      const anchor = form.querySelector(':scope > .chat-spacer') || (sendBtn?.parentElement === form ? sendBtn : null);
      if (anchor) anchor.before(attachBtn);
      else form.appendChild(attachBtn);
    }
    attachBtn.addEventListener('click', () => picker.click());
    picker.addEventListener('change', () => {
      if (picker.files?.length) addFiles(Array.from(picker.files));
      picker.value = '';
    });
    input?.addEventListener('paste', (e) => {
      const files = Array.from(e.clipboardData?.items || [])
        .filter((it) => it.kind === 'file' && accepts(it))
        .map((it) => it.getAsFile()).filter(Boolean);
      if (files.length) {
        e.preventDefault();
        addFiles(files);
        return;
      }
      // A clipboard holding only an image url becomes an attachment, not text.
      const pasted = (e.clipboardData?.getData('text') || '').trim();
      if (pasted && looksLikeImageUrl(pasted)) {
        e.preventDefault();
        addImageUrl(pasted);
      }
    });
    form.addEventListener('dragover', (e) => { e.preventDefault(); });
    form.addEventListener('drop', (e) => {
      const files = Array.from(e.dataTransfer?.files || []).filter(accepts);
      if (files.length) {
        e.preventDefault();
        addFiles(files);
      }
    });
  }

  function clearAttachments() {
    attachments = [];
    renderAttachments();
  }

  function clearComposer() {
    if (input) { input.value = ''; input.style.height = ''; }
    clearAttachments();
  }

  input?.addEventListener('input', () => {
    input.style.height = 'auto';
    input.style.height = `${input.scrollHeight}px`;
  });
  input?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      form?.requestSubmit();
    }
  });
  form?.addEventListener('submit', (e) => {
    e.preventDefault();
    if (busy) return;
    const text = (input?.value || '').trim();
    if (!text && !attachments.length) return;
    opts.onSend?.(text, attachments.slice());
  });

  // While a stoppable reply runs, the send button becomes Stop; it stays disabled after the click until the reply ends.
  let stopHandler = null;
  const sendIcon = sendBtn?.innerHTML || SEND_SVG;
  const sendLabel = sendBtn?.getAttribute('aria-label') || 'Send';
  function syncSend() {
    if (!sendBtn) return;
    const stoppable = busy && typeof stopHandler === 'function';
    sendBtn.disabled = busy && !stoppable;
    if (sendBtn.classList.contains('is-stop') === stoppable) return;
    sendBtn.classList.toggle('is-stop', stoppable);
    sendBtn.innerHTML = stoppable ? STOP_SVG : sendIcon;
    sendBtn.title = stoppable ? 'Stop' : sendLabel;
    sendBtn.setAttribute('aria-label', stoppable ? 'Stop' : sendLabel);
  }
  sendBtn?.addEventListener('click', (e) => {
    if (!sendBtn.classList.contains('is-stop')) return;
    e.preventDefault();
    const handler = stopHandler;
    stopHandler = null;
    syncSend();
    handler?.();
  });

  return {
    el,
    log,
    form,
    input,
    ready: markdownReady,
    appendMessage,
    appendNode,
    beginAssistantStream,
    setBusy(on) {
      busy = !!on;
      if (!busy) stopHandler = null;
      syncSend();
      syncActions();
    },
    /** Turns the send button into Stop while busy; `fn` runs once on click. */
    setStopHandler(fn) {
      stopHandler = typeof fn === 'function' ? fn : null;
      syncSend();
    },
    isBusy: () => busy,
    clear() {
      closeMenu();
      log.innerHTML = '';
      refreshJump();
    },
    clearComposer,
    clearAttachments,
    scrollToBottom,
    syncScroll,
    refreshJump,
    getAttachments: () => attachments.slice(),
    addAttachment,
    addImageUrl,
    renderAttachments,
  };
}
