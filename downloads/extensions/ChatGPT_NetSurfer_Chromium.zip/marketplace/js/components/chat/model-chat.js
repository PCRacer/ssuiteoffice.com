import { mountChat } from './chat-view.js?v=5';
import { mountChatSidebar } from './chat-sidebar.js?v=5';
import { readSSE } from './chat-transport.js';
import { renderSchemaForm, loadSchemaWidgets } from '/marketplace/js/runner/schema-form.js';
import { showToast } from '/marketplace/js/components/toast.js';
import { saveSnapshot, runPreflight, showAgreementModal } from '/marketplace/js/shared/pending-paid.js';
import { buildModelApiUrl, checkAuthOrRedirect, formatCredits, extractCreditsNumber, refreshCreditsBalance } from '/marketplace/js/shared/model-api.js?v=3';
import { showCorporateEmailModal, showPlanRequiredModal, openPricingModal } from '/marketplace/js/shared/model-gate-modals.js?v=2';

const SETTINGS_SVG = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/></svg>';
// Same credit glyph as the navbar balance (navbar.js #creditsDisplay).
const BOLT_SVG = '<svg width="16" height="16" viewBox="0 0 14 14" fill="currentColor" aria-hidden="true"><path d="M4.48963 7.68204H5.79855V11.5184C5.79855 12.0831 6.3577 12.3496 6.65422 11.9233L9.86088 7.34104C10.1405 6.94142 9.91595 6.31802 9.49235 6.31802H8.18342V2.48171C8.18342 1.91692 7.62426 1.65051 7.32774 2.07676L4.1211 6.65903C3.84576 7.05864 4.07026 7.68204 4.48963 7.68204Z"/></svg>';
const COST_TITLE = 'Estimated credits for this message';
const IMAGE_KEYS = ['image', 'image_url', 'image_input', 'images', 'input_images'];
const MAX_TOKEN_KEYS = ['max_tokens', 'maxTokens', 'max_output_tokens', 'maxOutputTokens', 'max_new_tokens', 'maxNewTokens', 'max_completion_tokens', 'maxCompletionTokens', 'max_tokens_to_sample', 'maxTokensToSample'];
// Mirrors CHAT_DEFAULT_MAX_OUTPUT_TOKENS in src/services/model-chat.ts, which the server reserves per turn.
const CHAT_DEFAULT_MAX_OUTPUT_TOKENS = 4096;
const INTERNAL_ERROR_RE = /\bsql:|SQL syntax|Unknown column|no such (table|column)|\bER_[A-Z_]{3,}|SQLITE_|parameters:\s*\[|\bSELECT\b.+\bFROM\b|\bINSERT INTO\b|\bUPDATE\s+\S+\s+SET\b|\bDELETE FROM\b|Duplicate entry|Table '[^']+' doesn't exist|ECONNREFUSED|\bat .+\(.+:\d+:\d+\)/;

function errorText(err, fallback) {
  const text = typeof err === 'string' ? err : (err && typeof err.message === 'string' ? err.message : '');
  return text && !INTERNAL_ERROR_RE.test(text) ? text : fallback;
}

function toast(title, type = 'error') {
  showToast({ title, type });
}

function titleOf(text) {
  return String(text || '').replace(/\s+/g, ' ').trim().slice(0, 80);
}

function itemText(item) {
  return (Array.isArray(item?.content) ? item.content : [])
    .map(c => (typeof c?.text === 'string' ? c.text : ''))
    .join('');
}

function fieldType(field) {
  return field?._raw?.type || field?.type;
}

function promptKeyOf(schema) {
  const props = schema?.properties || {};
  return ['prompt', 'text', 'question', 'query', 'input'].find(k => props[k] && fieldType(props[k]) === 'string') || 'prompt';
}

// The schema field that takes image urls; null hides the attach button.
function imageFieldOf(schema) {
  const props = schema?.properties || {};
  const candidates = Object.entries(props).map(([key, field]) => {
    const raw = field?._raw || field || {};
    const isArray = (raw.type || field?.type) === 'array';
    const item = isArray ? (raw.items || field?.items || {}) : raw;
    const type = item.type || (isArray ? field?.items?.type : field?.type) || 'string';
    const format = String(item.format || (isArray ? '' : field?.format) || '').toLowerCase();
    return { key, isArray, type, format, maxItems: Number(field?.maxItems ?? raw.maxItems) || undefined };
  }).filter(c => c.type === 'string');
  const hit = candidates.find(c => IMAGE_KEYS.includes(c.key))
    || candidates.find(c => c.format === 'image' || (c.format === 'uri' && /image/i.test(c.key)));
  if (!hit) return null;
  return { key: hit.key, isArray: hit.isArray, max: hit.isArray ? hit.maxItems : 1, required: (schema?.required || []).includes(hit.key) };
}

// schema-form takes plain JSON schema + x-uap; the playground schema is normalized (integer lives in _raw).
function formSchemaOf(schema, skip) {
  const properties = {};
  for (const [key, field] of Object.entries(schema?.properties || {})) {
    if (!field || skip.includes(key)) continue;
    const { _raw, enumLabels, ...prop } = field;
    if (_raw?.type === 'integer') prop.type = 'integer';
    if (Array.isArray(enumLabels)) prop['x-uap'] = { ...(prop['x-uap'] || {}), enumLabels };
    properties[key] = prop;
  }
  return { type: 'object', properties, required: (schema?.required || []).filter(k => k in properties) };
}

function readyImages(attachments, field) {
  if (!field) return [];
  const ready = attachments.filter(a => a.status === 'ready' && a.url).map(a => a.url);
  return field.isArray ? ready : ready.slice(0, 1);
}

function eventModel(info) {
  return { id: info.id, name: info.displayName || info.id, category: info.mediaType || '' };
}

const FULL_TIME_FMT = new Intl.DateTimeFormat(undefined, { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });

function msgTime(date) {
  return FULL_TIME_FMT.format(date);
}

// One muted line above the bubble: "Model · time", either part optional.
function setMsgMeta(wrap, { name, at } = {}) {
  if (!wrap) return;
  const date = at ? new Date(at) : null;
  const validDate = date && !Number.isNaN(date.getTime()) ? date : null;
  let label = wrap.querySelector(':scope > .chat-msg-model');
  if (!label) {
    if (!name && !validDate) return;
    label = document.createElement('span');
    label.className = 'chat-msg-model';
    wrap.prepend(label);
  }
  if (name) label.dataset.model = name;
  if (validDate) {
    label.dataset.time = msgTime(validDate);
    label.title = validDate.toLocaleString();
  }
  label.textContent = [label.dataset.model, label.dataset.time].filter(Boolean).join(' · ');
}

function setHash(id) {
  history.replaceState(history.state, '', `${location.pathname}${location.search}${id ? `#c=${id}` : ''}`);
}

// Follows the navbar's login signal instead of sending another slow /auth/me.
function whenSignedInKnown() {
  if (window.AitopiaCache?.getUserProfile?.()) return Promise.resolve(true);
  const nav = window.NavbarComponent;
  if (!nav?.isLoggedIn || !document.getElementById('navbar-container')) return fetchSignedIn();
  const known = nav.isLoggedIn();
  if (typeof known === 'boolean') return Promise.resolve(known);
  return new Promise((resolve) => {
    window.addEventListener('aitopia-auth-changed', (e) => resolve(e.detail?.loggedIn === true), { once: true });
  });
}

async function fetchSignedIn() {
  try {
    const res = await fetch('https://aitopia.ai/auth/me', { credentials: 'include' });
    if (!res.ok) return false;
    const json = await res.json();
    const user = json?.data?.user || json?.data || json?.user || json;
    return !!(user && !Array.isArray(user) && typeof user === 'object' && (user.email || user.key));
  } catch {
    return false;
  }
}

// The job is reused across turns, so a completed status only counts once it carries this turn.
async function pollModelJob(jobId, turn, onStatus, stopped) {
  for (let attempt = 0; attempt < 900; attempt++) {
    if (stopped?.()) return { status: 'cancelled' };
    try {
      const res = await fetch(`https://aitopia.ai/api/models/jobs/${encodeURIComponent(jobId)}`);
      const job = await res.json();
      if (job.status === 'failed' || job.status === 'cancelled') return job;
      if (job.status === 'completed' && (turn == null || job.output?.chatTurn === turn)) return job;
      if (!res.ok && res.status < 500) return { status: 'failed', error: job.error || 'Job not found' };
      onStatus?.(job.status);
    } catch (err) {
      console.error('Poll error:', err);
    }
    await new Promise(resolve => setTimeout(resolve, 2000));
  }
  return { status: 'failed', error: 'Timed out waiting for the reply.' };
}

// Shows the reply as it is written (SSE); falls back to polling when the live view is unavailable or drops.
// Resolves to the same job shape as pollModelJob.
async function followModelReply(jobId, turn, streamUrl, stream, onStatus, stopped) {
  const url = streamUrl || `https://aitopia.ai/api/models/jobs/${encodeURIComponent(jobId)}/stream?turn=${encodeURIComponent(turn)}`;
  try {
    const res = await fetch(url, { headers: { Accept: 'text/event-stream' } });
    if (res.ok && (res.headers.get('content-type') || '').includes('text/event-stream')) {
      let result = null;
      await readSSE(res, (type, data) => {
        if (type === 'token' && typeof data?.content === 'string') {
          stream.appendToken(data.content);
        } else if (type === 'done') {
          const final = typeof data?.result?.text === 'string' ? data.result.text : stream.text;
          result = !final.trim() && data?.result?.status === 'stopped'
            ? { status: 'failed', error: 'Stopped.' }
            : { status: 'completed', output: { text: final, chatTurn: turn } };
        } else if (type === 'error' && !data?.retryable) {
          result = { status: 'failed', error: data?.message };
        }
      });
      if (result) return result;
    }
  } catch (err) {
    console.warn('[model-chat] live reply unavailable, polling instead', err);
  }
  return pollModelJob(jobId, turn, onStatus, stopped);
}

async function stopModelReply(jobId) {
  try {
    const res = await fetch(`https://aitopia.ai/api/models/jobs/${encodeURIComponent(jobId)}/stop`, { method: 'POST', credentials: 'include' });
    if (!res.ok && res.status !== 409) toast('Could not stop the reply.');
  } catch {
    toast('Could not stop the reply.');
  }
}

/** Sidebar loader for a conversations endpoint returning `{ conversations, nextCursor }`. */
export function createConversationLoader(url) {
  return async (cursor) => {
    const qs = new URLSearchParams({ limit: '20' });
    if (cursor) qs.set('cursor', cursor);
    const res = await fetch(`${url}?${qs}`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    return {
      items: (data.conversations || []).map(c => ({
        id: c.conversationId, title: c.title, updatedAt: c.updatedAt, modelId: c.modelId || null, subtitle: c.modelName || '',
      })),
      nextCursor: data.nextCursor || null,
    };
  };
}

/**
 * Text-model chat with a conversation sidebar. `onConversationModel(modelId)` lets the host follow an opened
 * conversation's latest model via `setModel(info, schema, { keepConversation: true })`.
 */
export async function mountModelChat({ root, modelInfo, modelSchema, sidebar = {}, onConversationModel, conversationUrl, modelLabel, composerTools = [] }) {
  const signedInKnown = whenSignedInKnown();
  const state = { info: modelInfo, schema: modelSchema, signedIn: false, destroyed: false };
  let conv = { id: null, title: '', turnCount: 0, history: [] };
  let ui = null;
  let sidebarApi = null;
  let estimateTimer = 0;

  root.innerHTML = `
    <div class="chat-shell">
      <aside class="chat-sidebar"></aside>
      <section class="chat-main"></section>
    </div>`;
  const shell = root.querySelector('.chat-shell');
  const main = root.querySelector('.chat-main');

  function estimateInput(u) {
    const values = {};
    for (const [key, value] of Object.entries(u.pruneSettings(window.agent_form_data || {}))) {
      if (value !== undefined && value !== '') values[key] = value;
    }
    const images = readyImages(u.chat.getAttachments(), u.imageField);
    if (images.length) values[u.imageField.key] = u.imageField.isArray ? images : images[0];
    const text = u.chat.input.value.trim();
    if (!u.tokenPriced) {
      values[u.promptKey] = text;
      return values;
    }
    // Token-priced turns bill the whole history, so price it the way the server builds the provider input.
    const turns = [...conv.history, { role: 'user', text }];
    const { prompt: _prompt, messages: _messages, ...base } = values;
    const props = state.schema?.properties || {};
    if ('messages' in props) {
      const system = typeof base.system_prompt === 'string' ? base.system_prompt.trim() : '';
      if (system) delete base.system_prompt;
      const messages = [...(system ? [{ role: 'system', content: system }] : []), ...turns.map(t => ({ role: t.role, content: t.text }))];
      base.messages = fieldType(props.messages) === 'string' ? JSON.stringify(messages) : messages;
      if ((state.schema?.required || []).includes(u.promptKey)) base[u.promptKey] = text;
    } else {
      base[u.promptKey] = turns.length <= 1
        ? text
        : [...turns.map(t => `${t.role === 'user' ? 'User' : 'Assistant'}: ${t.text}`), 'Assistant:'].join('\n\n');
    }
    if (!MAX_TOKEN_KEYS.some(k => base[k] != null && base[k] !== '')) base.max_tokens = CHAT_DEFAULT_MAX_OUTPUT_TOKENS;
    return base;
  }

  function syncCost() {
    clearTimeout(estimateTimer);
    const u = ui;
    if (!u || state.destroyed) return;
    const credits = extractCreditsNumber(formatCredits(state.info, estimateInput(u)));
    u.cost.hidden = credits === null;
    u.costValue.textContent = credits ?? '';
  }

  function scheduleCost() {
    clearTimeout(estimateTimer);
    estimateTimer = setTimeout(syncCost, 150);
  }

  function modelName(id) {
    const info = state.info;
    return modelLabel?.(id) || (id === info.id ? info.displayName || info.name : '') || id;
  }

  // Replies get a model label once the conversation has more than one model; the first reply is labelled then.
  function markModel(c, wrap, modelId) {
    if (!modelId || !wrap) return;
    if (!c.lastModel) {
      c.lastModel = modelId;
      c.firstReply = { wrap, modelId };
      return;
    }
    if (modelId === c.lastModel) return;
    if (c.firstReply) {
      setMsgMeta(c.firstReply.wrap, { name: modelName(c.firstReply.modelId) });
      c.firstReply = null;
    }
    c.lastModel = modelId;
    setMsgMeta(wrap, { name: modelName(modelId) });
  }

  // keepLog carries the rendered conversation and ready attachments over to the rebuilt per-model composer.
  function build(keepLog = false) {
    const draft = ui?.chat.input?.value || '';
    const oldLog = keepLog ? ui?.chat.log : null;
    const oldImages = keepLog && ui ? ui.chat.getAttachments().filter(a => a.status === 'ready' && a.url).map(a => a.url) : [];
    if (ui) {
      ui.floating.forEach(n => n.remove());
      main.querySelectorAll(':scope > .chat-log, :scope > .chat-composer-zone, :scope > .chat-empty').forEach(n => n.remove());
    }
    const info = state.info;
    const schema = state.schema;
    const name = info.name || info.displayName || info.id;
    const imageField = imageFieldOf(schema);
    const promptKey = promptKeyOf(schema);

    const chat = mountChat(main, {
      onSend: (text, attachments) => { send(text, attachments); },
      onError: (msg) => toast(msg),
      onAttachmentsChange: () => scheduleCost(),
      attachments: imageField ? { accept: 'image/*', max: imageField.max } : null,
      empty: { title: 'Hi, how can I help you?', hint: `Chatting with ${name}` },
      onNotice: (msg) => toast(msg, 'success'),
      messageActions: {
        copy: true,
        share: true,
        // Read per reply, so they appear once sign-in is known without rebuilding the chat.
        get regenerate() { return state.signedIn ? regenerate : undefined; },
        get branch() { return state.signedIn ? branch : undefined; },
        isLast: (msg) => msg.turn != null && !!conv.id,
      },
    });
    if (oldLog) {
      chat.log.replaceChildren(...oldLog.childNodes);
      chat.scrollToBottom();
    }
    chat.input.placeholder = `Message ${name}`;
    chat.input.setAttribute('aria-label', `Message ${name}`);
    chat.input.addEventListener('input', scheduleCost);
    chat.log.addEventListener('click', (e) => {
      const img = e.target.closest('.chat-msg-img');
      if (img?.src) window.open(img.src, '_blank', 'noopener');
    });

    // Settings are generated from the schema; the composer owns the prompt, history and images.
    const panel = document.createElement('div');
    panel.className = 'chat-settings';
    panel.hidden = true;
    panel.innerHTML = '<div class="chat-settings-head"><span>Settings</span><button type="button" class="chat-tool" aria-label="Close settings">&times;</button></div>';
    const settingsBody = document.createElement('div');
    panel.appendChild(settingsBody);
    chat.form.parentElement.appendChild(panel);
    const formSchema = formSchemaOf(schema, [promptKey, 'messages', ...(imageField ? [imageField.key] : [])]);
    // Select menus mount on <body class="aitopia">; clicks inside them must not close the popover.
    const bodyBefore = new Set(document.body.children);
    const settings = renderSchemaForm({ schema: formSchema, container: settingsBody, collapseOptional: false });
    const floating = [...document.body.children].filter(n => !bodyBefore.has(n));
    settingsBody.addEventListener('input', scheduleCost);
    settingsBody.addEventListener('change', scheduleCost);
    // Untouched fields without a schema default render a placeholder (e.g. 0); drop them so the provider default applies.
    let baseline = {};
    const baselineReady = settings.getValues().then((values) => { baseline = values; }, () => {});

    const settingsBtn = document.createElement('button');
    settingsBtn.type = 'button';
    settingsBtn.className = 'chat-tool';
    settingsBtn.title = 'Settings';
    settingsBtn.setAttribute('aria-label', 'Settings');
    settingsBtn.setAttribute('aria-expanded', 'false');
    settingsBtn.innerHTML = SETTINGS_SVG;
    settingsBtn.hidden = Object.keys(formSchema.properties).length === 0;
    settingsBtn.addEventListener('click', () => next.setSettingsOpen(panel.hidden));
    panel.querySelector('.chat-settings-head button').addEventListener('click', () => next.setSettingsOpen(false));

    const cost = document.createElement('span');
    cost.className = 'chat-cost';
    cost.title = COST_TITLE;
    cost.hidden = true;
    cost.innerHTML = `${BOLT_SVG}<span></span>`;
    const spacer = chat.form.querySelector('.chat-spacer');
    spacer.before(settingsBtn, ...composerTools);
    chat.form.querySelector('.chat-send').before(cost);

    // Open upward when there is room above the composer, otherwise downward; cap height to the space available.
    const placeSettings = () => {
      if (panel.hidden) return;
      const shellRect = shell.getBoundingClientRect();
      const zoneRect = chat.form.getBoundingClientRect();
      const above = zoneRect.top - shellRect.top - 16;
      const below = shellRect.bottom - zoneRect.bottom - 16;
      panel.style.maxHeight = '';
      const wanted = Math.min(panel.scrollHeight, 560);
      const down = above < wanted && below > above;
      panel.classList.toggle('is-below', down);
      panel.style.maxHeight = `${Math.max(160, Math.min(560, down ? below : above))}px`;
    };

    const next = {
      chat,
      settings,
      panel,
      settingsBtn,
      floating,
      cost,
      costValue: cost.querySelector('span'),
      promptKey,
      imageField,
      tokenPriced: info.cost?.perMillionInput > 0 || info.cost?.perMillionOutput > 0,
      baselineReady,
      placeSettings,
      pruneSettings: (values) => Object.fromEntries(Object.entries(values).filter(([key, value]) =>
        formSchema.properties[key]?.default != null || !(key in baseline) || JSON.stringify(value) !== JSON.stringify(baseline[key]))),
      setSettingsOpen(open) {
        panel.hidden = !open;
        settingsBtn.setAttribute('aria-expanded', String(open));
        placeSettings();
      },
    };
    ui = next;
    if (draft) {
      chat.input.value = draft;
      chat.input.dispatchEvent(new Event('input'));
    }
    if (oldImages.length) {
      if (imageField) oldImages.slice(0, imageField.max || undefined).forEach(url => chat.addImageUrl(url));
      else toast('This model does not accept images.', 'info');
    }
    syncCost();
    baselineReady.then(() => { if (ui === next) syncCost(); });
  }

  const onResize = () => ui?.placeSettings();
  const onDocClick = (e) => {
    if (!ui || ui.panel.hidden) return;
    const path = e.composedPath();
    if (path.includes(ui.panel) || path.includes(ui.settingsBtn) || ui.floating.some(n => path.includes(n))) return;
    ui.setSettingsOpen(false);
  };
  const onKey = (e) => { if (e.key === 'Escape') ui?.setSettingsOpen(false); };
  window.addEventListener('resize', onResize);
  window.addEventListener('aitopia:form:data-changed', scheduleCost);
  document.addEventListener('click', onDocClick);
  document.addEventListener('keydown', onKey);

  function addRow(c, info) {
    sidebarApi?.prepend({ id: c.id, title: c.title, updatedAt: new Date().toISOString(), modelId: info.id, subtitle: sidebar.rowSubtitle?.(info) || '' });
  }

  function newChat() {
    conv = { id: null, title: '', turnCount: 0, history: [] };
    ui.chat.clear();
    ui.chat.setBusy(false);
    sidebarApi?.setActive(null);
    setHash(null);
    syncCost();
    ui.chat.input?.focus();
  }

  async function openConversation(id) {
    const c = { id, title: '', turnCount: 0, history: [] };
    conv = c;
    ui.chat.clear();
    ui.chat.setBusy(false);
    sidebarApi?.setActive(id);
    setHash(id);
    const loading = ui.chat.beginAssistantStream({ status: 'Loading conversation…' });
    let data;
    try {
      const url = conversationUrl ? conversationUrl(id) : `${buildModelApiUrl('info', state.info.id)}/conversations/${encodeURIComponent(id)}`;
      const res = await fetch(url);
      data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error((res.status < 500 && typeof data.error === 'string' && data.error) || 'Could not load this conversation.');
    } catch (err) {
      if (c === conv && !state.destroyed) loading.fail(errorText(err, 'Could not load this conversation.'));
      return;
    }
    if (c !== conv || state.destroyed) return;
    const latestModel = typeof data.modelId === 'string' && data.modelId ? data.modelId : null;
    if (latestModel && latestModel !== state.info.id && onConversationModel) {
      try {
        await onConversationModel(latestModel);
      } catch (err) {
        console.error('[model-chat] model switch failed', err);
        if (c === conv) toast('Could not load this model.');
      }
      if (c !== conv || state.destroyed) return;
    }
    const info = state.info;
    loading.wrap.remove();
    const items = (Array.isArray(data.items) ? data.items : [])
      .filter(item => item?.type === 'message' && (item.role === 'user' || item.role === 'assistant'));
    const answered = new Set(items.filter(item => item.role === 'assistant').map(item => item.turn));
    let pendingText = '';
    for (const item of items) {
      const text = itemText(item);
      if (!text) continue;
      if (item.role === 'user' && !c.title) c.title = titleOf(text);
      if (item.role === 'assistant') c.turnCount++;
      if (item.role === 'assistant' || item.turn == null || answered.has(item.turn)) c.history.push({ role: item.role, text });
      else if (item.turn === data.pendingTurn) pendingText = text;
      const images = item.role === 'user' && Array.isArray(item.content)
        ? item.content.filter(x => x?.type === 'input_image' && typeof x.image_url === 'string').map(x => ({ type: 'image', source: { type: 'url', url: x.image_url } }))
        : [];
      const msg = ui.chat.appendMessage(item.role, images.length ? [{ type: 'text', text }, ...images] : text, { turn: item.turn });
      setMsgMeta(msg.wrap, { at: item.createdAt });
      if (item.role === 'assistant') markModel(c, msg.wrap, (typeof item.model === 'string' && item.model) || latestModel);
    }
    if (data.busy && data.jobId && data.pendingTurn != null) {
      const stream = ui.chat.beginAssistantStream({ status: 'Thinking…' });
      stream.msg.turn = data.pendingTurn;
      const chat = ui.chat;
      chat.setBusy(true);
      chat.setStopHandler(() => stopModelReply(data.jobId));
      followModelReply(data.jobId, data.pendingTurn, null, stream, null, () => state.destroyed)
        .then((job) => finishTurn(c, info, job, stream, pendingText, latestModel || info.id))
        .finally(() => { if (c === conv) chat.setBusy(false); });
    }
    syncCost();
  }

  async function send(text, attachments = []) {
    const u = ui;
    const c = conv;
    const info = state.info;
    if (attachments.some(a => a.status === 'uploading')) {
      toast('Wait for the image to finish uploading.', 'info');
      return;
    }
    const field = u.imageField;
    const images = readyImages(attachments, field);
    if (!text) {
      if (images.length) toast('Add a message to send with the image.', 'info');
      return;
    }
    if (field?.required && !images.length) {
      toast('Attach an image to send to this model.', 'info');
      return;
    }
    u.chat.setBusy(true);
    try {
      if (!(await checkAuthOrRedirect())) return;
      if (!(await showAgreementModal())) return;
      if (c !== conv) return;

      let settings;
      try {
        await u.baselineReady;
        settings = u.pruneSettings(await u.settings.getValues());
      } catch (err) {
        u.setSettingsOpen(true);
        if (err?.name === 'FieldValidationError' && err.fieldId) u.settings.setFieldError(err.fieldId, err.message);
        else toast(errorText(err, 'Check the settings and try again.'));
        return;
      }
      if (c !== conv) return;

      const body = { message: text, settings };
      if (images.length) {
        settings[field.key] = field.isArray ? images : images[0];
        body.imageKey = field.key;
      }
      if (c.id) body.runId = c.id;
      if (!c.title) c.title = titleOf(text);

      const userMsg = u.chat.appendMessage('user', images.length
        ? [{ type: 'text', text }, ...images.map(url => ({ type: 'image', source: { type: 'url', url } }))]
        : text);
      setMsgMeta(userMsg.wrap, { at: new Date() });
      u.chat.clearComposer();
      syncCost();
      const stream = u.chat.beginAssistantStream({ status: 'Thinking…' });
      await run(c, info, body, { ...settings, [u.promptKey]: text }, stream, text);
    } finally {
      if (c === conv) u.chat.setBusy(false);
    }
  }

  // Replaces the last reply with a new one from the current model.
  async function regenerate(msg) {
    const u = ui;
    const c = conv;
    const info = state.info;
    if (!u || u.chat.isBusy() || !c.id || msg?.turn == null) return;
    u.chat.setBusy(true);
    try {
      if (!(await checkAuthOrRedirect())) return;
      if (!(await showAgreementModal())) return;
      if (c !== conv) return;

      let settings;
      try {
        await u.baselineReady;
        settings = u.pruneSettings(await u.settings.getValues());
      } catch (err) {
        u.setSettingsOpen(true);
        if (err?.name === 'FieldValidationError' && err.fieldId) u.settings.setFieldError(err.fieldId, err.message);
        else toast(errorText(err, 'Check the settings and try again.'));
        return;
      }
      if (c !== conv || !msg.wrap.isConnected) return;

      const body = { runId: c.id, regenerate: true, settings };
      if (u.imageField) body.imageKey = u.imageField.key;
      msg.wrap.remove();
      if (c.history[c.history.length - 1]?.role === 'assistant') c.history.pop();
      c.turnCount = Math.max(0, c.turnCount - 1);
      if (c.firstReply?.wrap === msg.wrap) {
        c.firstReply = null;
        c.lastModel = null;
      }
      const stream = u.chat.beginAssistantStream({ status: 'Thinking…' });
      await run(c, info, body, settings, stream, '', msg.turn);
    } finally {
      if (c === conv) u.chat.setBusy(false);
    }
  }

  async function deleteConversation(id) {
    let res = null;
    try {
      res = await fetch(`https://aitopia.ai/api/chat/conversations/${encodeURIComponent(id)}`, { method: 'DELETE' });
    } catch { /* network error: generic message below */ }
    if (!res?.ok) {
      const code = res?.status === 409 ? (await res.json().catch(() => ({}))).code : null;
      const message = code === 'CHAT_BUSY' ? 'Wait for the reply to finish.'
        : code === 'HAS_PUBLISHED_OUTPUT' ? "This chat has a published output and can't be deleted."
          : 'Could not delete this conversation.';
      toast(message);
      throw new Error(message);
    }
    if (!state.destroyed && conv.id === id) newChat();
  }

  let branching = false;
  async function branch(msg) {
    const c = conv;
    if (branching || !c.id || msg?.turn == null) return;
    branching = true;
    try {
      const res = await fetch(`https://aitopia.ai/api/chat/conversations/${encodeURIComponent(c.id)}/fork`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ upToTurn: msg.turn }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || typeof data.conversationId !== 'string' || !data.conversationId) {
        throw new Error((res.status < 500 && typeof data.error === 'string' && data.error) || 'Could not branch this chat.');
      }
      if (state.destroyed) return;
      const modelId = typeof data.modelId === 'string' && data.modelId ? data.modelId : state.info.id;
      sidebarApi?.prepend({
        id: data.conversationId,
        title: c.title,
        updatedAt: new Date().toISOString(),
        modelId,
        subtitle: sidebar.rowSubtitle?.({ id: modelId, displayName: modelName(modelId) }) || '',
      });
      await openConversation(data.conversationId);
    } catch (err) {
      toast(errorText(err, 'Could not branch this chat.'));
    } finally {
      branching = false;
    }
  }

  // Same credit/auth gates as the media playground's generate(), reported inside the assistant bubble.
  async function run(c, info, body, formData, stream, text, turn = null) {
    try {
      const preflight = await runPreflight(null);
      if (preflight.limit) {
        stream.fail(errorText(preflight.limit.error, 'Queue limit reached. Please wait for your current jobs to complete or upgrade your plan.'));
        return;
      }
      if (preflight.insufficient) {
        saveSnapshot('model_form_snapshot', formData);
        stream.fail('You are out of credits. Top up to keep chatting.');
        setTimeout(() => openPricingModal(), 0);
        return;
      }

      document.dispatchEvent(new CustomEvent('aitopia:model-generate-start', { detail: { model: eventModel(info) } }));

      const response = await fetch(`${buildModelApiUrl('info', info.id)}/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const result = await response.json();

      if (response.status === 402 && result.code === 'QUEUE_LIMIT_EXCEEDED') {
        stream.fail(errorText(result.error, 'Queue limit reached. Please wait for your current jobs to complete or upgrade your plan.'));
        return;
      }
      if (response.status === 402 && result.requiredCredits !== undefined) {
        saveSnapshot('model_form_snapshot', formData);
        stream.fail('Not enough credits for this message.');
        openPricingModal();
        const av = Number(result.availableCredits);
        document.dispatchEvent(new CustomEvent('aitopia:model-credit-limit', {
          detail: { limitType: Number.isFinite(av) && av > 0 ? 'Not enough credits' : 'Out of credits' }
        }));
        return;
      }
      if (response.status === 401 && result.code === 'corporate_email') {
        stream.fail('This model requires an account with a corporate email address.');
        showCorporateEmailModal();
        return;
      }
      if (response.status === 403 && result.code === 'plan_required') {
        stream.fail('This model requires the Creator plan.');
        showPlanRequiredModal();
        return;
      }
      if (response.status === 409 && result.code === 'CHAT_BUSY') {
        stream.fail('A reply is still in progress.');
        return;
      }
      if (response.status === 400 && result.code === 'NOTHING_TO_REGENERATE') {
        stream.fail('Could not regenerate this reply.');
        return;
      }
      if (!response.ok || result.error) throw new Error((response.status < 500 && typeof result.error === 'string' && result.error) || 'Could not send your message.');
      if (!result.jobId) throw new Error('The model did not start.');

      refreshCreditsBalance();
      if (!c.id && result.runId) {
        c.id = result.runId;
        if (c === conv) {
          setHash(c.id);
          if (state.signedIn) {
            addRow(c, info);
            sidebarApi?.setActive(c.id);
          }
        }
      }
      const replyTurn = result.turn ?? turn;
      stream.msg.turn = replyTurn;
      if (c === conv) ui?.chat.setStopHandler(() => stopModelReply(result.jobId));
      const job = await followModelReply(result.jobId, replyTurn, result.streamUrl, stream,
        (status) => stream.setStatus(status === 'pending' || status === 'queued' ? 'Waiting in queue…' : 'Thinking…'),
        () => state.destroyed);
      await finishTurn(c, info, job, stream, text);
    } catch (err) {
      stream.fail(errorText(err, 'Something went wrong. Please try again.'));
    }
  }

  async function finishTurn(c, info, job, stream, text, modelId = info.id) {
    if (state.destroyed) return;
    refreshCreditsBalance();
    const reply = job?.status === 'completed' && typeof job.output?.text === 'string' ? job.output.text : '';
    if (!reply.trim()) {
      stream.fail(job?.status === 'completed' ? 'The model returned an empty reply.' : errorText(job?.error, 'Generation failed.'));
      return;
    }
    // A streamed reply is already on screen; add only what the live view missed.
    const shown = stream.text || '';
    if (!reply.startsWith(shown)) stream.reset();
    stream.appendToken(reply.startsWith(shown) ? reply.slice(shown.length) : reply);
    await stream.finish(reply);
    setMsgMeta(stream.wrap, { at: new Date() });
    markModel(c, stream.wrap, modelId);
    c.turnCount++;
    if (text) c.history.push({ role: 'user', text });
    c.history.push({ role: 'assistant', text: reply });
    if (c === conv) syncCost();
    document.dispatchEvent(new CustomEvent('aitopia:model-generate-success', { detail: { model: eventModel(info) } }));
    if (!state.signedIn || !c.id) return;
    addRow(c, info);
    if (c === conv) sidebarApi?.setActive(c.id);
  }

  await loadSchemaWidgets(modelSchema);
  build();

  const hashId = /^#c=([A-Za-z0-9-]{8,64})$/.exec(location.hash)?.[1] || null;
  // The composer is usable right away; only the signed-in parts wait for the login state.
  void signedInKnown.then((signedIn) => {
    if (state.destroyed) return;
    state.signedIn = signedIn;
    sidebarApi = mountChatSidebar(shell.querySelector('.chat-sidebar'), {
      loadConversations: async (cursor) => {
        if (!state.signedIn || typeof sidebar.loadConversations !== 'function') return { items: [], nextCursor: null };
        return sidebar.loadConversations(cursor);
      },
      onSelect: (id) => { openConversation(id); },
      onNewChat: () => newChat(),
      onDelete: state.signedIn ? deleteConversation : undefined,
      activeId: state.signedIn ? (conv.id || hashId) : null,
    });
    if (!state.signedIn) {
      const emptyRow = shell.querySelector('.chat-sidebar-empty');
      if (emptyRow) emptyRow.textContent = 'Sign in to keep your chats here.';
    }
    if (hashId && state.signedIn && !conv.id && !ui?.chat.isBusy()) openConversation(hashId);
    else if (hashId && !state.signedIn) setHash(null);
  });

  return {
    get modelInfo() { return state.info; },
    get conversationId() { return conv.id; },
    get busy() { return !!ui?.chat.isBusy(); },
    /** Returns false (and changes nothing) when keeping the conversation while a reply is in flight. */
    setModel(nextInfo, nextSchema, { keepConversation = false } = {}) {
      if (keepConversation && ui?.chat.isBusy()) return false;
      state.info = nextInfo;
      state.schema = nextSchema;
      build(keepConversation);
      if (!keepConversation) newChat();
      return true;
    },
    openConversation,
    newChat,
    destroy() {
      state.destroyed = true;
      clearTimeout(estimateTimer);
      window.removeEventListener('resize', onResize);
      window.removeEventListener('aitopia:form:data-changed', scheduleCost);
      document.removeEventListener('click', onDocClick);
      document.removeEventListener('keydown', onKey);
      ui?.floating.forEach(n => n.remove());
      ui = null;
      root.innerHTML = '';
    },
  };
}
