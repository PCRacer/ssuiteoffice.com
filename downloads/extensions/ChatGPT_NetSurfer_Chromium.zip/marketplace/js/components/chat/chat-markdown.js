import { escapeHtml } from '/marketplace/js/shared/markdown.js';

let md = null;

// Same vendored markdown-it the shared renderer loads; until it resolves we paint plain text.
export const markdownReady = import('/marketplace/vendor/markdown-it.esm.js')
  .then((mod) => {
    const markdownit = mod?.default || mod;
    if (typeof markdownit !== 'function') return;
    const inst = markdownit({ html: false, linkify: true, breaks: true });
    // Indented prose from models is rarely meant as code.
    inst.disable('code');
    const linkOpen = inst.renderer.rules.link_open
      || ((tokens, idx, options, env, self) => self.renderToken(tokens, idx, options));
    inst.renderer.rules.link_open = (tokens, idx, options, env, self) => {
      tokens[idx].attrSet('target', '_blank');
      tokens[idx].attrSet('rel', 'noopener noreferrer');
      return linkOpen(tokens, idx, options, env, self);
    };
    inst.renderer.rules.fence = (tokens, idx, options, env) => {
      const t = tokens[idx];
      return fenceHtml(t.info, t.content, env);
    };
    md = inst;
  })
  .catch(() => {});

// renderFence may return a Node (inserted as-is), false (omit the block) or null (default <pre>).
function fenceHtml(info, body, env) {
  const lang = String(info || '').trim().split(/\s+/)[0].toLowerCase();
  let node = null;
  if (env.renderFence) {
    try { node = env.renderFence(lang, body, { streaming: env.streaming }); }
    catch (err) { console.error('[chat] renderFence failed', err); node = null; }
  }
  if (node === false) return '';
  if (node instanceof Node) {
    env.nodes.push(node);
    return `<div data-chat-fence="${env.nodes.length - 1}"></div>`;
  }
  return `<pre><code>${escapeHtml(body)}</code></pre>`;
}

// A trailing fence that opened but has not closed yet (only possible mid-stream).
function splitOpenFence(text) {
  let open = null;
  let openAt = -1;
  let offset = 0;
  for (const line of text.split('\n')) {
    const m = /^ {0,3}(`{3,}|~{3,})(.*)$/.exec(line);
    if (m) {
      if (!open) {
        if (!(m[1][0] === '`' && m[2].includes('`'))) {
          open = { ch: m[1][0], len: m[1].length, info: m[2] };
          openAt = offset;
        }
      } else if (m[1][0] === open.ch && m[1].length >= open.len && !m[2].trim()) {
        open = null;
      }
    }
    offset += line.length + 1;
  }
  if (!open) return null;
  const rest = text.slice(openAt);
  const nl = rest.indexOf('\n');
  return { before: text.slice(0, openAt), info: open.info, body: nl === -1 ? null : rest.slice(nl + 1) };
}

/** Render `text` into `target`; returns false when markdown-it is not loaded yet (plain text painted). */
export function renderChatMarkdown(target, text, { streaming = false, renderFence = null } = {}) {
  const src = String(text ?? '');
  if (!md) {
    target.classList.add('chat-md-plain');
    target.textContent = src;
    if (!streaming) {
      markdownReady.then(() => {
        if (md && target.isConnected) renderChatMarkdown(target, src, { streaming, renderFence });
      });
    }
    return false;
  }
  target.classList.remove('chat-md-plain');
  const env = { streaming, renderFence, nodes: [] };
  const open = streaming ? splitOpenFence(src) : null;
  let html = md.render(open ? open.before : src, env);
  // An opener line still arriving (no newline yet) is skipped so it never flashes as text.
  if (open && open.body !== null) html += fenceHtml(open.info, open.body, env);
  const purify = globalThis.DOMPurify;
  if (purify?.sanitize) html = purify.sanitize(html, { ADD_ATTR: ['target'] });
  target.innerHTML = html;
  for (const slot of target.querySelectorAll('[data-chat-fence]')) {
    const node = env.nodes[Number(slot.getAttribute('data-chat-fence'))];
    if (node) slot.replaceWith(node);
    else slot.remove();
  }
  return true;
}
