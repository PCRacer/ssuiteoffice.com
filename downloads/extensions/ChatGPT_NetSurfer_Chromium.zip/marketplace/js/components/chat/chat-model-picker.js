import { thumbImage } from '/marketplace/js/shared/media-thumb.js';

const CHEVRON_SVG = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>';
const BOLT_SVG = '<svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>';
const SEARCH_SVG = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>';

function make(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text != null) node.textContent = text;
  return node;
}

function modelName(item) {
  return item?.displayName || item?.name || item?.id || '';
}

function makeIcon(item) {
  const icon = make('span', 'chat-model-picker-icon');
  const name = modelName(item);
  if (item?.coverImageUrl) {
    const img = make('img');
    img.src = thumbImage(item.coverImageUrl, 32);
    img.alt = '';
    img.loading = 'lazy';
    img.decoding = 'async';
    img.addEventListener('error', () => { img.remove(); icon.textContent = name.charAt(0).toUpperCase(); }, { once: true });
    icon.appendChild(img);
  } else {
    icon.textContent = name.charAt(0).toUpperCase();
  }
  return icon;
}

/**
 * Searchable model dropdown. `loadModels()` resolves to `[{ id, displayName, coverImageUrl, creditsEstimated }]`;
 * `onChange(item)` fires only on a user pick, never for `setValue`.
 */
export function mountChatModelPicker({ loadModels, value = null, onChange, placeholder = 'Select a model' } = {}) {
  const el = make('div', 'chat-model-picker');
  const trigger = make('button', 'chat-model-picker-trigger');
  trigger.type = 'button';
  trigger.setAttribute('aria-haspopup', 'listbox');
  trigger.setAttribute('aria-expanded', 'false');
  const pop = make('div', 'chat-model-picker-pop');
  pop.hidden = true;
  const searchWrap = make('label', 'chat-model-picker-search');
  searchWrap.innerHTML = SEARCH_SVG;
  const search = make('input');
  search.type = 'search';
  search.placeholder = 'Search models';
  search.setAttribute('aria-label', 'Search models');
  search.autocomplete = 'off';
  searchWrap.appendChild(search);
  const list = make('div', 'chat-model-picker-list');
  list.setAttribute('role', 'listbox');
  const status = make('div', 'chat-model-picker-status', 'Loading models…');
  pop.append(searchWrap, list, status);
  el.append(trigger, pop);

  let items = [];
  let selectedId = value;
  let visible = [];
  let activeIndex = -1;

  function renderTrigger() {
    const item = items.find((m) => m.id === selectedId);
    trigger.innerHTML = '';
    if (item) trigger.appendChild(makeIcon(item));
    const label = make('span', 'chat-model-picker-label', item ? modelName(item) : (selectedId || placeholder));
    trigger.append(label);
    trigger.insertAdjacentHTML('beforeend', CHEVRON_SVG);
    trigger.title = item ? `${modelName(item)} (${item.id})` : placeholder;
    trigger.setAttribute('aria-label', `Model: ${item ? modelName(item) : placeholder}`);
  }

  function setActive(index) {
    const rows = list.children;
    if (rows[activeIndex]) rows[activeIndex].classList.remove('is-active');
    activeIndex = index;
    const row = rows[index];
    if (row) {
      row.classList.add('is-active');
      row.scrollIntoView({ block: 'nearest' });
    }
  }

  function buildRow(item) {
    const row = make('button', 'chat-model-picker-item');
    row.type = 'button';
    row.setAttribute('role', 'option');
    row.setAttribute('aria-selected', String(item.id === selectedId));
    if (item.id === selectedId) row.classList.add('is-selected');
    const text = make('span', 'chat-model-picker-text');
    text.append(make('span', 'chat-model-picker-name', modelName(item)), make('span', 'chat-model-picker-id', item.id));
    row.append(makeIcon(item), text);
    const credits = Number(item.creditsEstimated?.credits);
    if (Number.isFinite(credits) && credits > 0) {
      const chip = make('span', 'chat-model-picker-credits');
      chip.innerHTML = BOLT_SVG;
      chip.appendChild(document.createTextNode(String(credits)));
      chip.title = 'Estimated credits per message';
      row.appendChild(chip);
    }
    row.addEventListener('click', () => pick(item));
    return row;
  }

  function renderList() {
    const q = search.value.trim().toLowerCase();
    visible = q ? items.filter((m) => `${modelName(m)} ${m.id}`.toLowerCase().includes(q)) : items;
    list.innerHTML = '';
    for (const item of visible) list.appendChild(buildRow(item));
    activeIndex = -1;
    if (!status.dataset.state) {
      status.hidden = visible.length > 0;
      status.textContent = 'No models found.';
    }
  }

  function place() {
    if (pop.hidden) return;
    const bounds = (el.closest('.chat-shell') || document.documentElement).getBoundingClientRect();
    // Measure from the element the popover is positioned against (the composer zone on mobile).
    const rect = (pop.offsetParent || trigger).getBoundingClientRect();
    const top = Math.max(bounds.top, 0);
    const bottom = Math.min(bounds.bottom, window.innerHeight);
    const above = rect.top - top - 12;
    const below = bottom - rect.bottom - 12;
    const down = above < 320 && below > above;
    pop.classList.toggle('is-below', down);
    pop.style.maxHeight = `${Math.max(180, Math.min(440, down ? below : above))}px`;
  }

  function setOpen(open) {
    if (open === !pop.hidden) return;
    pop.hidden = !open;
    trigger.setAttribute('aria-expanded', String(open));
    if (!open) return;
    search.value = '';
    renderList();
    place();
    const index = visible.findIndex((m) => m.id === selectedId);
    if (index >= 0) setActive(index);
    search.focus();
  }

  function pick(item) {
    setOpen(false);
    trigger.focus();
    if (!item || item.id === selectedId) return;
    selectedId = item.id;
    renderTrigger();
    onChange?.(item);
  }

  trigger.addEventListener('click', () => setOpen(pop.hidden));
  search.addEventListener('input', () => { renderList(); if (visible.length) setActive(0); });
  search.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault();
      if (!visible.length) return;
      const step = e.key === 'ArrowDown' ? 1 : -1;
      setActive((activeIndex + step + visible.length) % visible.length);
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (visible[activeIndex]) pick(visible[activeIndex]);
    } else if (e.key === 'Escape') {
      e.stopPropagation();
      setOpen(false);
      trigger.focus();
    }
  });
  const onDocClick = (e) => {
    if (!pop.hidden && !e.composedPath().includes(el)) setOpen(false);
  };
  const onKey = (e) => { if (e.key === 'Escape') setOpen(false); };
  const onResize = () => place();
  document.addEventListener('click', onDocClick);
  document.addEventListener('keydown', onKey);
  window.addEventListener('resize', onResize);

  status.dataset.state = 'loading';
  renderTrigger();
  const ready = Promise.resolve()
    .then(() => loadModels())
    .then((rows) => {
      items = (Array.isArray(rows) ? rows : []).filter((m) => m && m.id);
      delete status.dataset.state;
      renderTrigger();
      renderList();
      return items.slice();
    })
    .catch((err) => {
      console.error('[chat-model-picker] load failed', err);
      status.dataset.state = 'error';
      status.hidden = false;
      status.textContent = 'Could not load models.';
      return [];
    });

  return {
    el,
    ready,
    getItems: () => items.slice(),
    getValue: () => selectedId,
    getSelected: () => items.find((m) => m.id === selectedId) || null,
    setValue(id) {
      selectedId = id || null;
      renderTrigger();
    },
    open: () => setOpen(true),
    close: () => setOpen(false),
    destroy() {
      document.removeEventListener('click', onDocClick);
      document.removeEventListener('keydown', onKey);
      window.removeEventListener('resize', onResize);
      el.remove();
    },
  };
}
