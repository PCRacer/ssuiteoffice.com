import * as browserStorage from '/marketplace/js/services/browser-storage.js';

const resolve = (v, id) => (typeof v === 'function' ? v(id) : v);

/**
 * History in browser storage as a JSON array. `key` / `options` may be functions of
 * the id passed to load/save; an empty save removes the entry.
 */
export function createBrowserHistoryAdapter({ key, options }) {
  return {
    async load(id) {
      try {
        const raw = await browserStorage.getItem(resolve(key, id), resolve(options, id));
        const parsed = raw ? JSON.parse(raw) : [];
        return Array.isArray(parsed) ? parsed : [];
      } catch {
        return [];
      }
    },
    async save(messages, id) {
      try {
        if (messages?.length) {
          await browserStorage.setItem(resolve(key, id), JSON.stringify(messages), resolve(options, id));
        } else {
          await browserStorage.removeItem(resolve(key, id), resolve(options, id));
        }
      } catch { /* quota / disabled storage: history just won't survive reload */ }
    },
  };
}

function outputText(output) {
  if (output == null) return '';
  if (typeof output === 'string') return output;
  if (Array.isArray(output) && output.every((p) => typeof p === 'string')) return output.join('');
  if (typeof output === 'object' && typeof output.text === 'string') return output.text;
  return '```json\n' + JSON.stringify(output, null, 2) + '\n```';
}

/** Server-persisted turns: `fetchTurns(conversationId)` resolves to `[{ userText, output }]`. */
export function createRunsHistoryAdapter({ fetchTurns }) {
  return {
    async load(conversationId) {
      if (!conversationId) return [];
      const turns = await fetchTurns(conversationId);
      const messages = [];
      for (const t of Array.isArray(turns) ? turns : []) {
        if (t?.userText) messages.push({ role: 'user', content: String(t.userText) });
        const text = outputText(t?.output);
        if (text) messages.push({ role: 'assistant', content: text });
      }
      return messages;
    },
    async save() { /* each turn is already a server-side run */ },
  };
}
