/**
 * Read an SSE response body, calling `onEvent(type, data, envelope)` per event.
 * Matches the server's SSEWriter: `event:` + `data:` lines, `{ type, data, ... }` envelope.
 */
export async function readSSE(res, onEvent) {
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const chunks = buffer.split('\n\n');
    buffer = chunks.pop() || '';
    for (const chunk of chunks) {
      let eventType = 'message';
      let dataStr = '';
      for (const line of chunk.split('\n')) {
        if (line.startsWith('event:')) eventType = line.slice(6).trim();
        else if (line.startsWith('data:')) dataStr += line.slice(5).trim();
      }
      if (!dataStr) continue;
      let parsed;
      try { parsed = JSON.parse(dataStr); } catch { continue; }
      onEvent(eventType, parsed?.data ?? parsed, parsed);
    }
  }
}

/**
 * Job + poll backends: `start()` returns a job handle, `poll(job)` returns
 * `{ done, text?, error? }`. Resolves to the final text, rejects on error.
 */
export async function pollTransport({ start, poll, intervalMs = 2000 }) {
  const job = await start();
  while (true) {
    const r = await poll(job);
    if (r?.error) throw (r.error instanceof Error ? r.error : new Error(String(r.error)));
    if (r?.done) return String(r.text ?? '');
    await new Promise((resolve) => setTimeout(resolve, intervalMs));
  }
}
