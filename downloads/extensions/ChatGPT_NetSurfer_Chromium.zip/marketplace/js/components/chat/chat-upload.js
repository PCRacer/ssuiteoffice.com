import { fetchHelper } from '/marketplace/js/shared/fetch-helper.js';

// Our CDN urls don't always end in an extension, so its host counts as an image too.
export const IMAGE_URL_RE = /https?:\/\/[^\s]+?(?:\.(?:png|jpe?g|gif|webp)|cdn\.aitopia\.ai\/[^\s]+)/gi;

export function looksLikeImageUrl(s) {
  const v = String(s || '').trim();
  if (!/^https?:\/\/\S+$/i.test(v)) return false;
  return /\.(png|jpe?g|gif|webp)(\?|#|$)/i.test(v) || /cdn\.aitopia\.ai\//i.test(v);
}

// The CDN overwrites by filename, so every upload needs a unique base name; the server adds the extension.
export function uniqueUploadName(file, prefix = 'chat', index = 0) {
  const unique = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
  const base = file?.name ? file.name.replace(/\.[^.]+$/, '').replace(/[^a-zA-Z0-9._-]+/g, '-') : '';
  return `${base ? `${prefix}-${base}` : prefix}-${index}-${unique}`;
}

/** Uploads one file to the CDN via /api/uploads and returns its url. */
export async function uploadChatImage(file, filename = uniqueUploadName(file)) {
  const res = await fetchHelper(`https://aitopia.ai/api/uploads?filename=${encodeURIComponent(filename)}`, {
    method: 'POST',
    headers: { 'Content-Type': file.type || 'application/octet-stream' },
    body: file,
  });
  const json = await res.json().catch(() => null);
  if (!res.ok || !json?.url) throw new Error('Upload failed');
  return json.url;
}
