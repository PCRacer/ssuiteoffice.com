const rtf = typeof Intl !== 'undefined' && Intl.RelativeTimeFormat
  ? new Intl.RelativeTimeFormat(undefined, { numeric: 'auto' })
  : null;

const SIDEBAR_LEFT_PATHS = '<path d="M14.6458 9.99967V5.99967C14.6458 2.66634 13.3125 1.33301 9.97917 1.33301H5.97917C2.64583 1.33301 1.3125 2.66634 1.3125 5.99967V9.99967C1.3125 13.333 2.64583 14.6663 5.97917 14.6663H9.97917C13.3125 14.6663 14.6458 13.333 14.6458 9.99967Z"/><path d="M5.3125 1.33301V14.6663"/><path d="M9.9801 6.29297L8.27344 7.99964L9.9801 9.7063"/>';
const HISTORY_SVG = `<svg width="18" height="18" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${SIDEBAR_LEFT_PATHS}</svg>`;
const PANEL_OPEN_SVG = `<svg class="chat-toggle-open" width="18" height="18" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${SIDEBAR_LEFT_PATHS}</svg>`;
const PANEL_CLOSE_SVG = `<svg class="chat-toggle-close" width="18" height="18" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${SIDEBAR_LEFT_PATHS}</svg>`;
const TRASH_SVG = '<svg width="16" height="16" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M17.5 4.98307C14.725 4.70807 11.9333 4.56641 9.15 4.56641C7.5 4.56641 5.85 4.64974 4.2 4.81641L2.5 4.98307"/><path d="M7.08398 4.14199L7.26732 3.05033C7.40065 2.25866 7.50065 1.66699 8.90898 1.66699H11.0923C12.5007 1.66699 12.609 2.29199 12.734 3.05866L12.9173 4.14199"/><path d="M15.7096 7.61621L15.168 16.0079C15.0763 17.3162 15.0013 18.3329 12.6763 18.3329H7.3263C5.0013 18.3329 4.9263 17.3162 4.83464 16.0079L4.29297 7.61621"/><path d="M8.60938 13.75H11.3844"/><path d="M7.91602 10.417H12.0827"/></svg>';
const CLOSE_SVG = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 6 6 18M6 6l12 12"/></svg>';
const NEW_SVG = '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3H7a4 4 0 0 0-4 4v10a4 4 0 0 0 4 4h10a4 4 0 0 0 4-4v-5"/><path d="M18.5 2.5a2.12 2.12 0 0 1 3 3L12 15l-4 1 1-4Z"/></svg>';

const UNITS = [
  ['year', 31536000], ['month', 2592000], ['week', 604800],
  ['day', 86400], ['hour', 3600], ['minute', 60],
];

function relativeTime(value) {
  const t = value ? new Date(value).getTime() : NaN;
  if (!Number.isFinite(t)) return '';
  const secs = Math.round((t - Date.now()) / 1000);
  if (!rtf) return new Date(t).toLocaleDateString();
  for (const [unit, size] of UNITS) {
    if (Math.abs(secs) >= size) return rtf.format(Math.round(secs / size), unit);
  }
  return rtf.format(0, 'minute');
}

// 'panel' (in the sidebar) swaps open/close glyphs via CSS; 'history' opens the list from the chat area.
function makeToggle(kind) {
  const toggle = make('button', 'chat-sidebar-toggle');
  toggle.type = 'button';
  toggle.setAttribute('data-chat-sidebar-toggle', '');
  const label = kind === 'history' ? 'Chat history' : 'Toggle sidebar';
  toggle.setAttribute('aria-label', label);
  toggle.title = label;
  toggle.innerHTML = kind === 'history' ? HISTORY_SVG : PANEL_OPEN_SVG + PANEL_CLOSE_SVG;
  return toggle;
}

function iconButton(className, svg, label) {
  const btn = make('button', className);
  btn.type = 'button';
  btn.innerHTML = svg;
  btn.setAttribute('aria-label', label);
  btn.title = label;
  return btn;
}

function make(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text != null) node.textContent = text;
  return node;
}

/**
 * Conversation list for a `.chat-shell`. `loadConversations(cursor)` resolves to
 * `{ items: [{ id, title, updatedAt, subtitle? }], nextCursor }`; `onDelete(id)` rejects to keep the row.
 */
export function mountChatSidebar(el, { loadConversations, onSelect, onNewChat, onDelete, activeId = null } = {}) {
  el.classList.add('chat-sidebar');
  el.innerHTML = '';
  const shell = el.closest('.chat-shell');

  const head = make('div', 'chat-sidebar-head');
  if (shell) head.appendChild(makeToggle('panel'));
  const newBtn = make('button', 'chat-sidebar-new');
  newBtn.type = 'button';
  newBtn.innerHTML = NEW_SVG;
  newBtn.appendChild(make('span', 'chat-sidebar-new-label', 'New chat'));
  head.appendChild(newBtn);
  const list = make('div', 'chat-sidebar-list');
  list.setAttribute('role', 'list');
  const empty = make('div', 'chat-sidebar-empty', 'No conversations yet.');
  empty.hidden = true;
  const more = make('button', 'chat-sidebar-more', 'Load more');
  more.type = 'button';
  more.hidden = true;
  const errorRow = make('div', 'chat-sidebar-error', 'Could not load conversations.');
  errorRow.hidden = true;
  el.append(head, list, empty, errorRow, more);

  let active = activeId;
  let cursor = null;
  let loading = false;
  let generation = 0;
  const rows = new Map();
  let endConfirm = null;

  let backdrop = null;
  if (shell) {
    backdrop = shell.querySelector('.chat-shell-backdrop');
    if (!backdrop) {
      backdrop = make('div', 'chat-shell-backdrop');
      shell.appendChild(backdrop);
    }
    backdrop.addEventListener('click', () => closeDrawer());
    const main = shell.querySelector('.chat-main');
    // Mobile has no rail, so the chat area carries its own toggle there.
    if (main && !main.querySelector('[data-chat-sidebar-toggle]')) {
      const chatHead = make('div', 'chat-head');
      chatHead.appendChild(makeToggle('history'));
      main.prepend(chatHead);
    }
    shell.addEventListener('click', (e) => {
      if (e.target.closest('[data-chat-sidebar-toggle]')) shell.classList.toggle('is-sidebar-open');
    });
  }
  function closeDrawer() { shell?.classList.remove('is-sidebar-open'); }

  function syncEmpty() {
    empty.hidden = rows.size > 0 || loading || !errorRow.hidden;
  }

  function buildRow(conv) {
    const row = make('div', 'chat-sidebar-item');
    row.setAttribute('role', 'listitem');
    row.setAttribute('data-chat-conv', String(conv.id));
    const open = make('button', 'chat-sidebar-open');
    open.type = 'button';
    const title = make('span', 'chat-sidebar-title', conv.title || 'Untitled chat');
    const time = make('span', 'chat-sidebar-time', relativeTime(conv.updatedAt));
    if (conv.updatedAt) time.title = new Date(conv.updatedAt).toLocaleString();
    open.append(title, time);
    if (conv.subtitle) open.appendChild(make('span', 'chat-sidebar-subtitle', conv.subtitle));
    open.addEventListener('click', () => {
      setActive(conv.id);
      // Only the mobile drawer auto-closes on select; on desktop the panel stays open (toggle-only).
      if (window.matchMedia('(max-width: 768px)').matches) closeDrawer();
      onSelect?.(conv.id);
    });
    row.appendChild(open);
    if (typeof onDelete === 'function') {
      const del = iconButton('chat-sidebar-del', TRASH_SVG, 'Delete chat');
      del.addEventListener('click', () => startConfirm(row, conv.id));
      row.appendChild(del);
    }
    if (String(conv.id) === String(active)) markActive(row, true);
    return row;
  }

  function startConfirm(row, id) {
    const key = String(id);
    if (row.classList.contains('is-pending')) return;
    openConfirmModal({
      title: 'Delete chat?',
      message: 'This conversation will be permanently deleted.',
      confirmLabel: 'Delete',
      cancelLabel: 'Cancel',
      danger: true,
    }).then(async (ok) => {
      if (!ok) { row.querySelector('.chat-sidebar-del')?.focus(); return; }
      row.classList.add('is-pending');
      row.setAttribute('aria-busy', 'true');
      try {
        await onDelete(id);
      } catch {
        row.classList.remove('is-pending');
        row.removeAttribute('aria-busy');
        return;
      }
      if (rows.get(key) === row) rows.delete(key);
      row.remove();
      if (String(active) === key) active = null;
      syncEmpty();
    });
  }

  function openConfirmModal({ title = 'Are you sure?', message = '', confirmLabel = 'OK', cancelLabel = 'Cancel', danger = false } = {}) {
    return new Promise((resolve) => {
      endConfirm?.();
      const back = make('div', 'chat-confirm-back');
      const dialog = make('div', 'chat-confirm');
      dialog.setAttribute('role', 'alertdialog');
      dialog.setAttribute('aria-modal', 'true');
      dialog.appendChild(make('h3', 'chat-confirm-title', title));
      if (message) dialog.appendChild(make('p', 'chat-confirm-msg', message));
      const actions = make('div', 'chat-confirm-actions');
      const cancel = make('button', 'chat-confirm-btn chat-confirm-cancel', cancelLabel);
      cancel.type = 'button';
      const ok = make('button', `chat-confirm-btn chat-confirm-ok${danger ? ' is-danger' : ''}`, confirmLabel);
      ok.type = 'button';
      actions.append(cancel, ok);
      dialog.appendChild(actions);
      back.appendChild(dialog);
      document.body.appendChild(back);

      let settled = false;
      const done = (val) => {
        if (settled) return;
        settled = true;
        document.removeEventListener('keydown', onKey, true);
        if (endConfirm === dismiss) endConfirm = null;
        back.remove();
        resolve(val);
      };
      const dismiss = () => done(false);
      const onKey = (e) => { if (e.key === 'Escape') { e.stopPropagation(); done(false); } };
      document.addEventListener('keydown', onKey, true);
      back.addEventListener('click', (e) => { if (e.target === back) done(false); });
      cancel.addEventListener('click', () => done(false));
      ok.addEventListener('click', () => done(true));
      endConfirm = dismiss;
      cancel.focus();
    });
  }

  function markActive(row, on) {
    row.classList.toggle('is-active', on);
    if (on) row.setAttribute('aria-current', 'true');
    else row.removeAttribute('aria-current');
  }

  async function loadPage(reset) {
    if (loading && !reset) return;
    const gen = reset ? ++generation : generation;
    loading = true;
    more.disabled = true;
    errorRow.hidden = true;
    syncEmpty();
    try {
      const page = await loadConversations(reset ? null : cursor);
      if (gen !== generation) return;
      if (reset) { endConfirm?.(); list.innerHTML = ''; rows.clear(); }
      for (const conv of page?.items || []) {
        if (!conv || conv.id == null || rows.has(String(conv.id))) continue;
        const row = buildRow(conv);
        rows.set(String(conv.id), row);
        list.appendChild(row);
      }
      cursor = page?.nextCursor ?? null;
      more.hidden = !cursor;
    } catch (err) {
      if (gen !== generation) return;
      console.error('[chat-sidebar] load failed', err);
      errorRow.hidden = false;
    } finally {
      if (gen === generation) {
        loading = false;
        more.disabled = false;
        syncEmpty();
      }
    }
  }

  function setActive(id) {
    active = id;
    for (const [key, row] of rows) markActive(row, key === String(id));
  }

  newBtn.addEventListener('click', () => {
    setActive(null);
    closeDrawer();
    onNewChat?.();
  });
  more.addEventListener('click', () => loadPage(false));

  loadPage(true);

  return {
    refresh: () => loadPage(true),
    setActive,
    prepend(conv) {
      if (!conv || conv.id == null) return;
      rows.get(String(conv.id))?.remove();
      const row = buildRow(conv);
      rows.set(String(conv.id), row);
      list.prepend(row);
      syncEmpty();
    },
    updateTitle(id, title) {
      const node = rows.get(String(id))?.querySelector('.chat-sidebar-title');
      if (node) node.textContent = title || 'Untitled chat';
    },
  };
}
