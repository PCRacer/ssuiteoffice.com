const rtf = typeof Intl !== 'undefined' && Intl.RelativeTimeFormat
  ? new Intl.RelativeTimeFormat(undefined, { numeric: 'auto' })
  : null;

const HISTORY_SVG = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l3 2"/></svg>';
const PANEL_OPEN_SVG = '<svg class="chat-toggle-open" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 3v18M14 9l3 3-3 3"/></svg>';
const PANEL_CLOSE_SVG = '<svg class="chat-toggle-close" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 3v18M16 15l-3-3 3-3"/></svg>';
const TRASH_SVG = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 6h18"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/></svg>';
const CLOSE_SVG = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 6 6 18M6 6l12 12"/></svg>';
const NEW_SVG = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/><path d="M12 8v6M9 11h6"/></svg>';

const UNITS = [
  ['year', 31536000], ['month', 2592000], ['week', 604800],
  ['day', 86400], ['hour', 3600], ['minute', 60],
];

function relativeTime(value) {
  const t = value ? new Date(value).getTime() : NaN;
  if (!Number.isFinite(t)) return '';
  const secs = Math.round((t - Date.now()) / 1000);
  if (!rtf) return new Date(t).toLocaleDateString();
  for (const [unit, size] of UNITS) {
    if (Math.abs(secs) >= size) return rtf.format(Math.round(secs / size), unit);
  }
  return rtf.format(0, 'minute');
}

// 'panel' (in the sidebar) swaps open/close glyphs via CSS; 'history' opens the list from the chat area.
function makeToggle(kind) {
  const toggle = make('button', 'chat-sidebar-toggle');
  toggle.type = 'button';
  toggle.setAttribute('data-chat-sidebar-toggle', '');
  const label = kind === 'history' ? 'Chat history' : 'Toggle sidebar';
  toggle.setAttribute('aria-label', label);
  toggle.title = label;
  toggle.innerHTML = kind === 'history' ? HISTORY_SVG : PANEL_OPEN_SVG + PANEL_CLOSE_SVG;
  return toggle;
}

function iconButton(className, svg, label) {
  const btn = make('button', className);
  btn.type = 'button';
  btn.innerHTML = svg;
  btn.setAttribute('aria-label', label);
  btn.title = label;
  return btn;
}

function make(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text != null) node.textContent = text;
  return node;
}

/**
 * Conversation list for a `.chat-shell`. `loadConversations(cursor)` resolves to
 * `{ items: [{ id, title, updatedAt, subtitle? }], nextCursor }`; `onDelete(id)` rejects to keep the row.
 */
export function mountChatSidebar(el, { loadConversations, onSelect, onNewChat, onDelete, activeId = null } = {}) {
  el.classList.add('chat-sidebar');
  el.innerHTML = '';
  const shell = el.closest('.chat-shell');

  const head = make('div', 'chat-sidebar-head');
  if (shell) head.appendChild(makeToggle('panel'));
  const newBtn = make('button', 'chat-sidebar-new');
  newBtn.type = 'button';
  newBtn.innerHTML = NEW_SVG;
  newBtn.appendChild(make('span', 'chat-sidebar-new-label', 'New chat'));
  head.appendChild(newBtn);
  const list = make('div', 'chat-sidebar-list');
  list.setAttribute('role', 'list');
  const empty = make('div', 'chat-sidebar-empty', 'No conversations yet.');
  empty.hidden = true;
  const more = make('button', 'chat-sidebar-more', 'Load more');
  more.type = 'button';
  more.hidden = true;
  const errorRow = make('div', 'chat-sidebar-error', 'Could not load conversations.');
  errorRow.hidden = true;
  el.append(head, list, empty, errorRow, more);

  let active = activeId;
  let cursor = null;
  let loading = false;
  let generation = 0;
  const rows = new Map();
  let endConfirm = null;

  let backdrop = null;
  if (shell) {
    backdrop = shell.querySelector('.chat-shell-backdrop');
    if (!backdrop) {
      backdrop = make('div', 'chat-shell-backdrop');
      shell.appendChild(backdrop);
    }
    backdrop.addEventListener('click', () => closeDrawer());
    const main = shell.querySelector('.chat-main');
    // Mobile has no rail, so the chat area carries its own toggle there.
    if (main && !main.querySelector('[data-chat-sidebar-toggle]')) {
      const chatHead = make('div', 'chat-head');
      chatHead.appendChild(makeToggle('history'));
      main.prepend(chatHead);
    }
    shell.addEventListener('click', (e) => {
      if (e.target.closest('[data-chat-sidebar-toggle]')) shell.classList.toggle('is-sidebar-open');
    });
  }
  function closeDrawer() { shell?.classList.remove('is-sidebar-open'); }

  function syncEmpty() {
    empty.hidden = rows.size > 0 || loading || !errorRow.hidden;
  }

  function buildRow(conv) {
    const row = make('div', 'chat-sidebar-item');
    row.setAttribute('role', 'listitem');
    row.setAttribute('data-chat-conv', String(conv.id));
    const open = make('button', 'chat-sidebar-open');
    open.type = 'button';
    const title = make('span', 'chat-sidebar-title', conv.title || 'Untitled chat');
    const time = make('span', 'chat-sidebar-time', relativeTime(conv.updatedAt));
    if (conv.updatedAt) time.title = new Date(conv.updatedAt).toLocaleString();
    open.append(title, time);
    if (conv.subtitle) open.appendChild(make('span', 'chat-sidebar-subtitle', conv.subtitle));
    open.addEventListener('click', () => {
      setActive(conv.id);
      closeDrawer();
      onSelect?.(conv.id);
    });
    row.appendChild(open);
    if (typeof onDelete === 'function') {
      const del = iconButton('chat-sidebar-del', TRASH_SVG, 'Delete chat');
      del.addEventListener('click', () => startConfirm(row, conv.id));
      row.appendChild(del);
    }
    if (String(conv.id) === String(active)) markActive(row, true);
    return row;
  }

  function startConfirm(row, id) {
    endConfirm?.();
    const key = String(id);
    const box = make('div', 'chat-sidebar-confirm');
    const yes = iconButton('chat-sidebar-confirm-yes', TRASH_SVG, 'Delete');
    const no = iconButton('chat-sidebar-confirm-no', CLOSE_SVG, 'Cancel');
    box.append(make('span', 'chat-sidebar-confirm-label', 'Delete chat?'), yes, no);
    row.appendChild(box);
    row.classList.add('is-confirming');

    const onPointer = (e) => { if (!row.contains(e.target)) finish(false); };
    const onKey = (e) => { if (e.key === 'Escape') finish(true); };
    document.addEventListener('pointerdown', onPointer, true);
    document.addEventListener('keydown', onKey, true);
    function detach() {
      document.removeEventListener('pointerdown', onPointer, true);
      document.removeEventListener('keydown', onKey, true);
      if (endConfirm === finish) endConfirm = null;
    }
    function finish(refocus) {
      detach();
      box.remove();
      row.classList.remove('is-confirming', 'is-pending');
      row.removeAttribute('aria-busy');
      if (refocus) row.querySelector('.chat-sidebar-del')?.focus();
    }
    endConfirm = finish;

    no.addEventListener('click', () => finish(true));
    yes.addEventListener('click', async () => {
      detach();
      row.classList.add('is-pending');
      row.setAttribute('aria-busy', 'true');
      yes.disabled = true;
      no.disabled = true;
      try {
        await onDelete(id);
      } catch {
        finish(false);
        return;
      }
      if (rows.get(key) === row) rows.delete(key);
      row.remove();
      if (String(active) === key) active = null;
      syncEmpty();
    });
    no.focus();
  }

  function markActive(row, on) {
    row.classList.toggle('is-active', on);
    if (on) row.setAttribute('aria-current', 'true');
    else row.removeAttribute('aria-current');
  }

  async function loadPage(reset) {
    if (loading && !reset) return;
    const gen = reset ? ++generation : generation;
    loading = true;
    more.disabled = true;
    errorRow.hidden = true;
    syncEmpty();
    try {
      const page = await loadConversations(reset ? null : cursor);
      if (gen !== generation) return;
      if (reset) { endConfirm?.(); list.innerHTML = ''; rows.clear(); }
      for (const conv of page?.items || []) {
        if (!conv || conv.id == null || rows.has(String(conv.id))) continue;
        const row = buildRow(conv);
        rows.set(String(conv.id), row);
        list.appendChild(row);
      }
      cursor = page?.nextCursor ?? null;
      more.hidden = !cursor;
    } catch (err) {
      if (gen !== generation) return;
      console.error('[chat-sidebar] load failed', err);
      errorRow.hidden = false;
    } finally {
      if (gen === generation) {
        loading = false;
        more.disabled = false;
        syncEmpty();
      }
    }
  }

  function setActive(id) {
    active = id;
    for (const [key, row] of rows) markActive(row, key === String(id));
  }

  newBtn.addEventListener('click', () => {
    setActive(null);
    closeDrawer();
    onNewChat?.();
  });
  more.addEventListener('click', () => loadPage(false));

  loadPage(true);

  return {
    refresh: () => loadPage(true),
    setActive,
    prepend(conv) {
      if (!conv || conv.id == null) return;
      rows.get(String(conv.id))?.remove();
      const row = buildRow(conv);
      rows.set(String(conv.id), row);
      list.prepend(row);
      syncEmpty();
    },
    updateTitle(id, title) {
      const node = rows.get(String(id))?.querySelector('.chat-sidebar-title');
      if (node) node.textContent = title || 'Untitled chat';
    },
  };
}
