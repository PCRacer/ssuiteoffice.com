/**
 * Multi-media upload field component.
 * Self-contained port of model.html's buildMultiFileUploadElement: dropzone with
 * file count, "Clear all", preview grid, drag-drop, and paste-URL+Add row.
 * Files are uploaded to the CDN and stored as URLs; pasted URLs are kept as-is.
 */
import {
  updateFormData, createFieldLabel, createHelpToggle,
} from '../../runner/overrides/ui-core.js';
import { acceptForKind, isFileTypeAccepted, maxBytesForKind, formatBytes, uploadFileToServer } from '../../shared/media.js';

export function createMultiMediaUploadField({
  label,
  id,
  help,
  kind = 'image',
  maxFiles = 8,
  initialValue,
} = {}) {
  const wrap = document.createElement('div');
  const fieldKey = id || label || 'multiMedia';
  if (id) wrap.setAttribute('data-id', id);

  const suffix = Math.random().toString(16).slice(2);
  const accept = acceptForKind(kind);
  const allowedDesc =
    kind === 'video' ? 'video files'
    : kind === 'audio' ? 'MP3, WAV, or OGG audio'
    : kind === 'audioOrVideo' ? 'audio or video files'
    : kind === 'imageOrVideo' ? 'images or videos'
    : 'PNG, JPG, or WEBP images';

  // Header with label + help toggle (sibling components render their own).
  const header = document.createElement('div');
  header.className = 'mb-3';
  const headerRow = document.createElement('div');
  headerRow.className = 'flex items-center';
  const title = label ? String(label) : 'Upload';
  const labelEl = createFieldLabel(title, { required: false });
  labelEl.className = 'block text-sm font-medium mx-2';
  headerRow.appendChild(labelEl);
  const { trigger } = createHelpToggle({ idSeed: `multi_${suffix}`, labelText: title, helpText: help });
  if (trigger) {
    wrap.setAttribute('data-help-scope', '');
    headerRow.appendChild(trigger);
  }
  header.appendChild(headerRow);
  wrap.appendChild(header);

  const container = document.createElement('div');
  container.className = 'space-y-3';

  // Clear-all row
  const clearRow = document.createElement('div');
  clearRow.className = 'flex items-center justify-between hidden';
  const clearAllBtn = document.createElement('button');
  clearAllBtn.type = 'button';
  clearAllBtn.className = 'ml-auto text-xs text-red-400 hover:text-red-300 transition-colors';
  clearAllBtn.textContent = 'Clear all';
  clearRow.appendChild(clearAllBtn);
  container.appendChild(clearRow);

  // Drop zone
  const uploadLabel = accept.includes('video') ? 'Upload Videos'
    : accept.includes('audio') ? 'Upload Audio'
      : accept.includes('image') ? 'Upload Images' : 'Upload Files';
  const dropZone = document.createElement('div');
  dropZone.className =
    'file-drop-zone relative rounded-[16px] h-[115px] px-4 py-5 text-center cursor-pointer flex flex-col items-center justify-center ' +
    'border border-dashed border-[#D9D9D9] dark:border-[#272727] bg-panel-input ' +
    'hover:border-[#ccc] dark:hover:border-[#3a3a3a] hover:bg-panel-hover transition-colors';
  dropZone.innerHTML = `
    <div class="flex flex-col items-center gap-2">
      <div class="w-8 h-8 flex items-center justify-center">
        <svg class="w-5 h-5 text-muted-foreground" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 16.5V9.75m0 0l3 3m-3-3l-3 3M6.75 19.5a4.5 4.5 0 01-1.41-8.775 5.25 5.25 0 0110.338-2.32 3.75 3.75 0 013.57 4.26A4.5 4.5 0 0118 19.5H6.75z"/></svg>
      </div>
      <div class="space-y-1">
        <div class="agent-form-upload-title">${uploadLabel}</div>
        <div class="agent-form-hint" style="color: #9335EC !important">Multiple files supported</div>
      </div>
    </div>
  `;
  const countEl = document.createElement('span');
  countEl.className = 'absolute top-2 right-2 text-[11px] font-medium text-gray-400 dark:text-gray-500 tabular-nums pointer-events-none';
  countEl.setAttribute('data-multi-count', '');
  countEl.textContent = `0/${maxFiles}`;
  dropZone.appendChild(countEl);

  const fileInput = document.createElement('input');
  fileInput.type = 'file';
  fileInput.accept = accept;
  fileInput.multiple = true;
  fileInput.className = 'hidden';
  fileInput.id = `multi_file_${suffix}`;

  // Preview grid
  const previewGrid = document.createElement('div');
  previewGrid.className = 'grid grid-cols-2 sm:grid-cols-3 gap-2 mt-3 hidden';

  // URL + Add row
  const urlWrapper = document.createElement('div');
  urlWrapper.className = 'flex gap-2 hidden';
  const urlInput = document.createElement('input');
  urlInput.type = 'text';
  urlInput.className = 'flex-1 text-[13px] bg-panel-input border border-panel-border rounded-2xl px-4 py-2 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:border-[#D9D9D9]/40 dark:focus:border-[#D9D9D9]/20 transition-colors';
  urlInput.placeholder = 'Or paste URL and press Enter...';
  const addUrlBtn = document.createElement('button');
  addUrlBtn.type = 'button';
  addUrlBtn.className = 'px-3 py-2 text-[13px] bg-panel-input border border-panel-border hover:bg-panel-hover rounded-2xl text-gray-900 dark:text-white transition-colors';
  addUrlBtn.textContent = 'Add';
  urlWrapper.appendChild(urlInput);
  urlWrapper.appendChild(addUrlBtn);

  const errorEl = document.createElement('p');
  errorEl.className = 'mt-1 px-1 text-[11px] leading-normal text-red-500 dark:text-red-400 hidden';
  errorEl.setAttribute('role', 'alert');
  errorEl.setAttribute('aria-live', 'polite');

  const statusEl = document.createElement('p');
  statusEl.className = 'mt-1 px-1 text-[11px] leading-normal text-muted-foreground hidden';
  statusEl.setAttribute('role', 'status');
  statusEl.setAttribute('aria-live', 'polite');

  container.appendChild(fileInput);
  container.appendChild(dropZone);
  container.appendChild(previewGrid);
  container.appendChild(urlWrapper);
  wrap.appendChild(container);
  wrap.appendChild(errorEl);
  wrap.appendChild(statusEl);

  let items = [];
  let isUploading = false;
  let uploadPromise = Promise.resolve();

  function setError(message) {
    if (!message) {
      errorEl.textContent = '';
      errorEl.classList.add('hidden');
      return;
    }
    errorEl.textContent = String(message);
    errorEl.classList.remove('hidden');
  }

  function clearError() {
    setError('');
  }

  function syncToGlobal() {
    updateFormData(fieldKey, items.length > 0 ? items.slice() : undefined);
  }

  function setUploading(value) {
    isUploading = Boolean(value);
    fileInput.disabled = isUploading;
    urlInput.disabled = isUploading;
    addUrlBtn.disabled = isUploading;
    clearAllBtn.disabled = isUploading;
    dropZone.setAttribute('aria-busy', isUploading ? 'true' : 'false');
    dropZone.classList.toggle('opacity-60', isUploading);
    statusEl.classList.toggle('hidden', !isUploading);
    if (!isUploading) statusEl.textContent = '';
  }

  function renderPreview() {
    countEl.textContent = `${items.length}/${maxFiles}`;
    const empty = items.length === 0;
    clearRow.classList.toggle('hidden', empty);
    previewGrid.classList.toggle('hidden', empty);

    previewGrid.innerHTML = '';
    const sortable = items.length > 1;
    items.forEach((src, idx) => {
      const cell = document.createElement('div');
      cell.className = 'relative group';
      cell.dataset.idx = String(idx);
      cell.style.userSelect = 'none';
      cell.style.webkitUserSelect = 'none';
      cell.style.webkitTouchCallout = 'none';
      if (sortable) cell.style.cursor = 'grab';

      if (accept.includes('image')) {
        const img = document.createElement('img');
        img.src = src;
        img.draggable = false;
        img.className = 'w-full h-20 object-cover rounded-xl';
        cell.appendChild(img);
      } else if (accept.includes('video')) {
        const video = document.createElement('video');
        video.src = src;
        video.muted = true;
        video.draggable = false;
        video.className = 'w-full h-20 object-cover rounded-xl';
        cell.appendChild(video);
      } else {
        const ph = document.createElement('div');
        ph.className = 'w-full h-20 bg-panel-input rounded-xl flex items-center justify-center text-2xl';
        ph.textContent = accept.includes('audio') ? '🎵' : '📁';
        cell.appendChild(ph);
      }

      const removeBtn = document.createElement('button');
      removeBtn.type = 'button';
      removeBtn.className = 'absolute top-1 right-1 w-5 h-5 bg-red-500 hover:bg-red-600 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity';
      if (window.matchMedia?.('(hover: none)').matches) removeBtn.classList.remove('opacity-0');
      removeBtn.setAttribute('aria-label', `Remove file ${idx + 1}`);
      removeBtn.innerHTML = `<svg class="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>`;
      removeBtn.addEventListener('click', () => removeAt(idx));
      cell.appendChild(removeBtn);

      const badge = document.createElement('div');
      badge.className = 'absolute bottom-1 left-1 px-1 bg-black/60 rounded text-[10px] text-white';
      badge.textContent = String(idx + 1);
      cell.appendChild(badge);

      previewGrid.appendChild(cell);
    });
  }

  async function addFiles(fileList) {
    if (isUploading) return;
    const remaining = maxFiles - items.length;
    if (remaining <= 0) {
      setError(`Maximum ${maxFiles} files allowed`);
      return;
    }
    const all = Array.from(fileList);
    const typeValid = all.filter((f) => isFileTypeAccepted(f, accept));
    const uploadMaxFor = (f) => maxBytesForKind(
      f.type?.startsWith?.('video/') ? 'video'
        : f.type?.startsWith?.('audio/') ? 'audio'
          : f.type?.startsWith?.('image/') ? 'image' : kind,
    );
    const oversized = typeValid.find((f) => f.size > uploadMaxFor(f));
    const valid = typeValid.filter((f) => f.size <= uploadMaxFor(f));
    const toAdd = valid.slice(0, remaining);
    const validationErrors = [];
    if (typeValid.length < all.length) validationErrors.push(`Unsupported file type. Please use ${allowedDesc}.`);
    if (oversized) {
      validationErrors.push(`${oversized.name} is too large (${formatBytes(oversized.size)}). Max is ${formatBytes(uploadMaxFor(oversized))}.`);
    }
    if (valid.length > toAdd.length) validationErrors.push(`Maximum ${maxFiles} files allowed.`);
    if (toAdd.length === 0) {
      setError(validationErrors.join(' '));
      return;
    }
    clearError();

    setUploading(true);
    let failedCount = 0;
    try {
      for (let index = 0; index < toAdd.length; index++) {
        const file = toAdd[index];
        statusEl.textContent = `Uploading ${index + 1} of ${toAdd.length}…`;
        try {
          const url = await uploadFileToServer(file, { filename: file.name });
          items.push(url);
          renderPreview();
          syncToGlobal();
        } catch {
          failedCount++;
        }
      }
      if (failedCount > 0) validationErrors.push(`${failedCount} file${failedCount === 1 ? '' : 's'} could not be uploaded. Please try again.`);
      if (validationErrors.length > 0) setError(validationErrors.join(' '));
    } finally {
      fileInput.value = '';
      setUploading(false);
    }
  }

  function addUrl(url) {
    if (isUploading) return;
    const trimmed = String(url || '').trim();
    if (!trimmed) return;
    if (items.length >= maxFiles) {
      setError(`Maximum ${maxFiles} files allowed`);
      return;
    }
    items.push(trimmed);
    urlInput.value = '';
    clearError();
    renderPreview();
    syncToGlobal();
  }

  function removeAt(index) {
    if (isUploading) return;
    items.splice(index, 1);
    renderPreview();
    syncToGlobal();
  }

  function clearAll() {
    if (isUploading) return;
    items = [];
    fileInput.value = '';
    renderPreview();
    syncToGlobal();
  }

  dropZone.addEventListener('click', () => fileInput.click());
  const DRAG_CLASSES = ['dragover', 'border-primary/40', 'bg-primary/5'];
  dropZone.addEventListener('dragover', (e) => { e.preventDefault(); dropZone.classList.add(...DRAG_CLASSES); });
  dropZone.addEventListener('dragleave', () => dropZone.classList.remove(...DRAG_CLASSES));
  dropZone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropZone.classList.remove(...DRAG_CLASSES);
    if (e.dataTransfer?.files?.length) {
      uploadPromise = addFiles(e.dataTransfer.files);
    }
  });
  fileInput.addEventListener('change', () => {
    if (fileInput.files?.length) {
      uploadPromise = addFiles(fileInput.files);
    }
  });
  addUrlBtn.addEventListener('click', () => addUrl(urlInput.value));
  urlInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      addUrl(urlInput.value);
    }
  });

  clearAllBtn.addEventListener('click', clearAll);

  let drag = null;

  function cellAt(x, y) {
    return [...previewGrid.children].find((c) => {
      const r = c.getBoundingClientRect();
      return x >= r.left && x <= r.right && y >= r.top && y <= r.bottom;
    });
  }

  function startDrag(x, y) {
    const r = drag.cell.getBoundingClientRect();
    const ghost = drag.cell.cloneNode(true);
    ghost.style.cssText = `position:fixed;left:${r.left}px;top:${r.top}px;width:${r.width}px;height:${r.height}px;margin:0;pointer-events:none;z-index:9999;transform:scale(1.08);opacity:0.92;box-shadow:0 12px 28px rgba(0,0,0,0.35);border-radius:0.75rem;`;
    document.body.appendChild(ghost);
    drag.cell.style.opacity = '0.3';
    Object.assign(drag, { active: true, ghost, offX: x - r.left, offY: y - r.top });
    document.body.style.cursor = 'grabbing';
    navigator.vibrate?.(10);
  }

  function moveDrag(x, y) {
    if (!drag.cell.isConnected) return endDrag(false);
    drag.ghost.style.left = `${x - drag.offX}px`;
    drag.ghost.style.top = `${y - drag.offY}px`;
    const over = cellAt(x, y);
    if (!over || over === drag.cell) return;
    const cells = [...previewGrid.children];
    previewGrid.insertBefore(drag.cell, cells.indexOf(drag.cell) < cells.indexOf(over) ? over.nextSibling : over);
  }

  function endDrag(commit) {
    if (!drag) return;
    clearTimeout(drag.timer);
    window.removeEventListener('pointermove', onPointerMove);
    window.removeEventListener('pointerup', onPointerUp);
    window.removeEventListener('pointercancel', onPointerCancel);
    window.removeEventListener('touchmove', onTouchMove);
    if (drag.active) {
      drag.ghost.remove();
      document.body.style.cursor = '';
      const order = [...previewGrid.children].map((c) => Number(c.dataset.idx));
      if (commit && drag.cell.isConnected && order.some((v, i) => v !== i)) {
        items = order.map((i) => items[i]);
        syncToGlobal();
      }
      renderPreview();
    }
    drag = null;
  }

  function onPointerMove(e) {
    if (!drag || e.pointerId !== drag.id) return;
    if (drag.active) {
      e.preventDefault();
      moveDrag(e.clientX, e.clientY);
      return;
    }
    const moved = Math.hypot(e.clientX - drag.x, e.clientY - drag.y);
    if (drag.touch && moved > 8) endDrag(false);
    else if (!drag.touch && moved > 5) startDrag(e.clientX, e.clientY);
  }
  const onPointerUp = (e) => { if (drag && e.pointerId === drag.id) endDrag(true); };
  const onPointerCancel = (e) => { if (drag && e.pointerId === drag.id) endDrag(false); };
  const onTouchMove = (e) => { if (drag?.active) e.preventDefault(); };

  previewGrid.addEventListener('pointerdown', (e) => {
    const cell = e.target.closest('[data-idx]');
    if (!cell || drag || isUploading || items.length < 2 || e.button > 0 || e.target.closest('button')) return;
    drag = { cell, id: e.pointerId, x: e.clientX, y: e.clientY, active: false, touch: e.pointerType !== 'mouse' };
    if (drag.touch) drag.timer = setTimeout(() => { if (drag && !drag.active) startDrag(drag.x, drag.y); }, 300);
    window.addEventListener('pointermove', onPointerMove);
    window.addEventListener('pointerup', onPointerUp);
    window.addEventListener('pointercancel', onPointerCancel);
    window.addEventListener('touchmove', onTouchMove, { passive: false });
  });
  previewGrid.addEventListener('contextmenu', (e) => {
    if (window.matchMedia?.('(hover: none)').matches && e.target.closest('[data-idx]')) e.preventDefault();
  });

  function setValue(value) {
    const list = Array.isArray(value) ? value : (value ? [value] : []);
    items = list.filter((v) => typeof v === 'string' && v.trim()).slice(0, maxFiles);
    clearError();
    renderPreview();
    syncToGlobal();
  }

  const getValue = async () => {
    await uploadPromise;
    return items.length > 0 ? items.slice() : undefined;
  };
  wrap.multiMedia = { getValue, setValue };

  if (initialValue != null) setValue(initialValue);
  else syncToGlobal();

  return {
    wrap,
    getValue,
    setValue,
    setError,
    clearError,
  };
}

/** Schema property -> node plus the value it contributes. `kind` picks the
 *  media type; the caller derives it from the widget name. */
export function bindMultiMediaUploadField({ key, title, description, propSchema, isRequired, kind }) {
  const field = createMultiMediaUploadField({
    label: title, id: key, help: description, kind,
    maxFiles: Number.isFinite(propSchema?.maxItems) ? Number(propSchema.maxItems) : 8,
    initialValue: propSchema?.default,
  });
  return {
    node: field.wrap,
    replaces: true,
    fields: [{ key, kind: 'multi_media', required: isRequired, _getValue: field.getValue }],
  };
}
