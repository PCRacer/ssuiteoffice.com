/**
 * Canvas pieces shared by the camera components (angle picker, camera path editor).
 */

const TWO_PI = Math.PI * 2;

export function drawCameraIcon(ctx, x, y, angle, size, colors) {
  const camW = 14;
  const camH = 10;
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(angle);
  ctx.scale(size, size);

  ctx.fillStyle = colors.body;
  ctx.beginPath();
  ctx.roundRect(-camW / 2, -camH / 2, camW, camH, 2.5);
  ctx.fill();

  ctx.beginPath();
  ctx.moveTo(camW / 2, -camH / 2 + 1);
  ctx.lineTo(camW / 2 + 5, -camH / 2 + 2.5);
  ctx.lineTo(camW / 2 + 5, camH / 2 - 2.5);
  ctx.lineTo(camW / 2, camH / 2 - 1);
  ctx.closePath();
  ctx.fill();
  // Lens circle
  ctx.fillStyle = colors.lens;
  ctx.beginPath();
  ctx.arc(0, 0, 2.5, 0, TWO_PI);
  ctx.fill();
  ctx.restore();
}

/**
 * Loads a reference image once per url and hands it to `onImage` (null on
 * failure or clear). A failed url stays memoised so it isn't refetched on
 * every form change.
 */
export function createReferenceImageLoader(onImage) {
  let currentUrl = '';
  return {
    load(url) {
      if (url === currentUrl) return;
      currentUrl = url;
      if (!url) { onImage(null); return; }
      // No crossOrigin: pixels are never read, and CORS fails on a plainly cached image.
      const img = new Image();
      img.onload = () => onImage(img);
      img.onerror = () => onImage(null);
      img.src = url;
    },
  };
}
