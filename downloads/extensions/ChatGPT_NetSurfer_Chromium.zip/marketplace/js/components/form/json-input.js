// The JSON editor's factory lives in runner/overrides/ui.js for historical
// reasons; its schema binding lives here with every other component's.
import { createJsonField } from '../../runner/overrides/ui.js';
import { buildTemplateForProperty, formatJsonText } from '../../shared/schema-templates.js';

/** Schema property -> node plus the value it contributes. */
export function bindJsonField({ key, title, description, propSchema, isRequired, isReadOnly, type }) {
  const jsonType = type === 'array' ? 'array' : 'object';
  const field = createJsonField({
    label: title,
    id: key,
    required: isRequired,
    help: description,
    jsonType,
    defaultValue: propSchema?.default,
    computeTemplate: () => {
      const t = String(propSchema?.type || '').toLowerCase();
      if (t === 'object' || t === 'array') {
        return buildTemplateForProperty({ key, propSchema, required: isRequired });
      }
      return jsonType === 'array' ? [] : {};
    },
    formatJson: formatJsonText,
  });
  if (isReadOnly) {
    field.wrap.classList.add('opacity-75');
    field.textarea.readOnly = true;
    field.wrap.querySelectorAll('button').forEach((btn) => { btn.disabled = true; });
  }
  return {
    node: field.wrap,
    replaces: true,
    fields: [{
      key,
      kind: 'json',
      required: isRequired,
      textarea: field.textarea,
      jsonType,
      _getValue: field.getValue,
      _getRaw: field.getRaw,
    }],
  };
}
