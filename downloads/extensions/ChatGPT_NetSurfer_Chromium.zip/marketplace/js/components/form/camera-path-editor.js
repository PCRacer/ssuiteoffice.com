/**
 * Camera Path Editor component
 * Edits a FAL camera trajectory (keyframes of time / azimuth / elevation /
 * distance) around a reference image, mirroring FAL's camera-motion editor.
 * `getValues()` returns `{ keyframes }` in FAL's shape.
 */
import { createSliderField } from '../../runner/overrides/ui.js';
import { createReferenceImageLoader, drawCameraIcon } from './camera-canvas.js';

const DEG = Math.PI / 180;
const TWO_PI = Math.PI * 2;
const FULL_TURN = 360;

// The azimuth dial runs +/- 3 turns, elevation covers the half sphere and
// distance is relative to the reference framing, like FAL's editor.
const AZIMUTH_LIMIT = 3 * FULL_TURN;
const ELEVATION_LIMIT = 90;
const DISTANCE_RANGE = [0.1, 2];
const DISTANCE_STEP = 0.05;
const REST_KEYFRAME = { time: 0, azimuth: 0, elevation: 0, distance: 1 };
const MIN_KEYFRAMES = 2;
const DEFAULT_MAX_KEYFRAMES = 12;
const DEFAULT_DURATION_SECONDS = 5;
const DIAL_RADIUS_PX = 22;
const DIAL_TICKS = 8;
const KEYFRAME_TIME_GAP = 0.02;
const TIME_NUDGE_SECONDS = 0.1;
const NUDGE_DEGREES = { fine: 1, coarse: 15 };
const DOT_RADIUS = { active: 5, idle: 3 };
const DOT_HIT_RADIUS = 10;
const CLICK_SLOP_PX = 4;
const DEFAULT_DURATION_OPTIONS = [5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15];
const TIMELINE_START_LABEL = '0:00';
// Diamonds sit inside the track so the first and last are never clipped, even
// when active (11 px, rotated) and hovered (×1.25).
const TIMELINE_INSET_PX = 10;
const timelineLeft = (time) => `calc(${TIMELINE_INSET_PX}px + (100% - ${TIMELINE_INSET_PX * 2}px) * ${time})`;
const DISTANCE_SLIDER_STEP = 0.01;
// Room for the longest readout ("back-right quarter view · 1.13 turns", three
// lines at this width) so the dial cell never changes height while turning.
const DIAL_VIEW_MIN_HEIGHT_PX = 44;
const SLIDER_VALUE_MIN_WIDTH = '4.5ch';
const FOCUS_RING = '0 0 0 2px hsl(var(--ait-m-primary) / 0.35)';
const DIAMOND_STATIC_STYLE = 'position:absolute;top:50%;padding:0;transform:rotate(45deg);transition:transform 0.12s;touch-action:none;border:1px solid transparent;';
// Orbiting the viewer: a drag across the whole scene turns it half a turn, the
// handle turns it by the pixel, and the pitch stays between a low front view
// and almost straight down.
const VIEW_PITCH_RANGE = [-15, 85];
const VIEW_DRAG_DEGREES = { yaw: 180, pitch: 120 };
const VIEW_HANDLE_DEGREES_PER_PX = { yaw: 1.5, pitch: 1 };
const VIEW_KEY_STEP_DEGREES = 5;
const BACK_SIDE_ALPHA = 0.45;
// The label hangs below its tick so a camera parked at the front never covers it.
const FRONT_LABEL = { text: 'front', dropPx: 12 };
const VIEW_HANDLE_STYLE = 'position:absolute;right:8px;bottom:8px;width:28px;height:28px;padding:0;border-radius:50%;display:flex;align-items:center;justify-content:center;cursor:grab;touch-action:none;background:hsl(var(--ait-m-background) / 0.7);border:1px solid hsl(var(--ait-m-foreground) / 0.2);color:hsl(var(--ait-m-foreground) / 0.7);';
const VIEW_HANDLE_ICON = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M3 12c0 2.5 4 4.5 9 4.5s9-2 9-4.5"/><path d="M19 9l2 3-3 1"/></svg>';
// There is no wheel or modifier key on touch screens, so the hint points at
// the second finger and the Distance slider instead.
const HINT_TEXT = {
  pointer: 'Drag to move the camera · ⇧-drag or right-drag to orbit the view · click, then scroll for distance · click a dot to select',
  touch: 'Drag to move the camera · two fingers orbit the view · Distance slider for zoom · tap a dot to select',
};

const VIEW_SECTOR = 45;
const VIEW_NAMES = [
  'front view', 'front-right quarter view', 'right side view', 'back-right quarter view',
  'back view', 'back-left quarter view', 'left side view', 'front-left quarter view',
];

// FAL's opening move: a rest pose held for a frame, then a smoothstep full
// orbit to the right that settles just before the clip ends.
const DEFAULT_PATH = { poses: 9, timeOffset: 1 / 30, timeSpan: 0.85, turn: FULL_TURN };
// Presets and resamples stop this long before the clip ends and hold the last
// pose, as FAL's editor does, so the move settles instead of being cut off.
const HOLD_SECONDS = 1;

// FAL's presets, in its menu order; `time` is a fraction of the move, not of the clip.
const CAMERA_PRESETS = [
  { id: 'dolly-in', label: 'Dolly in', distance: [1, 0.35] },
  { id: 'dolly-out', label: 'Dolly out', distance: [1, 2] },
  { id: 'spiral-in', label: 'Spiral in', azimuth: [0, 60], distance: [1, 0.35] },
  { id: 'crane-up', label: 'Crane up', elevation: [0, 31], distance: [1, 1.166] },
  { id: 'orbit-360-right', label: 'Orbit 360° right', azimuth: [0, 45, 90, 135, 180, 225, 270, 315, 360] },
  { id: 'orbit-360-left', label: 'Orbit 360° left', azimuth: [0, -45, -90, -135, -180, -225, -270, -315, -360] },
  { id: 'half-orbit-right', label: 'Half orbit right', azimuth: [0, 45, 90, 135, 180] },
  { id: 'half-orbit-left', label: 'Half orbit left', azimuth: [0, -45, -90, -135, -180] },
  { id: 'high-orbit-right', label: 'High orbit right', azimuth: [0, 45, 90], elevation: [0, 15, 30] },
  { id: 'low-orbit-right', label: 'Low orbit right', azimuth: [0, 45, 90], elevation: [0, -10, -20] },
  {
    id: 'orbit-360-spiral-in', label: 'Orbit 360° spiral in',
    azimuth: [0, 45, 90, 135, 180, 225, 270, 315, 360],
    distance: [1, 0.95, 0.9, 0.85, 0.8, 0.75, 0.7, 0.65, 0.6],
  },
  { id: 'swing', label: 'Swing', azimuth: [0, 45, 45, -45, -45], time: [0, 0.35, 0.5, 0.85, 1] },
];

const GHOST_BUTTON_STYLE = 'display:inline-flex;align-items:center;justify-content:center;gap:4px;border-radius:8px;padding:4px 10px;font-size:11px;cursor:pointer;background:transparent;border:1px solid hsl(var(--ait-m-foreground) / 0.14);color:hsl(var(--ait-m-foreground) / 0.7);';
const SELECT_STYLE = 'height:26px;border-radius:8px;padding:0 8px;font-size:11px;line-height:1;background:transparent;border:1px solid hsl(var(--ait-m-foreground) / 0.14);color:hsl(var(--ait-m-foreground) / 0.8);';
const MUTED_TEXT_STYLE = 'font-size:11px;color:hsl(var(--ait-m-foreground) / 0.55);';
const CONTROLS_GRID_STYLE = 'display:grid;grid-template-columns:auto minmax(0, 1fr);column-gap:14px;row-gap:6px;align-items:center;margin-top:12px;';
const HINT_STYLE = 'margin:6px 0 0;text-align:center;font-size:11px;line-height:1.4;';

// The scene is a perspective view: the subject is a vertical image plane at
// the origin facing +z, the camera orbits it, and a fixed viewer watches from
// slightly above and to the left, like FAL's editor. The focal length is the
// largest that keeps every preset pose (Dolly out's end at distance 2 is the
// binding one) inside the canvas; `center` is where the subject lands, as
// fractions of the canvas size.
export const VIEWER = { yaw: -30, pitch: 22, distance: 4.2, focal: 3.0, center: { x: 0.5, y: 0.48 } };
const GRID = { extent: 1.5, step: 0.5, y: -1.1 };
const IMAGE_PLANE = { width: 1.0, defaultAspect: 16 / 9, minHeight: 0.35, maxHeight: 1.6, strips: 4, stripOverlap: 0.03 };
const REFERENCE_RING = { radius: 1, segments: 72, tickEvery: 45 };
const PATH_SAMPLES_PER_SEGMENT = 12;
const CANVAS = { aspectRatio: '4/3', width: 280, height: 210 };
const SCENE_STROKE = { grid: 1, ring: 1, path: 1.5, lookAt: 1, planeBorder: 1 };
const LOOK_AT_ALPHA = 0.6;
// A camera behind the picture still shows through it as a ghost, so it is never lost.
const GHOST_CAMERA_ALPHA = 0.3;
const TICK_RADIUS = 1.5;
const CAMERA_ICON_SCALE = { min: 0.7, max: 1 };
// Lines fade from full strength at the near edge of the scene to `min` at the far edge.
const DEPTH_FADE = { span: 1.5, min: 0.35 };
const SCENE_COLORS = {
  dark: {
    background: '#1a1c1f', grid: 'rgba(255,255,255,0.10)', ring: 'rgba(255,255,255,0.28)',
    tick: 'rgba(255,255,255,0.5)', path: 'hsl(170 60% 45%)', planeFill: '#252729', planeBorder: 'rgba(255,255,255,0.12)',
    lens: 'rgba(255,255,255,0.9)',
  },
  light: {
    background: '#EAEFF6', grid: 'rgba(0,0,0,0.10)', ring: 'rgba(0,0,0,0.22)',
    tick: 'rgba(0,0,0,0.4)', path: 'hsl(170 55% 38%)', planeFill: '#dde3ed', planeBorder: 'rgba(0,0,0,0.1)',
    lens: 'rgba(255,255,255,0.95)',
  },
};

const num = (value, fallback) => { const n = Number(value); return Number.isFinite(n) ? n : fallback; };
const clamp = (value, min, max) => Math.min(Math.max(value, min), max);
const round4 = (value) => Math.round(value * 10000) / 10000;
const clampAzimuth = (azimuth) => clamp(azimuth, -AZIMUTH_LIMIT, AZIMUTH_LIMIT);
const clampElevation = (elevation) => clamp(elevation, -ELEVATION_LIMIT, ELEVATION_LIMIT);
const clampDistance = (distance) => clamp(distance, DISTANCE_RANGE[0], DISTANCE_RANGE[1]);
const isDark = () => window.matchMedia?.('(prefers-color-scheme: dark)')?.matches || document.documentElement.classList.contains('dark');
const isTouch = () => Boolean(window.matchMedia?.('(hover: none)')?.matches);
const themeColors = () => SCENE_COLORS[isDark() ? 'dark' : 'light'];
const sideOfPlane = (point) => (point.z >= 0 ? 'front' : 'behind');
const lerpPoint = (a, b, t) => ({ x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t, z: a.z + (b.z - a.z) * t });

export function cameraWorldPosition({ azimuth, elevation, distance }) {
  const az = azimuth * DEG;
  const el = elevation * DEG;
  return { x: distance * Math.sin(az) * Math.cos(el), y: distance * Math.sin(el), z: distance * Math.cos(az) * Math.cos(el) };
}

// Rotates the world so the viewer sits on the +z axis, then projects with the
// focal length measured in half canvas heights so any FAL pose stays in frame.
export function projectPoint(point, viewer, width, height) {
  const yaw = viewer.yaw * DEG;
  const pitch = viewer.pitch * DEG;
  const x1 = point.x * Math.cos(yaw) - point.z * Math.sin(yaw);
  const z1 = point.x * Math.sin(yaw) + point.z * Math.cos(yaw);
  const y2 = point.y * Math.cos(pitch) - z1 * Math.sin(pitch);
  const z2 = z1 * Math.cos(pitch) + point.y * Math.sin(pitch);
  const depth = viewer.distance - z2;
  const scale = (viewer.focal * height / 2) / depth;
  return { x: width * viewer.center.x + x1 * scale, y: height * viewer.center.y - y2 * scale, depth, scale };
}

// The image plane is opaque, so anything on its far side (z < 0) is drawn
// before it and anything on the near side after; segments that cross it are
// cut at the crossing so a path never pops in front of the picture.
export function splitAtImagePlane(points) {
  const runs = { front: [], behind: [] };
  let run = [];
  let side = null;
  points.forEach((point, index) => {
    const previous = points[index - 1];
    if (previous && sideOfPlane(previous) !== sideOfPlane(point)) {
      const crossing = lerpPoint(previous, point, previous.z / (previous.z - point.z));
      run.push(crossing);
      runs[side].push(run);
      run = [crossing];
    }
    side = sideOfPlane(point);
    run.push(point);
  });
  if (run.length > 1) runs[side].push(run);
  return runs;
}

// From behind the picture the draw order flips and the plane dims, so an
// orbit past the edge never hides the path behind an opaque wall.
export function viewerIsInFront(viewer) {
  return projectPoint({ x: 0, y: 0, z: 1 }, viewer, 1, 1).depth < projectPoint({ x: 0, y: 0, z: -1 }, viewer, 1, 1).depth;
}

const normalizeYaw = (yaw) => ((((yaw + 180) % FULL_TURN) + FULL_TURN) % FULL_TURN) - 180;

const depthAlpha = (depth) => {
  const near = VIEWER.distance - DEPTH_FADE.span;
  const progress = clamp((depth - near) / (DEPTH_FADE.span * 2), 0, 1);
  return 1 - (1 - DEPTH_FADE.min) * progress;
};

function viewNameFor(azimuth) {
  const turn = ((azimuth % FULL_TURN) + FULL_TURN) % FULL_TURN;
  return VIEW_NAMES[Math.round(turn / VIEW_SECTOR) % VIEW_NAMES.length];
}

function viewLabel(azimuth) {
  const turns = Math.abs(azimuth) / FULL_TURN;
  return turns >= 1 ? `${viewNameFor(azimuth)} · ${turns.toFixed(2)} turns` : viewNameFor(azimuth);
}

function azimuthLabel(azimuth) {
  return `${Math.round(azimuth)}° · ${viewLabel(azimuth)}`;
}

// FAL eases between keyframes with this cosine curve, so a preview and a
// resampled path match its playground; its opening orbit is a smoothstep.
const easeInOut = (progress) => (1 - Math.cos(Math.PI * progress)) / 2;
const smoothstep = (progress) => progress * progress * (3 - 2 * progress);

function primaryColor(dark) {
  const value = getComputedStyle(document.documentElement).getPropertyValue('--primary').trim();
  if (value) return `hsl(${value})`;
  return dark ? 'rgba(255,255,255,0.9)' : 'rgba(0,0,0,0.75)';
}

function formatClock(seconds) {
  const total = Math.max(0, num(seconds, 0));
  const minutes = Math.floor(total / 60);
  const rest = total - minutes * 60;
  return `${minutes}:${rest < 10 ? '0' : ''}${rest.toFixed(1)}`;
}

function toKeyframe(keyframe = {}) {
  return {
    time: round4(clamp(num(keyframe.time, 0), 0, 1)),
    azimuth: round4(clampAzimuth(num(keyframe.azimuth, 0))),
    elevation: round4(clampElevation(num(keyframe.elevation, 0))),
    distance: round4(clampDistance(num(keyframe.distance, REST_KEYFRAME.distance))),
  };
}

function defaultCameraPath() {
  const path = [{ ...REST_KEYFRAME }];
  for (let i = 0; i < DEFAULT_PATH.poses; i++) {
    const progress = i / (DEFAULT_PATH.poses - 1);
    path.push({
      time: round4(DEFAULT_PATH.timeOffset + DEFAULT_PATH.timeSpan * progress),
      azimuth: round4(DEFAULT_PATH.turn * smoothstep(progress)),
      elevation: REST_KEYFRAME.elevation,
      distance: REST_KEYFRAME.distance,
    });
  }
  return path;
}

function presetCameraPath(preset, endTime) {
  const count = Math.max(
    preset.azimuth?.length || 0, preset.elevation?.length || 0,
    preset.distance?.length || 0, preset.time?.length || 0,
  );
  return Array.from({ length: count }, (_, i) => ({
    time: round4((preset.time ? preset.time[i] : i / (count - 1)) * endTime),
    azimuth: preset.azimuth?.[i] ?? REST_KEYFRAME.azimuth,
    elevation: preset.elevation?.[i] ?? REST_KEYFRAME.elevation,
    distance: preset.distance?.[i] ?? REST_KEYFRAME.distance,
  }));
}

// The camera holds the first pose before its time and the last one after it,
// exactly like FAL plays the path back.
function interpolatePose(path, time) {
  if (path.length === 0) return { ...REST_KEYFRAME };
  const first = path[0];
  const last = path[path.length - 1];
  if (time <= first.time) return { azimuth: first.azimuth, elevation: first.elevation, distance: first.distance };
  if (time >= last.time) return { azimuth: last.azimuth, elevation: last.elevation, distance: last.distance };

  let index = 1;
  while (index < path.length - 1 && path[index].time < time) index++;
  const from = path[index - 1];
  const to = path[index];
  const span = to.time - from.time;
  const progress = span > 0 ? easeInOut((time - from.time) / span) : 0;
  return {
    azimuth: round4(from.azimuth + (to.azimuth - from.azimuth) * progress),
    elevation: round4(from.elevation + (to.elevation - from.elevation) * progress),
    distance: round4(from.distance + (to.distance - from.distance) * progress),
  };
}

function resamplePath(path, count, endTime) {
  return Array.from({ length: count }, (_, i) => {
    const time = round4((i / (count - 1)) * endTime);
    return { time, ...interpolatePose(path, time) };
  });
}

function buildOption(value, text) {
  const option = document.createElement('option');
  option.value = value;
  option.textContent = text;
  return option;
}

function labelled(text, control) {
  const field = document.createElement('label');
  field.style.cssText = `display:inline-flex;align-items:center;gap:4px;${MUTED_TEXT_STYLE}`;
  field.appendChild(document.createTextNode(text));
  field.appendChild(control);
  return field;
}

export function createCameraPathEditor({
  id,
  maxKeyframes = DEFAULT_MAX_KEYFRAMES,
  getDurationSeconds = () => DEFAULT_DURATION_SECONDS,
  durationOptions = DEFAULT_DURATION_OPTIONS,
  onDurationChange,
  getReferenceImageUrl = () => '',
} = {}) {
  const wrap = document.createElement('div');
  if (id) wrap.setAttribute('data-id', id);
  wrap.setAttribute('data-component', 'camera-path-editor');

  // ── State ──
  let path = defaultCameraPath();
  let activeIndex = 0;
  let previewPose = null;            // set while the path is playing back
  let playheadTime = null;
  let playFrame = null;
  let userImg = null;
  let viewer = { ...VIEWER };
  const loader = createReferenceImageLoader((img) => { userImg = img; draw(); });

  const activeKeyframe = () => path[activeIndex];
  const currentPose = () => previewPose || activeKeyframe();
  const durationSeconds = () => Math.max(num(getDurationSeconds(), DEFAULT_DURATION_SECONDS), 0.1);
  const moveEndTime = () => {
    const seconds = durationSeconds();
    return seconds > HOLD_SECONDS ? round4((seconds - HOLD_SECONDS) / seconds) : 1;
  };
  const pathValues = () => path.map(toKeyframe).sort((a, b) => a.time - b.time);

  // ── Canvas: perspective scene ──
  const canvasWrap = document.createElement('div');
  canvasWrap.className = 'relative rounded-[16px] overflow-hidden select-none border border-white/[0.06] dark:border-white/[0.06] bg-[#1a1c1f]';
  canvasWrap.style.cssText = `aspect-ratio:${CANVAS.aspectRatio};max-width:280px;margin:0 auto;`;

  const canvas = document.createElement('canvas');
  let sceneSize = { width: CANVAS.width, height: CANVAS.height };
  fitCanvasToLayout();
  canvas.style.cssText = 'width:100%;height:100%;cursor:grab;touch-action:none;';
  // The wheel only steers distance once the scene is focused, so scrolling
  // the page across it never changes the camera by accident.
  canvas.tabIndex = 0;
  canvas.style.outline = 'none';
  canvas.addEventListener('focus', () => { canvasWrap.style.boxShadow = FOCUS_RING; });
  canvas.addEventListener('blur', () => { canvasWrap.style.boxShadow = ''; });
  canvasWrap.appendChild(canvas);

  const viewHandle = document.createElement('button');
  viewHandle.type = 'button';
  viewHandle.setAttribute('data-view-orbit', '');
  viewHandle.setAttribute('aria-label', 'Orbit the view');
  viewHandle.title = 'Drag to orbit the view';
  viewHandle.style.cssText = VIEW_HANDLE_STYLE;
  viewHandle.innerHTML = VIEW_HANDLE_ICON;
  canvasWrap.appendChild(viewHandle);

  const viewResetBtn = document.createElement('button');
  viewResetBtn.type = 'button';
  viewResetBtn.setAttribute('data-view-reset', '');
  viewResetBtn.title = 'Back to the default view';
  viewResetBtn.style.cssText = `${GHOST_BUTTON_STYLE}position:absolute;top:8px;right:8px;background:hsl(var(--ait-m-background) / 0.7);`;
  viewResetBtn.style.display = 'none';
  viewResetBtn.textContent = 'Reset view';
  viewResetBtn.addEventListener('click', () => resetView());
  canvasWrap.appendChild(viewResetBtn);

  function setView(yaw, pitch) {
    viewer = { ...viewer, yaw: normalizeYaw(yaw), pitch: clamp(pitch, VIEW_PITCH_RANGE[0], VIEW_PITCH_RANGE[1]) };
    viewResetBtn.style.display = viewer.yaw === VIEWER.yaw && viewer.pitch === VIEWER.pitch ? 'none' : '';
    draw();
  }

  function resetView() {
    setView(VIEWER.yaw, VIEWER.pitch);
  }

  // Dragging right pulls the scene's front to the right; dragging down tips
  // it toward the viewer, as if turning the model by hand.
  function orbitBy(dx, dy, degreesPerPx) {
    setView(viewer.yaw - dx * degreesPerPx.yaw, viewer.pitch + dy * degreesPerPx.pitch);
  }

  let handleLast = null;
  viewHandle.addEventListener('pointerdown', (e) => {
    handleLast = { x: e.clientX, y: e.clientY };
    viewHandle.setPointerCapture?.(e.pointerId);
  });
  viewHandle.addEventListener('pointermove', (e) => {
    if (!handleLast) return;
    orbitBy(e.clientX - handleLast.x, e.clientY - handleLast.y, VIEW_HANDLE_DEGREES_PER_PX);
    handleLast = { x: e.clientX, y: e.clientY };
  });
  const releaseHandle = () => { handleLast = null; };
  viewHandle.addEventListener('pointerup', releaseHandle);
  viewHandle.addEventListener('pointercancel', releaseHandle);

  canvas.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowLeft') setView(viewer.yaw + VIEW_KEY_STEP_DEGREES, viewer.pitch);
    else if (e.key === 'ArrowRight') setView(viewer.yaw - VIEW_KEY_STEP_DEGREES, viewer.pitch);
    else if (e.key === 'ArrowUp') setView(viewer.yaw, viewer.pitch + VIEW_KEY_STEP_DEGREES);
    else if (e.key === 'ArrowDown') setView(viewer.yaw, viewer.pitch - VIEW_KEY_STEP_DEGREES);
    else if (e.key === 'Home') resetView();
    else return;
    e.preventDefault();
  });

  // The backing store follows the element's CSS size and the device pixel
  // ratio so 1 px scene lines stay crisp on retina screens.
  function fitCanvasToLayout() {
    const rect = canvas.getBoundingClientRect();
    sceneSize = { width: rect.width || CANVAS.width, height: rect.height || CANVAS.height };
    const ratio = window.devicePixelRatio || 1;
    canvas.width = Math.round(sceneSize.width * ratio);
    canvas.height = Math.round(sceneSize.height * ratio);
  }

  const hintEl = document.createElement('p');
  hintEl.setAttribute('data-camera-hint', '');
  hintEl.textContent = isTouch() ? HINT_TEXT.touch : HINT_TEXT.pointer;
  hintEl.style.cssText = HINT_STYLE;

  function applyTheme() {
    const dk = isDark();
    canvasWrap.style.background = themeColors().background;
    canvasWrap.style.borderColor = dk ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.06)';
    hintEl.style.color = dk ? 'rgba(255,255,255,0.35)' : 'rgba(0,0,0,0.35)';
  }
  applyTheme();

  function draw() {
    const ctx = canvas.getContext('2d');
    const { width, height } = sceneSize;
    const dk = isDark();
    const colors = themeColors();
    const primary = primaryColor(dk);
    const project = (point) => projectPoint(point, viewer, width, height);
    const layers = sceneLayers(currentPose());
    const inFront = viewerIsInFront(viewer);
    const far = inFront ? layers.behind : layers.front;
    const near = inFront ? layers.front : layers.behind;

    ctx.setTransform(window.devicePixelRatio || 1, 0, 0, window.devicePixelRatio || 1, 0, 0);
    ctx.clearRect(0, 0, width, height);
    ctx.fillStyle = colors.background;
    ctx.fillRect(0, 0, width, height);

    drawGroundGrid(ctx, project, colors);
    drawSceneLayer(ctx, project, far, colors, primary);
    drawImagePlane(ctx, project, colors, inFront);
    drawSceneLayer(ctx, project, near, colors, primary);
    if (far.camera) {
      ctx.globalAlpha = GHOST_CAMERA_ALPHA;
      drawCameraObject(ctx, project, far.camera, colors, primary);
      ctx.globalAlpha = 1;
    }
  }

  // World-space content sorted by which side of the image plane it is on.
  function sceneLayers(cameraPose) {
    const onRing = (azimuth, elevation) => cameraWorldPosition({ azimuth, elevation, distance: REFERENCE_RING.radius });
    const ring = splitAtImagePlane(Array.from({ length: REFERENCE_RING.segments + 1 }, (_, i) => onRing((i * FULL_TURN) / REFERENCE_RING.segments, 0)));
    const pathRuns = splitAtImagePlane(pathSamples());
    const ticks = Array.from({ length: FULL_TURN / REFERENCE_RING.tickEvery }, (_, i) => ({
      point: onRing(i * REFERENCE_RING.tickEvery, 0),
      label: i === 0 ? FRONT_LABEL.text : null,
    }));
    const dots = path.map((keyframe, index) => ({ point: cameraWorldPosition(keyframe), active: index === activeIndex }));
    const camera = cameraWorldPosition(cameraPose);
    const layer = (side) => ({
      ring: ring[side],
      path: pathRuns[side],
      ticks: ticks.filter(tick => sideOfPlane(tick.point) === side),
      dots: dots.filter(dot => sideOfPlane(dot.point) === side),
      camera: sideOfPlane(camera) === side ? camera : null,
    });
    return { behind: layer('behind'), front: layer('front') };
  }

  // The drawn path is the eased motion FAL will play, not chords between the
  // keyframes, so a spiral-in visibly tightens.
  function pathSamples() {
    const samples = [cameraWorldPosition(path[0])];
    for (let i = 1; i < path.length; i++) {
      const from = path[i - 1].time;
      const span = path[i].time - from;
      for (let step = 1; step <= PATH_SAMPLES_PER_SEGMENT; step++) {
        samples.push(cameraWorldPosition(interpolatePose(path, from + (span * step) / PATH_SAMPLES_PER_SEGMENT)));
      }
    }
    return samples;
  }

  function drawSceneLayer(ctx, project, layer, colors, primary) {
    layer.ring.forEach(run => strokeDepthRun(ctx, run.map(project), colors.ring, SCENE_STROKE.ring));
    layer.ticks.forEach(({ point, label }) => {
      const dot = project(point);
      fillDot(ctx, dot, colors.tick, TICK_RADIUS, depthAlpha(dot.depth));
      if (label) drawLabel(ctx, { x: dot.x, y: dot.y + FRONT_LABEL.dropPx }, label, colors.tick, depthAlpha(dot.depth));
    });
    layer.path.forEach(run => strokeDepthRun(ctx, run.map(project), colors.path, SCENE_STROKE.path));
    layer.dots.forEach(({ point, active }) => {
      const dot = project(point);
      if (active) fillDot(ctx, dot, primary, DOT_RADIUS.active, 1);
      else fillDot(ctx, dot, colors.path, DOT_RADIUS.idle, depthAlpha(dot.depth));
    });
    if (layer.camera) drawCameraObject(ctx, project, layer.camera, colors, primary);
  }

  // Each segment gets its own alpha so a line fades as it recedes; butt caps
  // keep translucent neighbours from doubling up where they meet.
  function strokeDepthRun(ctx, points, color, width, alpha = 1) {
    ctx.strokeStyle = color;
    ctx.lineWidth = width;
    ctx.lineCap = 'butt';
    for (let i = 1; i < points.length; i++) {
      const from = points[i - 1];
      const to = points[i];
      const fade = ((from.fade ?? 1) + (to.fade ?? 1)) / 2;
      ctx.globalAlpha = alpha * fade * depthAlpha((from.depth + to.depth) / 2);
      ctx.beginPath();
      ctx.moveTo(from.x, from.y);
      ctx.lineTo(to.x, to.y);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
  }

  function drawLabel(ctx, at, text, color, alpha) {
    ctx.globalAlpha = alpha;
    ctx.fillStyle = color;
    ctx.font = '500 10px system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(text, at.x, at.y);
    ctx.globalAlpha = 1;
  }

  function fillDot(ctx, point, color, radius, alpha) {
    ctx.globalAlpha = alpha;
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.arc(point.x, point.y, radius, 0, TWO_PI);
    ctx.fill();
    ctx.globalAlpha = 1;
  }

  function drawGroundGrid(ctx, project, colors) {
    const { extent, step, y } = GRID;
    // The grid dies out toward its own edge, so neither its clipped near
    // corner nor its far rim ends in a hard line.
    const fadeAt = (x, z) => 1 - Math.min(1, (x * x + z * z) / (extent * extent));
    const gridPoint = (x, z) => ({ ...project({ x, y, z }), fade: fadeAt(x, z) });
    const lines = Math.round((extent * 2) / step) + 1;
    const offsets = Array.from({ length: lines }, (_, i) => -extent + i * step);
    offsets.forEach(offset => {
      strokeDepthRun(ctx, offsets.map(t => gridPoint(t, offset)), colors.grid, SCENE_STROKE.grid);
      strokeDepthRun(ctx, offsets.map(t => gridPoint(offset, t)), colors.grid, SCENE_STROKE.grid);
    });
  }

  function planeSize() {
    const aspect = userImg ? userImg.naturalWidth / userImg.naturalHeight : IMAGE_PLANE.defaultAspect;
    const width = IMAGE_PLANE.width;
    return { width, height: clamp(width / aspect, IMAGE_PLANE.minHeight, IMAGE_PLANE.maxHeight) };
  }

  function traceQuad(ctx, quad) {
    ctx.beginPath();
    quad.forEach((point, index) => (index === 0 ? ctx.moveTo(point.x, point.y) : ctx.lineTo(point.x, point.y)));
    ctx.closePath();
  }

  function drawImagePlane(ctx, project, colors, inFront) {
    const size = planeSize();
    const corner = (x, y) => ({ x: (x * size.width) / 2, y: (y * size.height) / 2, z: 0 });
    const corners = { topLeft: corner(-1, 1), topRight: corner(1, 1), bottomRight: corner(1, -1), bottomLeft: corner(-1, -1) };
    const quad = [corners.topLeft, corners.topRight, corners.bottomRight, corners.bottomLeft].map(project);

    ctx.globalAlpha = inFront ? 1 : BACK_SIDE_ALPHA;
    if (userImg) {
      ctx.save();
      traceQuad(ctx, quad);
      ctx.clip();
      drawPlaneTexture(ctx, project, corners, size);
      ctx.restore();
    } else {
      traceQuad(ctx, quad);
      ctx.fillStyle = colors.planeFill;
      ctx.fill();
    }
    ctx.globalAlpha = 1;
    traceQuad(ctx, quad);
    ctx.strokeStyle = colors.planeBorder;
    ctx.lineWidth = SCENE_STROKE.planeBorder;
    ctx.lineJoin = 'round';
    ctx.stroke();
  }

  // Canvas has no perspective-correct texturing: the picture goes on as a few
  // vertical strips, each affine-mapped to its own projected corners, which
  // keeps the keystone error well under a pixel at this size.
  function drawPlaneTexture(ctx, project, corners, size) {
    const { naturalWidth, naturalHeight } = userImg;
    const cover = Math.max(size.width / naturalWidth, size.height / naturalHeight);
    const source = { width: size.width / cover, height: size.height / cover };
    source.x = (naturalWidth - source.width) / 2;
    source.y = (naturalHeight - source.height) / 2;
    const { strips, stripOverlap } = IMAGE_PLANE;
    for (let i = 0; i < strips; i++) {
      const from = i / strips;
      const to = Math.min(1, (i + 1) / strips + stripOverlap);
      const topLeft = project(lerpPoint(corners.topLeft, corners.topRight, from));
      const topRight = project(lerpPoint(corners.topLeft, corners.topRight, to));
      const bottomLeft = project(lerpPoint(corners.bottomLeft, corners.bottomRight, from));
      ctx.save();
      ctx.transform(topRight.x - topLeft.x, topRight.y - topLeft.y, bottomLeft.x - topLeft.x, bottomLeft.y - topLeft.y, topLeft.x, topLeft.y);
      ctx.drawImage(userImg, source.x + source.width * from, source.y, source.width * (to - from), source.height, 0, 0, 1, 1);
      ctx.restore();
    }
  }

  function drawCameraObject(ctx, project, position, colors, primary) {
    const subject = project({ x: 0, y: 0, z: 0 });
    const point = project(position);
    const alpha = ctx.globalAlpha;
    ctx.strokeStyle = primary;
    ctx.lineWidth = SCENE_STROKE.lookAt;
    ctx.globalAlpha = alpha * LOOK_AT_ALPHA;
    ctx.beginPath();
    ctx.moveTo(point.x, point.y);
    ctx.lineTo(subject.x, subject.y);
    ctx.stroke();
    ctx.globalAlpha = alpha;
    const size = clamp(point.scale / subject.scale, CAMERA_ICON_SCALE.min, CAMERA_ICON_SCALE.max);
    drawCameraIcon(ctx, point.x, point.y, Math.atan2(subject.y - point.y, subject.x - point.x), size, { body: primary, lens: colors.lens });
  }

  // ── Pointer: a drag moves the active camera; shift, alt, the right button
  // or a second finger orbit the viewer instead; a click on a dot selects it ──
  const pointers = new Map();
  let drag = null;

  const canvasPoint = (e) => {
    const rect = canvas.getBoundingClientRect();
    return { x: e.clientX - rect.left, y: e.clientY - rect.top, width: rect.width || sceneSize.width, height: rect.height || sceneSize.height };
  };
  const centroid = () => {
    const points = Array.from(pointers.values());
    return { x: points.reduce((sum, p) => sum + p.x, 0) / points.length, y: points.reduce((sum, p) => sum + p.y, 0) / points.length };
  };
  const isViewGesture = (e) => e.button === 2 || e.shiftKey || e.altKey || pointers.size > 1;

  // A camera drag starts from the active keyframe's own pose, never from
  // wherever the preview camera happens to be.
  function startDrag(mode, at) {
    if (mode === 'camera') stopPlay();
    const pose = activeKeyframe();
    drag = { mode, x: at.x, y: at.y, azimuth: pose.azimuth, elevation: pose.elevation, yaw: viewer.yaw, pitch: viewer.pitch };
  }

  canvas.addEventListener('contextmenu', (e) => e.preventDefault());

  canvas.addEventListener('pointerdown', (e) => {
    const at = canvasPoint(e);
    pointers.set(e.pointerId, at);
    canvas.setPointerCapture?.(e.pointerId);
    canvas.focus?.({ preventScroll: true });
    canvas.style.cursor = 'grabbing';
    startDrag(isViewGesture(e) ? 'view' : 'camera', pointers.size > 1 ? centroid() : at);
  });

  canvas.addEventListener('pointermove', (e) => {
    if (!pointers.has(e.pointerId) || !drag) return;
    const at = canvasPoint(e);
    pointers.set(e.pointerId, at);
    const from = pointers.size > 1 ? centroid() : at;
    const dx = from.x - drag.x;
    const dy = from.y - drag.y;
    if (dx === 0 && dy === 0) return;
    if (drag.mode === 'view') {
      setView(drag.yaw - (dx / at.width) * VIEW_DRAG_DEGREES.yaw, drag.pitch + (dy / at.height) * VIEW_DRAG_DEGREES.pitch);
      return;
    }
    // The dial, readouts and sliders follow the camera while it is dragged,
    // not only once it is dropped.
    editActivePose({
      azimuth: Math.round(clampAzimuth(drag.azimuth + (dx / at.width) * FULL_TURN)),
      elevation: Math.round(clampElevation(drag.elevation - (dy / at.height) * 120)),
    });
  });

  function endDrag(event) {
    if (event) pointers.delete(event.pointerId);
    if (drag?.mode === 'camera' && event && isClick(event)) selectKeyframeAt(event);
    // Lifting one of two fingers ends the orbit; the finger left behind starts nothing new.
    drag = null;
    if (pointers.size === 0) canvas.style.cursor = 'grab';
    refreshControls();
  }

  function isClick(event) {
    const at = canvasPoint(event);
    return Math.hypot(at.x - drag.x, at.y - drag.y) <= CLICK_SLOP_PX;
  }

  // The path dots are the only selectable targets in the scene, so a click
  // that lands on one activates its keyframe instead of ending an orbit drag.
  function selectKeyframeAt(event) {
    const { x, y, width, height } = canvasPoint(event);
    let nearest = -1;
    let nearestDistance = DOT_HIT_RADIUS;
    path.forEach((keyframe, index) => {
      const point = projectPoint(cameraWorldPosition(keyframe), viewer, width, height);
      const distance = Math.hypot(point.x - x, point.y - y);
      if (distance <= nearestDistance) { nearest = index; nearestDistance = distance; }
    });
    if (nearest >= 0) activateKeyframe(nearest);
  }

  canvas.addEventListener('pointerup', (e) => endDrag(e));
  canvas.addEventListener('pointercancel', (e) => endDrag(e));

  canvas.addEventListener('wheel', (e) => {
    if (document.activeElement !== canvas) return;
    e.preventDefault();
    const step = e.deltaY > 0 ? DISTANCE_STEP : -DISTANCE_STEP;
    editActivePose({ distance: round4(clampDistance(activeKeyframe().distance + step)) });
  }, { passive: false });

  // ── Controls ──
  const presetSelect = document.createElement('select');
  presetSelect.setAttribute('data-camera-preset', '');
  presetSelect.title = 'Camera motion preset';
  presetSelect.style.cssText = `${SELECT_STYLE}flex:1;min-width:0;`;
  const placeholder = buildOption('', 'Preset');
  placeholder.disabled = true;
  placeholder.selected = true;
  presetSelect.appendChild(placeholder);
  CAMERA_PRESETS.forEach(preset => presetSelect.appendChild(buildOption(preset.id, preset.label)));
  // The menu keeps the applied preset until a hand edit takes the path over.
  presetSelect.addEventListener('change', () => {
    const preset = CAMERA_PRESETS.find(p => p.id === presetSelect.value);
    // Play the move right away so the choice is understood without a click.
    if (preset) { replacePath(presetCameraPath(preset, moveEndTime())); togglePlay(); }
  });

  const resetBtn = document.createElement('button');
  resetBtn.type = 'button';
  resetBtn.setAttribute('data-camera-reset', '');
  resetBtn.title = 'Reset to the default orbit';
  resetBtn.style.cssText = GHOST_BUTTON_STYLE;
  resetBtn.textContent = 'Reset';
  resetBtn.addEventListener('click', () => { manualEdit(); replacePath(defaultCameraPath()); togglePlay(); });

  const presetRow = document.createElement('div');
  presetRow.style.cssText = 'display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:10px;';
  presetRow.appendChild(presetSelect);
  presetRow.appendChild(resetBtn);

  const timelineTrack = document.createElement('div');
  timelineTrack.setAttribute('data-camera-timeline', '');
  timelineTrack.style.cssText = 'position:relative;height:22px;border-radius:6px;background:hsl(var(--ait-m-foreground) / 0.07);';

  const playheadEl = document.createElement('span');
  playheadEl.style.cssText = 'position:absolute;top:2px;bottom:2px;width:1px;background:hsl(var(--ait-m-primary));left:0;display:none;';
  timelineTrack.appendChild(playheadEl);

  // Pressing the empty track previews the camera at that moment; letting go
  // returns to the active keyframe. Diamonds handle their own presses.
  let scrubbing = false;
  const trackTime = (e) => {
    const rect = timelineTrack.getBoundingClientRect();
    const usable = rect.width - TIMELINE_INSET_PX * 2;
    return usable > 0 ? clamp((e.clientX - rect.left - TIMELINE_INSET_PX) / usable, 0, 1) : 0;
  };
  timelineTrack.addEventListener('pointerdown', (e) => {
    if (e.target.closest?.('[data-keyframe-chip]')) return;
    stopPlay();
    scrubbing = true;
    timelineTrack.setPointerCapture?.(e.pointerId);
    scrubTo(trackTime(e));
  });
  timelineTrack.addEventListener('pointermove', (e) => { if (scrubbing) scrubTo(trackTime(e)); });
  const endScrub = () => {
    if (!scrubbing) return;
    scrubbing = false;
    playheadTime = null;
    previewPose = null;
    renderTimeline();
    draw();
  };
  timelineTrack.addEventListener('pointerup', endScrub);
  timelineTrack.addEventListener('pointercancel', endScrub);

  function scrubTo(time) {
    playheadTime = round4(time);
    previewPose = interpolatePose(path, playheadTime);
    renderTimeline();
    draw();
  }

  const timelineLabels = document.createElement('div');
  timelineLabels.style.cssText = `display:flex;justify-content:space-between;margin-top:2px;${MUTED_TEXT_STYLE}font-variant-numeric:tabular-nums;`;
  const startLabel = document.createElement('span');
  startLabel.textContent = TIMELINE_START_LABEL;
  const timelineEndLabel = document.createElement('span');
  timelineLabels.appendChild(startLabel);
  timelineLabels.appendChild(timelineEndLabel);

  const timelineBlock = document.createElement('div');
  timelineBlock.style.cssText = 'margin-top:12px;';
  timelineBlock.appendChild(timelineTrack);
  timelineBlock.appendChild(timelineLabels);

  const playBtn = document.createElement('button');
  playBtn.type = 'button';
  playBtn.setAttribute('data-camera-play', '');
  playBtn.setAttribute('aria-label', 'Play camera preview');
  playBtn.setAttribute('aria-pressed', 'false');
  playBtn.title = 'Play camera preview';
  playBtn.style.cssText = `${GHOST_BUTTON_STYLE}width:26px;height:26px;padding:0;flex:none;`;
  playBtn.textContent = '▶';
  playBtn.addEventListener('click', () => togglePlay());

  const clockEl = document.createElement('span');
  clockEl.setAttribute('data-camera-clock', '');
  clockEl.style.cssText = `${MUTED_TEXT_STYLE}font-variant-numeric:tabular-nums;flex:none;`;

  const countSelect = document.createElement('select');
  countSelect.setAttribute('data-keyframe-count', '');
  countSelect.style.cssText = SELECT_STYLE;
  for (let n = MIN_KEYFRAMES; n <= maxKeyframes; n++) countSelect.appendChild(buildOption(String(n), String(n)));
  countSelect.addEventListener('change', () => {
    manualEdit();
    replacePath(resamplePath(path, Number(countSelect.value), moveEndTime()));
  });

  const durationSelect = document.createElement('select');
  durationSelect.setAttribute('data-camera-duration', '');
  durationSelect.style.cssText = SELECT_STYLE;
  durationOptions.forEach(seconds => durationSelect.appendChild(buildOption(String(seconds), `${seconds}s`)));
  durationSelect.addEventListener('change', () => {
    // The preview captured the old clip length when it started.
    stopPlay();
    onDurationChange?.(Number(durationSelect.value));
    refreshControls();
  });

  const removeBtn = document.createElement('button');
  removeBtn.type = 'button';
  removeBtn.setAttribute('data-keyframe-remove', '');
  removeBtn.setAttribute('aria-label', 'Remove keyframe');
  removeBtn.title = 'Remove keyframe';
  removeBtn.style.cssText = `${GHOST_BUTTON_STYLE}width:26px;height:26px;padding:0;flex:none;margin-left:auto;`;
  removeBtn.innerHTML = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14"/></svg>';
  removeBtn.addEventListener('click', () => removeKeyframe(activeIndex));

  const transport = document.createElement('div');
  transport.style.cssText = 'display:flex;align-items:center;gap:8px;margin-top:8px;';
  transport.appendChild(playBtn);
  transport.appendChild(clockEl);
  transport.appendChild(removeBtn);
  const settings = document.createElement('div');
  settings.style.cssText = 'display:flex;align-items:center;gap:12px;margin-top:8px;';
  settings.appendChild(labelled('Keyframes', countSelect));
  settings.appendChild(labelled('Duration', durationSelect));
  const toolbar = document.createElement('div');
  toolbar.appendChild(transport);
  toolbar.appendChild(settings);

  const captionEl = document.createElement('p');
  captionEl.setAttribute('data-camera-caption', '');
  captionEl.style.cssText = 'margin-top:8px;font-size:12px;min-height:16px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:hsl(var(--ait-m-primary));';

  // ── Active keyframe: azimuth dial + elevation / distance sliders ──
  const dial = document.createElement('div');
  dial.setAttribute('data-azimuth-dial', '');
  dial.setAttribute('role', 'slider');
  dial.setAttribute('aria-label', 'Azimuth');
  dial.setAttribute('aria-valuemin', String(-AZIMUTH_LIMIT));
  dial.setAttribute('aria-valuemax', String(AZIMUTH_LIMIT));
  dial.tabIndex = 0;
  dial.title = 'Azimuth — drag around the dial or use the arrow keys';
  dial.style.cssText = `position:relative;flex:none;width:${DIAL_RADIUS_PX * 2 + 12}px;height:${DIAL_RADIUS_PX * 2 + 12}px;border-radius:50%;cursor:grab;touch-action:none;border:1px solid hsl(var(--ait-m-foreground) / 0.14);`;
  for (let i = 0; i < DIAL_TICKS; i++) {
    const tick = document.createElement('span');
    tick.style.cssText = `position:absolute;top:50%;left:50%;width:1px;height:4px;margin:-2px 0 0 0;background:hsl(var(--ait-m-foreground) / 0.25);transform:rotate(${(i * FULL_TURN) / DIAL_TICKS}deg) translateY(-${DIAL_RADIUS_PX}px);`;
    dial.appendChild(tick);
  }
  const dialHandle = document.createElement('span');
  dialHandle.style.cssText = 'position:absolute;top:50%;left:50%;width:8px;height:8px;margin:-4px 0 0 -4px;border-radius:50%;background:hsl(var(--ait-m-primary));';
  dial.appendChild(dialHandle);

  const dialValueEl = document.createElement('span');
  dialValueEl.setAttribute('data-azimuth-readout', '');
  dialValueEl.style.cssText = 'font-size:12px;font-weight:600;font-variant-numeric:tabular-nums;';

  const dialViewEl = document.createElement('span');
  dialViewEl.setAttribute('data-azimuth-view', '');
  dialViewEl.style.cssText = `${MUTED_TEXT_STYLE}text-align:center;line-height:1.3;min-height:${DIAL_VIEW_MIN_HEIGHT_PX}px;`;

  const dialCell = document.createElement('div');
  dialCell.style.cssText = 'grid-row:span 2;display:flex;flex-direction:column;align-items:center;gap:4px;width:92px;';
  dialCell.appendChild(dial);
  dialCell.appendChild(dialValueEl);
  dialCell.appendChild(dialViewEl);
  bindDial();

  function setAzimuth(azimuth) {
    editActivePose({ azimuth: Math.round(clampAzimuth(azimuth)) });
  }

  function bindDial() {
    let dragAngle = null;
    const pointerAngle = (e) => {
      const rect = dial.getBoundingClientRect();
      return Math.atan2(e.clientX - (rect.left + rect.width / 2), (rect.top + rect.height / 2) - e.clientY) / DEG;
    };

    dial.addEventListener('pointerdown', (e) => {
      dragAngle = pointerAngle(e);
      dial.setPointerCapture?.(e.pointerId);
    });
    dial.addEventListener('pointermove', (e) => {
      if (dragAngle === null) return;
      const angle = pointerAngle(e);
      // Crossing the top of the dial adds or removes a turn instead of
      // snapping back through zero.
      let delta = angle - dragAngle;
      if (delta > 180) delta -= FULL_TURN;
      if (delta < -180) delta += FULL_TURN;
      dragAngle = angle;
      setAzimuth(activeKeyframe().azimuth + delta);
    });
    const release = () => { dragAngle = null; };
    dial.addEventListener('pointerup', release);
    dial.addEventListener('pointercancel', release);

    dial.addEventListener('keydown', (e) => {
      const step = e.shiftKey ? NUDGE_DEGREES.coarse : NUDGE_DEGREES.fine;
      if (e.key === 'ArrowRight') setAzimuth(activeKeyframe().azimuth + step);
      else if (e.key === 'ArrowLeft') setAzimuth(activeKeyframe().azimuth - step);
      else if (e.key === 'Home') setAzimuth(0);
      else return;
      e.preventDefault();
    });
  }

  function updateDial() {
    const { azimuth } = activeKeyframe();
    dial.setAttribute('aria-valuenow', String(Math.round(azimuth)));
    dial.setAttribute('aria-valuetext', azimuthLabel(azimuth));
    dialHandle.style.transform = `rotate(${azimuth}deg) translateY(-${DIAL_RADIUS_PX}px)`;
    dialValueEl.textContent = `${Math.round(azimuth)}°`;
    dialViewEl.textContent = viewLabel(azimuth);
  }

  const elevationSlider = createSliderField({
    label: 'Elevation', id: 'elevation',
    min: -ELEVATION_LIMIT, max: ELEVATION_LIMIT, step: 1, defaultValue: activeKeyframe().elevation, unit: '°',
  });
  const distanceSlider = createSliderField({
    label: 'Distance', id: 'distance',
    min: DISTANCE_RANGE[0], max: DISTANCE_RANGE[1], step: DISTANCE_SLIDER_STEP, defaultValue: activeKeyframe().distance,
  });
  const sliderValueEl = (slider) => slider.wrap.querySelector('.tabular-nums');
  // A fixed value column keeps the tracks from resizing as "0°" becomes
  // "-90°"; the shared slider prints one decimal, distance needs two.
  [elevationSlider, distanceSlider].forEach(slider => { const valueEl = sliderValueEl(slider); if (valueEl) valueEl.style.minWidth = SLIDER_VALUE_MIN_WIDTH; });
  elevationSlider.input.addEventListener('input', () => editActivePose({ elevation: clampElevation(Number(elevationSlider.input.value)) }));
  distanceSlider.input.addEventListener('input', () => editActivePose({ distance: round4(clampDistance(Number(distanceSlider.input.value))) }));

  function showDistance() {
    const valueEl = sliderValueEl(distanceSlider);
    if (valueEl) valueEl.textContent = activeKeyframe().distance.toFixed(2);
  }

  const controlsWrap = document.createElement('div');
  controlsWrap.style.cssText = CONTROLS_GRID_STYLE;
  controlsWrap.appendChild(dialCell);
  controlsWrap.appendChild(elevationSlider.wrap);
  controlsWrap.appendChild(distanceSlider.wrap);

  wrap.appendChild(presetRow);
  wrap.appendChild(canvasWrap);
  wrap.appendChild(hintEl);
  wrap.appendChild(timelineBlock);
  wrap.appendChild(toolbar);
  wrap.appendChild(captionEl);
  wrap.appendChild(controlsWrap);

  // ── Path editing ──
  // Keyframe 0 opens the clip and the last one anchors its end, so only the
  // middle diamonds move and the path never needs re-ordering.
  const isPinned = (index) => index === 0 || index === path.length - 1;

  function clampedTime(time, index) {
    const current = path[index].time;
    // The allowed range always contains the current time, so a keyframe that
    // already crowds a neighbour can only move away from it, never past it.
    const lower = Math.min(current, (path[index - 1]?.time ?? 0) + KEYFRAME_TIME_GAP);
    const upper = Math.max(current, (path[index + 1]?.time ?? 1) - KEYFRAME_TIME_GAP);
    return round4(clamp(time, lower, upper));
  }

  function moveKeyframe(index, time) {
    if (isPinned(index)) return;
    manualEdit();
    path[index] = { ...path[index], time: clampedTime(time, index) };
    afterChange();
  }

  // Every hand edit leaves the preset behind and takes over from the preview.
  function manualEdit() {
    stopPlay();
    presetSelect.value = '';
  }

  function editActivePose(patch) {
    manualEdit();
    path[activeIndex] = { ...activeKeyframe(), ...patch };
    afterChange();
  }

  function replacePath(next) {
    stopPlay();
    path = next.slice(0, maxKeyframes).map(toKeyframe).sort((a, b) => a.time - b.time);
    activateKeyframe(0);
  }

  function activateKeyframe(index) {
    activeIndex = clamp(index, 0, path.length - 1);
    afterChange();
  }

  function removeKeyframe(index) {
    if (path.length <= MIN_KEYFRAMES) return;
    manualEdit();
    path.splice(index, 1);
    path[0] = { ...path[0], time: 0 };
    activateKeyframe(Math.min(index, path.length - 1));
  }

  // ── Timeline ──
  function renderTimeline() {
    if (playheadTime === null) renderDiamonds();
    renderPlayhead();
  }

  // Diamonds are reused while the count holds so a drag keeps its pointer
  // capture and the focused keyframe survives a keyboard nudge.
  function renderDiamonds() {
    const diamonds = () => Array.from(timelineTrack.querySelectorAll('[data-keyframe-chip]'));
    if (diamonds().length !== path.length) {
      diamonds().forEach(diamond => diamond.remove());
      path.forEach((_, index) => timelineTrack.appendChild(buildDiamond(index)));
    }
    diamonds().forEach((diamond, index) => styleDiamond(diamond, index));
  }

  function renderPlayhead() {
    const duration = durationSeconds();
    const position = playheadTime ?? activeKeyframe().time;
    playheadEl.style.display = playheadTime === null ? 'none' : 'block';
    playheadEl.style.left = timelineLeft(position);
    clockEl.textContent = `${formatClock(position * duration)} / ${formatClock(duration)}`;
    timelineEndLabel.textContent = formatClock(duration);
    captionEl.textContent = playheadTime === null
      ? `Keyframe ${activeIndex + 1} of ${path.length} · ${formatClock(activeKeyframe().time * duration)}`
      : `Previewing ${formatClock(position * duration)}`;
  }

  function buildDiamond(index) {
    const diamond = document.createElement('button');
    diamond.type = 'button';
    diamond.setAttribute('data-keyframe-chip', String(index));
    diamond.style.cssText = DIAMOND_STATIC_STYLE;
    diamond.addEventListener('click', () => activateKeyframe(index));
    diamond.addEventListener('keydown', (e) => onDiamondKey(e, index));
    bindDiamondDrag(diamond, index);
    return diamond;
  }

  function styleDiamond(diamond, index) {
    const keyframe = path[index];
    const active = index === activeIndex;
    const size = active ? 11 : 9;
    // Pinned diamonds still select their keyframe, so they are never "disabled";
    // the label says that only their time is fixed.
    const label = `Keyframe ${index + 1} · ${formatClock(keyframe.time * durationSeconds())}${isPinned(index) ? ' · pinned' : ''}`;
    diamond.setAttribute('aria-label', label);
    diamond.title = label;
    // Only the dynamic properties change here, so a hover scale or an
    // in-flight drag transform survives the re-render.
    Object.assign(diamond.style, {
      left: timelineLeft(keyframe.time),
      width: `${size}px`,
      height: `${size}px`,
      margin: `${-size / 2}px 0 0 ${-size / 2}px`,
      cursor: isPinned(index) ? 'default' : 'grab',
      borderColor: active ? 'hsl(var(--ait-m-primary))' : 'hsl(var(--ait-m-foreground) / 0.35)',
      background: active ? 'hsl(var(--ait-m-primary))' : 'hsl(var(--ait-m-background))',
    });
  }

  function onDiamondKey(event, index) {
    const step = TIME_NUDGE_SECONDS / durationSeconds();
    if (event.key === 'ArrowRight') moveKeyframe(index, path[index].time + step);
    else if (event.key === 'ArrowLeft') moveKeyframe(index, path[index].time - step);
    else if (event.key === 'End') moveKeyframe(index, 1);
    else if (event.key === 'Home') moveKeyframe(index, 0);
    else if (event.key === 'Delete' || event.key === 'Backspace') removeKeyframe(index);
    else return;
    event.preventDefault();
  }

  function bindDiamondDrag(diamond, index) {
    let moving = false;
    diamond.addEventListener('pointerdown', (e) => {
      if (isPinned(index)) return;
      moving = true;
      diamond.setPointerCapture?.(e.pointerId);
    });
    diamond.addEventListener('pointermove', (e) => {
      if (!moving) return;
      const rect = timelineTrack.getBoundingClientRect();
      const usable = rect.width - TIMELINE_INSET_PX * 2;
      if (usable > 0) moveKeyframe(index, (e.clientX - rect.left - TIMELINE_INSET_PX) / usable);
    });
    const release = () => { moving = false; };
    diamond.addEventListener('pointerup', release);
    diamond.addEventListener('pointercancel', release);
    diamond.addEventListener('mouseenter', () => { if (!isPinned(index)) diamond.style.transform = 'rotate(45deg) scale(1.25)'; });
    diamond.addEventListener('mouseleave', () => { diamond.style.transform = 'rotate(45deg)'; });
  }

  function updateControls() {
    const keyframe = activeKeyframe();
    updateDial();
    elevationSlider.setNumber(keyframe.elevation);
    distanceSlider.setNumber(keyframe.distance);
    showDistance();
    countSelect.value = String(path.length);
    const duration = String(durationSeconds());
    if (durationOptions.some(seconds => String(seconds) === duration)) durationSelect.value = duration;
    removeBtn.disabled = path.length <= MIN_KEYFRAMES;
    removeBtn.style.opacity = removeBtn.disabled ? '0.4' : '1';
  }

  // ── Playback ──
  function togglePlay() {
    if (playFrame !== null) { stopPlay(); return; }
    const duration = durationSeconds() * 1000;
    const startedAt = performance.now();
    playBtn.textContent = '■';
    playBtn.setAttribute('aria-pressed', 'true');
    const step = (now) => {
      const progress = Math.min((now - startedAt) / duration, 1);
      playheadTime = progress;
      previewPose = interpolatePose(path, progress);
      renderTimeline();
      draw();
      if (progress >= 1) { stopPlay(); return; }
      playFrame = requestAnimationFrame(step);
    };
    playFrame = requestAnimationFrame(step);
  }

  function stopPlay() {
    if (playFrame === null) return;
    cancelAnimationFrame(playFrame);
    playFrame = null;
    playheadTime = null;
    previewPose = null;
    playBtn.textContent = '▶';
    playBtn.setAttribute('aria-pressed', 'false');
    renderTimeline();
    draw();
  }

  function refreshControls() {
    updateControls();
    renderTimeline();
  }

  function afterChange() {
    updateControls();
    renderTimeline();
    draw();
  }

  // The page owns the clip duration and the reference image; it calls this
  // whenever either changes.
  function refresh() {
    refreshControls();
    loader.load(getReferenceImageUrl() || '');
  }

  refresh();
  requestAnimationFrame(() => { fitCanvasToLayout(); draw(); });
  if (typeof ResizeObserver !== 'undefined') {
    new ResizeObserver(() => { fitCanvasToLayout(); draw(); }).observe(canvasWrap);
  }
  window.matchMedia?.('(prefers-color-scheme: dark)')?.addEventListener('change', () => { applyTheme(); draw(); });
  new MutationObserver(() => { applyTheme(); draw(); }).observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });

  return {
    wrap,
    getValues: () => ({ keyframes: pathValues() }),
    setValues: ({ keyframes } = {}) => {
      if (Array.isArray(keyframes) && keyframes.length > 0) replacePath(keyframes);
    },
    refresh,
  };
}
