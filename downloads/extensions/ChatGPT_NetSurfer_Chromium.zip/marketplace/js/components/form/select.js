/**
 * Custom select/dropdown field component.
 * Renders a styled dropdown with positioned menu, checkmarks, and click-outside dismissal.
 */
import { createChipGroup } from './chip-group.js';
import { shouldPreferSelectForKey, optionLabelsFor, hasAuthoredLabel } from './field-shape.js';
import { updateFormData, createFieldLabel, createHelpToggle } from '../../runner/overrides/ui.js';

export function createSelectField({
  label,
  id,
  required = false,
  help,
  options = [],
  defaultValue,
  rawLabels = false,
} = {}) {
  const wrap = document.createElement('div');
  const fieldKey = id || label || 'select';
  if (id) wrap.setAttribute('data-id', id);
  wrap.setAttribute('data-component', 'select');

  if (label && String(label).trim()) {
    const header = document.createElement('div');
    header.className = 'mb-2';
    const headerRow = document.createElement('div');
    headerRow.className = 'flex items-center';
    const labelEl = createFieldLabel(label, { required });
    labelEl.className = 'block text-[13px] font-medium mx-2';
    headerRow.appendChild(labelEl);
    const { trigger } = createHelpToggle({ idSeed: label, labelText: label, helpText: help });
    if (trigger) {
      wrap.setAttribute('data-help-scope', '');
      headerRow.appendChild(trigger);
    }
    header.appendChild(headerRow);
    wrap.appendChild(header);
  }

  const select = document.createElement('select');
  const selectId = `select-${Math.random().toString(16).slice(2)}`;
  select.id = selectId;
  select.className = 'sr-only';
  if (label) select.setAttribute('aria-label', String(label));
  if (required) select.required = true;

  // Only a bare value gets prettified. Callers that resolved an author label
  // pass rawLabels so their wording survives verbatim.
  const capitalize = s => s ? s.replace(/[_-]/g, ' ').replace(/\b\w/g, c => c.toUpperCase()) : '';
  const normalizedOptions = (Array.isArray(options) ? options : []).map(opt => {
    const text = String(opt?.label ?? opt?.value ?? '');
    return { value: String(opt?.value ?? ''), label: rawLabels ? text : capitalize(text) };
  });

  // Placeholder option for the "no default" case. When the schema doesn't
  // declare a default, we refuse to silently auto-select the first option —
  // that masked required-field validation (any required enum would already
  // pass because the form always shipped a value the user never consciously
  // picked). With this placeholder, getValue() returns '' until the user
  // commits to a choice, and the validator surfaces "Please fill out this
  // field" as expected.
  const desiredDefault = defaultValue != null ? String(defaultValue) : null;
  const hasMatchingDefault = desiredDefault != null && normalizedOptions.some((opt) => opt.value === desiredDefault);
  const showPlaceholder = !hasMatchingDefault;

  if (showPlaceholder) {
    const placeholderEl = document.createElement('option');
    placeholderEl.value = '';
    placeholderEl.textContent = 'Select...';
    placeholderEl.disabled = true;
    placeholderEl.dataset.placeholder = '1';
    select.appendChild(placeholderEl);
  }

  for (const opt of normalizedOptions) {
    const optionEl = document.createElement('option');
    optionEl.value = opt.value;
    optionEl.textContent = opt.label;
    select.appendChild(optionEl);
  }

  if (hasMatchingDefault) {
    select.value = desiredDefault;
  } else {
    // Leave the placeholder selected — select.value is '' which the field
    // wrapper treats as "no choice yet".
    select.value = '';
  }

  const dropdownBtn = document.createElement('button');
  dropdownBtn.type = 'button';
  dropdownBtn.className =
    'w-full flex items-center justify-between rounded-[16px] bg-panel-input ' +
    'border border-panel-border ' +
    'px-4 h-12 cursor-pointer hover:bg-panel-hover transition-colors ' +
    'focus:outline-none focus:border-[#D9D9D9]/40 dark:focus:border-[#D9D9D9]/20';

  const btnContent = document.createElement('div');
  btnContent.className = 'text-left min-w-0 flex-1';

  const btnValue = document.createElement('div');
  const btnValueBaseClass = 'text-[13px] font-semibold truncate';
  const selectedOpt = normalizedOptions.find(o => o.value === select.value);
  const applyBtnValueStyle = (opt) => {
    if (opt) {
      btnValue.className = `${btnValueBaseClass} text-gray-900 dark:text-white`;
      btnValue.textContent = opt.label;
    } else {
      // Muted color for the placeholder state — visually distinct from a real
      // selection so users (and screen readers) can tell the field is still
      // unfilled.
      btnValue.className = `${btnValueBaseClass} text-gray-400 dark:text-gray-500`;
      btnValue.textContent = 'Select...';
    }
  };
  applyBtnValueStyle(selectedOpt);

  btnContent.appendChild(btnValue);

  const chevron = document.createElement('div');
  chevron.className = 'text-gray-500 dark:text-gray-400 shrink-0 ml-2';
  chevron.innerHTML = `
    <svg class="w-4 h-4" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <path d="M2.21999 5.93998C2.21999 5.81332 2.26665 5.68665 2.36665 5.58665C2.55999 5.39332 2.87999 5.39332 3.07332 5.58665L7.41999 9.93332C7.73999 10.2533 8.25999 10.2533 8.57999 9.93332L12.9267 5.58665C13.12 5.39332 13.44 5.39332 13.6333 5.58665C13.8267 5.77998 13.8267 6.09998 13.6333 6.29332L9.28665 10.64C8.94665 10.98 8.48665 11.1733 7.99999 11.1733C7.51332 11.1733 7.05332 10.9867 6.71332 10.64L2.36665 6.29332C2.27332 6.19332 2.21999 6.06665 2.21999 5.93998Z"/>
    </svg>
  `;

  dropdownBtn.appendChild(btnContent);
  dropdownBtn.appendChild(chevron);

  const dropdownMenu = document.createElement('div');
  dropdownMenu.className =
    'hidden fixed z-[9999] rounded-[16px] bg-panel-input ' +
    'border border-[#D9D9D9]/20 dark:border-[#333] shadow-2xl overflow-y-auto max-h-[280px]';

  function positionDropdown() {
    const btnRect = dropdownBtn.getBoundingClientRect();
    const spaceBelow = window.innerHeight - btnRect.bottom;
    const spaceAbove = btnRect.top;
    const menuHeight = Math.min(280, normalizedOptions.length * 48);

    // Set width to match button
    const minWidth = 200;
    const dropdownWidth = Math.max(minWidth, btnRect.width);
    dropdownMenu.style.width = `${dropdownWidth}px`;
    let leftPos = btnRect.left;
    leftPos = Math.min(leftPos, window.innerWidth - dropdownWidth - 8);
    leftPos = Math.max(8, leftPos);
    dropdownMenu.style.left = `${leftPos}px`;

    if (spaceBelow < menuHeight && spaceAbove > spaceBelow) {
      // Open upward
      dropdownMenu.style.bottom = `${window.innerHeight - btnRect.top + 4}px`;
      dropdownMenu.style.top = 'auto';
    } else {
      // Open downward
      dropdownMenu.style.top = `${btnRect.bottom + 4}px`;
      dropdownMenu.style.bottom = 'auto';
    }
  }

  // Long lists get a filter box; typing narrows, it never adds a value.
  const SEARCH_THRESHOLD = 4;
  let searchInput = null;
  if (normalizedOptions.length >= SEARCH_THRESHOLD) {
    const searchWrap = document.createElement('div');
    searchWrap.className = 'sticky top-0 p-2 bg-panel-input border-b border-[#D9D9D9]/15 dark:border-[#333]';
    searchInput = document.createElement('input');
    searchInput.type = 'text';
    searchInput.placeholder = 'Search…';
    searchInput.className =
      'w-full rounded-[10px] bg-panel-hover border border-panel-border px-3 h-9 ' +
      'text-[13px] text-gray-900 dark:text-white placeholder:text-gray-400 ' +
      'focus:outline-none focus:border-[#D9D9D9]/40';
    searchInput.addEventListener('click', (e) => e.stopPropagation());
    searchWrap.appendChild(searchInput);
    dropdownMenu.appendChild(searchWrap);
  }

  const emptyState = document.createElement('div');
  emptyState.className = 'hidden px-4 py-3 text-[13px] text-gray-400 dark:text-gray-500';
  emptyState.textContent = 'No match';

  normalizedOptions.forEach((opt) => {
    const item = document.createElement('button');
    item.type = 'button';
    item.className =
      'w-full flex items-center justify-between px-4 py-3 text-left text-[13px] ' +
      'text-gray-900 dark:text-white hover:bg-panel-hover transition-colors';
    item.dataset.value = opt.value;

    const itemLabel = document.createElement('span');
    itemLabel.textContent = opt.label;

    const itemCheck = document.createElement('span');
    itemCheck.className = opt.value === select.value ? 'text-primary/90' : 'invisible';
    itemCheck.innerHTML = `<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>`;

    item.appendChild(itemLabel);
    item.appendChild(itemCheck);
    dropdownMenu.appendChild(item);

    item.addEventListener('click', () => {
      select.value = opt.value;
      applyBtnValueStyle(opt);
      dropdownMenu.classList.add('hidden');
      if (searchInput) { searchInput.value = ''; applyFilter(''); }
      dropdownMenu.querySelectorAll('button').forEach(btn => {
        const check = btn.querySelector('span:last-child');
        if (check) check.className = btn.dataset.value === opt.value ? 'text-primary/90' : 'invisible';
      });
      select.dispatchEvent(new Event('change', { bubbles: true }));
    });
  });

  dropdownMenu.appendChild(emptyState);

  function applyFilter(term) {
    const q = String(term || '').trim().toLowerCase();
    let visible = 0;
    for (const btn of dropdownMenu.querySelectorAll('button[data-value]')) {
      const opt = normalizedOptions.find(o => o.value === btn.dataset.value);
      const hit = !q
        || (opt?.label || '').toLowerCase().includes(q)
        || String(btn.dataset.value).toLowerCase().includes(q);
      btn.classList.toggle('hidden', !hit);
      if (hit) visible += 1;
    }
    emptyState.classList.toggle('hidden', visible > 0);
  }
  if (searchInput) searchInput.addEventListener('input', () => applyFilter(searchInput.value));

  dropdownBtn.addEventListener('click', () => {
    const wasHidden = dropdownMenu.classList.contains('hidden');
    if (wasHidden) {
      positionDropdown();
      if (searchInput) {
        searchInput.value = '';
        applyFilter('');
        setTimeout(() => searchInput.focus(), 0);
      }
    }
    dropdownMenu.classList.toggle('hidden');
  });

  document.addEventListener('click', (e) => {
    if (!wrap.contains(e.target) && !dropdownMenu.contains(e.target)) {
      dropdownMenu.classList.add('hidden');
    }
  });

  window.addEventListener('scroll', () => {
    if (!dropdownMenu.classList.contains('hidden')) positionDropdown();
  }, true);

  const row = document.createElement('div');
  row.className = 'relative';
  row.appendChild(select);
  row.appendChild(dropdownBtn);
  document.body.appendChild(dropdownMenu);
  wrap.appendChild(row);

  // Sync to global form data (keep empty strings as-is, don't convert to undefined)
  const syncToGlobal = () => updateFormData(fieldKey, select.value);
  select.addEventListener('change', syncToGlobal);
  syncToGlobal(); // Initial sync

  const errorEl = document.createElement('p');
  errorEl.className = 'mt-1 text-[11px] leading-normal text-red-500 dark:text-red-400 hidden';
  errorEl.setAttribute('role', 'alert');
  wrap.appendChild(errorEl);

  function setError(message) {
    if (!message) {
      errorEl.textContent = '';
      errorEl.classList.add('hidden');
      dropdownBtn.style.outline = '';
      return;
    }
    errorEl.textContent = String(message);
    errorEl.classList.remove('hidden');
    dropdownBtn.style.outline = '1.5px solid #f87171';
  }

  function clearError() {
    setError('');
  }

  select.addEventListener('change', clearError);

  return {
    wrap,
    select,
    getValue: () => select.value,
    setValue: (v) => {
      const oldValue = select.value;
      const nextValue = v == null ? '' : String(v);
      select.value = nextValue;
      // Keep the visible button label in sync with the underlying select.
      // Without this, a programmatic reset (setValue(null)) would leave the
      // button showing the previously-chosen label.
      const opt = normalizedOptions.find(o => o.value === select.value);
      applyBtnValueStyle(opt);
      // Refresh the check-mark column on the open menu, if any.
      dropdownMenu.querySelectorAll('button').forEach((btn) => {
        const check = btn.querySelector('span:last-child');
        if (check) check.className = btn.dataset.value === select.value ? 'text-primary/90' : 'invisible';
      });
      if (oldValue !== select.value) {
        select.dispatchEvent(new Event('change', { bubbles: true }));
      }
      syncToGlobal();
    },
    setError,
    clearError,
  };
}

/** Schema property -> node plus the value it contributes. A short list of
 *  non-settings values renders as chips; everything else as a dropdown. */
export function bindEnumField({ key, title, description, propSchema, isRequired, isReadOnly, widgetHint }) {
  const preferSelect = widgetHint === 'select' || shouldPreferSelectForKey(key, title);
  const canUseChips = !preferSelect && propSchema.enum.length > 0 && propSchema.enum.length <= 6;

  const labelFor = optionLabelsFor(propSchema);
  const rawLabels = hasAuthoredLabel(propSchema);
  // Chips never prettified a bare value, and createSelectField prettifies one
  // itself — so only an authored label is resolved here.
  const options = propSchema.enum.map((option, i) => ({
    value: JSON.stringify(option),
    label: rawLabels ? labelFor(option, i) : String(option),
  }));
  const defaultValue = propSchema?.default !== undefined ? JSON.stringify(propSchema.default) : undefined;

  if (canUseChips) {
    const chip = createChipGroup({
      label: title, id: key, required: isRequired, help: description,
      options, defaultValue, layout: 'wrap',
    });
    if (isReadOnly) {
      chip.wrap.classList.add('opacity-75');
      chip.wrap.querySelectorAll('button').forEach((btn) => { btn.disabled = true; });
    }
    return {
      node: chip.wrap,
      fields: [{ key, kind: 'enum', required: isRequired, _getValue: chip.getValue }],
    };
  }

  const field = createSelectField({
    label: title, id: key, required: isRequired, help: description, options, defaultValue, rawLabels,
  });
  if (isReadOnly) {
    field.wrap.classList.add('opacity-75');
    field.select.disabled = true;
  }
  return {
    node: field.wrap,
    fields: [{ key, kind: 'enum', required: isRequired, select: field.select, _getValue: field.getValue }],
  };
}
