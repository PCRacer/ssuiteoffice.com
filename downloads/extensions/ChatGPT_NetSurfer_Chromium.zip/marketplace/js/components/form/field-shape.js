// Schema-shape heuristics shared by the form binders. These read a property and
// say what shape it is; they draw nothing and belong to no single component.

function prettifyValue(value) {
  return value.replace(/[_-]/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
}

/**
 * Per-option data (labels, images, categories, multipliers) as a list indexed
 * like `enum`. Docs published before that carry a value-keyed object: pass
 * `enumValues` to re-key it exactly. Without them it falls back to insertion
 * order, which the engine reorders when every key looks like a number.
 */
export function optionListOf(source, enumValues) {
  if (Array.isArray(source)) return source;
  if (!source || typeof source !== 'object') return [];
  if (Array.isArray(enumValues)) return enumValues.map((v) => source[String(v)] ?? null);
  return Object.values(source);
}

/** True when the author filled in at least one entry. */
export function hasOptionData(source) {
  return optionListOf(source).some((v) => v != null && String(v).trim() !== '');
}

/**
 * What one enum option is called on screen. Values are frequently whole
 * sentences fed to a model, so an author-supplied label always wins and is
 * never reformatted — only a bare value gets prettified.
 */
export function optionLabelsFor(propSchema, entry = {}) {
  const xuap = propSchema?.['x-uap'] && typeof propSchema['x-uap'] === 'object' ? propSchema['x-uap'] : {};
  const enumValues = Array.isArray(propSchema?.enum) ? propSchema.enum : undefined;
  const sources = [xuap.optionLabels, propSchema?.enumLabels, xuap.enumLabels, entry?.enumLabels]
    .map((s) => optionListOf(s, enumValues))
    .filter((a) => a.length);

  return (value, index) => {
    if (index != null) {
      for (const list of sources) {
        const at = list[index];
        if (at != null && String(at).trim()) return String(at);
      }
    }
    return prettifyValue(String(value));
  };
}

/** True when the author named this option, so callers must not restyle it. */
export function hasAuthoredLabel(propSchema, entry = {}) {
  const xuap = propSchema?.['x-uap'] && typeof propSchema['x-uap'] === 'object' ? propSchema['x-uap'] : {};
  return [xuap.optionLabels, propSchema?.enumLabels, xuap.enumLabels, entry?.enumLabels]
    .some(hasOptionData);
}

/** Long text, a prompt, or an explicitly wide field. */
export function isTextArea(propSchema, key) {
  const format = String(propSchema?.format || '').toLowerCase();
  if (format === 'textarea') return true;
  if (typeof propSchema?.maxLength === 'number' && propSchema.maxLength > 200) return true;
  const description = String(propSchema?.description || '');
  if (description.length > 120) return true;
  const k = String(key || '').toLowerCase();
  return /prompt|instruction|system|negative/.test(k);
}

export function normalizeKeyTitleText(key, title) {
  return `${String(key || '')} ${String(title || '')}`.toLowerCase();
}

const MEDIA_PAIR_TOKEN_SETS = [
  ['start', 'end'],
  ['source', 'target'],
  ['before', 'after'],
  ['person', 'garment'],
];

/** Two media fields that read as a pair, so they can share a row. */
export function isPairedMediaRow(aText, bText) {
  if (!aText || !bText) return false;
  for (const [aToken, bToken] of MEDIA_PAIR_TOKEN_SETS) {
    if (aText.includes(aToken) && bText.includes(bToken)) return true;
    if (aText.includes(bToken) && bText.includes(aToken)) return true;
  }
  return false;
}

/** Settings-like enums read better as a dropdown than as chips. */
export function shouldPreferSelectForKey(key, title) {
  const t = normalizeKeyTitleText(key, title);
  return /duration|seconds|resolution|quality|aspect|ratio|width|height|format|image.?size|scale|background|formality|texture|style|preset|color|skin|finish|direction|time|season|gender|age|pose|expression|softness|detail/.test(t);
}

function classifySettingsKey(text) {
  const t = String(text || '').toLowerCase();
  if (/duration|seconds|\bsecs?\b|\btime\b/.test(t)) return 'duration';
  if (/aspect|ratio/.test(t)) return 'aspect';
  if (/resolution|quality|\bsize\b|\b720p\b|\b1080p\b|\b4k\b/.test(t)) return 'resolution';
  if (/\bwidth\b/.test(t)) return 'width';
  if (/\bheight\b/.test(t)) return 'height';
  return null;
}

/** Two settings fields that belong side by side, e.g. width and height. */
export function isPairedSettingsRow(aKeyTitle, bKeyTitle) {
  const a = classifySettingsKey(aKeyTitle);
  const b = classifySettingsKey(bKeyTitle);
  if (!a || !b || a === b) return false;
  const allowedPairs = new Set([
    'duration:resolution',
    'duration:aspect',
    'resolution:aspect',
    'width:height',
  ]);
  const direct = `${a}:${b}`;
  const inverse = `${b}:${a}`;
  return allowedPairs.has(direct) || allowedPairs.has(inverse);
}

export function coerceNumber(value, integer) {
  if (value === '' || value == null) return null;
  const n = integer ? Number.parseInt(String(value), 10) : Number.parseFloat(String(value));
  if (!Number.isFinite(n)) return null;
  return n;
}

export function normalizeMediaKind(value) {
  if (typeof value !== 'string') return null;
  const v = value.trim().toLowerCase();
  if (v === 'image') return 'image';
  if (v === 'video') return 'video';
  if (v === 'audio') return 'audio';
  if (v === 'imageorvideo' || v === 'image_or_video' || v === 'image-video') return 'imageOrVideo';
  if (v === 'audioorvideo' || v === 'audio_or_video' || v === 'audio-video') return 'audioOrVideo';
  return null;
}

