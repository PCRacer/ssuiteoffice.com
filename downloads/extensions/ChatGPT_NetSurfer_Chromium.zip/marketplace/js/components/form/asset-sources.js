// Where the asset picker gets its items. One entry per tab; each source owns
// its own fetch, its filters and whether it accepts uploads. Adding a source
// here is all it takes — the picker and the builder's field editor read this list.
//
//   id / label            tab identity
//   mediaKinds            which input kinds the tab appears for
//   allowUpload           shows an upload card in the grid
//   uploadPrefix          prepended to the uploaded file name
//   allowDelete           per-item delete button
//   filters               sidebar groups, each { id, label, options: [{id,label}] }
//   fetch({mediaKind, filters, cursor}) -> { items, nextCursor }
//                         items: {id,url,thumbUrl,label,kind}
//                         nextCursor: pass back to page; null/absent = last page

const CDN_TYPE_BY_KIND = { image: 'image', video: 'video', audio: 'audio' };

/** The `avatar-` name prefix is how an uploaded avatar is told apart from a
 *  plain upload — the CDN has one folder per account, not one per kind. */
const AVATAR_PREFIX = 'avatar-';
const PRODUCT_PREFIX = 'product-';
const RUN_OUTPUT_NAME = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}_.+_\d+\.[a-z0-9]+$/i;

async function getJson(url) {
  const res = await fetch(url, { credentials: 'same-origin' });
  if (!res.ok) throw new Error(`Request failed (${res.status})`);
  return res.json();
}

function cdnFileToItem(file) {
  const url = String(file?.url || '');
  if (!url) return null;
  // A zero-byte row is a failed or interrupted upload: the URL resolves but
  // serves nothing, so it would render as an empty tile nobody can pick.
  if (Number(file?.size) <= 0) return null;
  return {
    id: String(file?.id || file?.name || url),
    name: String(file?.name || ''),
    url,
    thumbUrl: url,
    label: String(file?.name || '').replace(/^(avatar|product)-/, '').replace(/\.[a-z0-9]+$/i, '').replace(/-[0-9a-f]{8}$/, ''),
    kind: String(file?.type || 'image'),
    size: Number(file?.size) || 0,
    updatedAt: Number(file?.updated_date) || 0,
  };
}

const CDN_PAGE_SIZE = 30;

/** The cursor for CDN sources is just the next page number. */
async function listCdn({ mediaKind, search, cursor, length = CDN_PAGE_SIZE }) {
  const page = Number(cursor) || 1;
  const params = new URLSearchParams();
  params.set('type', CDN_TYPE_BY_KIND[mediaKind] || 'all');
  params.set('page', String(page));
  params.set('length', String(length));
  if (search) params.set('search', search);
  const data = await getJson(`https://aitopia.ai/api/cdn/files?${params}`);
  return {
    items: (Array.isArray(data?.files) ? data.files : []).map(cdnFileToItem).filter(Boolean),
    nextCursor: data?.hasMore ? page + 1 : null,
  };
}

export const ASSET_SOURCES = [
  {
    id: 'uploads',
    label: 'Uploads',
    mediaKinds: ['image', 'video', 'audio'],
    allowUpload: true,
    uploadPrefix: '',
    allowDelete: true,
    filters: [],
    async fetch({ mediaKind, cursor }) {
      const page = await listCdn({ mediaKind, cursor });
      // Avatars, products and run outputs have their own tabs; keep them out of the plain uploads list.
      // This thins the page client-side, so a page can come back short — the
      // picker keeps paging while nextCursor stands, which covers it.
      return {
        items: page.items.filter((it) => !it.name.startsWith(AVATAR_PREFIX) && !it.name.startsWith(PRODUCT_PREFIX) && !RUN_OUTPUT_NAME.test(it.name)),
        nextCursor: page.nextCursor,
      };
    },
  },
  {
    id: 'generations',
    label: 'Generations',
    mediaKinds: ['image', 'video', 'audio'],
    allowUpload: false,
    filters: [],
    async fetch({ mediaKind, cursor }) {
      const params = new URLSearchParams({ kind: mediaKind, limit: '30' });
      if (cursor) params.set('cursor', cursor);
      const data = await getJson(`https://aitopia.ai/api/me/creations?${params}`);
      const items = (Array.isArray(data?.creations) ? data.creations : [])
        .map((c) => {
          const url = String(c?.preview?.url || '');
          if (!url) return null;
          return {
            id: String(c?.runId || url),
            name: '',
            url,
            thumbUrl: url,
            label: String(c?.agentId || ''),
            kind: String(c?.preview?.kind || mediaKind),
            updatedAt: Date.parse(c?.createdAt || '') || 0,
          };
        })
        .filter(Boolean);
      return { items, nextCursor: data?.nextCursor || null };
    },
  },
  {
    id: 'avatars',
    label: 'Avatars',
    mediaKinds: ['image'],
    allowUpload: true,
    uploadPrefix: AVATAR_PREFIX,
    allowDelete: true,
    uploadLabel: 'Create avatar',
    filters: [
      {
        id: 'owner', label: '', style: 'sidebar',
        options: [
          { id: 'all', label: 'All' },
          { id: 'pinned', label: 'Pinned' },
          { id: 'mine', label: 'My avatars' },
        ],
      },
      {
        id: 'gender', label: '', style: 'chips',
        options: [{ id: 'male', label: 'Male' }, { id: 'female', label: 'Female' }],
      },
    ],
    // Curated avatars ship as JSON; the customer's own are CDN files named
    // `avatar-*`. A CDN failure must not hide the curated ones, so it is caught.
    async fetch({ cursor }) {
      let mine = [];
      let nextCursor = null;
      try {
        const page = await listCdn({ mediaKind: 'image', search: AVATAR_PREFIX, cursor });
        mine = page.items
          .filter((it) => it.name.startsWith(AVATAR_PREFIX))
          .map((it) => ({ ...it, owner: 'mine', gender: '' }));
        nextCursor = page.nextCursor;
      } catch { /* the curated list below still renders */ }

      // The customer's own avatars come first, the shipped ones behind them —
      // so the curated file is appended on the LAST page, not the first: pages
      // append as they arrive, and adding it earlier would strand it in the
      // middle once page two loads.
      if (nextCursor) return { items: mine, nextCursor };

      const curated = await getJson('/data/avatars.json').catch(() => null);
      const curatedItems = (Array.isArray(curated?.avatars) ? curated.avatars : []).map((a) => ({
        id: String(a?.id || a?.url || ''),
        name: '',
        url: String(a?.url || ''),
        thumbUrl: String(a?.thumbUrl || a?.url || ''),
        label: String(a?.name || ''),
        kind: 'image',
        gender: String(a?.gender || ''),
        owner: 'all',
        updatedAt: 0,
      })).filter((it) => it.url);

      return { items: [...mine, ...curatedItems], nextCursor: null };
    },
  },
  {
    id: 'products',
    label: 'Products',
    mediaKinds: ['image'],
    allowUpload: true,
    uploadPrefix: PRODUCT_PREFIX,
    allowDelete: true,
    uploadLabel: 'Add product',
    filters: [
      {
        id: 'owner', label: '', style: 'sidebar',
        options: [{ id: 'all', label: 'All' }, { id: 'pinned', label: 'Pinned' }],
      },
    ],
    async fetch({ cursor }) {
      const page = await listCdn({ mediaKind: 'image', search: PRODUCT_PREFIX, cursor });
      return {
        items: page.items.filter((it) => it.name.startsWith(PRODUCT_PREFIX)).map((it) => ({ ...it, owner: 'mine' })),
        nextCursor: page.nextCursor,
      };
    },
  },
];

export function assetSource(id) {
  return ASSET_SOURCES.find((s) => s.id === id) || null;
}

/** Sources that can serve this input kind, in the order an author listed them. */
export function sourcesFor(mediaKind, allowed) {
  const kind = mediaKind || 'image';
  const usable = ASSET_SOURCES.filter((s) => s.mediaKinds.includes(kind));
  if (!Array.isArray(allowed) || !allowed.length) return usable;
  return allowed.map((id) => usable.find((s) => s.id === id)).filter(Boolean);
}
