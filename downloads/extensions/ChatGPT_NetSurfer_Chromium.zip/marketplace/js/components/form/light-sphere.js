/**
 * Light Sphere component
 * The user drags a light around the subject; the field value is a prompt-ready sentence.
 */
import { updateFormData, onAgentFormDataChange } from '../../runner/overrides/ui-core.js';
import { DEG, TWO_PI, appendFieldHeader, appendErrorSlot, createSphereStage, drawCaption, drawSubject, watchFormImage, whileConnected } from './sphere-canvas.js';

const WARM_LIGHT = '255,244,214';

const LIGHT_PRESETS = [
  { label: 'Top', rotation: 0, tilt: 90 },
  { label: 'Front', rotation: 0, tilt: 0 },
  { label: 'Right', rotation: 90, tilt: 0 },
  { label: 'Left', rotation: 270, tilt: 0 },
  { label: 'Back', rotation: 180, tilt: 0 },
  { label: 'Bottom', rotation: 0, tilt: -90 },
];

const LIGHT_SECTORS = [
  'from the front, facing the subject',
  "from the front-right (viewer's right), at about 45 degrees",
  "from the right side (viewer's right)",
  "from behind the subject on the right (viewer's right), as a rim light",
  'from directly behind the subject (backlight / rim light outlining the silhouette)',
  "from behind the subject on the left (viewer's left), as a rim light",
  "from the left side (viewer's left)",
  "from the front-left (viewer's left), at about 45 degrees",
];

export function describeLightAngle(rotation, tilt) {
  if (tilt >= 70) return 'from directly above the subject (overhead top light). Top surfaces such as the head and shoulders catch bright highlights and short shadows fall straight down beneath the subject.';
  if (tilt <= -70) return 'from directly below the subject (under-lighting). Undersides such as the chin catch the light and shadows are cast upward, giving a dramatic under-lit look.';
  const r = ((rotation % 360) + 360) % 360;
  const sector = Math.round(r / 45) % 8;
  const horiz = LIGHT_SECTORS[sector];
  const vert = tilt >= 35 ? 'positioned high above the subject'
    : tilt >= 12 ? 'slightly above eye level'
    : tilt > -12 ? 'at eye level'
    : tilt > -35 ? 'slightly below eye level'
    : 'positioned low below the subject';
  return `${horiz}, ${vert}. ${describeLightEffect(sector * 45, tilt)}.`;
}

function describeLightEffect(rotation, tilt) {
  const x = Math.sin(rotation * DEG);
  const z = Math.cos(rotation * DEG);
  const fall = tilt >= 35 ? 'downward' : tilt <= -35 ? 'upward' : null;
  if (z < -0.4) {
    return 'The subject is backlit: a bright rim of light outlines its edges and silhouette while the side facing the viewer stays noticeably darker';
  }
  if (Math.abs(x) < 0.4) {
    if (tilt <= -35) return 'The subject is lit from below: the undersides of the chin, nose and brows are the brightest areas, the top of the subject is darker, and shadows are cast upward';
    if (tilt >= 35) return 'The subject is lit from above and in front: the top of the head and the shoulders are bright, with soft shadows under the brows, nose and chin';
    return 'The side of the subject facing the viewer is fully lit and shadows fall behind the subject';
  }
  const lit = x > 0 ? "viewer's right" : "viewer's left";
  const dark = x > 0 ? "viewer's left" : "viewer's right";
  return `The ${lit} side of the subject is clearly brighter, the ${dark} side falls into visible shadow, and cast shadows fall toward the ${dark}${fall ? ` and ${fall}` : ''}`;
}

function drawLight(ctx, x, y, dk, alpha, rgb, level) {
  ctx.save();
  ctx.globalAlpha = alpha;
  const radius = 46 * (0.5 + 0.5 * level);
  const halo = ctx.createRadialGradient(x, y, 0, x, y, radius);
  halo.addColorStop(0, `rgba(${rgb},${0.55 * level})`);
  halo.addColorStop(1, `rgba(${rgb},0)`);
  ctx.fillStyle = halo;
  ctx.beginPath();
  ctx.arc(x, y, radius, 0, TWO_PI);
  ctx.fill();
  ctx.fillStyle = `rgb(${rgb})`;
  ctx.strokeStyle = dk ? 'rgba(0,0,0,0.35)' : 'rgba(0,0,0,0.2)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.arc(x, y, 9, 0, TWO_PI);
  ctx.fill();
  ctx.stroke();
  ctx.restore();
}

function shadeImage(ctx, x, y, size, lx, ly, behind, rgb, level) {
  const mx = x + size / 2;
  const my = y + size / 2;
  if (behind) {
    ctx.fillStyle = 'rgba(0,0,0,0.45)';
    ctx.fillRect(x, y, size, size);
    return;
  }
  let dx = lx - mx;
  let dy = ly - my;
  const len = Math.hypot(dx, dy);
  if (len < 4) {
    ctx.fillStyle = `rgba(${rgb},${0.12 * level})`;
    ctx.fillRect(x, y, size, size);
    return;
  }
  dx /= len; dy /= len;
  const half = size / 2;
  const g = ctx.createLinearGradient(mx + dx * half, my + dy * half, mx - dx * half, my - dy * half);
  g.addColorStop(0, `rgba(${rgb},${0.28 * level})`);
  g.addColorStop(0.5, 'rgba(0,0,0,0)');
  g.addColorStop(1, 'rgba(0,0,0,0.5)');
  ctx.fillStyle = g;
  ctx.fillRect(x, y, size, size);
}

export function createLightSphere({ label, id, required = false, help } = {}) {
  const wrap = document.createElement('div');
  const fieldKey = id || 'lightDirection';
  if (id) wrap.setAttribute('data-id', id);
  wrap.setAttribute('data-component', 'light-sphere');
  appendFieldHeader(wrap, { label, required, help });

  const state = { rotation: 45, tilt: 30 };
  let userImg = null;
  const describe = () => describeLightAngle(state.rotation, state.tilt);

  const presetButtons = [];
  const grid = document.createElement('div');
  grid.style.cssText = 'display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin-bottom:10px;';
  for (const preset of LIGHT_PRESETS) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.setAttribute('role', 'radio');
    btn.textContent = preset.label;
    btn.addEventListener('click', () => { state.rotation = preset.rotation; state.tilt = preset.tilt; afterChange(); });
    grid.appendChild(btn);
    presetButtons.push({ btn, preset });
  }
  wrap.appendChild(grid);

  function applyPresetButtons() {
    for (const { btn, preset } of presetButtons) {
      const active = Math.abs(state.tilt) === 90
        ? preset.tilt === state.tilt
        : preset.tilt === state.tilt && preset.rotation === state.rotation;
      btn.setAttribute('aria-checked', active ? 'true' : 'false');
      btn.className = 'h-10 rounded-lg text-[13px] font-medium transition-all text-center ' + (active
        ? 'bg-primary text-primary-foreground shadow-md'
        : 'bg-panel-input text-gray-700 dark:text-gray-300 hover:bg-panel-hover border border-black/5 dark:border-[#232527]');
    }
  }

  const stage = createSphereStage({
    hint: 'Hold and drag to change light direction',
    fullWidth: true,
    tiltMin: -90,
    tiltPerHeight: 180,
    state,
    onChange: () => afterChange(),
    paint(ctx, g) {
      const behind = Math.cos(state.rotation * DEG) * Math.cos(state.tilt * DEG) < -0.05;
      const rgb = lightRgb();
      const level = lightLevel();
      if (behind) drawLight(ctx, g.px, g.py, g.dk, 0.55, rgb, level);
      drawSubject(ctx, g, userImg, 0.775, (c, x, y, size) => shadeImage(c, x, y, size, g.px, g.py, behind, rgb, level));
      if (!behind) drawLight(ctx, g.px, g.py, g.dk, 1, rgb, level);
      const s = state.tilt >= 0 ? '+' : '';
      drawCaption(ctx, g, `${Math.round(state.rotation)}° around · ${s}${Math.round(state.tilt)}° height`);
    },
  });
  wrap.appendChild(stage.el);

  // The light takes the exact color of the form's light color picker.
  function lightRgb() {
    const key = wrap.closest('form')?.querySelector('[data-component="color-picker"]')?.getAttribute('data-id');
    const hex = /^#([0-9a-f]{6})$/i.exec(key ? String(window.agent_form_data?.[key] ?? '') : '');
    if (!hex) return WARM_LIGHT;
    const n = parseInt(hex[1], 16);
    return `${n >> 16},${(n >> 8) & 255},${n & 255}`;
  }
  // …and its strength follows a brightness/intensity slider: 1 at 70%, 0 at the minimum.
  function lightLevel() {
    const slider = wrap.closest('form')?.querySelector('[data-component="slider"][data-id*="bright" i], [data-component="slider"][data-id*="intens" i]');
    const range = slider?.querySelector('input[type="range"]');
    const value = Number(window.agent_form_data?.[slider?.getAttribute('data-id')]);
    if (!range || !Number.isFinite(value)) return 1;
    const min = Number(range.min) || 0;
    const max = Number(range.max) || 100;
    return Math.max(0, (value - min) / (max - min)) / 0.7;
  }
  let offColor;
  const alive = whileConnected(wrap, () => offColor?.());
  offColor = onAgentFormDataChange(() => { if (alive()) stage.draw(); });

  const uploadField = () => {
    const uploads = [...(wrap.closest('form')?.querySelectorAll('[data-component="file-upload"]') || [])];
    const byKey = uploads.find((el) => /^(imageUrl|image_url|image)$/.test(el.closest('[data-id]')?.getAttribute('data-id') || ''));
    return byKey || (uploads.length === 1 ? uploads[0] : null);
  };
  const uploadInput = () => uploadField()?.querySelector('input[type="file"]') || null;

  const uploadBtn = document.createElement('button');
  uploadBtn.type = 'button';
  uploadBtn.hidden = true;
  uploadBtn.setAttribute('aria-label', 'Upload photo');
  uploadBtn.className = 'absolute flex flex-col items-center justify-center gap-1 rounded-xl text-[11px] font-semibold transition-opacity';
  uploadBtn.style.cssText = 'left:50%;top:50%;width:22%;aspect-ratio:1/1;transform:translate(-50%,-50%);color:rgba(255,255,255,0.8);background:rgba(0,0,0,0.25);touch-action:none;';
  uploadBtn.addEventListener('mouseenter', () => { uploadBtn.style.opacity = '1'; });
  uploadBtn.addEventListener('mouseleave', () => { if (userImg) uploadBtn.style.opacity = '0'; });
  // The light sits under this button at Front, so a press here must still drag.
  stage.attachDrag(uploadBtn);
  uploadBtn.addEventListener('click', (e) => { if (e.detail === 0 || !stage.dragMoved()) uploadInput()?.click(); });
  stage.el.appendChild(uploadBtn);

  function syncUploadButton() {
    uploadBtn.innerHTML = userImg
      ? '<span>Replace</span>'
      : '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg><span>Upload</span>';
    uploadBtn.style.opacity = userImg ? '0' : '1';
  }
  syncUploadButton();

  stage.el.addEventListener('dragover', (e) => { if (uploadInput()) e.preventDefault(); });
  stage.el.addEventListener('drop', (e) => {
    const input = uploadInput();
    if (!input || !e.dataTransfer?.files?.length) return;
    e.preventDefault();
    const dt = new DataTransfer();
    dt.items.add(e.dataTransfer.files[0]);
    input.files = dt.files;
    input.dispatchEvent(new Event('change', { bubbles: true }));
  });

  watchFormImage(wrap, (img) => { userImg = img; syncUploadButton(); stage.draw(); });

  function afterChange() {
    updateFormData(fieldKey, describe());
    applyPresetButtons();
    stage.draw();
  }

  const setError = appendErrorSlot(wrap);

  let tries = 0;
  const attachUpload = () => {
    const field = uploadField();
    if (!field) {
      if (++tries < 25) setTimeout(attachUpload, 200);
      return;
    }
    const uploadRow = field.closest('[data-form-body] > *') || field;
    uploadRow.style.display = 'none';
    uploadBtn.hidden = false;
    const rowObs = new MutationObserver(() => {
      if (!wrap.isConnected) { rowObs.disconnect(); return; }
      const failed = [...uploadRow.querySelectorAll('[role="alert"]')].some((el) => el.textContent.trim());
      setError(failed ? 'Please upload a photo' : '');
    });
    rowObs.observe(uploadRow, { subtree: true, childList: true, characterData: true, attributes: true });
  };
  setTimeout(attachUpload, 0);

  updateFormData(fieldKey, describe());
  applyPresetButtons();

  return { wrap, getDescription: describe, disable: () => stage.setDisabled(true) };
}

/** Schema property -> the light sphere; contributes one prompt-ready sentence. */
export function bindLightSphere({ key, title, description, isRequired, isReadOnly }) {
  const picker = createLightSphere({ label: title, id: key, required: isRequired, help: description });
  if (isReadOnly) {
    picker.wrap.classList.add('opacity-75');
    picker.wrap.querySelectorAll('button').forEach(btn => { btn.disabled = true; });
    picker.disable();
  }
  return {
    node: picker.wrap,
    replaces: true,
    fields: [{ key, kind: 'string', required: isRequired, _getValue: picker.getDescription }],
  };
}
