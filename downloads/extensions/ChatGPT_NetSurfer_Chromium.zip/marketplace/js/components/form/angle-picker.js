/**
 * Angle Picker component
 * Manages three form-data fields: horizontalAngle, verticalAngle, zoom.
 */
import { updateFormData, createSliderField } from '../../runner/overrides/ui.js';
import { drawCameraIcon } from './camera-canvas.js';
import { appendFieldHeader, appendErrorSlot, createSphereStage, drawCaption, drawSubject, watchFormImage } from './sphere-canvas.js';

export function createAnglePicker({
  label,
  id,
  required = false,
  help,
  defaultH = 0,
  defaultV = 0,
  defaultZ = 5,
} = {}) {
  const wrap = document.createElement('div');
  if (id) wrap.setAttribute('data-id', id);
  wrap.setAttribute('data-component', 'angle-picker');
  appendFieldHeader(wrap, { label, required, help });

  const num = (v, fb) => { const n = Number(v); return Number.isFinite(n) ? n : fb; };
  const state = { rotation: num(defaultH, 0), tilt: num(defaultV, 0) };
  let zoom = num(defaultZ, 5);
  let userImg = null;

  const syncToGlobal = () => {
    updateFormData('horizontalAngle', state.rotation);
    updateFormData('verticalAngle', state.tilt);
    updateFormData('zoom', zoom);
  };

  const stage = createSphereStage({
    hint: 'Hold and drag to change camera angle',
    tiltMin: -30,
    tiltPerHeight: 120,
    state,
    onChange: () => afterChange(),
    paint(ctx, g) {
      drawSubject(ctx, g, userImg, 0.55 + (zoom / 10) * 0.45);

      ctx.strokeStyle = g.dk ? 'rgba(255,255,255,0.2)' : 'rgba(0,0,0,0.15)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(g.px, g.py);
      ctx.lineTo(g.cx, g.cy);
      ctx.stroke();

      drawCameraIcon(ctx, g.px, g.py, Math.atan2(g.cy - g.py, g.cx - g.px), 1, {
        body: g.dk ? 'rgba(255,255,255,0.6)' : 'rgba(0,0,0,0.5)',
        lens: g.dk ? 'rgba(255,255,255,0.9)' : 'rgba(0,0,0,0.7)',
      });

      const sign = state.tilt >= 0 ? '+' : '';
      drawCaption(ctx, g, `${Math.round(state.rotation)}° rot · ${sign}${Math.round(state.tilt)}° tilt · zoom ${Math.round(zoom)}/10`);
    },
  });
  wrap.appendChild(stage.el);
  watchFormImage(wrap, (img) => { userImg = img; stage.draw(); });

  const slidersWrap = document.createElement('div');
  slidersWrap.className = 'mt-4 space-y-2';

  const rotSlider = createSliderField({
    label: 'Rotation', id: 'horizontalAngle',
    min: 0, max: 360, step: 1, defaultValue: state.rotation, unit: '°',
  });
  const tiltSlider = createSliderField({
    label: 'Tilt', id: 'verticalAngle',
    min: -30, max: 90, step: 1, defaultValue: state.tilt, unit: '°',
  });
  const zoomSlider = createSliderField({
    label: 'Zoom', id: 'zoom',
    min: 0, max: 10, step: 1, defaultValue: zoom,
  });

  rotSlider.input.addEventListener('input', () => {
    state.rotation = Number(rotSlider.input.value);
    afterChange(true);
  });
  tiltSlider.input.addEventListener('input', () => {
    state.tilt = Number(tiltSlider.input.value);
    afterChange(true);
  });
  zoomSlider.input.addEventListener('input', () => {
    zoom = Number(zoomSlider.input.value);
    afterChange(true);
  });

  slidersWrap.appendChild(rotSlider.wrap);
  slidersWrap.appendChild(tiltSlider.wrap);
  slidersWrap.appendChild(zoomSlider.wrap);
  wrap.appendChild(slidersWrap);

  function updateSliders() {
    rotSlider.setNumber(state.rotation);
    tiltSlider.setNumber(state.tilt);
    zoomSlider.setNumber(zoom);
  }

  function afterChange(fromSlider = false) {
    if (!fromSlider) updateSliders();
    syncToGlobal();
    stage.draw();
  }

  syncToGlobal();

  const setError = appendErrorSlot(wrap);

  return {
    wrap,
    getValues: () => ({ horizontalAngle: state.rotation, verticalAngle: state.tilt, zoom }),
    setValues: ({ horizontalAngle, verticalAngle, zoom: z } = {}) => {
      if (horizontalAngle != null) state.rotation = num(horizontalAngle, state.rotation);
      if (verticalAngle != null) state.tilt = num(verticalAngle, state.tilt);
      if (z != null) zoom = num(z, zoom);
      afterChange();
    },
    setError,
    clearError: () => setError(''),
    disable: () => stage.setDisabled(true),
  };
}

/** Schema property -> node plus the form values this component contributes.
 *  It writes four: three numbers the model reads, and a sentence for prompts. */
export function bindAnglePicker({ key, title, description, propSchema, isRequired, isReadOnly }) {
  const picker = createAnglePicker({
    label: title,
    id: key,
    required: isRequired,
    help: description,
    defaultH: propSchema?.default ?? 0,
    defaultV: 0,
    defaultZ: 5,
  });
  if (isReadOnly) {
    picker.wrap.classList.add('opacity-75');
    picker.wrap.querySelectorAll('input').forEach(inp => { inp.disabled = true; });
    picker.disable();
  }
  return {
    node: picker.wrap,
    replaces: true,
    fields: [
      { key: 'horizontalAngle', kind: 'number', required: false, _getNumber: () => picker.getValues().horizontalAngle },
      { key: 'verticalAngle', kind: 'number', required: false, _getNumber: () => picker.getValues().verticalAngle },
      { key: 'zoom', kind: 'number', required: false, _getNumber: () => picker.getValues().zoom },
      { key, kind: 'string', required: false, _getValue: () => {
        const v = picker.getValues();
        return `horizontal ${v.horizontalAngle}°, vertical ${v.verticalAngle}°, zoom ${v.zoom}/10`;
      } },
    ],
  };
}
