/**
 * Lighting Studio component
 * Up to two coloured lights are placed around a sphere; the field's value is a picture of that sphere, which a
 * relight model reads its light from. Mirrors FAL's lighting studio: same scene, same controls, same picture.
 */
import { createSliderField } from './slider.js';
import { drawCameraIcon } from './camera-canvas.js';
import { DEG, TWO_PI, isDark } from './sphere-canvas.js';

const REFERENCE_SIZE = 1024;
const PREVIEW_SIZE = 256;

// FAL's opening rig. Light 2 sits at -65°, where FAL's own example picture has it, so an untouched studio sends
// that picture pixel for pixel.
const DEFAULT_RIG = {
  ambient: 0.08,
  lights: [
    { enabled: true, azimuth: 65, elevation: 25, distance: 3, intensity: 1.5, softness: 0.3, color: '#ffd6a3' },
    { enabled: true, azimuth: -65, elevation: 20, distance: 3, intensity: 1.5, softness: 0.3, color: '#9b66ff' },
  ],
};
const DEFAULT_SELECTED = 1;

const DISTANCE_RANGE = [0.9, 6];
const LIGHT_SLIDERS = [
  { key: 'azimuth', label: 'Azimuth', min: -180, max: 180, step: 1, unit: '°' },
  { key: 'elevation', label: 'Elevation', min: -90, max: 90, step: 1, unit: '°' },
  { key: 'distance', label: 'Distance', min: DISTANCE_RANGE[0], max: DISTANCE_RANGE[1], step: 0.1 },
  { key: 'intensity', label: 'Intensity', min: 0, max: 6, step: 0.05 },
  { key: 'softness', label: 'Softness', min: 0, max: 1, step: 0.01 },
];
const AMBIENT_SLIDER = { key: 'ambient', label: 'Ambient fill', min: 0, max: 1, step: 0.01 };
const GUIDES = [
  { axis: 'azimuth', label: 'Horizontal orbit' },
  { axis: 'elevation', label: 'Vertical orbit' },
  { axis: 'distance', label: 'Distance' },
];
const SNAP = { every: 45, within: 4 };
const AZIMUTH_MARKERS = [-180, -135, -90, -45, 0, 45, 90, 135];
const ELEVATION_MARKERS = [-90, -45, 0, 45, 90];

// ── The picture: a matte unit sphere resting on a floor, seen from the front and slightly above ──
const SPHERE_Y = 1;
const VIEW = { eyeY: 2.6, eyeZ: 6, lookY: -1.6, lookZ: -6, extent: 4.8 };
const ALBEDO = { sphere: 0.55, floor: 0.2 };
const SPOT_CONE_DEGREES = 104.4;
const SOFTNESS_SPREAD_DEGREES = 24;
const SHADOW_BIAS = 0.003;
const GLOSS = { power: 40, strength: 0.12 };
const FALLOFF_REFERENCE = 6;

const clamp = (value, min, max) => Math.min(Math.max(value, min), max);
const round2 = (value) => Math.round(value * 100) / 100;
const srgbToLinear = (c) => (c <= 0.04045 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4);
const toByte = (light) => Math.round(255 * (1 - Math.exp(-Math.max(0, light))) ** (1 / 2.2));

/** Where a light sits: on a sphere of twice its distance around the subject. */
function lightPosition({ azimuth, elevation, distance }) {
  const reach = 2 * distance;
  const flat = Math.cos(elevation * DEG) * reach;
  return [Math.sin(azimuth * DEG) * flat, SPHERE_Y + Math.sin(elevation * DEG) * reach, Math.cos(azimuth * DEG) * flat];
}

function prepareLight(light) {
  const spread = SOFTNESS_SPREAD_DEGREES * light.softness;
  const offsets = spread < 0.1 ? [[0, 0]] : [[0, 0], [-spread, 0], [spread, 0], [0, -spread], [0, spread]];
  const position = lightPosition(light);
  const reach = 2 * light.distance;
  const halfCone = SPOT_CONE_DEGREES / 2 * DEG;
  const hex = parseInt(light.color.slice(1), 16);
  return {
    position,
    // Unit vector from the light to the subject.
    aim: [-position[0] / reach, (SPHERE_Y - position[1]) / reach, -position[2] / reach],
    outer: Math.cos(halfCone),
    inner: Math.cos(0.75 * halfCone),
    color: [hex >> 16, (hex >> 8) & 255, hex & 255].map((c) => srgbToLinear(c / 255)),
    gain: light.intensity / offsets.length,
    samples: offsets.map(([turn, lift]) => lightPosition({
      azimuth: light.azimuth + turn,
      elevation: clamp(light.elevation + lift, -90, 90),
      distance: light.distance,
    })),
  };
}

/** Distance along a unit ray to the subject sphere, or Infinity. */
function sphereHit(ox, oy, oz, dx, dy, dz) {
  const cy = oy - SPHERE_Y;
  const along = ox * dx + cy * dy + oz * dz;
  const inside = along * along - (ox * ox + cy * cy + oz * oz) + 1;
  if (inside < 0) return Infinity;
  const t = -along - Math.sqrt(inside);
  return t > 0.002 ? t : Infinity;
}

/** RGBA pixels (size × size) of the sphere under the rig. */
function renderLightingReference(rig, size) {
  const pixels = new Uint8ClampedArray(size * size * 4);
  const lights = rig.lights.filter((light) => light.enabled).map(prepareLight);
  const viewLength = Math.hypot(VIEW.lookY, VIEW.lookZ);
  const vy = VIEW.lookY / viewLength;
  const vz = VIEW.lookZ / viewLength;
  // The picture plane's "up": the view direction turned a quarter turn.
  const upY = -vz;
  const upZ = vy;

  for (let row = 0; row < size; row++) {
    const v = (0.5 - row / (size - 1)) * VIEW.extent;
    const oy = VIEW.eyeY + upY * v;
    const oz = VIEW.eyeZ + upZ * v;
    for (let col = 0; col < size; col++) {
      const ox = (col / (size - 1) - 0.5) * VIEW.extent;
      const toSphere = sphereHit(ox, oy, oz, 0, vy, vz);
      const toFloor = -oy / vy;
      const onSphere = toSphere < toFloor;
      const t = Math.min(toSphere, toFloor);
      const px = ox;
      const py = oy + vy * t;
      const pz = oz + vz * t;
      let nx = 0, ny = 1, nz = 0;
      if (onSphere) {
        const length = Math.sqrt(px * px + (py - SPHERE_Y) * (py - SPHERE_Y) + pz * pz);
        nx = px / length; ny = (py - SPHERE_Y) / length; nz = pz / length;
      }
      const albedo = onSphere ? ALBEDO.sphere : ALBEDO.floor;
      let r = rig.ambient * albedo, g = r, b = r;

      for (const light of lights) {
        const fx = px - light.position[0], fy = py - light.position[1], fz = pz - light.position[2];
        const fromLight = Math.sqrt(fx * fx + fy * fy + fz * fz);
        const edge = clamp(((fx * light.aim[0] + fy * light.aim[1] + fz * light.aim[2]) / fromLight - light.outer) / (light.inner - light.outer), 0, 1);
        const cone = edge * edge * (3 - 2 * edge);
        if (!cone) continue;
        for (const sample of light.samples) {
          let lx = sample[0] - px, ly = sample[1] - py, lz = sample[2] - pz;
          const away = Math.sqrt(lx * lx + ly * ly + lz * lz);
          lx /= away; ly /= away; lz /= away;
          if (sphereHit(px + nx * SHADOW_BIAS, py + ny * SHADOW_BIAS, pz + nz * SHADOW_BIAS, lx, ly, lz) < away - SHADOW_BIAS) continue;
          const facing = Math.max(0, nx * lx + ny * ly + nz * lz);
          let gloss = 0;
          if (onSphere && facing > 0) {
            const hy = ly - vy, hz = lz - vz;
            const half = Math.sqrt(lx * lx + hy * hy + hz * hz);
            gloss = Math.max(0, (nx * lx + ny * hy + nz * hz) / half) ** GLOSS.power * GLOSS.strength;
          }
          const falloff = (FALLOFF_REFERENCE / Math.max(1, away)) ** 2;
          const amount = (albedo * facing + gloss) * light.gain * cone * falloff;
          r += amount * light.color[0]; g += amount * light.color[1]; b += amount * light.color[2];
        }
      }
      const at = (row * size + col) * 4;
      pixels[at] = toByte(r); pixels[at + 1] = toByte(g); pixels[at + 2] = toByte(b); pixels[at + 3] = 255;
    }
  }
  return pixels;
}

function paintReference(canvas, rig) {
  canvas.getContext('2d').putImageData(new ImageData(renderLightingReference(rig, canvas.width), canvas.width), 0, 0);
}

// ── The stage: the same scene from a fixed diagonal direction, where the lights are dragged ──
// The viewer looks at the sphere from the front-right and above, like FAL's 3D view. FAL's view is twice as
// wide as this form, so here the viewer backs away as a light is pulled out past the default distance: the
// farthest light stays where a default one sits, and no handle leaves the canvas.
const STAGE = { aspectRatio: '4/3', width: 360, height: 270, offset: [12, 8, 12], fovDegrees: 45 };
const STAGE_FORWARD = STAGE.offset.map((c) => -c / Math.hypot(...STAGE.offset));
const STAGE_RIGHT = [-STAGE_FORWARD[2], 0, STAGE_FORWARD[0]].map((c) => c / Math.hypot(STAGE_FORWARD[0], STAGE_FORWARD[2]));
const STAGE_UP = [
  STAGE_RIGHT[1] * STAGE_FORWARD[2] - STAGE_RIGHT[2] * STAGE_FORWARD[1],
  STAGE_RIGHT[2] * STAGE_FORWARD[0] - STAGE_RIGHT[0] * STAGE_FORWARD[2],
  STAGE_RIGHT[0] * STAGE_FORWARD[1] - STAGE_RIGHT[1] * STAGE_FORWARD[0],
];
const SUBJECT = [0, SPHERE_Y, 0];
const GRID = { extent: 10, step: 2 };
// Where the picture is taken from, drawn as a small camera in front of the sphere.
const PICTURE_CAMERA = { position: [0, SPHERE_Y, 8.5], lineEnd: [0, SPHERE_Y, 1.2], iconScale: 1.3 };
const RING_SEGMENTS = 96;
const ARC_SEGMENTS = 64;
const HANDLE = { radius: 7, selectedRadius: 9, hit: 16, arrowAt: 0.65, arrow: 6 };
const MARKER = { radius: 4, hit: 10 };
// A guide seen edge-on barely moves on screen per degree; a drag is never scaled by less than this many pixels.
const MIN_GUIDE_PIXELS = 0.4;
const STAGE_COLORS = {
  dark: { background: '#1a1c1f', line: 'rgba(255,255,255,0.14)', guide: 'rgba(255,255,255,0.3)', sphere: '#3a3d42', label: 'rgba(20,22,25,0.85)', text: 'rgba(255,255,255,0.9)', marker: '#1a1c1f', camera: 'rgba(255,255,255,0.55)' },
  light: { background: '#EAEFF6', line: 'rgba(0,0,0,0.12)', guide: 'rgba(0,0,0,0.28)', sphere: '#b9c0cc', label: 'rgba(255,255,255,0.9)', text: 'rgba(0,0,0,0.8)', marker: '#ffffff', camera: 'rgba(0,0,0,0.45)' },
};

const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];

const SEGMENT_STYLE = 'flex:1 1 0;min-width:0;height:32px;padding:0 10px;border-radius:8px;font-size:12px;font-weight:500;cursor:pointer;white-space:nowrap;display:inline-flex;align-items:center;justify-content:center;gap:6px;';
const SEGMENT_ON_STYLE = 'background:hsl(var(--ait-m-primary));color:hsl(var(--ait-m-primary-foreground));border:1px solid transparent;';
const SEGMENT_OFF_STYLE = 'background:transparent;color:hsl(var(--ait-m-foreground) / 0.8);border:1px solid hsl(var(--ait-m-foreground) / 0.14);';
// Three guide labels of unequal length share a narrow row: each button takes the width its text needs.
const GUIDE_SEGMENT_STYLE = 'flex:1 1 auto;padding:0 6px;';
const ROW_STYLE = 'display:flex;align-items:center;gap:6px;';
const MUTED_TEXT_STYLE = 'font-size:11px;line-height:1.4;color:hsl(var(--ait-m-foreground) / 0.55);';
const PANEL_STYLE = 'display:flex;flex-direction:column;gap:10px;';

function segmentButton(text, onClick) {
  const btn = document.createElement('button');
  btn.type = 'button';
  btn.textContent = text;
  btn.addEventListener('click', onClick);
  return btn;
}

function pressSegment(btn, pressed, extraStyle = '') {
  btn.setAttribute('aria-pressed', pressed ? 'true' : 'false');
  btn.style.cssText = SEGMENT_STYLE + (pressed ? SEGMENT_ON_STYLE : SEGMENT_OFF_STYLE) + extraStyle;
}

/**
 * `uploadPanel` is the form's own image upload for the field; it is shown on the "Upload image" tab, for a
 * picture the user already has. `usesUpload()` tells the form which of the two the field takes.
 */
export function createLightingStudio({ id, uploadPanel } = {}) {
  const wrap = document.createElement('div');
  if (id) wrap.setAttribute('data-id', id);
  wrap.setAttribute('data-component', 'lighting-studio');
  wrap.style.cssText = PANEL_STYLE;

  // ── State ──
  const rig = { ambient: DEFAULT_RIG.ambient, lights: DEFAULT_RIG.lights.map((light) => ({ ...light })) };
  let selected = DEFAULT_SELECTED;
  let axis = 'azimuth';
  let tab = 'studio';
  const selectedLight = () => rig.lights[selected];

  // ── Tabs ──
  const tabRow = document.createElement('div');
  tabRow.style.cssText = ROW_STYLE;
  const tabButtons = [['studio', 'Lighting studio'], ['image', 'Upload image']].map(([value, text]) => ({
    value, btn: segmentButton(text, () => { tab = value; showTab(); }),
  }));
  tabButtons.forEach(({ btn }) => tabRow.appendChild(btn));
  const studioPanel = document.createElement('div');
  studioPanel.style.cssText = PANEL_STYLE;

  function showTab() {
    tabButtons.forEach(({ value, btn }) => pressSegment(btn, value === tab));
    studioPanel.style.display = tab === 'studio' ? 'flex' : 'none';
    uploadPanel.style.display = tab === 'image' ? '' : 'none';
  }

  // ── Light sources and colour ──
  const lightRow = document.createElement('div');
  lightRow.style.cssText = ROW_STYLE;
  const lightButtons = rig.lights.map((_, index) => {
    const btn = segmentButton('', () => {
      rig.lights[index].enabled = true;
      selected = index;
      refresh();
    });
    lightRow.appendChild(btn);
    return btn;
  });
  const removeBtn = segmentButton('×', () => {
    rig.lights[1].enabled = false;
    selected = 0;
    refresh();
  });
  removeBtn.setAttribute('aria-label', 'Remove light 2');
  removeBtn.title = 'Remove light 2';
  removeBtn.style.cssText = `${SEGMENT_STYLE}${SEGMENT_OFF_STYLE}flex:none;width:32px;padding:0;`;
  lightRow.appendChild(removeBtn);

  const colorLabel = document.createElement('label');
  colorLabel.style.cssText = `${ROW_STYLE}justify-content:space-between;font-size:12px;color:hsl(var(--ait-m-foreground) / 0.8);`;
  colorLabel.textContent = 'Color';
  const colorValue = document.createElement('span');
  colorValue.style.cssText = `${ROW_STYLE}gap:8px;`;
  const colorHex = document.createElement('span');
  colorHex.style.cssText = `${MUTED_TEXT_STYLE}font-variant-numeric:tabular-nums;`;
  const colorInput = document.createElement('input');
  colorInput.type = 'color';
  colorInput.setAttribute('aria-label', 'Light color');
  colorInput.style.cssText = 'width:36px;height:24px;padding:0;border:1px solid hsl(var(--ait-m-foreground) / 0.14);border-radius:6px;background:transparent;cursor:pointer;';
  colorInput.addEventListener('input', () => { selectedLight().color = colorInput.value; refresh(); });
  colorValue.appendChild(colorHex);
  colorValue.appendChild(colorInput);
  colorLabel.appendChild(colorValue);

  // ── Guide ──
  const guideRow = document.createElement('div');
  guideRow.style.cssText = ROW_STYLE;
  const guideButtons = GUIDES.map((guide) => {
    const btn = segmentButton(guide.label, () => { axis = guide.axis; refresh(); });
    guideRow.appendChild(btn);
    return { axis: guide.axis, btn };
  });

  // ── Stage ──
  const stageWrap = document.createElement('div');
  stageWrap.style.cssText = `position:relative;aspect-ratio:${STAGE.aspectRatio};width:100%;border-radius:16px;overflow:hidden;user-select:none;`;
  const stage = document.createElement('canvas');
  stage.setAttribute('role', 'img');
  stage.setAttribute('aria-label', 'Light positions around the sphere');
  stage.style.cssText = 'display:block;width:100%;height:100%;touch-action:none;';
  stageWrap.appendChild(stage);
  let stageSize = { width: STAGE.width, height: STAGE.height };
  let hits = { lights: [], markers: [] };

  const hintEl = document.createElement('p');
  hintEl.style.cssText = `${MUTED_TEXT_STYLE}margin:0;`;
  hintEl.textContent = 'Drag a light along the highlighted guide, or click a 45° marker. Lights always point at the sphere; the camera marks where the picture is taken from. This view is approximate.';

  // The backing store follows the element's CSS size and the device pixel ratio, so lines stay crisp.
  function fitStageToLayout() {
    const rect = stage.getBoundingClientRect();
    if (rect.width) stageSize = { width: rect.width, height: rect.height };
    const ratio = window.devicePixelRatio || 1;
    stage.width = Math.round(stageSize.width * ratio);
    stage.height = Math.round(stageSize.height * ratio);
  }

  function projector() {
    const farthest = Math.max(...rig.lights.filter((light) => light.enabled).map((light) => light.distance));
    const back = Math.max(1, farthest / DEFAULT_RIG.lights[0].distance);
    const eye = SUBJECT.map((c, i) => c + STAGE.offset[i] * back);
    const focal = stageSize.height / 2 / Math.tan(STAGE.fovDegrees / 2 * DEG);
    return (point) => {
      const d = [point[0] - eye[0], point[1] - eye[1], point[2] - eye[2]];
      const depth = dot(d, STAGE_FORWARD);
      return {
        x: stageSize.width / 2 + dot(d, STAGE_RIGHT) / depth * focal,
        y: stageSize.height / 2 - dot(d, STAGE_UP) / depth * focal,
        depth,
        scale: focal / depth,
      };
    };
  }

  function guidePoints(light, guide) {
    if (guide === 'azimuth') return Array.from({ length: RING_SEGMENTS + 1 }, (_, i) => lightPosition({ ...light, azimuth: 360 * i / RING_SEGMENTS }));
    if (guide === 'elevation') return Array.from({ length: ARC_SEGMENTS + 1 }, (_, i) => lightPosition({ ...light, elevation: -90 + 180 * i / ARC_SEGMENTS }));
    return DISTANCE_RANGE.map((distance) => lightPosition({ ...light, distance }));
  }

  function drawStage() {
    const ctx = stage.getContext('2d');
    const { width, height } = stageSize;
    const colors = STAGE_COLORS[isDark() ? 'dark' : 'light'];
    const project = projector();
    const centre = project(SUBJECT);
    const light = selectedLight();
    // The backing store's own scale: the device pixel ratio may have changed since it was sized.
    const ratio = stage.width / width;
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    ctx.fillStyle = colors.background;
    ctx.fillRect(0, 0, width, height);

    const line = (from, to) => { ctx.beginPath(); ctx.moveTo(from.x, from.y); ctx.lineTo(to.x, to.y); ctx.stroke(); };

    ctx.strokeStyle = colors.line;
    ctx.lineWidth = 1;
    for (let at = -GRID.extent; at <= GRID.extent; at += GRID.step) {
      line(project([at, 0, -GRID.extent]), project([at, 0, GRID.extent]));
      line(project([-GRID.extent, 0, at]), project([GRID.extent, 0, at]));
    }

    const camera = project(PICTURE_CAMERA.position);
    const cameraLineEnd = project(PICTURE_CAMERA.lineEnd);
    ctx.strokeStyle = colors.camera;
    ctx.setLineDash([3, 3]);
    line(camera, cameraLineEnd);
    ctx.setLineDash([]);
    drawCameraIcon(ctx, camera.x, camera.y, Math.atan2(cameraLineEnd.y - camera.y, cameraLineEnd.x - camera.x), PICTURE_CAMERA.iconScale, { body: colors.camera, lens: colors.background });

    // Guides and lights behind the sphere are drawn before it, the rest after.
    const drawGuides = (behind) => {
      for (const { axis: guide } of GUIDES) {
        const active = guide === axis;
        if (guide === 'distance' && !active) continue;
        const points = guidePoints(light, guide).map(project);
        ctx.strokeStyle = active ? light.color : colors.guide;
        ctx.lineWidth = active ? 2 : 1;
        for (let i = 1; i < points.length; i++) {
          if (((points[i - 1].depth + points[i].depth) / 2 > centre.depth) === behind) line(points[i - 1], points[i]);
        }
      }
    };
    const drawLight = ({ index, at }) => {
      const item = rig.lights[index];
      const isSelected = index === selected;
      ctx.strokeStyle = item.color;
      ctx.fillStyle = item.color;
      ctx.lineWidth = isSelected ? 2 : 1;
      ctx.setLineDash(isSelected ? [] : [4, 3]);
      line(at, centre);
      ctx.setLineDash([]);
      const tip = { x: at.x + (centre.x - at.x) * HANDLE.arrowAt, y: at.y + (centre.y - at.y) * HANDLE.arrowAt };
      const heading = Math.atan2(centre.y - at.y, centre.x - at.x);
      ctx.beginPath();
      for (const turn of [0, 2.5, -2.5]) ctx.lineTo(tip.x + Math.cos(heading + turn) * HANDLE.arrow, tip.y + Math.sin(heading + turn) * HANDLE.arrow);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(at.x, at.y, isSelected ? HANDLE.selectedRadius : HANDLE.radius, 0, TWO_PI);
      ctx.fill();
      ctx.strokeStyle = colors.marker;
      ctx.lineWidth = 1.5;
      ctx.stroke();

      const text = `Light ${index + 1}`;
      ctx.font = '500 11px system-ui, sans-serif';
      const boxWidth = ctx.measureText(text).width + 12;
      const boxX = clamp(at.x - boxWidth / 2, 2, width - boxWidth - 2);
      const boxY = Math.max(2, at.y - HANDLE.selectedRadius - 24);
      ctx.fillStyle = colors.label;
      ctx.beginPath();
      ctx.roundRect(boxX, boxY, boxWidth, 18, 6);
      ctx.fill();
      ctx.fillStyle = colors.text;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(text, boxX + boxWidth / 2, boxY + 9.5);
    };

    const placed = rig.lights
      .map((item, index) => ({ index, enabled: item.enabled, at: project(lightPosition(item)) }))
      .filter((entry) => entry.enabled);
    drawGuides(true);
    placed.filter((entry) => entry.at.depth > centre.depth).forEach(drawLight);

    // The sphere, brightened on the side each light reaches.
    const radius = centre.scale;
    ctx.save();
    ctx.beginPath();
    ctx.arc(centre.x, centre.y, radius, 0, TWO_PI);
    ctx.clip();
    ctx.fillStyle = colors.sphere;
    ctx.fillRect(centre.x - radius, centre.y - radius, radius * 2, radius * 2);
    for (const item of rig.lights) {
      if (!item.enabled) continue;
      const toward = lightPosition(item).map((c, i) => (c - SUBJECT[i]) / (2 * item.distance));
      const litX = centre.x + dot(toward, STAGE_RIGHT) * radius;
      const litY = centre.y - dot(toward, STAGE_UP) * radius;
      const glow = ctx.createRadialGradient(litX, litY, 0, litX, litY, radius * 1.7);
      glow.addColorStop(0, item.color);
      glow.addColorStop(1, 'rgba(0,0,0,0)');
      // A light on the far side of the sphere only reaches its rim.
      ctx.globalAlpha = Math.min(1, item.intensity / DEFAULT_RIG.lights[0].intensity) * (dot(toward, STAGE_FORWARD) < 0.3 ? 0.9 : 0.3);
      ctx.fillStyle = glow;
      ctx.fillRect(centre.x - radius, centre.y - radius, radius * 2, radius * 2);
    }
    ctx.restore();

    drawGuides(false);
    placed.filter((entry) => entry.at.depth <= centre.depth).forEach(drawLight);

    const markers = [];
    // A light straight above or below has no horizontal orbit to mark.
    if (axis !== 'distance' && !(axis === 'azimuth' && Math.abs(light.elevation) >= 89)) {
      for (const value of axis === 'azimuth' ? AZIMUTH_MARKERS : ELEVATION_MARKERS) {
        if (value === light[axis]) continue;
        const at = project(lightPosition({ ...light, [axis]: value }));
        ctx.beginPath();
        ctx.arc(at.x, at.y, MARKER.radius, 0, TWO_PI);
        ctx.fillStyle = colors.marker;
        ctx.fill();
        ctx.strokeStyle = colors.guide;
        ctx.lineWidth = 1;
        ctx.stroke();
        markers.push({ value, x: at.x, y: at.y });
      }
    }
    hits = { lights: placed.map((entry) => ({ index: entry.index, x: entry.at.x, y: entry.at.y })), markers };
  }

  const nearest = (list, x, y, within) => list
    .map((item) => ({ item, away: Math.hypot(item.x - x, item.y - y) }))
    .filter((entry) => entry.away <= within)
    .sort((a, b) => a.away - b.away)[0]?.item;
  const pointerAt = (event) => {
    const rect = stage.getBoundingClientRect();
    return { x: event.clientX - rect.left, y: event.clientY - rect.top };
  };

  // A drag moves the light along the active guide only: the pointer's travel is measured against the direction
  // that guide runs on screen at the light. `drag.light` keeps the unsnapped value, so a snap never holds it.
  let drag = null;
  stage.addEventListener('pointerdown', (event) => {
    if (event.button !== 0) return;
    const { x, y } = pointerAt(event);
    const handle = nearest(hits.lights, x, y, HANDLE.hit);
    if (handle) {
      selected = handle.index;
      drag = { pointerId: event.pointerId, x: event.clientX, y: event.clientY, light: { ...selectedLight() } };
      stage.setPointerCapture?.(event.pointerId);
      event.preventDefault();
      refresh();
      return;
    }
    const marker = nearest(hits.markers, x, y, MARKER.hit);
    if (marker) { selectedLight()[axis] = marker.value; refresh(); }
  });
  stage.addEventListener('pointermove', (event) => {
    if (drag?.pointerId !== event.pointerId) {
      const { x, y } = pointerAt(event);
      stage.style.cursor = nearest(hits.lights, x, y, HANDLE.hit) ? 'grab' : nearest(hits.markers, x, y, MARKER.hit) ? 'pointer' : 'default';
      return;
    }
    const project = projector();
    const here = project(lightPosition(drag.light));
    const ahead = project(lightPosition({ ...drag.light, [axis]: drag.light[axis] + 0.5 }));
    const perUnit = { x: (ahead.x - here.x) * 2, y: (ahead.y - here.y) * 2 };
    const moved = ((event.clientX - drag.x) * perUnit.x + (event.clientY - drag.y) * perUnit.y)
      / Math.max(perUnit.x * perUnit.x + perUnit.y * perUnit.y, MIN_GUIDE_PIXELS ** 2);
    drag.x = event.clientX;
    drag.y = event.clientY;
    const raw = drag.light[axis] + moved;
    if (axis === 'azimuth') drag.light.azimuth = ((raw + 180) % 360 + 360) % 360 - 180;
    else if (axis === 'elevation') drag.light.elevation = clamp(raw, -90, 90);
    else drag.light.distance = clamp(raw, ...DISTANCE_RANGE);

    const value = drag.light[axis];
    const snapped = SNAP.every * Math.round(value / SNAP.every);
    if (axis === 'distance') selectedLight().distance = Math.round(value * 10) / 10;
    else if (Math.abs(value - snapped) <= SNAP.within) selectedLight()[axis] = axis === 'azimuth' && snapped === 180 ? -180 : snapped;
    else selectedLight()[axis] = Math.round(value);
    refresh();
  });
  const endDrag = (event) => { if (drag?.pointerId === event.pointerId) drag = null; };
  for (const type of ['pointerup', 'pointercancel', 'lostpointercapture']) stage.addEventListener(type, endDrag);

  // ── Preview: the picture that is sent ──
  const previewRow = document.createElement('div');
  previewRow.style.cssText = `${ROW_STYLE}gap:12px;`;
  const preview = document.createElement('canvas');
  preview.width = preview.height = PREVIEW_SIZE;
  preview.setAttribute('role', 'img');
  preview.setAttribute('aria-label', 'Lighting reference preview');
  preview.style.cssText = 'width:112px;height:112px;flex:none;border-radius:10px;';
  const previewText = document.createElement('div');
  previewText.style.cssText = MUTED_TEXT_STYLE;
  previewText.innerHTML = `<div style="font-size:12px;font-weight:600;color:hsl(var(--ait-m-foreground) / 0.9);">Lighting reference</div><div>This picture is sent to the model as the target lighting.</div><div>${REFERENCE_SIZE} × ${REFERENCE_SIZE} PNG</div>`;
  previewRow.appendChild(preview);
  previewRow.appendChild(previewText);

  let previewFrame = null;
  function schedulePreview() {
    if (previewFrame !== null) return;
    previewFrame = requestAnimationFrame(() => { previewFrame = null; paintReference(preview, rig); });
  }

  // ── Sliders ──
  const sliderGrid = document.createElement('div');
  sliderGrid.style.cssText = 'display:grid;grid-template-columns:auto minmax(0, 1fr);column-gap:12px;row-gap:8px;align-items:center;';
  const sliders = [...LIGHT_SLIDERS, AMBIENT_SLIDER].map((spec) => {
    const holder = () => (spec === AMBIENT_SLIDER ? rig : selectedLight());
    // No label of its own: six stacked labels would double the height of this narrow form.
    const field = createSliderField({
      id: `${id}-${spec.key}`,
      min: spec.min, max: spec.max, step: spec.step, defaultValue: holder()[spec.key], unit: spec.unit,
    });
    field.input.setAttribute('aria-label', spec.label);
    const name = document.createElement('span');
    name.style.cssText = 'font-size:12px;color:hsl(var(--ait-m-foreground) / 0.8);';
    name.textContent = spec.label;
    const valueEl = field.wrap.querySelector('.tabular-nums');
    valueEl.style.minWidth = '4.5ch';
    const onEdit = () => { holder()[spec.key] = round2(Number(field.input.value)); refresh(); };
    field.input.addEventListener('input', onEdit);
    field.input.addEventListener('change', onEdit);
    sliderGrid.appendChild(name);
    sliderGrid.appendChild(field.wrap);
    return () => {
      field.setNumber(holder()[spec.key]);
      // The shared slider prints one decimal; intensity, softness and ambient fill move in hundredths.
      valueEl.textContent = `${holder()[spec.key]}${spec.unit || ''}`;
    };
  });

  function refresh() {
    lightButtons.forEach((btn, index) => {
      const light = rig.lights[index];
      pressSegment(btn, light.enabled && index === selected);
      btn.setAttribute('aria-label', light.enabled ? `Select light ${index + 1}` : `Add light ${index + 1}`);
      btn.textContent = light.enabled ? `Light ${index + 1}` : `+ Light ${index + 1}`;
      if (!light.enabled) return;
      const swatch = document.createElement('span');
      swatch.style.cssText = `width:8px;height:8px;border-radius:50%;flex:none;background:${light.color};`;
      btn.prepend(swatch);
    });
    removeBtn.style.display = rig.lights[1].enabled ? '' : 'none';
    colorInput.value = selectedLight().color;
    colorHex.textContent = selectedLight().color.toUpperCase();
    guideButtons.forEach((guide) => pressSegment(guide.btn, guide.axis === axis, GUIDE_SEGMENT_STYLE));
    sliders.forEach((show) => show());
    drawStage();
    schedulePreview();
  }

  [lightRow, colorLabel, guideRow, stageWrap, hintEl, previewRow, sliderGrid].forEach((el) => studioPanel.appendChild(el));
  wrap.appendChild(tabRow);
  wrap.appendChild(studioPanel);
  wrap.appendChild(uploadPanel);

  fitStageToLayout();
  refresh();
  // The canvas has no size until it is in the page, and none while its tab is hidden.
  new ResizeObserver(() => { fitStageToLayout(); drawStage(); }).observe(stageWrap);
  new MutationObserver(() => drawStage()).observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });
  // Last, so a studio that fails while it is being built leaves the upload panel visible for the form to use.
  showTab();

  return {
    wrap,
    usesUpload: () => tab === 'image',
    /** The picture for the rig as it stands, as a PNG data URL. */
    getImage() {
      const canvas = document.createElement('canvas');
      canvas.width = canvas.height = REFERENCE_SIZE;
      paintReference(canvas, rig);
      return canvas.toDataURL('image/png');
    },
  };
}
