// Factories for the components embed-runner draws from an enum field. The names
// and rules live in component-meta.js; this file only attaches the browser
// factory to the handful of ids that path can render.
//
// Two things deliberately live elsewhere:
//   - schema-form.js imports each `bind*` directly, so there is no binder map.
//   - The server reads component-meta.js through src/uap/component-registry.ts.
import { createTextInputField } from './text-input.js';
import { createTextAreaField } from './textarea.js';
import { createNumberField } from './number-input.js';
import { createSelectField } from './select.js';
import { createSliderField } from './slider.js';
import { createCheckboxField } from './checkbox.js';
import { createColorPickerField } from './color-picker.js';
import { createChipGroup } from './chip-group.js';
import { createJsonField } from '../../runner/overrides/ui.js';
import { COMPONENT_META } from './component-meta.js';

/** Every factory here takes the same {label,id,required,help,options,defaultValue}
 *  shape, which is what embed-runner's enum branch calls it with. A component
 *  that needs anything else must not appear in this map. */
const ENUM_FACTORIES = {
  select: createSelectField,
  'radio-group': createSelectField,   // rendered as a select, for consistency
  textarea: createTextAreaField,
  input: createTextInputField,
  slider: createSliderField,
  number: createNumberField,
  checkbox: createCheckboxField,
  'color-picker': createColorPickerField,
  'chip-group': createChipGroup,
  'json-input': createJsonField,
};

/** id -> factory. A component with aliases is exposed under the alias embed-runner
 *  actually passes (`json`, not `json-input`), matching the map this replaced. */
export function componentFactories() {
  const out = {};
  for (const [id, factory] of Object.entries(ENUM_FACTORIES)) {
    const aliases = COMPONENT_META.find(m => m.id === id)?.aliases;
    if (aliases?.length) for (const alias of aliases) out[alias] = factory;
    else out[id] = factory;
  }
  return out;
}
