/**
 * Asset picker component.
 *
 * A trigger card opens a modal whose tabs are data sources (uploads,
 * generations, avatars — see asset-sources.js). Picking a tile sets the field
 * to that file's URL. Visual language follows visual-picker.js.
 *
 * Schema shape it consumes (via schema-form.js):
 *   x-uap.ui_component: "asset-picker"
 *   x-uap.assetSources: ["avatars", "uploads"]   // optional, order = tab order
 *   x-uap.defaultSource: "avatars"               // optional, tab open on launch
 *   x-uap.assetKind: "image" | "video" | "audio" // defaults to image
 *   x-uap.triggerLabel: "Choose avatar"
 */
import { sourcesFor } from './asset-sources.js';
import { ensurePickerModalStyles } from './picker-modal-styles.js';
import { uploadFileToServer } from '../../shared/media.js';
import { updateFormData, createFieldLabel, createHelpToggle } from '../../runner/overrides/ui.js';

const VIDEO_EXT = /\.(mp4|webm|mov|m4v|ogv)(\?.*)?$/i;
const PINNED_STORAGE_KEY = 'aitopia:asset-picker:pinned';
const MAX_IMAGE_EDGE = 2048;

function isVideoUrl(url) {
  return typeof url === 'string' && VIDEO_EXT.test(url);
}

/** One observer for the whole grid: a library can hold hundreds of files, and
 *  `loading="lazy"` alone still lets the browser build every node up front. */
const lazyObserver = typeof IntersectionObserver === 'function'
  ? new IntersectionObserver((entries, obs) => {
    for (const entry of entries) {
      if (!entry.isIntersecting) continue;
      obs.unobserve(entry.target);
      entry.target.src = entry.target.dataset.src || '';
      delete entry.target.dataset.src;
    }
  }, { rootMargin: '300px' })
  : null;

function lazySrc(el, url) {
  if (!lazyObserver) { el.src = url; return; }
  el.dataset.src = url;
  lazyObserver.observe(el);
}

/** `onDead` fires when the file cannot be displayed — a CDN row can outlive its
 *  bytes, and a card with nothing in it is worse than no card. */
function makeThumb(url, alt, onDead) {
  if (!url) {
    const ph = document.createElement('div');
    ph.className = 'absolute inset-0 flex items-center justify-center text-xs text-gray-400 dark:text-gray-500';
    ph.textContent = alt || '';
    return ph;
  }
  if (isVideoUrl(url)) {
    const v = document.createElement('video');
    v.muted = true; v.loop = true; v.playsInline = true; v.autoplay = true;
    v.preload = 'none';
    v.className = 'absolute inset-0 w-full h-full object-cover';
    v.onerror = () => { v.remove(); onDead?.(); };
    lazySrc(v, url);
    return v;
  }
  const img = document.createElement('img');
  img.alt = alt || '';
  img.loading = 'lazy';
  img.decoding = 'async';
  img.className = 'absolute inset-0 w-full h-full object-cover';
  img.onerror = () => { img.remove(); onDead?.(); };
  lazySrc(img, url);
  return img;
}

function normalizePage(res) {
  return { items: Array.isArray(res?.items) ? res.items : [], nextCursor: res?.nextCursor || null };
}

// Shared by every picker: the CDN's cold listing is slow, so it is fetched ahead.
const firstPages = new Map();

function firstPageEntry(source, mediaKind, filters, { refresh = false } = {}) {
  const key = `${source.id}|${mediaKind}|${JSON.stringify(filters)}`;
  const cached = firstPages.get(key);
  if (cached && !refresh) return cached;
  const entry = { page: cached?.page || null, promise: null };
  entry.promise = Promise.resolve(source.fetch({ mediaKind, filters, cursor: null })).then((res) => {
    entry.page = normalizePage(res);
    return entry.page;
  });
  entry.promise.catch(() => { if (firstPages.get(key) === entry && !entry.page) firstPages.delete(key); });
  firstPages.set(key, entry);
  return entry;
}

function forgetCachedItem(url) {
  for (const entry of firstPages.values()) {
    if (entry.page) entry.page = { ...entry.page, items: entry.page.items.filter((it) => it.url !== url) };
  }
}

/* ── pinned: a per-browser convenience, so a read must never throw ── */
function readPinned() {
  try {
    const raw = localStorage.getItem(PINNED_STORAGE_KEY);
    const list = raw ? JSON.parse(raw) : [];
    return new Set(Array.isArray(list) ? list : []);
  } catch { return new Set(); }
}

function writePinned(set) {
  try { localStorage.setItem(PINNED_STORAGE_KEY, JSON.stringify([...set])); } catch { /* ignore */ }
}

/** Downscale to MAX_IMAGE_EDGE before upload; anything smaller passes through. */
async function shrinkImage(file) {
  if (!file.type.startsWith('image/') || file.type === 'image/gif') return file;
  let bitmap;
  try { bitmap = await createImageBitmap(file); } catch { return file; }
  const { width, height } = bitmap;
  const scale = Math.min(1, MAX_IMAGE_EDGE / Math.max(width, height));
  if (scale >= 1) { bitmap.close?.(); return file; }

  const canvas = document.createElement('canvas');
  canvas.width = Math.round(width * scale);
  canvas.height = Math.round(height * scale);
  canvas.getContext('2d').drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  bitmap.close?.();

  const type = file.type === 'image/png' ? 'image/png' : 'image/jpeg';
  const blob = await new Promise((resolve) => canvas.toBlob(resolve, type, 0.92));
  if (!blob) return file;
  const name = file.name.replace(/\.[^.]+$/, '') + (type === 'image/png' ? '.png' : '.jpg');
  return new File([blob], name, { type });
}

export function createAssetPickerField({
  label,
  id,
  required = false,
  help,
  sources = [],
  defaultSource = '',
  mediaKind = 'image',
  defaultValue,
  triggerLabel = 'Choose asset',
  persist = true,
  onChange,
} = {}) {
  const wrap = document.createElement('div');
  const fieldKey = id || label || 'assetPicker';
  if (id) wrap.setAttribute('data-id', id);
  wrap.setAttribute('data-component', 'asset-picker');

  const activeSources = sourcesFor(mediaKind, sources);
  const openingSource = activeSources.find((s) => s.id === defaultSource) || activeSources[0] || null;
  let selectedUrl = typeof defaultValue === 'string' ? defaultValue : '';
  const commit = (url) => {
    if (persist) updateFormData(fieldKey, url);
    onChange?.(url);
  };

  /* ── header ── */
  if (label) {
    const header = document.createElement('div');
    header.className = 'mb-2';
    const headerRow = document.createElement('div');
    headerRow.className = 'flex items-center';
    const labelEl = createFieldLabel(label, { required });
    labelEl.className = 'block text-[13px] font-medium';
    headerRow.appendChild(labelEl);
    const { trigger: helpTrigger } = createHelpToggle({ idSeed: label, labelText: label, helpText: help });
    if (helpTrigger) {
      wrap.setAttribute('data-help-scope', '');
      headerRow.appendChild(helpTrigger);
    }
    header.appendChild(headerRow);
    wrap.appendChild(header);
  }

  /* ── trigger card ── */
  const trigger = document.createElement('button');
  trigger.type = 'button';
  trigger.className = [
    'group relative inline-flex items-center gap-3',
    'rounded-2xl border border-black/10 dark:border-white/[0.08]',
    'bg-white dark:bg-neutral-900 p-1.5 pr-3 text-left',
    'hover:border-purple-300 dark:hover:border-purple-700/60',
    'transition-colors focus:outline-none focus:ring-2 focus:ring-primary/60',
  ].join(' ');
  trigger.setAttribute('aria-haspopup', 'dialog');
  trigger.setAttribute('aria-expanded', 'false');
  trigger.setAttribute('data-trigger', '');

  const triggerThumb = document.createElement('div');
  triggerThumb.className = 'relative w-12 h-12 rounded-xl overflow-hidden bg-black/5 dark:bg-white/5 flex-shrink-0 flex items-center justify-center';
  const triggerLabelEl = document.createElement('span');
  triggerLabelEl.className = 'text-[13px] font-medium text-gray-800 dark:text-gray-200 whitespace-nowrap';
  trigger.appendChild(triggerThumb);
  trigger.appendChild(triggerLabelEl);

  // Buttons can't nest, so the clear button sits beside the trigger.
  const triggerBox = document.createElement('div');
  triggerBox.className = 'relative inline-flex max-w-full';
  triggerBox.setAttribute('data-asset-trigger-box', '');
  const clearBtn = document.createElement('button');
  clearBtn.type = 'button';
  clearBtn.className =
    'hidden absolute top-2 right-2 w-7 h-7 rounded-full bg-neutral-800/70 hover:bg-neutral-800/90 ' +
    'backdrop-blur flex items-center justify-center transition-colors z-10';
  clearBtn.setAttribute('data-asset-clear', '');
  clearBtn.setAttribute('aria-label', 'Remove file');
  clearBtn.innerHTML = '<svg class="w-4 h-4 text-white" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg>';
  clearBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    selectedUrl = '';
    commit('');
    refreshTrigger();
    clearError();
  });
  triggerBox.appendChild(trigger);
  triggerBox.appendChild(clearBtn);
  wrap.appendChild(triggerBox);

  const errorEl = document.createElement('p');
  errorEl.className = 'mt-1 text-[11px] leading-normal text-red-500 dark:text-red-400 hidden';
  errorEl.setAttribute('role', 'alert');
  wrap.appendChild(errorEl);

  const PLUS_ICON = '<svg class="w-5 h-5 text-gray-500 dark:text-gray-400" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 5v14M5 12h14"/></svg>';

  function refreshTrigger() {
    triggerThumb.innerHTML = '';
    trigger.toggleAttribute('data-filled', !!selectedUrl);
    clearBtn.classList.toggle('hidden', !selectedUrl);
    if (!selectedUrl) {
      triggerThumb.innerHTML = PLUS_ICON;
      triggerLabelEl.textContent = triggerLabel;
      return;
    }
    triggerThumb.appendChild(makeThumb(selectedUrl, ''));
    triggerLabelEl.textContent = 'Change';
  }

  /* ── modal shell ── */
  ensurePickerModalStyles();
  const overlay = document.createElement('div');
  overlay.className = 'avp-overlay';
  overlay.setAttribute('role', 'dialog');
  overlay.setAttribute('aria-modal', 'true');
  overlay.setAttribute('aria-label', label ? `Choose ${label}` : (triggerLabel || 'Choose file'));

  const dialog = document.createElement('div');
  dialog.className = 'avp-dialog';

  const head = document.createElement('div');
  head.className = 'avp-head';
  const tabs = document.createElement('div');
  tabs.className = 'avp-tabs';
  tabs.setAttribute('role', 'tablist');
  const dialogClose = document.createElement('button');
  dialogClose.type = 'button';
  dialogClose.setAttribute('aria-label', 'Close');
  dialogClose.className = 'avp-close';
  dialogClose.innerHTML = '<svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg>';
  head.appendChild(tabs);
  head.appendChild(dialogClose);
  dialog.appendChild(head);

  const body = document.createElement('div');
  body.className = 'avp-body';
  const side = document.createElement('nav');
  side.className = 'avp-side';
  side.setAttribute('aria-label', 'Filters');
  const main = document.createElement('div');
  main.className = 'avp-main';
  const mainHead = document.createElement('div');
  mainHead.className = 'avp-main-head';
  const toolbarTitle = document.createElement('h4');
  toolbarTitle.className = 'avp-main-title';
  const chipsRow = document.createElement('div');
  chipsRow.className = 'avp-seg';
  mainHead.appendChild(toolbarTitle);
  mainHead.appendChild(chipsRow);
  main.appendChild(mainHead);
  const gridScroll = document.createElement('div');
  gridScroll.className = 'avp-scroll';
  const grid = document.createElement('div');
  grid.className = 'avp-grid avp-grid--5';
  grid.setAttribute('role', 'listbox');
  gridScroll.appendChild(grid);
  main.appendChild(gridScroll);
  body.appendChild(side);
  body.appendChild(main);
  dialog.appendChild(body);
  overlay.appendChild(dialog);

  let activeSource = openingSource;
  const tabButtons = [];
  for (const source of activeSources) {
    const tab = document.createElement('button');
    tab.type = 'button';
    tab.className = 'avp-tab';
    tab.setAttribute('role', 'tab');
    tab.textContent = source.label;
    tab.addEventListener('click', () => selectSource(source));
    tabButtons.push({ source, btn: tab });
    tabs.appendChild(tab);
  }

  /* ── per-source state ── */
  const fileInput = document.createElement('input');
  fileInput.type = 'file';
  fileInput.accept = mediaKind === 'video' ? 'video/*' : mediaKind === 'audio' ? 'audio/*' : 'image/*';
  fileInput.className = 'hidden';
  wrap.appendChild(fileInput);

  let items = [];
  let pinned = readPinned();
  let filterState = {};
  let loading = false;
  let loadingPage = false;
  let nextCursor = null;
  // Guards against a slow first page landing after the user switched tabs.
  let loadToken = 0;
  let pagedFurther = false;

  const pageObserver = typeof IntersectionObserver === 'function'
    ? new IntersectionObserver((entries) => {
      if (entries.some((e) => e.isIntersecting)) loadNextPage();
    }, { root: gridScroll, rootMargin: '400px' })
    : null;

  /** Sidebar filters become rows; chip filters become the segmented control, with "All" first. */
  function renderFilters() {
    side.innerHTML = '';
    chipsRow.innerHTML = '';
    if (!activeSource) return;
    for (const group of activeSource.filters || []) {
      if (group.style === 'chips') {
        const seg = (text, value) => {
          const b = document.createElement('button');
          b.type = 'button';
          const active = (filterState[group.id] || '') === value;
          b.className = 'avp-seg-btn' + (active ? ' is-active' : '');
          b.textContent = text;
          b.addEventListener('click', () => {
            filterState[group.id] = value;
            renderFilters();
            renderGrid();
          });
          chipsRow.appendChild(b);
        };
        seg('All', '');
        for (const option of group.options) seg(option.label, option.id);
        continue;
      }
      for (const option of group.options) {
        const b = document.createElement('button');
        b.type = 'button';
        b.className = 'avp-cat' + (filterState[group.id] === option.id ? ' is-active' : '');
        b.textContent = option.label;
        b.addEventListener('click', () => {
          filterState[group.id] = option.id;
          renderFilters();
          renderGrid();
        });
        side.appendChild(b);
      }
    }
    side.hidden = !side.children.length;
    chipsRow.hidden = !chipsRow.children.length;
  }

  function visibleItems() {
    return items.filter((item) => {
      for (const [groupId, value] of Object.entries(filterState)) {
        if (!value || value === 'all') continue;
        if (groupId === 'owner') {
          if (value === 'pinned' && !pinned.has(item.url)) return false;
          if (value === 'mine' && item.owner !== 'mine') return false;
          continue;
        }
        if (String(item[groupId] || '') !== value) return false;
      }
      return true;
    });
  }

  function selectItem(url, { close = true } = {}) {
    selectedUrl = url;
    commit(selectedUrl);
    refreshTrigger();
    clearError();
    for (const t of grid.querySelectorAll('.avp-thumb[role="option"]')) {
      t.setAttribute('aria-selected', t.closest('.avp-card')?.dataset.url === url ? 'true' : 'false');
    }
    if (close) closeModal({ delay: 240 });
  }

  let pendingUpload = null;

  function setPending(file, source) {
    clearPending();
    const isImage = /^image\//.test(file.type || '');
    pendingUpload = {
      sourceId: source?.id,
      name: file.name || 'Upload',
      preview: isImage ? URL.createObjectURL(file) : '',
      error: '',
    };
  }
  function clearPending() {
    if (pendingUpload?.preview) URL.revokeObjectURL(pendingUpload.preview);
    pendingUpload = null;
  }

  function makePendingCard() {
    const card = document.createElement('div');
    card.className = 'avp-card avp-card--pending';
    const thumb = document.createElement('div');
    thumb.className = 'avp-thumb';
    if (pendingUpload.preview) {
      const img = document.createElement('img');
      img.alt = '';
      img.src = pendingUpload.preview;
      img.className = 'absolute inset-0 w-full h-full object-cover';
      thumb.appendChild(img);
    }
    const veil = document.createElement('div');
    veil.className = 'avp-pending' + (pendingUpload.error ? ' is-error' : '');
    if (pendingUpload.error) {
      veil.innerHTML = '<span class="avp-pending-error"></span><button type="button" class="avp-pending-dismiss">Dismiss</button>';
      veil.querySelector('.avp-pending-error').textContent = pendingUpload.error;
      veil.querySelector('.avp-pending-dismiss').addEventListener('click', () => { clearPending(); renderGrid(); });
    } else {
      veil.innerHTML = '<span class="avp-spinner" aria-hidden="true"></span><span class="avp-pending-label">Uploading…</span>';
    }
    thumb.appendChild(veil);
    const cap = document.createElement('div');
    cap.className = 'avp-cap';
    cap.textContent = pendingUpload.name;
    card.appendChild(thumb);
    card.appendChild(cap);
    return card;
  }

  // The CDN listing can lag behind an upload, so a reload keeps these.
  const recentUploads = new Map();

  function addUploadedItem(url, source = activeSource) {
    let name = url.split(/[?#]/)[0].split('/').pop() || '';
    try { name = decodeURIComponent(name); } catch { /* keep raw */ }
    const item = {
      id: name || url, name, url, thumbUrl: url, owner: 'mine',
      label: name.replace(/^(avatar|product)-/, '').replace(/\.[a-z0-9]+$/i, '').replace(/-[0-9a-f]{8}$/, ''),
    };
    const recent = recentUploads.get(source?.id) || [];
    recentUploads.set(source?.id, [item, ...recent.filter((it) => it.url !== url)]);
    if (activeSource === source) items = [item, ...items.filter((it) => it.url !== url)];
  }

  const PLUS_CIRCLE = '<span class="avp-plus-circle"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg></span>';

  function makeUploadCard() {
    const text = activeSource.uploadLabel || 'Upload';
    const card = document.createElement('button');
    card.type = 'button';
    card.className = 'avp-card';
    const thumb = document.createElement('div');
    thumb.className = 'avp-thumb avp-thumb--upload';
    thumb.innerHTML = `${PLUS_CIRCLE}<span>${text}</span>`;
    const cap = document.createElement('div');
    cap.className = 'avp-cap';
    cap.textContent = text;
    card.appendChild(thumb);
    card.appendChild(cap);
    // Avatars are named first; plain uploads open the file dialog.
    card.addEventListener('click', () => (activeSource.id === 'avatars' ? openCreate() : fileInput.click()));
    return card;
  }

  function makeCard(item) {
    const card = document.createElement('div');
    card.className = 'avp-card';
    card.dataset.url = item.url;
    const selected = item.url === selectedUrl;

    const pick = document.createElement('button');
    pick.type = 'button';
    pick.className = 'avp-thumb';
    pick.setAttribute('role', 'option');
    pick.setAttribute('aria-selected', selected ? 'true' : 'false');
    pick.appendChild(makeThumb(item.thumbUrl || item.url, item.label, () => {
      // Drop it from the backing list too, so a re-render does not bring it back.
      items = items.filter((it) => it.url !== item.url);
      card.remove();
    }));
    pick.addEventListener('click', () => {
      if (selectedUrl && selectedUrl === item.url) {
        selectedUrl = '';
        commit('');
        refreshTrigger();
        pick.setAttribute('aria-selected', 'false');
        return;
      }
      selectItem(item.url);
    });
    card.appendChild(pick);

    const caption = document.createElement('div');
    caption.className = 'avp-cap';
    caption.textContent = item.label || ' ';
    if (item.label) caption.title = item.label;
    card.appendChild(caption);

    const actions = document.createElement('div');
    actions.className = 'avp-actions';

    const pinBtn = document.createElement('button');
    pinBtn.type = 'button';
    pinBtn.setAttribute('aria-label', pinned.has(item.url) ? 'Unpin' : 'Pin');
    pinBtn.className = 'avp-action';
    pinBtn.textContent = pinned.has(item.url) ? '★' : '☆';
    pinBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      if (pinned.has(item.url)) pinned.delete(item.url); else pinned.add(item.url);
      writePinned(pinned);
      renderGrid();
    });
    actions.appendChild(pinBtn);

    if (activeSource?.allowDelete && item.name) {
      const del = document.createElement('button');
      del.type = 'button';
      del.setAttribute('aria-label', 'Delete');
      del.className = 'avp-action avp-action--danger';
      del.innerHTML = '<svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M6 7h12M9 7V5h6v2m-7 0v12h8V7"/></svg>';
      del.addEventListener('click', async (e) => {
        e.stopPropagation();
        if (!(await askConfirm(item))) return;
        try {
          const res = await fetch(`https://aitopia.ai/api/cdn/files/${encodeURIComponent(item.name)}`, { method: 'DELETE' });
          if (!res.ok) throw new Error(`Delete failed (${res.status})`);
          items = items.filter((it) => it.url !== item.url);
          for (const [id, list] of recentUploads) recentUploads.set(id, list.filter((it) => it.url !== item.url));
          forgetCachedItem(item.url);
          if (item.url === selectedUrl) {
            selectedUrl = '';
            commit('');
            refreshTrigger();
          }
          renderGrid();
        } catch (err) {
          showGridMessage(err.message || 'Delete failed');
        }
      });
      actions.appendChild(del);
    }
    card.appendChild(actions);
    return card;
  }

  function makeSkeletonCard() {
    const card = document.createElement('div');
    card.className = 'avp-card avp-skeleton';
    card.setAttribute('aria-hidden', 'true');
    card.innerHTML = '<div class="avp-thumb"></div><div class="avp-skeleton-cap"></div>';
    return card;
  }

  function gridMessage(text) {
    const msg = document.createElement('p');
    msg.className = 'avp-msg';
    msg.textContent = text;
    return msg;
  }

  function showGridMessage(text) {
    grid.innerHTML = '';
    grid.appendChild(gridMessage(text));
  }

  function renderGrid() {
    // A re-render drops the old cards; stop watching them or the observer keeps
    // every card a filter ever produced.
    for (const el of grid.querySelectorAll('[data-src]')) lazyObserver?.unobserve(el);
    grid.innerHTML = '';
    if (activeSource?.allowUpload) grid.appendChild(makeUploadCard());
    if (pendingUpload && pendingUpload.sourceId === activeSource?.id) grid.appendChild(makePendingCard());
    if (loading) {
      for (let i = 0; i < 7; i++) grid.appendChild(makeSkeletonCard());
      return;
    }
    const visible = visibleItems();
    if (!visible.length && !activeSource?.allowUpload && !nextCursor) {
      showGridMessage('Nothing here yet.');
      return;
    }
    for (const item of visible) grid.appendChild(makeCard(item));
    mountSentinel();
  }

  /** Watches the end of the grid; seeing it means the user scrolled far enough
   *  that the next page should already be on its way. */
  function mountSentinel() {
    pageObserver?.disconnect();
    if (!nextCursor) return;
    const sentinel = gridMessage('Loading more…');
    grid.appendChild(sentinel);
    // No observer means no scroll trigger: fetching here instead would chain
    // renderGrid -> mountSentinel -> fetch and pull every page at once.
    if (!pageObserver) {
      sentinel.textContent = '';
      return;
    }
    pageObserver.observe(sentinel);
  }

  async function fetchPage(cursor) {
    return normalizePage(await activeSource.fetch({ mediaKind, filters: filterState, cursor }));
  }

  function showFirstPage(page) {
    const recent = (recentUploads.get(activeSource?.id) || []).filter((r) => !page.items.some((it) => it.url === r.url));
    items = [...recent, ...page.items];
    nextCursor = page.nextCursor;
    loading = false;
    renderGrid();
  }

  async function loadActiveSource() {
    if (!activeSource) return;
    const token = ++loadToken;
    loadingPage = false;
    pagedFurther = false;
    const cached = firstPageEntry(activeSource, mediaKind, filterState);
    const shown = cached.page;
    if (shown) {
      showFirstPage(shown);
    } else {
      loading = true;
      items = [];
      nextCursor = null;
      renderGrid();
    }
    try {
      const entry = shown ? firstPageEntry(activeSource, mediaKind, filterState, { refresh: true }) : cached;
      const page = await entry.promise;
      if (token !== loadToken) return;   // a newer tab won the race
      const unchanged = shown && page.items.map((it) => it.url).join() === shown.items.map((it) => it.url).join();
      if (unchanged || pagedFurther) return;
      showFirstPage(page);
    } catch (err) {
      if (token !== loadToken || shown) return;   // a stale list beats an error
      items = [];
      loading = false;
      renderGrid();
      showGridMessage(err.message || 'Could not load.');
    }
  }

  async function loadNextPage() {
    if (loadingPage || !nextCursor || !activeSource) return;
    loadingPage = true;
    pagedFurther = true;
    const token = loadToken;
    try {
      const page = await fetchPage(nextCursor);
      if (token !== loadToken) { loadingPage = false; return; }
      // The same run can arrive twice across pages; keep the first copy.
      const seen = new Set(items.map((it) => it.url));
      items = [...items, ...page.items.filter((it) => !seen.has(it.url))];
      nextCursor = page.nextCursor;
      // Cleared before the re-render: the fresh sentinel can fire immediately
      // when the page did not fill the viewport, and must not be turned away.
      loadingPage = false;
      renderGrid();
    } catch {
      // Stop paging rather than loop on a failing cursor.
      nextCursor = null;
      loadingPage = false;
      renderGrid();
    }
  }

  // The sidebar group always starts on its first option; chips start cleared.
  function defaultFilters(source) {
    const filters = {};
    for (const group of source.filters || []) {
      if (group.style !== 'chips') filters[group.id] = group.options[0]?.id || '';
    }
    return filters;
  }

  function selectSource(source) {
    activeSource = source;
    closeCreate();
    if (pendingUpload?.error) clearPending();
    filterState = defaultFilters(source);
    for (const t of tabButtons) {
      t.btn.classList.toggle('is-active', t.source === activeSource);
      t.btn.setAttribute('aria-selected', t.source === activeSource ? 'true' : 'false');
    }
    toolbarTitle.textContent = `All ${source.label}`;
    renderFilters();
    loadActiveSource();
  }

  async function uploadToLibrary(file, source, filename) {
    const prepared = await shrinkImage(file);
    const ext = (prepared.name.match(/\.[a-z0-9]+$/i) || [''])[0];
    const url = await uploadFileToServer(prepared, { filename: filename ? filename + ext : (source.uploadPrefix || '') + prepared.name });
    addUploadedItem(url, source);
    return url;
  }

  async function uploadAndSelect(file, filename, source = activeSource) {
    const url = await uploadToLibrary(file, source, filename);
    clearPending();
    renderGrid();
    selectItem(url, { close: false });
  }

  const accepts = (file) => (file?.type || '').startsWith(`${mediaKind}/`);
  const wrongKindMessage = `That file is not ${mediaKind === 'image' ? 'an image' : `a ${mediaKind} file`}.`;
  function uploadSource() {
    if (activeSource?.allowUpload) return activeSource;
    return activeSources.find((s) => s.allowUpload && s.id === 'uploads')
      || activeSources.find((s) => s.allowUpload) || null;
  }

  async function startUpload(file) {
    const source = uploadSource();
    if (!file || !source) return;
    // A second upload would clear the first one's card.
    if (pendingUpload && !pendingUpload.error) return;
    if (source !== activeSource) selectSource(source);
    setPending(file, source);
    if (!accepts(file)) pendingUpload.error = wrongKindMessage;
    renderGrid();
    gridScroll.scrollTop = 0;
    if (pendingUpload.error) return;
    try {
      await uploadAndSelect(file, undefined, source);
    } catch (err) {
      if (!pendingUpload) return;
      pendingUpload.error = err.message || 'Upload failed';
      renderGrid();
    }
  }

  fileInput.addEventListener('change', async () => {
    const file = fileInput.files?.[0];
    fileInput.value = '';
    if (!file || !activeSource) return;
    if (createOpen) { setCreateFile(file); return; }
    await startUpload(file);
  });

  const hasFiles = (e) => Array.from(e.dataTransfer?.types || []).includes('Files');

  // Children fire their own enter/leave; counting depth stops the flicker.
  function bindFileDrop(el, canDrop, onDrop) {
    let depth = 0;
    const reset = () => { depth = 0; el.classList.remove('is-dragover'); };
    el.addEventListener('dragenter', (e) => {
      if (!hasFiles(e) || !canDrop()) return;
      e.preventDefault();
      depth += 1;
      el.classList.add('is-dragover');
    });
    el.addEventListener('dragover', (e) => {
      if (!hasFiles(e) || !canDrop()) return;
      e.preventDefault();
      e.dataTransfer.dropEffect = 'copy';
    });
    el.addEventListener('dragleave', () => {
      if (depth && --depth === 0) el.classList.remove('is-dragover');
    });
    el.addEventListener('drop', (e) => {
      if (!hasFiles(e) || !canDrop()) return;
      e.preventDefault();
      reset();
      const file = e.dataTransfer.files[0];
      if (file) onDrop(file);
    });
  }

  const dropHint = document.createElement('div');
  dropHint.className = 'avp-drop-overlay';
  dropHint.innerHTML = `${PLUS_CIRCLE}<span>Drop to upload</span>`;
  body.appendChild(dropHint);
  bindFileDrop(dialog, () => !createOpen && !!uploadSource(), startUpload);

  const tileBusy = document.createElement('span');
  tileBusy.className = 'avp-tile-busy';
  tileBusy.innerHTML = '<span class="avp-spinner" aria-hidden="true"></span>';
  trigger.appendChild(tileBusy);
  let tileUploading = false;
  bindFileDrop(triggerBox, () => !tileUploading && !!uploadSource(), async (file) => {
    const source = uploadSource();
    if (!accepts(file)) { setError(wrongKindMessage); return; }
    clearError();
    tileUploading = true;
    triggerBox.classList.add('is-uploading');
    trigger.setAttribute('aria-busy', 'true');
    try {
      selectItem(await uploadToLibrary(file, source), { close: false });
    } catch (err) {
      setError(err.message || 'Upload failed');
    } finally {
      tileUploading = false;
      triggerBox.classList.remove('is-uploading');
      trigger.removeAttribute('aria-busy');
    }
  });

  /* ── "New Avatar" ── */
  const create = document.createElement('div');
  create.className = 'avp-create';
  create.innerHTML = `
    <button type="button" class="avp-back"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5l-7 7 7 7"/></svg>Back</button>
    <div class="avp-create-head">
      <h3 class="avp-create-title">New Avatar</h3>
      <div class="avp-seg">
        <button type="button" class="avp-seg-btn" disabled title="Coming soon">Generate with prompt</button>
        <button type="button" class="avp-seg-btn is-active">Uploaded Photo</button>
      </div>
    </div>
    <div class="avp-create-panel">
      <div class="avp-drop" role="button" tabindex="0" aria-label="Upload or drag a photo">
        ${PLUS_CIRCLE}
        <div class="avp-drop-title">Upload or drag</div>
        <div class="avp-drop-hint">PNG JPEG WEBP up to 10 MB.</div>
        <button type="button" class="avp-drop-change">Change photo</button>
      </div>
      <div class="avp-create-error" role="alert"></div>
      <div class="avp-create-foot">
        <input type="text" class="avp-name" placeholder="Your Avatar Name" maxlength="60">
        <button type="button" class="avp-create-btn" disabled>Create</button>
      </div>
    </div>`;
  dialog.appendChild(create);
  const backBtn = create.querySelector('.avp-back');
  const drop = create.querySelector('.avp-drop');
  const dropChange = create.querySelector('.avp-drop-change');
  const nameInput = create.querySelector('.avp-name');
  const createBtn = create.querySelector('.avp-create-btn');
  const createError = create.querySelector('.avp-create-error');
  let createOpen = false;
  let createFile = null;
  let createPreview = null;

  function syncCreateButton() {
    createBtn.disabled = !(createFile && nameInput.value.trim());
  }
  function setCreateFile(file) {
    if (!file || !/^image\//.test(file.type)) { createError.textContent = 'Pick a PNG, JPEG or WEBP image.'; return; }
    if (file.size > 10 * 1024 * 1024) { createError.textContent = 'That image is over 10 MB.'; return; }
    createError.textContent = '';
    createFile = file;
    if (createPreview) { URL.revokeObjectURL(createPreview.src); createPreview.remove(); }
    createPreview = document.createElement('img');
    createPreview.alt = '';
    createPreview.src = URL.createObjectURL(file);
    drop.appendChild(createPreview);
    drop.classList.add('has-file');
    syncCreateButton();
  }
  function openCreate() {
    createOpen = true;
    createFile = null;
    createError.textContent = '';
    if (createPreview) { URL.revokeObjectURL(createPreview.src); createPreview.remove(); createPreview = null; }
    drop.classList.remove('has-file');
    nameInput.value = '';
    syncCreateButton();
    dialog.classList.add('is-creating');
    create.classList.add('is-open');
    nameInput.focus();
  }
  function closeCreate() {
    if (!createOpen) return;
    createOpen = false;
    dialog.classList.remove('is-creating');
    create.classList.remove('is-open');
  }
  backBtn.addEventListener('click', closeCreate);
  drop.addEventListener('click', () => fileInput.click());
  drop.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); fileInput.click(); } });
  dropChange.addEventListener('click', (e) => { e.stopPropagation(); fileInput.click(); });
  bindFileDrop(drop, () => createOpen, setCreateFile);
  nameInput.addEventListener('input', syncCreateButton);
  createBtn.addEventListener('click', async () => {
    if (!createFile) return;
    const name = nameInput.value.trim();
    if (!name) return;
    createBtn.disabled = true;
    createBtn.textContent = 'Creating…';
    try {
      const slug = name.replace(/[^\p{L}\p{N}]+/gu, '-').replace(/^-+|-+$/g, '') || 'avatar';
      await uploadAndSelect(createFile, (activeSource?.uploadPrefix || 'avatar-') + slug);
      closeCreate();
    } catch (err) {
      createError.textContent = err.message || 'Upload failed';
    } finally {
      createBtn.textContent = 'Create';
      syncCreateButton();
    }
  });

  const confirmBox = document.createElement('div');
  confirmBox.className = 'avp-confirm';
  confirmBox.setAttribute('role', 'alertdialog');
  confirmBox.setAttribute('aria-modal', 'true');
  confirmBox.innerHTML = `
    <div class="avp-confirm-card">
      <div class="avp-confirm-thumb"></div>
      <h4 class="avp-confirm-title">Delete this file?</h4>
      <p class="avp-confirm-text"></p>
      <div class="avp-confirm-actions">
        <button type="button" class="avp-confirm-cancel">Cancel</button>
        <button type="button" class="avp-confirm-ok">Delete</button>
      </div>
    </div>`;
  dialog.appendChild(confirmBox);
  const confirmThumb = confirmBox.querySelector('.avp-confirm-thumb');
  const confirmText = confirmBox.querySelector('.avp-confirm-text');
  const confirmCancel = confirmBox.querySelector('.avp-confirm-cancel');
  const confirmOk = confirmBox.querySelector('.avp-confirm-ok');
  let confirmResolve = null;

  function settleConfirm(ok) {
    if (!confirmResolve) return;
    const resolve = confirmResolve;
    confirmResolve = null;
    confirmBox.classList.remove('is-open');
    resolve(ok);
  }
  function askConfirm(item) {
    settleConfirm(false);
    confirmThumb.innerHTML = '';
    confirmThumb.appendChild(makeThumb(item.thumbUrl || item.url, item.label || ''));
    confirmText.textContent = `"${item.label || item.name}" will be removed from your library. This can't be undone.`;
    confirmBox.classList.add('is-open');
    confirmCancel.focus();
    return new Promise((resolve) => { confirmResolve = resolve; });
  }
  confirmCancel.addEventListener('click', () => settleConfirm(false));
  confirmOk.addEventListener('click', () => settleConfirm(true));
  confirmBox.addEventListener('click', (e) => { if (e.target === confirmBox) settleConfirm(false); });

  /* ── open/close ── */
  let lastFocus = null;

  let closeTimer = null;
  function openModal() {
    if (!overlay.isConnected) document.body.appendChild(overlay);
    clearTimeout(closeTimer);
    overlay.classList.remove('is-closing');
    lastFocus = document.activeElement;
    overlay.classList.add('is-open');
    document.body.style.overflow = 'hidden';
    trigger.setAttribute('aria-expanded', 'true');
    pinned = readPinned();
    // Always back to the author's tab, not wherever the last visit ended up.
    if (openingSource) selectSource(openingSource);
    dialogClose.focus();
  }

  const CLOSE_MS = 340;
  /** `delay` lets a pick show its check before easing out. */
  function closeModal({ delay = 0 } = {}) {
    if (!overlay.classList.contains('is-open') || overlay.classList.contains('is-closing')) return;
    clearTimeout(closeTimer);
    settleConfirm(false);
    const ease = () => {
      overlay.classList.add('is-closing');
      closeTimer = setTimeout(() => {
        closeCreate();
        // A hidden overlay reports no intersection anyway, but this also drops the
        // sentinel a reopened modal would otherwise re-observe twice.
        pageObserver?.disconnect();
        overlay.classList.remove('is-open', 'is-closing');
        overlay.remove();
        document.body.style.overflow = '';
        trigger.setAttribute('aria-expanded', 'false');
        if (lastFocus && typeof lastFocus.focus === 'function') lastFocus.focus();
      }, CLOSE_MS);
    };
    if (delay > 0) closeTimer = setTimeout(ease, delay); else ease();
  }

  trigger.addEventListener('click', openModal);
  dialogClose.addEventListener('click', closeModal);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) closeModal(); });
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape' || !overlay.classList.contains('is-open')) return;
    if (confirmResolve) settleConfirm(false); else closeModal();
  });

  function setError(message) {
    if (!message) {
      errorEl.textContent = '';
      errorEl.classList.add('hidden');
      trigger.classList.remove('border-red-400', 'dark:border-red-500');
      return;
    }
    errorEl.textContent = String(message);
    errorEl.classList.remove('hidden');
    trigger.classList.add('border-red-400', 'dark:border-red-500');
  }

  function clearError() { setError(''); }

  refreshTrigger();
  if (selectedUrl) commit(selectedUrl);

  if (openingSource) {
    const warm = () => firstPageEntry(openingSource, mediaKind, defaultFilters(openingSource)).promise.catch(() => {});
    if (typeof requestIdleCallback === 'function') requestIdleCallback(warm, { timeout: 3000 });
    else setTimeout(warm, 1500);
  }

  const api = {
    wrap,
    getValue: () => selectedUrl || undefined,
    setValue: (v) => {
      selectedUrl = typeof v === 'string' ? v : '';
      commit(selectedUrl);
      refreshTrigger();
      clearError();
    },
    setError,
    clearError,
  };
  // Read by page templates.
  wrap.assetPicker = { getValue: api.getValue, setValue: api.setValue };
  return api;
}

/** Schema property -> node plus the URL it contributes. */
export function bindAssetPicker({ key, title, description, propSchema, isRequired, isReadOnly }) {
  const xuap = propSchema?.['x-uap'] || {};
  const field = createAssetPickerField({
    label: title, id: key, required: isRequired, help: description,
    sources: Array.isArray(xuap.assetSources) ? xuap.assetSources : [],
    defaultSource: typeof xuap.defaultSource === 'string' ? xuap.defaultSource : '',
    mediaKind: typeof xuap.assetKind === 'string' ? xuap.assetKind : 'image',
    defaultValue: propSchema?.default,
    triggerLabel: xuap.triggerLabel || 'Choose asset',
  });
  if (isReadOnly) {
    field.wrap.classList.add('opacity-75', 'pointer-events-none');
  }
  return {
    node: field.wrap,
    replaces: true,
    fields: [{ key, kind: 'string', required: isRequired, _getValue: field.getValue, setError: field.setError, clearError: field.clearError }],
  };
}
