// Shared styles for the visual-picker and asset-picker modals
export function ensurePickerModalStyles() {
  if (document.getElementById('aitopia-picker-modal-style')) return;
  const style = document.createElement('style');
  style.id = 'aitopia-picker-modal-style';
  style.textContent = `
    .avp-overlay{position:fixed;inset:0;z-index:9998;display:none;align-items:center;justify-content:center;padding:16px;background:rgba(0,0,0,.72);backdrop-filter:blur(6px)}
    .avp-overlay.is-open{display:flex;animation:avp-fade-in .22s ease both}
    .avp-overlay.is-open .avp-dialog{animation:avp-dialog-in .3s cubic-bezier(.22,.61,.36,1) both}
    .avp-overlay.is-closing{animation:avp-fade-out .34s ease both;pointer-events:none}
    .avp-overlay.is-closing .avp-dialog{animation:avp-dialog-out .34s cubic-bezier(.4,0,.2,1) both}
    @keyframes avp-fade-in{from{opacity:0}to{opacity:1}}
    @keyframes avp-fade-out{from{opacity:1}to{opacity:0}}
    @keyframes avp-dialog-in{from{opacity:0;transform:translateY(10px) scale(.98)}to{opacity:1;transform:none}}
    @keyframes avp-dialog-out{from{opacity:1;transform:none}to{opacity:0;transform:translateY(8px) scale(.985)}}
    @media(prefers-reduced-motion:reduce){.avp-overlay.is-open,.avp-overlay.is-open .avp-dialog,.avp-overlay.is-closing,.avp-overlay.is-closing .avp-dialog{animation:none}}
    .avp-dialog{position:relative;display:flex;flex-direction:column;width:min(1205px,100%);height:min(882px,92vh);border-radius:17px;overflow:hidden;background:#fff;border:1px solid rgba(0,0,0,.08);box-shadow:0 30px 80px rgba(0,0,0,.45)}
    .dark .avp-dialog{background:#101012;border-color:rgba(255,255,255,.08)}
    .avp-head{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:25px 25px 0}
    .avp-title{margin:0;font-size:17px;line-height:26px;font-weight:600;color:#111}
    .dark .avp-title{color:#fff}
    .avp-close{display:flex;align-items:center;justify-content:center;width:36px;height:36px;margin:-6px -8px 0 0;border-radius:9999px;border:0;cursor:pointer;color:#555;background:rgba(0,0,0,.06)}
    .avp-close:hover{background:rgba(0,0,0,.12)}
    .dark .avp-close{color:#c8c8cc;background:rgba(255,255,255,.08)}
    .dark .avp-close:hover{background:rgba(255,255,255,.14)}
    .avp-body{display:flex;flex:1 1 auto;min-height:0;gap:11px;padding:27px 25px 25px}
    .avp-side{flex:0 0 217px;display:flex;flex-direction:column;padding:24px 16px;border-radius:13px;overflow-y:auto;background:#F4F4F6}
    .dark .avp-side{background:#141416}
    .avp-cat{display:block;width:100%;padding:7px 0;border:0;background:none;text-align:left;font-size:15.5px;line-height:20px;font-weight:500;cursor:pointer;color:#77777c;transition:color .12s ease}
    .avp-cat:hover,.avp-cat.is-active{color:#111}
    .dark .avp-cat{color:#a0a0a5}
    .dark .avp-cat:hover,.dark .avp-cat.is-active{color:#fff}
    .avp-main{flex:1 1 auto;min-width:0;display:flex;flex-direction:column;border-radius:13px;overflow:hidden;background:#F4F4F6}
    .dark .avp-main{background:#141416}
    .avp-main-head{flex:0 0 auto;display:flex;align-items:center;justify-content:space-between;gap:12px;padding:24px 14px 22px}
    .avp-main-title{flex:0 0 auto;margin:0;padding:24px 14px 22px;font-size:16px;line-height:22px;font-weight:500;color:#111}
    .avp-main-head>.avp-main-title{padding:0}
    .dark .avp-main-title{color:#fff}
    .avp-scroll{flex:1 1 auto;min-height:0;overflow-y:auto;padding:0 14px 14px}
    .avp-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px 9px}
    @media(min-width:640px){.avp-grid{grid-template-columns:repeat(3,minmax(0,1fr))}}
    @media(min-width:1024px){.avp-grid{grid-template-columns:repeat(4,minmax(0,1fr))}}
    .avp-card{position:relative;display:flex;flex-direction:column;gap:14px;padding:0;border:0;background:none;text-align:left;cursor:pointer;color:inherit}
    .avp-thumb{position:relative;display:block;width:100%;padding:0;border:0;aspect-ratio:0.72;border-radius:10px;overflow:hidden;background:rgba(0,0,0,.06);cursor:pointer;transition:transform .2s cubic-bezier(.22,.61,.36,1),box-shadow .2s ease,filter .2s ease}
    .dark .avp-thumb{background:rgba(255,255,255,.06)}
    .avp-thumb > :is(img,video){transition:transform .35s cubic-bezier(.22,.61,.36,1)}
    .avp-card:hover .avp-thumb{transform:translateY(-3px);box-shadow:0 12px 28px rgba(0,0,0,.18),inset 0 0 0 1px rgba(0,0,0,.08)}
    .dark .avp-card:hover .avp-thumb{box-shadow:0 12px 28px rgba(0,0,0,.45),inset 0 0 0 1px rgba(255,255,255,.14)}
    .avp-card:hover .avp-thumb > :is(img,video){transform:scale(1.04)}
    .avp-card:hover .avp-cap{color:#111}
    .dark .avp-card:hover .avp-cap{color:#fff}
    .avp-card:active .avp-thumb{transform:translateY(-1px) scale(.99)}
    .avp-thumb::after{content:'';position:absolute;top:10px;right:10px;width:26px;height:26px;border-radius:9999px;background:hsl(var(--ait-m-primary)) url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='white' stroke-width='3' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M5 12.5l4.5 4.5L19 7.5'/%3E%3C/svg%3E") center/14px no-repeat;box-shadow:0 4px 12px rgba(0,0,0,.35);opacity:0;transform:scale(.6);transition:opacity .18s ease,transform .18s cubic-bezier(.34,1.4,.64,1);pointer-events:none}
    .avp-card[aria-selected="true"] .avp-thumb,.avp-thumb[aria-selected="true"]{box-shadow:inset 0 0 0 2.5px hsl(var(--ait-m-primary))}
    .avp-card[aria-selected="true"] .avp-thumb::after,.avp-thumb[aria-selected="true"]::after{opacity:1;transform:none}
    .avp-card[aria-selected="true"] .avp-cap,.avp-card:has(.avp-thumb[aria-selected="true"]) .avp-cap{color:#111}
    .dark .avp-card[aria-selected="true"] .avp-cap,.dark .avp-card:has(.avp-thumb[aria-selected="true"]) .avp-cap{color:#fff}
    .avp-card:focus-visible .avp-thumb,.avp-thumb:focus-visible{box-shadow:inset 0 0 0 2.5px hsl(var(--ait-m-primary)),0 0 0 3px hsl(var(--ait-m-primary) / .25)}
    .avp-card:focus-visible,.avp-thumb:focus-visible{outline:none}
    .avp-thumb--upload::after{display:none}
    .avp-card:hover .avp-thumb--upload{transform:none;box-shadow:none;border-color:rgba(0,0,0,.35)}
    .dark .avp-card:hover .avp-thumb--upload{border-color:rgba(255,255,255,.4)}
    .avp-thumb--upload{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;background:transparent;border:1px dashed rgba(0,0,0,.18);color:#77777c;font-size:13px;font-weight:500}
    .dark .avp-thumb--upload{border-color:rgba(255,255,255,.18);color:#a0a0a5}
    .avp-thumb--upload svg{width:22px;height:22px}
    .avp-cap{font-size:13px;line-height:18px;font-weight:600;color:#55555b;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;transition:color .18s ease}
    .dark .avp-cap{color:#b8b8be}
    .avp-actions{position:absolute;top:8px;right:8px;display:flex;gap:4px;opacity:0;transition:opacity .12s ease}
    .avp-card:hover .avp-actions,.avp-card:focus-within .avp-actions{opacity:1}
    .avp-action{width:28px;height:28px;border-radius:9999px;border:0;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.55);color:#fff;font-size:13px;cursor:pointer}
    .avp-action:hover{background:rgba(0,0,0,.78)}
    .avp-action--danger:hover{background:#dc2626}
    .avp-action svg{width:14px;height:14px}
    .avp-msg{grid-column:1/-1;padding:40px 0;text-align:center;font-size:13px;color:#8a8a8f}
    @media(max-width:767.98px){.avp-head{padding:18px 16px 0}.avp-body{flex-direction:column;padding:16px}.avp-side{flex:0 0 auto;flex-direction:row;flex-wrap:wrap;gap:4px 14px;padding:10px 12px}.avp-cat{width:auto;padding:4px 0}}
    .avp-tabs{display:flex;align-items:center;gap:6px;flex:1 1 auto;min-width:0;overflow-x:auto;scrollbar-width:none}
    .avp-tabs::-webkit-scrollbar{display:none}
    .avp-tab{height:34px;padding:0 16px;border-radius:9999px;border:0;background:transparent;font-size:14px;font-weight:500;color:#77777c;cursor:pointer;white-space:nowrap;transition:background .12s ease,color .12s ease}
    .avp-tab:hover{color:#111}
    .avp-tab.is-active{background:#111;color:#fff}
    .dark .avp-tab{color:#a0a0a5}
    .dark .avp-tab:hover{color:#fff}
    .dark .avp-tab.is-active{background:#fff;color:#111}
    .avp-side[hidden]{display:none}
    .avp-seg{display:inline-flex;align-items:center;gap:2px;padding:3px;border-radius:9999px;border:1px solid rgba(0,0,0,.1);background:rgba(0,0,0,.03)}
    .dark .avp-seg{border-color:rgba(255,255,255,.1);background:rgba(255,255,255,.03)}
    .avp-seg-btn{height:26px;padding:0 12px;border-radius:9999px;border:0;background:transparent;font-size:13px;font-weight:500;color:#77777c;cursor:pointer;transition:background .12s ease,color .12s ease}
    .avp-seg-btn.is-active{background:rgba(0,0,0,.08);color:#111;font-weight:600}
    .dark .avp-seg-btn{color:#a0a0a5}
    .dark .avp-seg-btn.is-active{background:rgba(255,255,255,.12);color:#fff}
    @media(min-width:1024px){.avp-grid--5{grid-template-columns:repeat(5,minmax(0,1fr))}}
    .avp-plus-circle{display:flex;align-items:center;justify-content:center;width:29px;height:29px;border-radius:9999px;background:rgba(0,0,0,.08);color:#333}
    .dark .avp-plus-circle{background:rgba(255,255,255,.1);color:#fff}
    .avp-plus-circle svg{width:14px;height:14px}
    .avp-thumb--upload span{font-size:12px}
    .avp-create{display:none;flex:1 1 auto;min-height:0;flex-direction:column;padding:0 25px 25px}
    .avp-create.is-open{display:flex}
    .avp-dialog.is-creating .avp-body{display:none}
    .avp-dialog.is-creating .avp-tabs{visibility:hidden}
    .avp-back{position:absolute;left:25px;top:22px;display:inline-flex;align-items:center;gap:8px;height:40px;padding:0 16px 0 12px;border-radius:12px;border:0;background:rgba(0,0,0,.06);color:#111;font-size:14px;font-weight:500;cursor:pointer}
    .dark .avp-back{background:rgba(255,255,255,.08);color:#fff}
    .avp-back svg{width:12px;height:12px}
    .avp-create-head{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:34px 0 18px}
    .avp-create-title{margin:0;font-size:17px;line-height:26px;font-weight:600;color:#111}
    .dark .avp-create-title{color:#fff}
    .avp-seg-btn[disabled]{cursor:not-allowed;opacity:.55}
    .avp-create-panel{flex:1 1 auto;min-height:0;display:flex;flex-direction:column;gap:20px;padding:16px;border-radius:13px;background:#F4F4F6}
    .dark .avp-create-panel{background:#141416}
    .avp-drop{flex:1 1 auto;min-height:240px;position:relative;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;border-radius:13px;border:1px dashed rgba(0,0,0,.2);background:transparent;cursor:pointer;color:#111;overflow:hidden}
    .dark .avp-drop{border-color:rgba(255,255,255,.2);color:#fff}
    .avp-drop.is-dragover{border-color:hsl(var(--ait-m-primary));background:hsl(var(--ait-m-primary) / .06)}
    .avp-drop .avp-plus-circle{width:38px;height:38px}
    .avp-drop .avp-plus-circle svg{width:18px;height:18px}
    .avp-drop-title{font-size:15px;font-weight:600}
    .avp-drop-hint{font-size:13px;line-height:20px;color:#8a8a8f;text-align:center}
    .avp-drop > img{position:absolute;inset:0;width:100%;height:100%;object-fit:contain;background:#000}
    .avp-drop.has-file > :not(img):not(.avp-drop-change){display:none}
    .avp-drop-change{display:none;position:absolute;right:12px;bottom:12px;height:32px;padding:0 12px;border-radius:9999px;border:0;background:rgba(0,0,0,.6);color:#fff;font-size:12px;font-weight:600;cursor:pointer}
    .avp-drop.has-file .avp-drop-change{display:inline-flex;align-items:center}
    .avp-create-foot{display:flex;align-items:center;justify-content:space-between;gap:16px}
    .avp-name{flex:0 1 480px;height:48px;padding:0 18px;border-radius:9999px;border:1px solid rgba(0,0,0,.1);background:transparent;font-size:15px;color:#111;outline:none}
    .avp-name::placeholder{color:#8a8a8f}
    .avp-name:focus{border-color:hsl(var(--ait-m-primary))}
    .dark .avp-name{border-color:rgba(255,255,255,.12);color:#fff}
    .avp-create-btn{height:48px;padding:0 36px;border-radius:9999px;border:0;background:#8B5CF6;color:#fff;font-size:15px;font-weight:600;cursor:pointer;box-shadow:0 8px 24px rgba(139,92,246,.35)}
    .avp-create-btn:hover{background:#9469F7}
    .avp-create-btn[disabled]{opacity:.5;cursor:not-allowed;box-shadow:none}
    .avp-create-error{font-size:13px;color:#ef4444}
    .avp-create-error:empty{display:none}
    .avp-body{position:relative}
    .avp-drop-overlay{position:absolute;inset:12px;z-index:4;display:none;flex-direction:column;align-items:center;justify-content:center;gap:10px;border-radius:13px;border:2px dashed hsl(var(--ait-m-primary));background:hsl(var(--ait-m-primary) / .1);backdrop-filter:blur(2px);color:#111;font-size:15px;font-weight:600;pointer-events:none}
    .dark .avp-drop-overlay{color:#fff}
    .avp-dialog.is-dragover .avp-drop-overlay{display:flex;animation:avp-fade-in .15s ease both}
    [data-asset-trigger-box].is-dragover button[data-trigger]{outline:2px dashed hsl(var(--ait-m-primary));outline-offset:2px}
    .avp-tile-busy{position:absolute;inset:0;z-index:2;display:none;align-items:center;justify-content:center;border-radius:inherit;background:rgba(0,0,0,.5)}
    [data-asset-trigger-box].is-uploading .avp-tile-busy{display:flex!important}
    .avp-skeleton{pointer-events:none}
    .avp-skeleton .avp-thumb,.avp-skeleton-cap{background:linear-gradient(90deg,rgba(127,127,127,.08) 25%,rgba(127,127,127,.18) 37%,rgba(127,127,127,.08) 63%);background-size:400% 100%;animation:avp-shimmer 1.4s ease infinite}
    .avp-skeleton .avp-thumb::after{display:none}
    .avp-skeleton-cap{width:60%;height:12px;margin:3px 0;border-radius:6px}
    @keyframes avp-shimmer{from{background-position:100% 50%}to{background-position:0 50%}}
    @media(prefers-reduced-motion:reduce){.avp-skeleton .avp-thumb,.avp-skeleton-cap{animation:none}}
    .avp-card--pending{cursor:default}
    .avp-card.avp-card--pending .avp-thumb,.dark .avp-card.avp-card--pending .avp-thumb{cursor:default;transform:none;box-shadow:none}
    .avp-card--pending .avp-thumb::after{display:none}
    .avp-pending{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;padding:12px;text-align:center;background:rgba(0,0,0,.45);color:#fff}
    .avp-pending.is-error{background:rgba(0,0,0,.7)}
    .avp-pending-label{font-size:12px;font-weight:600}
    .avp-pending-error{font-size:12px;line-height:16px;color:#fca5a5;overflow-wrap:anywhere}
    .avp-pending-dismiss{height:28px;padding:0 12px;border-radius:9999px;border:0;background:rgba(255,255,255,.16);color:#fff;font-size:12px;font-weight:600;cursor:pointer}
    .avp-pending-dismiss:hover{background:rgba(255,255,255,.26)}
    .avp-spinner{width:26px;height:26px;border-radius:9999px;border:2.5px solid rgba(255,255,255,.35);border-top-color:#fff;animation:avp-spin .8s linear infinite}
    @keyframes avp-spin{to{transform:rotate(360deg)}}
    .avp-confirm{position:absolute;inset:0;z-index:5;display:none;align-items:center;justify-content:center;padding:16px;background:rgba(0,0,0,.5);backdrop-filter:blur(3px)}
    .avp-confirm.is-open{display:flex;animation:avp-fade-in .18s ease both}
    .avp-confirm.is-open .avp-confirm-card{animation:avp-dialog-in .22s cubic-bezier(.22,.61,.36,1) both}
    .avp-confirm-card{width:min(360px,100%);padding:24px;border-radius:16px;text-align:center;background:#fff;border:1px solid rgba(0,0,0,.08);box-shadow:0 24px 60px rgba(0,0,0,.35)}
    .dark .avp-confirm-card{background:#18181b;border-color:rgba(255,255,255,.08)}
    .avp-confirm-thumb{position:relative;width:72px;height:96px;margin:0 auto 16px;border-radius:10px;overflow:hidden;background:rgba(0,0,0,.06)}
    .dark .avp-confirm-thumb{background:rgba(255,255,255,.06)}
    .avp-confirm-title{margin:0;font-size:16px;line-height:22px;font-weight:600;color:#111}
    .dark .avp-confirm-title{color:#fff}
    .avp-confirm-text{margin:6px 0 0;font-size:13px;line-height:19px;color:#6b6b70;overflow-wrap:anywhere}
    .dark .avp-confirm-text{color:#a0a0a5}
    .avp-confirm-actions{display:flex;gap:10px;margin-top:20px}
    .avp-confirm-actions>button{flex:1 1 0;height:40px;border-radius:10px;border:0;font-size:14px;font-weight:600;cursor:pointer;transition:background .12s ease}
    .avp-confirm-cancel{background:rgba(0,0,0,.06);color:#111}
    .avp-confirm-cancel:hover{background:rgba(0,0,0,.1)}
    .dark .avp-confirm-cancel{background:rgba(255,255,255,.08);color:#fff}
    .dark .avp-confirm-cancel:hover{background:rgba(255,255,255,.14)}
    .avp-confirm-ok{background:#dc2626;color:#fff}
    .avp-confirm-ok:hover{background:#b91c1c}
    @media(prefers-reduced-motion:reduce){.avp-confirm.is-open,.avp-confirm.is-open .avp-confirm-card{animation:none}}
  `;
  document.head.appendChild(style);
}
