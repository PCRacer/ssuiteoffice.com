/**
 * Agent selector component (agent-group modes).
 * Two looks from one field: 'tab' draws a segmented control, 'select' a
 * dropdown. Tab modes sharing a section fold into one tab with a tool list.
 * Copied from chip-group/pill-select rather than imported so each
 * look can be styled for the group header without touching those components.
 */
import { updateFormData, createFieldLabel, createHelpToggle } from '../../runner/overrides/ui-core.js';
import { optionListOf } from './field-shape.js';
import { thumbImage } from '../../shared/media-thumb.js';

function normalizeOptions(options) {
  return (Array.isArray(options) ? options : []).map((opt) => (
    opt && typeof opt === 'object'
      ? { value: String(opt.value), label: String(opt.label ?? opt.value) }
      : { value: String(opt), label: String(opt) }
  ));
}

const TOOL_ICONS = [
  [/watermark/, 'video-watermark-remover'],
  [/swap/, 'face-swap'],
  [/camera/, 'turnaround-360'],
  [/style/, 'sketch-to-image'],
  [/remov/, 'watermark-remover'],
  [/upscal/, 'closeup-clip'],
  [/background/, 'scene-generator'],
  [/video/, 'video-generator'],
  [/image|photo/, 'image-generator'],
];
const toolIcon = (text) => TOOL_ICONS.find(([re]) => re.test(text.toLowerCase()))?.[1] || '';

export function createAgentSelector({
  label,
  id,
  options = [],
  defaultValue,
  required = false,
  help,
  style = 'tab', // 'tab' | 'select'
  sections,
  describe,
  onToolState,
  onChange,
} = {}) {
  const wrap = document.createElement('div');
  const fieldKey = id || label || 'agentSelector';
  if (id) wrap.setAttribute('data-id', id);
  wrap.setAttribute('data-component', 'agent-selector');
  wrap.setAttribute('data-selector-style', style === 'select' ? 'select' : 'tab');

  if (label && String(label).trim()) {
    const header = document.createElement('div');
    header.className = 'mb-3';
    const row = document.createElement('div');
    row.className = 'flex items-center';
    const labelEl = createFieldLabel(String(label), { required });
    labelEl.className = 'block text-sm font-semibold mx-2';
    row.appendChild(labelEl);
    const { trigger } = createHelpToggle({ idSeed: label, labelText: label, helpText: help });
    if (trigger) {
      wrap.setAttribute('data-help-scope', '');
      row.appendChild(trigger);
    }
    header.appendChild(row);
    wrap.appendChild(header);
  }

  const normalized = normalizeOptions(options);
  // A group always opens on a mode, so fall back to the first one: publish
  // requires a default, but a draft or a renamed value must still render.
  let selected = defaultValue != null && normalized.some(o => o.value === String(defaultValue))
    ? String(defaultValue)
    : (normalized[0]?.value ?? '');

  const sync = (emit) => {
    updateFormData(fieldKey, selected);
    if (emit && typeof onChange === 'function') onChange(selected);
  };

  let apply;
  const notify = (open) => onToolState?.({ tool: normalized.find((o) => o.value === selected) || null, open });

  if (style === 'select') {
    const select = document.createElement('select');
    select.className = 'w-full px-3 py-2 rounded-xl text-sm bg-neutral-100 dark:bg-neutral-900 '
      + 'border border-neutral-200 dark:border-neutral-700 focus:outline-none focus:ring-2 focus:ring-primary/40';
    for (const opt of normalized) {
      const o = document.createElement('option');
      o.value = opt.value;
      o.textContent = opt.label;
      select.appendChild(o);
    }
    select.value = selected;
    select.addEventListener('change', () => {
      selected = select.value;
      sync(true);
      notify(false);
    });
    apply = () => { select.value = selected; notify(false); };
    wrap.appendChild(select);
  } else {
    const sectionOf = optionListOf(sections, normalized.map((o) => o.value));
    const tabs = [];
    normalized.forEach((opt, i) => {
      const name = String(sectionOf[i] ?? '').trim();
      const tab = name && tabs.find((t) => t.name === name);
      if (tab) tab.options.push(opt);
      else tabs.push({ name, options: [opt] });
    });
    const tabOf = (value) => tabs.find((t) => t.options.some((o) => o.value === value));

    const lastPick = new Map();
    let open = false;
    const setOpen = (next) => {
      if (open === next) return;
      open = next;
      apply();
    };
    const pick = (value) => {
      open = false;
      if (value === selected) { apply(); return; }
      selected = value;
      apply();
      sync(true);
    };

    const group = document.createElement('div');
    group.className = 'agent-mode-tabs flex w-full flex-wrap';
    group.setAttribute('role', 'radiogroup');
    const panel = document.createElement('div');
    panel.className = 'agent-mode-tools flex flex-col';
    panel.setAttribute('role', 'radiogroup');

    const buttons = tabs.map((tab) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.setAttribute('role', 'radio');
      btn.textContent = tab.options.length > 1 ? tab.name : tab.options[0].label;
      if (tab.options.length > 1) btn.setAttribute('data-tools', '');
      btn.addEventListener('click', () => {
        const switching = tabOf(selected) !== tab;
        if (switching) pick(lastPick.get(tab) || tab.options[0].value);
        if (tab.options.length > 1) setOpen(switching || !open);
      });
      group.appendChild(btn);
      return { btn, tab };
    });

    const toolRow = (opt, active) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.setAttribute('role', 'radio');
      btn.setAttribute('aria-checked', active ? 'true' : 'false');
      btn.className = 'agent-mode-tool';
      const glyph = document.createElement('span');
      glyph.className = 'agent-mode-tool-icon';
      glyph.setAttribute('aria-hidden', 'true');
      const navIcon = toolIcon(`${opt.value} ${opt.label}`);
      if (navIcon) glyph.style.setProperty('--icon', `url("/marketplace/icons/nav-menu/${navIcon}.svg")`);
      else glyph.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round">'
        + '<path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z"/><path d="M19 15l.7 1.8 1.8.7-1.8.7L19 20l-.7-1.8-1.8-.7 1.8-.7z"/></svg>';
      btn.appendChild(glyph);
      const text = document.createElement('span');
      text.className = 'agent-mode-tool-text';
      const name = document.createElement('span');
      name.className = 'agent-mode-tool-name';
      name.textContent = opt.label;
      text.appendChild(name);
      btn.appendChild(text);
      if (typeof describe === 'function') {
        Promise.resolve(describe(opt.value)).then(({ description, image } = {}) => {
          if (image) {
            const icon = document.createElement('img');
            icon.className = 'agent-mode-tool-icon';
            icon.src = thumbImage(image, 0, '.agent-mode-tool-icon');
            icon.alt = '';
            icon.onerror = () => icon.replaceWith(glyph);
            glyph.replaceWith(icon);
          }
          if (description) {
            const about = document.createElement('span');
            about.className = 'agent-mode-tool-about';
            about.textContent = description;
            about.title = description;
            text.appendChild(about);
          }
        });
      }
      btn.addEventListener('click', () => (active ? setOpen(!open) : pick(opt.value)));
      return btn;
    };

    apply = () => {
      const current = tabOf(selected);
      if (current && current.options.length > 1) lastPick.set(current, selected);
      for (const { btn, tab } of buttons) {
        const active = tab === current;
        btn.setAttribute('aria-checked', active ? 'true' : 'false');
        btn.className = 'agent-mode-tab grow min-w-0 truncate';
      }
      panel.innerHTML = '';
      panel.hidden = !current || current.options.length < 2;
      panel.toggleAttribute('data-open', open && !panel.hidden);
      document[open && !panel.hidden ? 'addEventListener' : 'removeEventListener']('click', onOutside);
      if (!panel.hidden) {
        for (const opt of current.options) panel.appendChild(toolRow(opt, opt.value === selected));
      }
      if (open && !panel.hidden) {
        const tabBox = buttons.find((b) => b.tab === current).btn.getBoundingClientRect();
        panel.style.setProperty('--tools-x', `${tabBox.left + tabBox.width / 2 - wrap.getBoundingClientRect().left}px`);
      }
      notify(!panel.hidden && open);
    };

    const onOutside = (e) => { if (!e.composedPath().includes(wrap)) setOpen(false); };
    wrap.addEventListener('keydown', (e) => { if (e.key === 'Escape') setOpen(false); });

    wrap.appendChild(group);
    wrap.appendChild(panel);
  }

  apply();
  sync(false);

  return {
    wrap,
    getValue: () => selected,
    setValue: (v) => {
      selected = v == null ? '' : String(v);
      apply();
      sync(false);
    },
  };
}
