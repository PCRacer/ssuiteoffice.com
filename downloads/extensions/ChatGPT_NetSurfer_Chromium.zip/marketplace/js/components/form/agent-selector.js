/**
 * Agent selector component (agent-group modes).
 * Two looks from one field: 'tab' draws a segmented control, 'select' a
 * dropdown. Copied from chip-group/pill-select rather than imported so each
 * look can be styled for the group header without touching those components.
 */
import { updateFormData, createFieldLabel, createHelpToggle } from '../../runner/overrides/ui.js';

function normalizeOptions(options) {
  return (Array.isArray(options) ? options : []).map((opt) => (
    opt && typeof opt === 'object'
      ? { value: String(opt.value), label: String(opt.label ?? opt.value) }
      : { value: String(opt), label: String(opt) }
  ));
}

export function createAgentSelector({
  label,
  id,
  options = [],
  defaultValue,
  required = false,
  help,
  style = 'tab', // 'tab' | 'select'
  onChange,
} = {}) {
  const wrap = document.createElement('div');
  const fieldKey = id || label || 'agentSelector';
  if (id) wrap.setAttribute('data-id', id);
  wrap.setAttribute('data-component', 'agent-selector');
  wrap.setAttribute('data-selector-style', style === 'select' ? 'select' : 'tab');

  if (label && String(label).trim()) {
    const header = document.createElement('div');
    header.className = 'mb-3';
    const row = document.createElement('div');
    row.className = 'flex items-center';
    const labelEl = createFieldLabel(String(label), { required });
    labelEl.className = 'block text-sm font-semibold mx-2';
    row.appendChild(labelEl);
    const { trigger } = createHelpToggle({ idSeed: label, labelText: label, helpText: help });
    if (trigger) {
      wrap.setAttribute('data-help-scope', '');
      row.appendChild(trigger);
    }
    header.appendChild(row);
    wrap.appendChild(header);
  }

  const normalized = normalizeOptions(options);
  // A group always opens on a mode, so fall back to the first one: publish
  // requires a default, but a draft or a renamed value must still render.
  let selected = defaultValue != null && normalized.some(o => o.value === String(defaultValue))
    ? String(defaultValue)
    : (normalized[0]?.value ?? '');

  const sync = (emit) => {
    updateFormData(fieldKey, selected);
    if (emit && typeof onChange === 'function') onChange(selected);
  };

  let apply;

  if (style === 'select') {
    const select = document.createElement('select');
    select.className = 'w-full px-3 py-2 rounded-xl text-sm bg-neutral-100 dark:bg-neutral-900 '
      + 'border border-neutral-200 dark:border-neutral-700 focus:outline-none focus:ring-2 focus:ring-primary/40';
    for (const opt of normalized) {
      const o = document.createElement('option');
      o.value = opt.value;
      o.textContent = opt.label;
      select.appendChild(o);
    }
    select.value = selected;
    select.addEventListener('change', () => {
      selected = select.value;
      sync(true);
    });
    apply = () => { select.value = selected; };
    wrap.appendChild(select);
  } else {
    const group = document.createElement('div');
    group.className = 'inline-flex flex-wrap gap-1 p-1 rounded-full bg-neutral-100 dark:bg-neutral-900 '
      + 'border border-neutral-200 dark:border-neutral-800';
    group.setAttribute('role', 'radiogroup');
    const buttons = [];

    apply = () => {
      for (const { btn, value } of buttons) {
        const active = value === selected;
        btn.setAttribute('aria-checked', active ? 'true' : 'false');
        btn.className = 'px-5 py-1.5 rounded-full text-sm font-medium transition-all '
          + (active
            ? 'bg-white dark:bg-neutral-700 text-gray-900 dark:text-white shadow-sm'
            : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white');
      }
    };

    for (const opt of normalized) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.setAttribute('role', 'radio');
      btn.textContent = opt.label;
      btn.addEventListener('click', () => {
        if (selected === opt.value) return;
        selected = opt.value;
        apply();
        sync(true);
      });
      group.appendChild(btn);
      buttons.push({ btn, value: opt.value });
    }
    wrap.appendChild(group);
  }

  apply();
  sync(false);

  return {
    wrap,
    getValue: () => selected,
    setValue: (v) => {
      selected = v == null ? '' : String(v);
      apply();
      sync(false);
    },
  };
}
