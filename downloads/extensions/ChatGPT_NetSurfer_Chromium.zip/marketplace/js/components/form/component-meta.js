// Component metadata — pure data, no DOM. Read by the browser registry and by
// the API when it builds the builder config, so both sides cannot drift.
//
//   id / widget / label / whenToUse / requires / types / internal
//   inlineEditor  offered by the step card's inline field editor
//   aliases       other names callers still use for this component
//   directRender  the model page renders it as-is, without subtype detection
//   upload        takes a file; `mediaKind` names the kind a multi-upload emits
// See registry.js for what each field means and which factory draws it.

export const COMPONENT_META = [
  {
    id: 'input', widget: 'input', label: 'Single-line input',
    whenToUse: 'A short single-line value: a name, a number, a URL.',
    requires: [], types: ['string', 'number', 'integer'], inlineEditor: true, directRender: true,
  },
  {
    id: 'textarea', widget: 'textarea', label: 'Multi-line text',
    whenToUse: 'Free text longer than a line, like a description or a prompt.',
    requires: [], types: ['string'], inlineEditor: true, directRender: true,
  },
  {
    id: 'slider', widget: 'slider', label: 'Slider',
    whenToUse: 'A number inside a known min-max the user tunes by feel.',
    requires: ['range'], types: ['number', 'integer'], inlineEditor: true, directRender: true,
  },
  {
    id: 'select', widget: 'select', label: 'Dropdown',
    whenToUse: 'One value from a fixed list of more than four.',
    requires: ['enum'], types: ['string', 'number', 'integer'], inlineEditor: true, directRender: true,
  },
  {
    id: 'radio-group', widget: 'radio-group', label: 'Radio buttons',
    whenToUse: 'One value from two to four choices, all worth showing at once.',
    requires: ['enum'], types: ['string'], inlineEditor: true, directRender: true,
  },
  {
    id: 'agent-selector', widget: 'radio-group', label: 'Agent group (tabs)',
    whenToUse: 'Split one agent into modes the buyer picks between — Video / Image — where each mode runs a different agent.',
    requires: ['enum'], types: ['string'], inlineEditor: true, directRender: true,
    studioHidden: true,
    optional: [
      'selectorStyle — tab (side-by-side buttons, the default) or select (searchable dropdown).',
    ],
  },
  {
    id: 'toggle', widget: 'pill-toggle', label: 'On/off switch',
    whenToUse: 'An on/off choice.',
    requires: [], types: ['boolean'], inlineEditor: true, directRender: true,
  },
  {
    id: 'file-upload', widget: 'media', label: 'File upload',
    whenToUse: 'The user supplies an image, video or audio file.',
    requires: [], types: ['string', 'array'], inlineEditor: true, upload: true,
  },
  {
    id: 'json-input', widget: 'json', label: 'JSON editor',
    whenToUse: 'A whole object or array the user edits as raw JSON.',
    requires: [], types: ['object', 'array'], inlineEditor: true, aliases: ['json'], directRender: true,
  },
  {
    id: 'prompt-picker', widget: 'prompt-picker', label: 'Image picker (visual cards)',
    whenToUse: 'One value from a list where seeing each option matters more than reading it. Every value needs a real thumbnail.',
    requires: ['enum', 'optionImages'], types: ['string'],
  },
  {
    id: 'visual-picker', widget: 'visual-picker', label: 'Visual picker (modal grid + categories)',
    whenToUse: 'Like prompt-picker but too many options for one row, so they open in a modal grouped by category.',
    requires: ['enum', 'optionImages'], types: ['string'],
  },
  {
    id: 'asset-picker', widget: 'asset_picker', label: 'Asset picker (avatars, uploads, generations)',
    whenToUse: 'The better default for ANY single-file input: the user picks from their own library — ready-made avatars, earlier uploads, past generations — or uploads a new one. The value is the chosen file URL, wired like file-upload. Prefer file-upload only for files a library cannot hold, such as a document the user brings fresh each run; use the multi-upload components when the key takes a list, since this one is single-choice.',
    requires: [], types: ['string'], inlineEditor: true,
    optional: [
      'assetKind — image | video | audio; which files the tabs list. Defaults to image.',
      'assetSources — tabs to offer, in order: avatars, uploads, generations. Use all three for a character, face, avatar or presenter; drop avatars for anything not a person (a product shot, a photo to edit, a clip to process). Omit the key to offer every source that fits the kind.',
      'defaultSource — which tab opens first; must be one of the offered tabs, else the first is used.',
      'triggerLabel — text on the closed picker card, e.g. "Choose avatar".',
    ],
  },
  {
    id: 'interactive-prompt', widget: 'interactive_prompt', label: 'Interactive prompt (inline pills)',
    whenToUse: 'A sentence the user completes by picking each blank from a list.',
    requires: ['template', 'slotFields', 'assembledTarget'], types: ['string'], inlineEditor: true,
  },
  {
    id: 'multi-select', widget: 'multi_select', label: 'Multi-select (checkboxes in dropdown)',
    whenToUse: 'Several values from a fixed list.',
    requires: ['enum'], types: ['array'],
  },
  {
    id: 'editable-select', widget: 'editable_select', label: 'Editable select (typeable dropdown)',
    whenToUse: 'A fixed list that the user may also type past.',
    requires: ['enum'], types: ['string'],
  },
  {
    id: 'color-picker', widget: 'color-picker', label: 'Color picker (hex + HSV)',
    whenToUse: 'A colour, entered as hex.',
    requires: [], types: ['string'],
  },
  {
    id: 'image-pair', widget: 'image_pair', label: 'Image pair (start + end frames)',
    whenToUse: 'A start and an end image, such as first and last frame.',
    requires: [], types: ['object', 'array'],
  },
  {
    id: 'angle-picker', widget: 'angle_picker', label: 'Camera angle (3D sphere)',
    whenToUse: 'A camera angle the user sets by rotating a sphere.',
    requires: [], types: ['string', 'number'],
  },
  {
    id: 'light-sphere', widget: 'light_sphere', label: 'Light direction (sphere)',
    whenToUse: 'A light direction the user drags around the subject; emits a prompt-ready sentence.',
    requires: [], types: ['string'],
  },
  {
    id: 'pill-toggle', widget: 'pill-toggle', label: 'Pill toggle',
    whenToUse: 'One value from two or three options shown as segmented pill buttons.',
    requires: ['enum'], types: ['string'],
  },

  // Below: components the system draws but the builder does not offer.
  {
    id: 'voice-picker', widget: 'voice-picker', label: 'Voice picker',
    whenToUse: 'A voice, chosen after hearing a preview of each.',
    requires: ['enum'], types: ['string'], internal: true,
  },
  {
    id: 'multi-image', widget: 'multi_image', label: 'Multiple image upload',
    whenToUse: 'Several images in one field.',
    requires: [], types: ['array'], inlineEditor: true,
    aliases: ['multi-file-upload'], upload: true, mediaKind: 'image',
  },
  {
    id: 'multi-video', widget: 'multi_video', label: 'Multiple video upload',
    whenToUse: 'Several videos in one field.',
    requires: [], types: ['array'], inlineEditor: true,
    aliases: ['multi-file-upload-video'], upload: true, mediaKind: 'video',
  },
  {
    id: 'multi-audio', widget: 'multi_audio', label: 'Multiple audio upload',
    whenToUse: 'Several audio files in one field.',
    requires: [], types: ['array'], inlineEditor: true,
    aliases: ['multi-file-upload-audio'], upload: true, mediaKind: 'audio',
  },
  {
    id: 'frame-upload', widget: 'frame_upload', label: 'Frame upload',
    whenToUse: 'A first or last video frame.',
    requires: [], types: ['string', 'object'], internal: true,
  },
  {
    id: 'transition-picker', widget: 'transition_picker', label: 'Transition picker',
    whenToUse: 'A transition style between clips.',
    requires: ['enum'], types: ['string'], internal: true,
  },
  {
    id: 'checklist', widget: 'checklist', label: 'Checklist',
    whenToUse: 'Several values shown as a flat list of checkboxes.',
    requires: ['enum'], types: ['array'], internal: true,
  },
  {
    id: 'chip-group', widget: 'chip-group', label: 'Chip group',
    whenToUse: 'A few values shown as compact chips.',
    requires: ['enum'], types: ['string', 'array'], internal: true,
  },
  {
    id: 'pill-select', widget: 'pill_select', label: 'Pill select',
    whenToUse: 'One value from a short list shown as pill buttons.',
    requires: ['enum'], types: ['string'], internal: true,
  },
  {
    id: 'number', widget: 'number', label: 'Number input',
    whenToUse: 'A number with an explicit min, max and step.',
    requires: [], types: ['number', 'integer'], internal: true,
  },
  {
    id: 'checkbox', widget: 'checkbox', label: 'Checkbox',
    whenToUse: 'A single opt-in checkbox.',
    requires: [], types: ['boolean'], internal: true,
  },
  {
    id: 'consent', widget: 'consent', label: 'Consent',
    whenToUse: 'A confirmation the user must tick before running.',
    requires: [], types: ['boolean'], internal: true,
  },
  {
    id: 'button', widget: 'button', label: 'Button',
    whenToUse: 'An action button, not a value.',
    requires: [], types: [], internal: true,
  },
];

/** An entry by its id or by any alias a published doc still writes. */
export function componentEntry(id) {
  if (typeof id !== 'string' || !id) return undefined;
  return COMPONENT_META.find(c => c.id === id || c.aliases?.includes(id));
}

/** The media kind a multi-upload control emits; null for anything else. */
export function multiUploadKind(id) {
  const entry = componentEntry(id);
  return entry?.upload && entry.mediaKind && entry.types?.includes('array')
    ? entry.mediaKind
    : null;
}
