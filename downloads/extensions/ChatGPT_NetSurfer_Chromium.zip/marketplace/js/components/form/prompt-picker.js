// Inline grid of image cards, one per enum value (text pills when none has a
// thumbnail). x-uap.collapsible folds it; type "array" allows several picks.
import { optionLabelsFor, optionListOf } from './field-shape.js';
import { createHelpToggle } from '../../runner/overrides/ui-core.js';
import { thumbImage, thumbVideo } from '../../shared/media-thumb.js';

const CHEVRON = '<svg class="w-4 h-4 shrink-0 transition-transform" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7"/></svg>';

function buildThumb(imageUrl, labelText) {
  const thumb = document.createElement('div');
  thumb.className = 'relative w-full aspect-square bg-black/5 dark:bg-white/5';
  if (!imageUrl) return thumb; // caption below already carries the label
  // Authors drop either an image or a video URL into optionImages. Sniffing the
  // extension avoids a HEAD request that would block the first paint.
  const isVideo = /\.(mp4|webm|mov|m4v|ogv)(\?.*)?$/i.test(imageUrl);
  if (isVideo) {
    const video = document.createElement('video');
    video.src = thumbVideo(imageUrl, 0, '.form-picker-thumb');
    video.muted = true;
    video.loop = true;
    video.playsInline = true;
    video.autoplay = true;
    video.preload = 'metadata';
    video.className = 'form-picker-thumb absolute inset-0 w-full h-full object-cover';
    video.style.objectPosition = 'top';
    video.onerror = () => { video.remove(); };
    thumb.appendChild(video);
  } else {
    const img = document.createElement('img');
    img.src = thumbImage(imageUrl, 0, '.form-picker-thumb');
    img.alt = labelText;
    img.loading = 'lazy';
    img.className = 'form-picker-thumb absolute inset-0 w-full h-full object-cover';
    img.style.objectPosition = 'top';
    img.onerror = () => { img.remove(); };
    thumb.appendChild(img);
  }
  return thumb;
}

function defaultValues(propSchema, isMulti) {
  const d = propSchema?.default;
  if (d == null || d === '') return [];
  if (Array.isArray(d)) return d.map(String);
  if (!isMulti) return [String(d)];
  // Picks are saved joined by ", ", and a value may hold commas itself: take the longest run that is a value.
  const values = new Set((propSchema.enum || []).map(String));
  const parts = String(d).split(',').map(s => s.trim()).filter(Boolean);
  const out = [];
  for (let i = 0; i < parts.length;) {
    let j = parts.length;
    while (j > i + 1 && !values.has(parts.slice(i, j).join(', '))) j--;
    out.push(parts.slice(i, j).join(', '));
    i = j;
  }
  return out;
}

/** Schema property -> node plus the value it contributes. */
export function bindPromptPicker({ key, title, description, propSchema, isRequired, isReadOnly }) {
  const xuap = propSchema?.['x-uap'] && typeof propSchema['x-uap'] === 'object' ? propSchema['x-uap'] : {};
  const optionImages = optionListOf(xuap.optionImages, propSchema.enum);
  const labelFor = optionLabelsFor(propSchema);
  const isMulti = propSchema?.type === 'array';
  const maxSelect = isMulti && Number(xuap.maxSelect) > 0 ? Number(xuap.maxSelect) : (isMulti ? Infinity : 1);

  const options = propSchema.enum.map((rawValue, i) => ({
    value: String(rawValue),
    label: labelFor(rawValue, i),
    image: typeof optionImages[i] === 'string' ? optionImages[i] : '',
  }));
  const labelOf = (value) => options.find(o => o.value === value)?.label ?? value;
  const pillMode = options.every(o => !o.image);

  const selected = new Set(defaultValues(propSchema, isMulti).filter(v => options.some(o => o.value === v)));
  const serialize = () => (isMulti ? [...selected].join(', ') : ([...selected][0] || ''));

  const wrapper = document.createElement('div');
  wrapper.setAttribute('data-prompt-picker', key);
  // V2/V4 move card grids into popovers; a folded grid would arrive hidden.
  const shell = String(document.body?.dataset?.agentTemplate || '').toUpperCase();
  const collapsible = xuap.collapsible === true && shell !== 'V2' && shell !== 'V4';
  let open = !collapsible;

  const hiddenInput = document.createElement('input');
  hiddenInput.type = 'hidden';
  hiddenInput.name = key;
  hiddenInput.value = serialize();

  // ── header ──
  const header = document.createElement('div');
  header.className = 'mb-1.5 mt-1.5';
  const row = document.createElement('div');
  row.className = 'flex items-center gap-2 min-w-0';
  const hasTitle = !!(title && String(title).trim());
  let summaryEl = null;
  let toggleBtn = null;

  if (hasTitle) {
    const labelEl = document.createElement('label');
    labelEl.className = 'block text-sm font-medium truncate ml-2';
    labelEl.textContent = title;
    if (isRequired) {
      const star = document.createElement('span');
      star.className = 'text-red-500 ml-1';
      star.textContent = '*';
      labelEl.appendChild(star);
    }
    row.appendChild(labelEl);

    if (collapsible) {
      const count = document.createElement('span');
      count.className = 'text-xs text-muted-foreground tabular-nums shrink-0';
      count.textContent = `· ${options.length}`;
      row.appendChild(count);
    }

    const { trigger } = createHelpToggle({ idSeed: key, labelText: title, helpText: description });
    if (trigger) {
      wrapper.setAttribute('data-help-scope', '');
      row.appendChild(trigger);
    }
  }

  if (collapsible) {
    summaryEl = document.createElement('span');
    summaryEl.className = 'ml-auto text-xs text-muted-foreground truncate min-w-0';
    row.appendChild(summaryEl);

    toggleBtn = document.createElement('button');
    toggleBtn.type = 'button';
    toggleBtn.className = 'shrink-0 inline-flex items-center justify-center w-6 h-6 rounded-full text-muted-foreground hover:text-foreground';
    toggleBtn.setAttribute('aria-label', `Toggle ${title || key}`);
    toggleBtn.innerHTML = CHEVRON;
    toggleBtn.addEventListener('click', (e) => { e.preventDefault(); setOpen(!open); });
    row.appendChild(toggleBtn);
    row.classList.add('cursor-pointer', 'select-none');
    row.addEventListener('click', (e) => {
      if (e.target.closest('[data-help-trigger]') || e.target === toggleBtn || toggleBtn.contains(e.target)) return;
      setOpen(!open);
    });
  }
  header.appendChild(row);

  // ── grid ──
  const grid = document.createElement('div');
  grid.className = pillMode ? 'flex flex-wrap gap-2' : 'grid grid-cols-3 gap-2';
  // The template shells find card grids by this role.
  grid.setAttribute('role', 'radiogroup');
  if (isMulti) grid.setAttribute('aria-multiselectable', 'true');
  grid.setAttribute('aria-label', title || key);

  const cards = [];
  const applySelectionStyles = () => {
    for (const card of cards) {
      const isSel = selected.has(card.dataset.value);
      card.setAttribute('aria-checked', isSel ? 'true' : 'false');
      card.classList.toggle('ring-2', isSel);
      card.classList.toggle('ring-primary', isSel);
      card.classList.toggle('ring-offset-1', isSel);
      card.classList.toggle('border-primary', isSel);
    }
    if (summaryEl) {
      const labels = [...selected].map(labelOf);
      summaryEl.textContent = labels.length ? labels.join(', ') : '';
      summaryEl.title = summaryEl.textContent;
    }
  };

  const commit = () => {
    hiddenInput.value = serialize();
    applySelectionStyles();
    hiddenInput.dispatchEvent(new Event('change', { bubbles: true }));
  };

  const pick = (value) => {
    if (selected.has(value)) {
      if (isMulti || !isRequired) selected.delete(value);
    } else if (isMulti) {
      if (selected.size >= maxSelect) selected.delete([...selected][0]);
      selected.add(value);
    } else {
      selected.clear();
      selected.add(value);
    }
    commit();
  };

  for (const opt of options) {
    const card = document.createElement('button');
    card.type = 'button';
    card.dataset.value = opt.value;
    card.setAttribute('role', 'radio');
    card.setAttribute('aria-checked', 'false');
    card.title = opt.label;
    if (pillMode) {
      card.className =
        'inline-flex items-center rounded-full border border-black/10 dark:border-white/10 bg-white dark:bg-neutral-950 '
        + 'px-3 py-1.5 text-xs font-medium transition focus:outline-none focus:ring-2 focus:ring-primary '
        + 'hover:border-primary/60 cursor-pointer';
      card.textContent = opt.label;
    } else {
      card.className =
        'group relative flex flex-col items-stretch text-left rounded-ios-lg border border-black/10 dark:border-white/10 '
        + 'bg-white dark:bg-neutral-950 overflow-hidden transition focus:outline-none focus:ring-2 focus:ring-primary '
        + 'hover:border-primary/60 cursor-pointer';
      card.appendChild(buildThumb(opt.image, opt.label));

      const caption = document.createElement('div');
      caption.className = 'px-1.5 py-1 text-xs font-medium leading-tight line-clamp-2 text-center';
      caption.textContent = opt.label;
      card.appendChild(caption);
    }

    card.addEventListener('click', () => pick(opt.value));
    grid.appendChild(card);
    cards.push(card);
  }

  function setOpen(next) {
    open = !!next;
    grid.classList.toggle('hidden', !open);
    if (toggleBtn) {
      toggleBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
      toggleBtn.firstElementChild?.classList.toggle('rotate-180', open);
    }
  }
  setOpen(open || selected.size > 0);
  applySelectionStyles();

  if (isReadOnly) {
    for (const card of cards) {
      card.disabled = true;
      card.classList.add('pointer-events-none', 'opacity-60');
    }
  }

  if (hasTitle || collapsible) wrapper.appendChild(header);
  wrapper.appendChild(grid);
  wrapper.appendChild(hiddenInput);

  // Read by picked-settings.js.
  wrapper.__promptPicker = {
    key,
    title: title || key,
    isMulti,
    isRequired,
    getSelected: () => [...selected].map(v => ({ value: v, label: labelOf(v) })),
    // Same rules as a card click: a locked form keeps its picks, a required single pick cannot be emptied.
    remove: (value) => { if (!isReadOnly && (isMulti || !isRequired) && selected.delete(value)) commit(); },
    clear: () => { if (!isReadOnly && (isMulti || !isRequired) && selected.size) { selected.clear(); commit(); } },
    random: () => {
      if (isReadOnly || options.length === 0) return;
      selected.clear();
      selected.add(options[Math.floor(Math.random() * options.length)].value);
      commit();
    },
  };

  return {
    nodes: [wrapper],
    fields: [{
      key,
      kind: isMulti ? 'multi_select' : 'enum',
      required: isRequired,
      _getValue: () => (selected.size ? serialize() : undefined),
    }],
  };
}
