// Inline grid of image cards, one per enum value. Unlike visual-picker it has
// no modal and no category chips — every option is on screen at once.
import { optionLabelsFor, optionListOf } from './field-shape.js';
import { createHelpToggle } from '../../runner/overrides/ui-core.js';

/** Header the picker draws itself, since it is not built on a field factory. */
function buildHeader({ key, title, description, isRequired, scopeEl }) {
  if (!title || !String(title).trim()) return null;
  const header = document.createElement('div');
  header.className = 'mb-1.5 mt-1.5';
  const row = document.createElement('div');
  row.className = 'flex items-center';

  const labelEl = document.createElement('label');
  labelEl.className = 'block text-sm font-medium';
  labelEl.textContent = title;
  if (isRequired) {
    const star = document.createElement('span');
    star.className = 'text-red-500 ml-1';
    star.textContent = '*';
    labelEl.appendChild(star);
  }
  row.appendChild(labelEl);

  const { trigger } = createHelpToggle({ idSeed: key, labelText: title, helpText: description });
  if (trigger) {
    scopeEl?.setAttribute('data-help-scope', '');
    row.appendChild(trigger);
  }
  header.appendChild(row);
  return header;
}

function buildThumb(imageUrl, labelText) {
  const thumb = document.createElement('div');
  thumb.className = 'relative w-full aspect-square bg-black/5 dark:bg-white/5';
  if (!imageUrl) {
    const placeholder = document.createElement('div');
    placeholder.className = 'absolute inset-0 flex items-center justify-center text-xs text-gray-400';
    placeholder.textContent = labelText;
    thumb.appendChild(placeholder);
    return thumb;
  }
  // Authors drop either an image or a video URL into optionImages. Sniffing the
  // extension avoids a HEAD request that would block the first paint.
  const isVideo = /\.(mp4|webm|mov|m4v|ogv)(\?.*)?$/i.test(imageUrl);
  if (isVideo) {
    const video = document.createElement('video');
    video.src = imageUrl;
    video.muted = true;
    video.loop = true;
    video.playsInline = true;
    video.autoplay = true;
    video.preload = 'metadata';
    video.className = 'absolute inset-0 w-full h-full object-cover';
    video.onerror = () => { video.remove(); };
    thumb.appendChild(video);
  } else {
    const img = document.createElement('img');
    img.src = imageUrl;
    img.alt = labelText;
    img.loading = 'lazy';
    img.className = 'absolute inset-0 w-full h-full object-cover';
    img.onerror = () => { img.remove(); };
    thumb.appendChild(img);
  }
  return thumb;
}

/** Schema property -> node plus the value it contributes. */
export function bindPromptPicker({ key, title, description, propSchema, isRequired, isReadOnly }) {
  // Returned as separate nodes, not wrapped: the caller mounts them straight
  // into the field wrapper, keeping the DOM identical to the inline version.
  const nodes = [];

  const xuap = propSchema?.['x-uap'] && typeof propSchema['x-uap'] === 'object' ? propSchema['x-uap'] : {};
  const optionImages = optionListOf(xuap.optionImages, propSchema.enum);
  const labelFor = optionLabelsFor(propSchema);

  const grid = document.createElement('div');
  grid.className = 'grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5';
  grid.setAttribute('role', 'radiogroup');
  grid.setAttribute('aria-label', title || key);

  const hiddenInput = document.createElement('input');
  hiddenInput.type = 'hidden';
  hiddenInput.name = key;
  hiddenInput.value = propSchema?.default != null ? String(propSchema.default) : '';

  const cards = [];
  let selectedValue = hiddenInput.value || '';

  const applySelectionStyles = () => {
    for (const card of cards) {
      const isSel = card.dataset.value === selectedValue;
      card.setAttribute('aria-checked', isSel ? 'true' : 'false');
      card.classList.toggle('ring-2', isSel);
      card.classList.toggle('ring-primary', isSel);
      card.classList.toggle('ring-offset-1', isSel);
      card.classList.toggle('border-primary', isSel);
      card.classList.toggle('opacity-70', !isSel);
    }
  };

  propSchema.enum.forEach((rawValue, optionIndex) => {
    const value = String(rawValue);
    const labelText = labelFor(rawValue, optionIndex);
    const imageUrl = typeof optionImages[optionIndex] === 'string' ? optionImages[optionIndex] : '';

    const card = document.createElement('button');
    card.type = 'button';
    card.dataset.value = value;
    card.setAttribute('role', 'radio');
    card.setAttribute('aria-checked', 'false');
    card.className =
      'group relative flex flex-col items-stretch text-left rounded-ios-lg border border-black/10 dark:border-white/10 '
      + 'bg-white dark:bg-neutral-950 overflow-hidden transition focus:outline-none focus:ring-2 focus:ring-primary '
      + 'hover:border-primary/60 cursor-pointer';

    card.appendChild(buildThumb(imageUrl, labelText));

    const caption = document.createElement('div');
    caption.className = 'px-2 py-1.5 text-xs font-medium truncate';
    caption.textContent = labelText;
    card.appendChild(caption);

    card.addEventListener('click', () => {
      selectedValue = value;
      hiddenInput.value = value;
      applySelectionStyles();
      hiddenInput.dispatchEvent(new Event('change', { bubbles: true }));
    });

    grid.appendChild(card);
    cards.push(card);
  });

  if (!selectedValue && propSchema?.default != null) {
    selectedValue = String(propSchema.default);
    hiddenInput.value = selectedValue;
  }
  applySelectionStyles();

  if (isReadOnly) {
    for (const card of cards) {
      card.disabled = true;
      card.classList.add('pointer-events-none', 'opacity-60');
    }
  }

  const header = buildHeader({ key, title, description, isRequired, scopeEl: grid });
  if (header) nodes.push(header);
  nodes.push(grid, hiddenInput);

  return {
    nodes,
    fields: [{
      key,
      kind: 'enum',
      required: isRequired,
      _getValue: () => (selectedValue ? selectedValue : undefined),
    }],
  };
}
