/**
 * Visual picker component.
 *
 * A compact trigger card; clicking it opens a modal with a thumbnail grid.
 * With categories the modal gains a sidebar and the grid shows one
 * category at a time.
 *
 * Schema shape it consumes (passed through schema-form.js):
 *   x-uap.ui_component: "visual-picker"
 *   x-uap.triggerLabel: "Choose Style"        // closed card + modal title
 *   x-uap.optionImages: [imageUrl, ...]        // aligned with enum by index
 *   x-uap.optionLabels: ["Closeup", ...]
 *   x-uap.optionCategories: ["Product Shot", ...]   // optional, sidebar rows
 *   enum: [...]
 *
 * Older docs carry these as value-keyed objects; optionListOf normalises both.
 */
import { optionLabelsFor, optionListOf } from './field-shape.js';
import { ensurePickerModalStyles } from './picker-modal-styles.js';
import { updateFormData, createFieldLabel, createHelpToggle, FieldValidationError } from '../../runner/overrides/ui-core.js';

const VIDEO_EXT = /\.(mp4|webm|mov|m4v|ogv)(\?.*)?$/i;

function isVideoUrl(url) {
  return typeof url === 'string' && VIDEO_EXT.test(url);
}

const onScreen = typeof IntersectionObserver === 'function'
  ? new IntersectionObserver((entries) => {
    for (const { target: v, isIntersecting } of entries) {
      if (!isIntersecting) { v.pause(); continue; }
      if (v.dataset.src) { v.src = v.dataset.src; delete v.dataset.src; }
      v.play().catch(() => {});
    }
  })
  : null;

function makeThumb(imageUrl, alt, extraClass = '', { whenVisible = false } = {}) {
  if (!imageUrl) {
    const ph = document.createElement('div');
    ph.className = 'absolute inset-0 flex items-center justify-center text-xs text-gray-400 dark:text-gray-500';
    ph.textContent = alt || '';
    return ph;
  }
  if (isVideoUrl(imageUrl)) {
    const v = document.createElement('video');
    v.muted = true;
    v.loop = true;
    v.playsInline = true;
    if (whenVisible && onScreen) {
      v.dataset.src = imageUrl;
      v.preload = 'none';
      onScreen.observe(v);
    } else {
      v.src = imageUrl;
      v.autoplay = true;
      v.preload = 'metadata';
    }
    v.className = 'absolute inset-0 w-full h-full object-cover ' + extraClass;
    v.onerror = () => { v.remove(); };
    return v;
  }
  const img = document.createElement('img');
  img.src = imageUrl;
  img.alt = alt || '';
  img.loading = 'lazy';
  img.className = 'absolute inset-0 w-full h-full object-cover ' + extraClass;
  img.onerror = () => { img.remove(); };
  return img;
}

export function createVisualPickerField({
  label,
  id,
  required = false,
  help,
  options = [],
  defaultValue,
  triggerLabel = 'Choose Option',
} = {}) {
  ensurePickerModalStyles();
  const wrap = document.createElement('div');
  const fieldKey = id || label || 'visualPicker';
  if (id) wrap.setAttribute('data-id', id);
  wrap.setAttribute('data-component', 'visual-picker');

  /* ── optional header (label + help) ── */
  if (label) {
    const header = document.createElement('div');
    header.className = 'mb-2';
    const headerRow = document.createElement('div');
    headerRow.className = 'flex items-center';
    const labelEl = createFieldLabel(label, { required });
    labelEl.className = 'block text-[13px] font-medium';
    headerRow.appendChild(labelEl);
    const { trigger: helpTrigger } = createHelpToggle({ idSeed: label, labelText: label, helpText: help });
    if (helpTrigger) {
      wrap.setAttribute('data-help-scope', '');
      headerRow.appendChild(helpTrigger);
    }
    header.appendChild(headerRow);
    wrap.appendChild(header);
  }

  /* ── state ── */
  const normalizedOptions = options.map((o) => ({
    value: String(o.value ?? ''),
    label: String(o.label ?? o.value ?? ''),
    image: typeof o.image === 'string' ? o.image : '',
    category: typeof o.category === 'string' ? o.category : '',
  }));
  let selectedValue = defaultValue != null && normalizedOptions.some((o) => o.value === String(defaultValue))
    ? String(defaultValue)
    : '';

  /* ── trigger card ── */
  const trigger = document.createElement('button');
  trigger.type = 'button';
  trigger.className = [
    'group relative inline-flex items-center gap-3',
    'rounded-2xl border border-black/10 dark:border-white/[0.08]',
    'bg-white dark:bg-neutral-900',
    'p-1.5 pr-3 text-left',
    'hover:border-purple-300 dark:hover:border-purple-700/60',
    'transition-colors focus:outline-none focus:ring-2 focus:ring-primary/60',
  ].join(' ');
  trigger.setAttribute('aria-haspopup', 'dialog');
  trigger.setAttribute('aria-expanded', 'false');
  trigger.setAttribute('data-trigger', '');

  const triggerThumb = document.createElement('div');
  triggerThumb.className = 'relative w-12 h-12 rounded-xl overflow-hidden bg-black/5 dark:bg-white/5 flex-shrink-0 flex items-center justify-center';
  const triggerIcon = document.createElement('span');
  triggerIcon.innerHTML = '<svg class="w-5 h-5 text-gray-500 dark:text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 8V6a2 2 0 012-2h2M4 16v2a2 2 0 002 2h2m8-16h2a2 2 0 012 2v2m-4 12h2a2 2 0 002-2v-2M12 8v8m-4-4h8"/></svg>';
  triggerThumb.appendChild(triggerIcon);

  const triggerLabelEl = document.createElement('span');
  triggerLabelEl.className = 'text-[13px] font-medium text-gray-800 dark:text-gray-200 whitespace-nowrap';
  triggerLabelEl.textContent = triggerLabel;

  trigger.appendChild(triggerThumb);
  trigger.appendChild(triggerLabelEl);
  wrap.appendChild(trigger);

  /* ── error message ── */
  const errorEl = document.createElement('p');
  errorEl.className = 'mt-1 text-[11px] leading-normal text-red-500 dark:text-red-400 hidden';
  errorEl.setAttribute('role', 'alert');
  wrap.appendChild(errorEl);

  function refreshTrigger() {
    trigger.toggleAttribute('data-filled', !!selectedValue);
    if (!selectedValue) {
      triggerThumb.innerHTML = '';
      triggerThumb.appendChild(triggerIcon);
      triggerLabelEl.textContent = triggerLabel;
      return;
    }
    const opt = normalizedOptions.find((o) => o.value === selectedValue);
    if (!opt) return;
    for (const v of triggerThumb.querySelectorAll('video')) onScreen?.unobserve(v);
    triggerThumb.innerHTML = '';
    triggerThumb.appendChild(makeThumb(opt.image, opt.label, '', { whenVisible: true }));
    triggerLabelEl.textContent = opt.label;
  }
  refreshTrigger();

  /* ── modal ── */
  const overlay = document.createElement('div');
  overlay.className = 'avp-overlay';
  overlay.setAttribute('role', 'dialog');
  overlay.setAttribute('aria-modal', 'true');
  if (label) overlay.setAttribute('aria-label', label);

  const dialog = document.createElement('div');
  dialog.className = 'avp-dialog';

  const dialogHeader = document.createElement('div');
  dialogHeader.className = 'avp-head';
  const dialogTitle = document.createElement('h3');
  dialogTitle.className = 'avp-title';
  dialogTitle.textContent = triggerLabel || (label ? `Choose ${label}` : 'Choose Option');
  const dialogClose = document.createElement('button');
  dialogClose.type = 'button';
  dialogClose.setAttribute('aria-label', 'Close');
  dialogClose.className = 'avp-close';
  dialogClose.innerHTML = '<svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg>';
  dialogHeader.appendChild(dialogTitle);
  dialogHeader.appendChild(dialogClose);
  dialog.appendChild(dialogHeader);

  const body = document.createElement('div');
  body.className = 'avp-body';
  dialog.appendChild(body);

  /* ── sidebar: one row per category ── */
  const categories = [];
  for (const opt of normalizedOptions) {
    if (opt.category && !categories.some((c) => c.name === opt.category)) {
      categories.push({ name: opt.category });
    }
  }
  // Uncategorized options need a row too, or they can't be picked.
  if (categories.length && normalizedOptions.some((o) => !o.category)) categories.push({ name: 'Other' });
  const catOf = (o) => o.category || 'Other';
  const selectedOpt = normalizedOptions.find((o) => o.value === selectedValue);
  let activeCategory = (selectedOpt && categories.length && catOf(selectedOpt)) || (categories[0] && categories[0].name) || '';
  const catButtons = [];

  if (categories.length) {
    const side = document.createElement('nav');
    side.className = 'avp-side';
    side.setAttribute('aria-label', 'Categories');
    for (const cat of categories) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'avp-cat';
      btn.textContent = cat.name;
      btn.addEventListener('click', () => {
        activeCategory = cat.name;
        renderGrid();
      });
      side.appendChild(btn);
      catButtons.push({ name: cat.name, btn });
    }
    body.appendChild(side);
  }

  /* ── grid ── */
  const main = document.createElement('div');
  main.className = 'avp-main';
  const mainTitle = document.createElement('h4');
  mainTitle.className = 'avp-main-title';
  const gridScroll = document.createElement('div');
  gridScroll.className = 'avp-scroll';
  const grid = document.createElement('div');
  grid.className = 'avp-grid';
  grid.setAttribute('role', 'listbox');
  gridScroll.appendChild(grid);
  if (categories.length) main.appendChild(mainTitle);
  main.appendChild(gridScroll);
  body.appendChild(main);

  function makeCard(opt) {
    const card = document.createElement('button');
    card.type = 'button';
    card.className = 'avp-card';
    card.dataset.value = opt.value;
    card.setAttribute('role', 'option');
    card.setAttribute('aria-selected', opt.value === selectedValue ? 'true' : 'false');

    const thumbWrap = document.createElement('div');
    thumbWrap.className = 'avp-thumb';
    thumbWrap.appendChild(makeThumb(opt.image, opt.label));
    card.appendChild(thumbWrap);

    const caption = document.createElement('div');
    caption.className = 'avp-cap';
    caption.textContent = opt.label;
    caption.title = opt.label;
    card.appendChild(caption);

    card.addEventListener('click', () => {
      const unpick = selectedValue === opt.value;
      selectedValue = unpick ? '' : opt.value;
      updateFormData(fieldKey, selectedValue || undefined);
      refreshTrigger();
      clearError();
      syncSelected();
      wrap.dispatchEvent(new CustomEvent('visual-picker:change', { bubbles: true, detail: { value: selectedValue } }));
      if (!unpick) closeModal({ delay: 240 });
    });
    return card;
  }

  const cardCache = new Map();
  function cardsFor(category) {
    if (!cardCache.has(category)) {
      const options = categories.length ? normalizedOptions.filter((o) => catOf(o) === category) : normalizedOptions;
      cardCache.set(category, options.map(makeCard));
    }
    return cardCache.get(category);
  }
  function syncSelected() {
    for (const cards of cardCache.values()) {
      for (const c of cards) c.setAttribute('aria-selected', c.dataset.value === selectedValue ? 'true' : 'false');
    }
  }

  function renderGrid() {
    for (const c of catButtons) c.btn.classList.toggle('is-active', c.name === activeCategory);
    mainTitle.textContent = activeCategory;
    grid.replaceChildren(...cardsFor(activeCategory));
    syncSelected();
    for (const v of grid.querySelectorAll('video')) if (v.paused) v.play().catch(() => {});
  }

  overlay.appendChild(dialog);

  /* ── open/close ── */
  let lastFocus = null;

  let closeTimer = null;
  function openModal() {
    if (!overlay.isConnected) document.body.appendChild(overlay);
    clearTimeout(closeTimer);
    overlay.classList.remove('is-closing');
    lastFocus = document.activeElement;
    const current = normalizedOptions.find((o) => o.value === selectedValue);
    if (current && categories.length) activeCategory = catOf(current);
    overlay.classList.add('is-open');
    document.body.style.overflow = 'hidden';
    trigger.setAttribute('aria-expanded', 'true');
    renderGrid();
    dialogClose.focus();
  }

  const CLOSE_MS = 340;
  /** `delay` lets a pick show its check before easing out. */
  function closeModal({ delay = 0 } = {}) {
    if (!overlay.classList.contains('is-open') || overlay.classList.contains('is-closing')) return;
    clearTimeout(closeTimer);
    const ease = () => {
      overlay.classList.add('is-closing');
      closeTimer = setTimeout(() => {
        overlay.classList.remove('is-open', 'is-closing');
        overlay.remove();
        document.body.style.overflow = '';
        trigger.setAttribute('aria-expanded', 'false');
        if (lastFocus && typeof lastFocus.focus === 'function') lastFocus.focus();
      }, CLOSE_MS);
    };
    if (delay > 0) closeTimer = setTimeout(ease, delay); else ease();
  }

  trigger.addEventListener('click', openModal);
  dialogClose.addEventListener('click', closeModal);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) closeModal(); });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && overlay.classList.contains('is-open')) closeModal();
  });

  /* ── form data sync ── */
  if (selectedValue) updateFormData(fieldKey, selectedValue);

  function setError(message) {
    if (!message) {
      errorEl.textContent = '';
      errorEl.classList.add('hidden');
      trigger.classList.remove('border-red-400', 'dark:border-red-500');
      return;
    }
    errorEl.textContent = String(message);
    errorEl.classList.remove('hidden');
    trigger.classList.add('border-red-400', 'dark:border-red-500');
  }

  function clearError() { setError(''); }

  const api = {
    wrap,
    getValue: () => selectedValue,
    setValue: (v) => {
      const next = v == null ? '' : String(v);
      if (next && !normalizedOptions.some((o) => o.value === next)) return;
      selectedValue = next;
      refreshTrigger();
      if (next) clearError();
      updateFormData(fieldKey, selectedValue);
      wrap.dispatchEvent(new CustomEvent('visual-picker:change', { bubbles: true, detail: { value: selectedValue } }));
    },
    setError,
    clearError,
  };
  // Read by page templates.
  wrap.visualPicker = { options: normalizedOptions.map((o) => ({ ...o })), getValue: api.getValue, setValue: api.setValue };
  return api;
}

/** Schema property -> node plus the value it contributes. Options come from
 *  x-uap: an image, a label and a category per enum value. */
export function bindVisualPickerField({
  key, title, description, propSchema, isRequired, isReadOnly, entry = {},
}) {
  const xuap = propSchema?.['x-uap'] && typeof propSchema['x-uap'] === 'object' ? propSchema['x-uap'] : {};
  const optionImages = optionListOf(xuap.optionImages, propSchema.enum);
  const optionCategories = optionListOf(xuap.optionCategories, propSchema.enum);
  const labelFor = optionLabelsFor(propSchema, entry);
  const triggerLabel = typeof entry.triggerLabel === 'string' && entry.triggerLabel
    ? entry.triggerLabel
    : (typeof xuap.triggerLabel === 'string' && xuap.triggerLabel ? xuap.triggerLabel : `Choose ${title}`);

  const options = propSchema.enum.map((rawValue, i) => ({
    value: String(rawValue),
    label: labelFor(rawValue, i),
    image: typeof optionImages[i] === 'string' ? optionImages[i] : '',
    category: typeof optionCategories[i] === 'string' ? optionCategories[i] : '',
  }));

  const picker = createVisualPickerField({
    label: title, id: key, required: isRequired, help: description, options,
    defaultValue: propSchema?.default != null ? String(propSchema.default) : undefined,
    triggerLabel,
  });
  if (isReadOnly) picker.wrap.classList.add('opacity-75', 'pointer-events-none');

  return {
    node: picker.wrap,
    replaces: true,
    fields: [{
      key, kind: 'enum', required: isRequired,
      setError: picker.setError, clearError: picker.clearError,
      _getValue: () => {
        const v = picker.getValue();
        if (isRequired && !v) throw new FieldValidationError(key, `Please select ${title.toLowerCase()}`);
        return v;
      },
    }],
  };
}
