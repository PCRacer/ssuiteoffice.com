// The catalog `list` field: an array of objects drawn as one row per item, each
// row field with the component its own schema asks for. schema-form,
// embed-runner and the builder's step editor all draw it from here.
import { createFieldLabel, createHelpToggle, updateFormData, FieldValidationError } from '../../runner/overrides/ui-core.js';
import { bindCheckboxField } from './checkbox.js';
import { bindNumberField } from './number-input.js';
import { bindSliderField } from './slider.js';
import { bindTextAreaField } from './textarea.js';
import { bindTextInputField } from './text-input.js';
import { bindJsonField } from './json-input.js';
import { bindEnumField } from './select.js';
import { bindMediaField } from './media-upload.js';
import { bindMultiMediaUploadField } from './multi-media-upload.js';
import { normalizeMediaKind } from './field-shape.js';
import { guessMediaKind } from '../../shared/media.js';

const isPlainObject = (v) => v != null && typeof v === 'object' && !Array.isArray(v);
const humanize = (s) => String(s || '').replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
// Normalized schemas keep `integer` in _raw.
export const typeOf = (sub) => (sub?._raw?.type === 'integer' ? 'integer' : sub?.type);

export function uploadKindOf(name, sub) {
  const accept = String(sub.ui?.accept || '');
  const format = sub.format || sub.items?.format;
  // A normalized field names its component; a hand-written one only has a format.
  const upload = sub.ui?.component ? sub.ui.component === 'file-upload' : ['uri', 'image', 'video', 'audio'].includes(format);
  if (!upload) return null;
  return normalizeMediaKind(format) || normalizeMediaKind(accept.split('/')[0])
    || guessMediaKind(name, { ...sub, type: 'string' }) || 'image';
}

/** A saved value as rows: an array, or the JSON text the old editor stored. null = not rows. */
export function parseRows(value) {
  if (value == null || value === '') return [];
  let rows = value;
  if (typeof rows === 'string') {
    try { rows = JSON.parse(rows); } catch { return null; }
  }
  return Array.isArray(rows) && rows.every(isPlainObject) ? rows : null;
}

// `placeholder` (a host that wires `${field}` references) lets any row field hold one.
function fits(sub, v, placeholder) {
  if (v === null) return false;
  if (placeholder && typeof v === 'string' && placeholder.test(v)) return true;
  if (Array.isArray(sub.enum) && sub.enum.length) return sub.enum.some((e) => e === v);
  const type = typeOf(sub);
  if (type === 'number' || type === 'integer') return typeof v === 'number';
  if (type === 'boolean') return typeof v === 'boolean';
  if (type === 'array') return Array.isArray(v);
  if (type === 'object') return isPlainObject(v);
  return typeof v === 'string';
}

/** An array-of-objects field labelled `list`. A saved value its rows cannot hold
 *  keeps the JSON editor, so opening a form never drops data. */
export function isListField(propSchema, value = propSchema?.default, { placeholder } = {}) {
  const p = propSchema || {};
  const props = p.items?.properties;
  if (p.type !== 'array' || !isPlainObject(props)) return false;
  if (p.ui?.component !== 'list' && p['x-uap']?.ui_component !== 'list') return false;
  const rows = parseRows(value);
  return rows !== null && rows.every((row) => Object.entries(row).every(([k, v]) => props[k] && fits(props[k], v, placeholder)));
}

/** True when a row has an upload field, which needs an async read. */
export function listNeedsUploads(propSchema) {
  return Object.entries(propSchema.items.properties).some(([name, sub]) => uploadKindOf(name, sub));
}

function bindRuntimeField(name, sub, args) {
  const type = typeOf(sub);
  const kind = uploadKindOf(name, sub);
  if (kind) return type === 'array' ? bindMultiMediaUploadField({ ...args, kind }) : bindMediaField({ ...args, mediaKind: kind });
  if (Array.isArray(sub.enum) && sub.enum.length) return bindEnumField(args);
  if (type === 'boolean') return bindCheckboxField(args);
  if (type === 'number' || type === 'integer') {
    if (sub.ui?.component !== 'slider' || sub.minimum == null || sub.maximum == null) return bindNumberField({ ...args, type });
    // A whole-number step would snap a saved 0.8 to 1.
    const propSchema = type === 'number' && sub.multipleOf == null ? { ...sub, multipleOf: 'any' } : sub;
    return bindSliderField({ ...args, type, propSchema });
  }
  if (type === 'array' || type === 'object') return bindJsonField({ ...args, type });
  return (sub.ui?.component === 'textarea' ? bindTextAreaField : bindTextInputField)(args);
}

// One runtime field's value; `draft` reads without waiting on uploads.
function readRuntimeField(f, draft) {
  switch (f.kind) {
    case 'media': return draft ? (f.urlInput.value.trim() || undefined) : f._mediaFieldGetValue();
    case 'multi_media': return draft ? undefined : f._getValue();
    case 'enum': {
      const raw = f._getValue();
      if (!raw) return undefined;
      try { return JSON.parse(raw); } catch { return raw; }
    }
    case 'number': {
      const n = f._getNumber();
      return n === undefined ? undefined : (f.integer ? Math.trunc(n) : n);
    }
    case 'boolean': return f._getValue();
    case 'json': {
      if (!draft) return f._getValue();
      try { return f._getValue(); } catch { return undefined; }
    }
    default: return f._getValue() || undefined;
  }
}

/** The runner's own components as a row field: { nodes, read(draft) }. */
function runtimeRowField(name, sub, args) {
  const bound = bindRuntimeField(name, sub, args);
  const field = bound.fields[0];
  return { nodes: bound.nodes ?? [bound.node], read: (draft) => readRuntimeField(field, draft) };
}

/**
 * `rowField(name, sub, args)` draws one row field as { node | nodes, read(draft) };
 * by default the runner's components. `onChange(value, { emptyRows })` hears every
 * edit; by default the value goes to agent_form_data, which pricing reads.
 * `emptyRows` adds rows a host re-render would lose (added, not filled in yet);
 * `summary(value)` is a line shown under the rows.
 */
export function bindListField({
  key, title, description, propSchema, isRequired, isReadOnly,
  value = propSchema.default, rowField = runtimeRowField, onChange, emptyRows = 0, summary,
}) {
  const itemProps = propSchema.items.properties;
  const itemRequired = propSchema.items.required || [];
  const maxItems = Number.isFinite(propSchema.maxItems) ? propSchema.maxItems : Infinity;
  const itemLabel = (title || humanize(propSchema.title || key)).replace(/s$/, '');
  const rows = [];
  let nextId = 0;

  const wrap = document.createElement('div');
  wrap.className = 'w-full min-w-0';
  wrap.setAttribute('data-id', key);
  wrap.setAttribute('data-component', 'list');
  if (title) {
    const header = document.createElement('div');
    header.className = 'mb-2 mt-2 flex items-center';
    const labelEl = createFieldLabel(title, { required: isRequired });
    labelEl.className = 'block text-sm font-medium mx-2';
    header.appendChild(labelEl);
    const { trigger } = createHelpToggle({ idSeed: key, labelText: title, helpText: description });
    if (trigger) {
      wrap.setAttribute('data-help-scope', '');
      header.appendChild(trigger);
    }
    wrap.appendChild(header);
  }
  const list = document.createElement('div');
  list.className = 'space-y-3';
  const addBtn = document.createElement('button');
  addBtn.type = 'button';
  addBtn.className = 'mt-2 text-[13px] font-medium px-3 py-2 rounded-xl bg-panel-input border border-panel-border '
    + 'hover:bg-panel-hover transition-colors disabled:opacity-50 disabled:cursor-not-allowed';
  addBtn.textContent = `+ Add ${itemLabel}`;
  const errorEl = document.createElement('p');
  errorEl.className = 'mt-1 text-[11px] leading-normal text-red-500 dark:text-red-400 hidden';
  errorEl.setAttribute('role', 'alert');
  const summaryEl = document.createElement('p');
  summaryEl.className = 'mt-2 text-[11px] leading-normal text-muted-foreground';
  summaryEl.hidden = true;
  wrap.append(list, summaryEl, addBtn, errorEl);

  const setError = (message) => {
    errorEl.textContent = message || '';
    errorEl.classList.toggle('hidden', !message);
  };

  // A row the user added counts once touched. A loaded row keeps its keys in
  // their order and gains only the ones the user changed, so an unedited form
  // saves exactly what it loaded.
  const rowValue = (row, values) => {
    if (!row.base && !row.touched) return null;
    const out = {};
    for (const name of new Set([...Object.keys(row.base || {}), ...Object.keys(values)])) {
      const v = values[name];
      if (v === undefined) continue;
      if (row.base && !(name in row.base) && JSON.stringify(v) === JSON.stringify(row.initial[name])) continue;
      out[name] = v;
    }
    return Object.keys(out).length > 0 ? out : null;
  };
  const readDraft = (row) => Object.fromEntries(
    Object.entries(row.fields).map(([name, f]) => [name, f.read(true)]));

  const getDraft = () => {
    const out = rows.map((row) => rowValue(row, readDraft(row))).filter(Boolean);
    return out.length > 0 ? out : undefined;
  };

  const showSummary = (draft) => {
    summaryEl.textContent = (summary && summary(draft)) || '';
    summaryEl.hidden = !summaryEl.textContent;
  };

  const emit = () => {
    const draft = getDraft();
    showSummary(draft);
    if (onChange) { onChange(draft, { emptyRows: rows.filter((row) => !rowValue(row, readDraft(row))).length }); return; }
    const data = typeof window !== 'undefined' ? window.agent_form_data : null;
    // Row widgets write their own keys (`${key}.0.prompt`); only the list's value belongs in the form data.
    if (data) for (const k of Object.keys(data)) if (k.startsWith(`${key}.`)) delete data[k];
    updateFormData(key, draft);
  };

  const renumber = () => {
    rows.forEach((row, i) => {
      row.titleEl.textContent = `${itemLabel} ${i + 1}`;
      row.removeBtn.setAttribute('aria-label', `Remove ${itemLabel} ${i + 1}`);
    });
    addBtn.disabled = isReadOnly || rows.length >= maxItems;
  };

  const addRow = (base) => {
    const id = nextId++;
    const item = document.createElement('div');
    item.dataset.listItem = String(id);
    item.className = 'space-y-3 p-3 rounded-2xl border border-panel-border';
    const head = document.createElement('div');
    head.className = 'flex items-center justify-between text-xs font-semibold text-muted-foreground';
    const titleEl = document.createElement('span');
    const removeBtn = document.createElement('button');
    removeBtn.type = 'button';
    removeBtn.className = 'text-red-500 hover:text-red-600 disabled:opacity-50';
    removeBtn.textContent = 'Remove';
    removeBtn.disabled = !!isReadOnly;
    head.append(titleEl, removeBtn);
    item.appendChild(head);

    const row = { item, titleEl, removeBtn, base: base || null, touched: false, fields: {}, initial: {} };
    for (const [name, sub] of Object.entries(itemProps)) {
      const rowSchema = base && name in base ? { ...sub, default: base[name] } : sub;
      const field = rowField(name, rowSchema, {
        key: `${key}.${id}.${name}`, title: humanize(sub.title || name), description: sub.description || '',
        propSchema: rowSchema, isRequired: itemRequired.includes(name), isReadOnly,
      });
      for (const node of field.nodes ?? [field.node]) {
        // Not a form field of its own: templates and model sync look fields up by data-id.
        node.removeAttribute?.('data-id');
        item.appendChild(node);
      }
      row.fields[name] = field;
    }
    row.initial = readDraft(row);
    for (const type of ['input', 'change', 'click']) item.addEventListener(type, () => { row.touched = true; });
    removeBtn.onclick = () => {
      item.remove();
      rows.splice(rows.indexOf(row), 1);
      renumber();
      emit();
    };
    rows.push(row);
    list.appendChild(item);
    renumber();
  };

  addBtn.onclick = () => {
    if (rows.length >= maxItems) return;
    addRow(null);
    emit();
  };
  // Clicks settle chip groups a tick later.
  wrap.addEventListener('input', emit);
  wrap.addEventListener('change', emit);
  wrap.addEventListener('click', () => setTimeout(emit, 0));

  const load = (next) => {
    for (const row of rows.splice(0)) row.item.remove();
    for (const base of parseRows(next) || []) addRow(base);
    renumber();
  };
  load(value);
  for (let i = 0; i < emptyRows && rows.length < maxItems; i++) addRow(null);
  // A host with its own onChange hears edits only: opening a form changes nothing.
  if (!onChange) emit();
  else showSummary(getDraft());
  wrap.listField = { setValue: (next) => { load(next); emit(); } };

  async function getValue() {
    const out = [];
    for (const [i, row] of rows.entries()) {
      if (!row.base && !row.touched) continue;
      const values = {};
      for (const [name, f] of Object.entries(row.fields)) {
        try {
          values[name] = await f.read(false);
        } catch (err) {
          throw new FieldValidationError(key, `${itemLabel} ${i + 1}: ${err?.message || 'invalid value'}`);
        }
      }
      const value = rowValue(row, values);
      if (!value) continue;
      const missing = itemRequired.find((name) => value[name] === undefined);
      if (missing) {
        throw new FieldValidationError(key, `${itemLabel} ${i + 1}: fill in ${humanize(itemProps[missing].title || missing)}`);
      }
      out.push(value);
    }
    return out.length > 0 ? out : undefined;
  }

  return {
    node: wrap,
    replaces: true,
    fields: [{ key, kind: 'list', required: isRequired, _getValue: getValue, setError }],
  };
}
