import { acceptForKind } from '../../shared/media.js';
/**
 * Textarea field component.
 * Renders a multi-line text input with label.
 */
import { updateFormData, createFieldLabel, createHelpToggle } from '../../runner/overrides/ui-core.js';

export function createTextAreaField({
  label,
  id,
  required = false,
  placeholder = '',
  rows = 6,
  help,
  defaultValue = '',
} = {}) {
  const wrap = document.createElement('div');
  const fieldKey = id || label || 'textarea';
  if (id) wrap.setAttribute('data-id', id);
  wrap.setAttribute('data-component', 'textarea');

  if (label && String(label).trim()) {
    const header = document.createElement('div');
    header.className = 'mb-2';
    const row = document.createElement('div');
    row.className = 'flex items-center';
    const labelEl = createFieldLabel(label, { required });
    labelEl.className = 'block text-sm font-medium mx-2';
    row.appendChild(labelEl);
    const { trigger } = createHelpToggle({ idSeed: label, labelText: label, helpText: help });
    if (trigger) {
      wrap.setAttribute('data-help-scope', '');
      row.appendChild(trigger);
    }
    header.appendChild(row);
    wrap.appendChild(header);
  }

  const card = document.createElement('div');
  card.className = 'rounded-xl bg-panel-input border border-panel-border p-4 transition-colors';

  const textarea = document.createElement('textarea');
  textarea.rows = rows;
  textarea.placeholder = placeholder || 'Type your prompt here...';
  textarea.className =
    'block w-full text-[13px] bg-transparent border-0 p-0 resize-none text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500';
  textarea.style.outline = 'none';
  textarea.style.boxShadow = 'none';
  if (required) textarea.required = true;
  if (defaultValue) textarea.value = String(defaultValue);

  // Sync to global form data (keep empty string as-is for consistency)
  const syncToGlobal = () => updateFormData(fieldKey, textarea.value.trim());
  textarea.addEventListener('input', syncToGlobal);
  textarea.addEventListener('change', syncToGlobal);
  syncToGlobal(); // Initial sync

  card.appendChild(textarea);
  wrap.appendChild(card);

  const errorEl = document.createElement('p');
  errorEl.className = 'mt-1 text-[11px] leading-normal text-red-500 dark:text-red-400 hidden';
  errorEl.setAttribute('role', 'alert');
  wrap.appendChild(errorEl);

  function setError(message) {
    if (!message) {
      errorEl.textContent = '';
      errorEl.classList.add('hidden');
      card.style.outline = '';
      return;
    }
    errorEl.textContent = String(message);
    errorEl.classList.remove('hidden');
    card.style.outline = '1.5px solid #f87171';
    card.style.outlineOffset = '-1px';
  }

  function clearError() {
    setError('');
  }

  textarea.addEventListener('input', clearError);

  return {
    wrap,
    textarea,
    getValue: () => textarea.value,
    getTrimmed: () => textarea.value.trim(),
    setValue: (v) => { textarea.value = v == null ? '' : String(v); syncToGlobal(); },
    setError,
    clearError,
  };
}

/** Schema property -> node plus the value it contributes. */
export function bindTextAreaField({ key, title, description, propSchema, isRequired, isReadOnly }) {
  const field = createTextAreaField({
    label: title, id: key, required: isRequired,
    placeholder: propSchema?.examples?.[0] || '',
    rows: 5, help: description,
    defaultValue: propSchema?.default != null ? String(propSchema.default) : '',
  });
  if (isReadOnly) {
    field.wrap.classList.add('opacity-75');
    field.textarea.readOnly = true;
  }
  return {
    node: field.wrap,
    replaces: true,
    fields: [{
      key, kind: 'string', required: isRequired,
      input: field.textarea, _getValue: field.getTrimmed, setError: field.setError,
    }],
  };
}

/** A base64 field: the textarea plus a file input that fills it. */
export function bindBase64Field({ key, title, description, propSchema, isRequired, isReadOnly, mediaKind }) {
  const kindForLimits = mediaKind || 'image';
  const field = createTextAreaField({
    label: title, id: key, required: isRequired,
    placeholder: 'data:...;base64,... or raw base64',
    rows: 4, help: description,
    defaultValue: propSchema?.default != null ? String(propSchema.default) : '',
  });

  const fileInput = document.createElement('input');
  fileInput.type = 'file';
  fileInput.accept = acceptForKind(kindForLimits);
  fileInput.className =
    'block w-full text-sm file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:bg-primary/90 file:text-white file:cursor-pointer '
    + 'bg-white dark:bg-neutral-950 border border-black/10 dark:border-white/10 rounded-ios-lg p-2 mb-2';

  const insertTarget = field.textarea?.parentNode || field.wrap;
  insertTarget.insertBefore(fileInput, field.textarea);

  if (isReadOnly) {
    field.wrap.classList.add('opacity-75');
    fileInput.disabled = true;
    field.textarea.readOnly = true;
  }

  return {
    node: field.wrap,
    replaces: true,
    fields: [{
      key, kind: 'base64', required: isRequired,
      mediaKind: kindForLimits, fileInput, base64Input: field.textarea,
    }],
  };
}
