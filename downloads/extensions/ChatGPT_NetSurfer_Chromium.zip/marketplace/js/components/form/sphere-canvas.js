/**
 * Shared wireframe-sphere stage for the camera angle picker and the light sphere.
 * The stage owns the canvas, chevrons, drag and theme; each component paints its own marker.
 */
import { createFieldLabel, createHelpToggle, onAgentFormDataChange } from '../../runner/overrides/ui.js';
import { createReferenceImageLoader } from './camera-canvas.js';

export const DEG = Math.PI / 180;
export const TWO_PI = Math.PI * 2;

/** Returns a check that stays true until `el` has been mounted and then removed; runs `teardown` once. */
export function whileConnected(el, teardown) {
  let mounted = false;
  return () => {
    if (el.isConnected) { mounted = true; return true; }
    if (!mounted) return true;
    mounted = false;
    teardown();
    return false;
  };
}

export function isDark() {
  return document.documentElement.classList.contains('dark');
}

export function appendFieldHeader(wrap, { label, required, help }) {
  if (!label || !String(label).trim()) return;
  const header = document.createElement('div');
  header.className = 'mb-3';
  const row = document.createElement('div');
  row.className = 'flex items-center';
  const labelEl = createFieldLabel(String(label), { required });
  labelEl.className = 'block text-[13px] font-semibold mx-2';
  row.appendChild(labelEl);
  const { trigger } = createHelpToggle({ idSeed: label, labelText: label, helpText: help });
  if (trigger) { wrap.setAttribute('data-help-scope', ''); row.appendChild(trigger); }
  header.appendChild(row);
  wrap.appendChild(header);
}

export function appendErrorSlot(wrap) {
  const errorEl = document.createElement('p');
  errorEl.className = 'mt-1 text-[11px] leading-normal text-red-500 dark:text-red-400 hidden';
  errorEl.setAttribute('role', 'alert');
  wrap.appendChild(errorEl);
  return function setError(msg) {
    if (!msg) { errorEl.textContent = ''; errorEl.classList.add('hidden'); return; }
    errorEl.textContent = String(msg);
    errorEl.classList.remove('hidden');
  };
}

/** Loads the form's reference image (imageUrl / image_url / first upload) and reports it. */
export function watchFormImage(wrap, onImage) {
  const loader = createReferenceImageLoader(onImage);
  function load() {
    const fd = window.agent_form_data;
    if (!fd) return;
    let raw = fd.imageUrl || fd.image_url || fd.image || fd.url;
    if (typeof raw === 'string') { try { raw = JSON.parse(raw); } catch { /* keep */ } }
    if (!raw) {
      const imgField = wrap.closest?.('form')?.querySelector?.('[data-component="file-upload"] img[src], [data-id="imageUrl"] img, [data-id="image"] img');
      if (imgField?.src) raw = imgField.src;
    }
    const isUrl = typeof raw === 'string' && (raw.startsWith('http') || raw.startsWith('blob:') || raw.startsWith('data:'));
    if (isUrl) loader.load(raw);
    else if (!raw) loader.load('');
  }
  onAgentFormDataChange(() => load());
  requestAnimationFrame(() => {
    load();
    const form = wrap.closest?.('form') || wrap.parentElement;
    if (!form) return;
    const formObs = new MutationObserver(() => { if (alive()) load(); });
    const alive = whileConnected(wrap, () => formObs.disconnect());
    formObs.observe(form, { subtree: true, childList: true, attributes: true, attributeFilter: ['src', 'value'] });
  });
}

/** Draws the reference image (or a placeholder) as a rounded square at the sphere centre. */
export function drawSubject(ctx, { cx, cy, R, dk }, img, scale, shade) {
  const size = R * 0.8 * scale;
  const x = cx - size / 2;
  const y = cy - size / 2;
  const radius = 12;
  if (img) {
    ctx.save();
    ctx.beginPath();
    ctx.roundRect(x, y, size, size, radius);
    ctx.clip();
    const fit = Math.max(size / img.naturalWidth, size / img.naturalHeight);
    const dw = img.naturalWidth * fit;
    const dh = img.naturalHeight * fit;
    ctx.drawImage(img, cx - dw / 2, cy - dh / 2, dw, dh);
    shade?.(ctx, x, y, size);
    ctx.restore();
    ctx.strokeStyle = dk ? 'rgba(255,255,255,0.12)' : 'rgba(0,0,0,0.1)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.roundRect(x, y, size, size, radius);
    ctx.stroke();
  } else {
    ctx.fillStyle = dk ? '#252729' : '#dde3ed';
    ctx.beginPath();
    ctx.roundRect(x, y, size, size, radius);
    ctx.fill();
    ctx.strokeStyle = dk ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.06)';
    ctx.lineWidth = 1;
    ctx.stroke();
  }
}

export function drawCaption(ctx, { cx, cy, R, dk }, text) {
  ctx.fillStyle = dk ? 'rgba(255,255,255,0.25)' : 'rgba(0,0,0,0.25)';
  ctx.font = '500 10px system-ui, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText(text, cx, cy + R + 22);
}

function drawGreatCircle(ctx, cx, cy, R, angle, type) {
  ctx.beginPath();
  if (type === 'vertical') {
    const squeeze = Math.abs(Math.cos(angle));
    ctx.ellipse(cx, cy, Math.max(R * squeeze, 0.5), R, 0, 0, TWO_PI);
  } else {
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(angle);
    ctx.beginPath();
    ctx.ellipse(0, 0, R, R * 0.35, 0, 0, TWO_PI);
    ctx.restore();
  }
  ctx.stroke();
}

const chevronColor = (hover) => (isDark() ? `rgba(255,255,255,${hover ? 0.65 : 0.35})` : `rgba(0,0,0,${hover ? 0.6 : 0.35})`);

function makeChevron(dir) {
  const btn = document.createElement('button');
  btn.type = 'button';
  btn.className = 'absolute flex items-center justify-center w-8 h-8 rounded-full transition-colors';
  btn.setAttribute('data-chevron', dir);
  btn.style.cssText = `color:${chevronColor(false)};background:transparent;`;
  const paths = {
    up: 'M7 13l5-5 5 5',
    down: 'M7 11l5 5 5-5',
    left: 'M13 17l-5-5 5-5',
    right: 'M11 7l5 5-5 5',
  };
  btn.innerHTML = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="${paths[dir]}"/></svg>`;
  const pos = {
    up:    'top:28px;left:50%;transform:translateX(-50%);',
    down:  'bottom:8px;left:50%;transform:translateX(-50%);',
    left:  'left:8px;top:50%;transform:translateY(-50%);',
    right: 'right:8px;top:50%;transform:translateY(-50%);',
  };
  btn.style.cssText += pos[dir];
  btn.addEventListener('mouseenter', () => { btn.style.color = chevronColor(true); });
  btn.addEventListener('mouseleave', () => { btn.style.color = chevronColor(false); });
  return btn;
}

/** `state` ({ rotation, tilt }) is mutated in place; `paint` draws the marker at (px, py). */
export function createSphereStage({ hint, fullWidth = false, tiltMin, tiltPerHeight, state, onChange, paint }) {
  const el = document.createElement('div');
  el.className = 'relative rounded-[16px] overflow-hidden select-none border border-white/[0.06] dark:border-white/[0.06] bg-[#1a1c1f]';
  el.style.cssText = fullWidth ? 'aspect-ratio:1/1;width:100%;' : 'aspect-ratio:1/1;max-width:280px;margin:0 auto;';

  const canvas = document.createElement('canvas');
  canvas.width = 400;
  canvas.height = 400;
  canvas.style.cssText = 'width:100%;height:100%;cursor:grab;touch-action:none;';
  el.appendChild(canvas);

  const hintEl = document.createElement('p');
  hintEl.className = 'absolute top-3 left-0 right-0 text-center text-[11px] pointer-events-none';
  hintEl.textContent = hint;
  el.appendChild(hintEl);

  function applyTheme() {
    const dk = isDark();
    el.style.background = dk ? '#1a1c1f' : '#EAEFF6';
    el.style.borderColor = dk ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.06)';
    hintEl.style.color = dk ? 'rgba(255,255,255,0.35)' : 'rgba(0,0,0,0.35)';
    el.querySelectorAll('[data-chevron]').forEach((btn) => { btn.style.color = chevronColor(false); });
  }
  applyTheme();

  const step = (dRot, dTilt) => {
    state.rotation = (state.rotation + dRot + 360) % 360;
    state.tilt = Math.max(tiltMin, Math.min(90, state.tilt + dTilt));
    onChange();
  };
  const chevrons = { up: [0, 15], down: [0, -15], left: [-15, 0], right: [15, 0] };
  for (const [dir, [dRot, dTilt]] of Object.entries(chevrons)) {
    const btn = makeChevron(dir);
    btn.addEventListener('click', () => step(dRot, dTilt));
    el.appendChild(btn);
  }

  function draw() {
    const ctx = canvas.getContext('2d');
    const W = canvas.width;
    const H = canvas.height;
    const cx = W / 2;
    const cy = H / 2;
    const R = W * 0.34;
    const dk = isDark();

    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = dk ? '#1a1c1f' : '#EAEFF6';
    ctx.fillRect(0, 0, W, H);

    ctx.strokeStyle = dk ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.06)';
    ctx.lineWidth = 0.7;
    const rotRad = state.rotation * DEG;
    const tiltRad = state.tilt * DEG;
    for (let i = 0; i < 12; i++) {
      drawGreatCircle(ctx, cx, cy, R, (i / 12) * Math.PI + rotRad, 'vertical');
    }
    for (let i = 1; i < 7; i++) {
      const latRad = (-70 + (i / 7) * 140) * DEG;
      const r = R * Math.cos(latRad);
      const y = cy - R * Math.sin(latRad) * Math.cos(tiltRad * 0.3);
      ctx.beginPath();
      ctx.ellipse(cx, y, r, r * 0.3, 0, 0, TWO_PI);
      ctx.stroke();
    }
    for (let i = 0; i < 6; i++) {
      drawGreatCircle(ctx, cx, cy, R, (i / 6) * Math.PI + rotRad + Math.PI / 4, 'diagonal');
    }

    ctx.strokeStyle = dk ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.08)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(cx, cy, R, 0, TWO_PI);
    ctx.stroke();

    const px = cx + R * Math.sin(rotRad) * Math.cos(tiltRad);
    const py = cy - R * Math.sin(tiltRad);
    paint(ctx, { cx, cy, R, dk, px, py });
  }

  let dragging = false;
  let dragMoved = false;
  let disabled = false;
  let start = null;

  function attachDrag(target) {
    target.addEventListener('pointerdown', (e) => {
      if (disabled) return;
      dragging = true;
      dragMoved = false;
      canvas.style.cursor = 'grabbing';
      const rect = canvas.getBoundingClientRect();
      start = { x: e.clientX - rect.left, y: e.clientY - rect.top, rotation: state.rotation, tilt: state.tilt };
      target.setPointerCapture(e.pointerId);
    });
    target.addEventListener('pointermove', (e) => {
      if (!dragging) return;
      const rect = canvas.getBoundingClientRect();
      const dx = (e.clientX - rect.left) - start.x;
      const dy = (e.clientY - rect.top) - start.y;
      if (Math.abs(dx) + Math.abs(dy) > 3) dragMoved = true;
      state.rotation = Math.round((start.rotation + (dx / rect.width) * 360 + 360) % 360);
      state.tilt = Math.round(Math.max(tiltMin, Math.min(90, start.tilt - (dy / rect.height) * tiltPerHeight)));
      onChange();
    });
    const end = () => { dragging = false; canvas.style.cursor = 'grab'; };
    target.addEventListener('pointerup', end);
    target.addEventListener('pointercancel', end);
  }
  attachDrag(canvas);

  const onTheme = () => {
    if (!alive()) return;
    applyTheme();
    draw();
  };
  const classObs = new MutationObserver(onTheme);
  classObs.observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });
  const alive = whileConnected(el, () => classObs.disconnect());
  requestAnimationFrame(() => draw());

  return {
    el, draw, attachDrag,
    dragMoved: () => dragMoved,
    setDisabled(v) {
      disabled = !!v;
      canvas.style.cursor = disabled ? 'default' : 'grab';
      el.querySelectorAll('button').forEach((btn) => { btn.disabled = disabled; });
    },
  };
}
