// Homepage building blocks; loaded synchronously so elements render as they are parsed.
(function () {
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const badge = (text, small, extra = '') => text
    ? `<span class="${extra}bg-primary text-primary-foreground ${small ? 'rounded-md text-[10px] px-1.5 py-0.5' : 'rounded-lg text-[11px] px-2.5 py-1'} font-bold italic">${esc(text)}</span>`
    : '';

  window.hpLazy = (function () {
    const load = (img) => {
      const src = img.dataset.lazySrc;
      img.src = window.AitopiaMedia ? window.AitopiaMedia.image(src, img.clientWidth) : src;
      img.removeAttribute('data-lazy-src');
    };
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => { if (e.isIntersecting) { io.unobserve(e.target); load(e.target); } });
    }, { rootMargin: '50px' });
    return { observe: (root) => (root || document).querySelectorAll('img[data-lazy-src]').forEach((img) => io.observe(img)) };
  })();

  const chevron = (d) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${d}"/></svg>`;
  const addArrows = (row) => [['hf-prev', 'Scroll left', 'm15 18-6-6 6-6', -1], ['hf-next', 'Scroll right', 'm9 18 6-6-6-6', 1]].forEach(([cls, label, d, dir]) => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = `hf-arrow ${cls}`;
    btn.setAttribute('aria-label', label);
    btn.innerHTML = chevron(d);
    btn.addEventListener('click', () => row.scrollBy({ left: dir * row.clientWidth * 0.8, behavior: 'smooth' }));
    row.parentElement.appendChild(btn);
  });
  const syncEdges = (row) => {
    const wrap = row.parentElement;
    wrap.classList.toggle('at-start', row.scrollLeft <= 4);
    wrap.classList.toggle('at-end', row.scrollLeft + row.clientWidth >= row.scrollWidth - 4);
    const media = row.querySelector('.hf-media, .aa-card > :first-child');
    if (media) {
      const m = media.getBoundingClientRect();
      wrap.style.setProperty('--hf-next-y', `${m.top - wrap.getBoundingClientRect().top + m.height / 2}px`);
    }
  };
  const rows = () => document.querySelectorAll('.hf-row');
  document.addEventListener('scroll', (e) => { if (e.target.classList?.contains('hf-row')) syncEdges(e.target); }, true);
  window.addEventListener('resize', () => rows().forEach(syncEdges));
  document.addEventListener('DOMContentLoaded', () => {
    const mo = new MutationObserver((records) => records.forEach((r) => syncEdges(r.target)));
    rows().forEach((row) => { addArrows(row); syncEdges(row); mo.observe(row, { childList: true }); });
  });

  const startVideos = (selector) => document.querySelectorAll(selector).forEach((el) => {
    el.dataset.videoSrc = el.dataset.deferredVideoSrc;
    el.removeAttribute('data-deferred-video-src');
    window.AitopiaLazyMedia?.observeOne(el);
  });
  // Featured videos wait only for the LCP image; banners wait for the full page load.
  document.addEventListener('DOMContentLoaded', () => {
    const lcp = document.querySelector('.hf-media img[fetchpriority="high"]');
    const start = () => startVideos('.hf-media[data-deferred-video-src]');
    if (!lcp || lcp.complete) start();
    else { lcp.addEventListener('load', start, { once: true }); lcp.addEventListener('error', start, { once: true }); }
  });
  window.addEventListener('load', () => startVideos('[data-deferred-video-src]'));

  const ICONS = {
    image: '<svg width="20" height="20" viewBox="0 0 18 18" fill="none"><path d="M6.75 16.5H11.25C15 16.5 16.5 15 16.5 11.25V6.75C16.5 3 15 1.5 11.25 1.5H6.75C3 1.5 1.5 3 1.5 6.75V11.25C1.5 15 3 16.5 6.75 16.5Z" stroke="currentColor" stroke-width="1.125" stroke-linecap="round" stroke-linejoin="round"/><path d="M6.75 7.5C7.57843 7.5 8.25 6.82843 8.25 6C8.25 5.17157 7.57843 4.5 6.75 4.5C5.92157 4.5 5.25 5.17157 5.25 6C5.25 6.82843 5.92157 7.5 6.75 7.5Z" stroke="currentColor" stroke-width="1.125" stroke-linecap="round" stroke-linejoin="round"/><path d="M2.00244 14.2125L5.69994 11.73C6.29244 11.3325 7.14744 11.3775 7.67994 11.835L7.92744 12.0525C8.51244 12.555 9.45744 12.555 10.0424 12.0525L13.1624 9.37498C13.7474 8.87248 14.6924 8.87248 15.2774 9.37498L16.4999 10.425" stroke="currentColor" stroke-width="1.125" stroke-linecap="round" stroke-linejoin="round"/><path d="M14.6 1.2l.55 1.5 1.5.55-1.5.55-.55 1.5-.55-1.5-1.5-.55 1.5-.55z" fill="currentColor" stroke="currentColor" stroke-width=".6" stroke-linejoin="round"/></svg>',
    video: '<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><path d="M18.3307 12.4993V7.49935C18.3307 3.33268 16.6641 1.66602 12.4974 1.66602H7.4974C3.33073 1.66602 1.66406 3.33268 1.66406 7.49935V12.4993C1.66406 16.666 3.33073 18.3327 7.4974 18.3327H12.4974C16.6641 18.3327 18.3307 16.666 18.3307 12.4993Z" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/><path d="M2.10156 5.92578H17.9016" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/><path d="M7.10156 1.75781V5.80781" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/><path d="M12.8984 1.75781V5.43281" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/><path d="M8.125 12.0421V11.0421C8.125 9.75875 9.03333 9.23376 10.1417 9.87542L11.0083 10.3754L11.875 10.8754C12.9833 11.5171 12.9833 12.5671 11.875 13.2088L11.0083 13.7088L10.1417 14.2088C9.03333 14.8504 8.125 14.3254 8.125 13.0421V12.0421V12.0421Z" stroke="currentColor" stroke-width="1.25" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    agents: '<svg width="20" height="20" viewBox="0 0 18 18" fill="none"><path d="M7.20001 15H10.8001C13.8 15 15 13.8 15 10.8V7.20001C15 4.2 13.8 3 10.8001 3H7.20001C4.20001 3 3 4.2 3 7.20001V10.8C3 13.8 4.20001 15 7.20001 15Z" stroke="currentColor" stroke-width="1.13" stroke-linecap="round" stroke-linejoin="round"/><line x1="7.065" y1="11.935" x2="10.935" y2="11.935" stroke="currentColor" stroke-width="1.13" stroke-linecap="round"/><line x1="7.065" y1="17.085" x2="10.935" y2="17.085" stroke="currentColor" stroke-width="1.13" stroke-linecap="round"/><line x1="17.035" y1="10.435" x2="17.035" y2="7.565" stroke="currentColor" stroke-width="1.13" stroke-linecap="round"/><line x1="1.00495" y1="10.435" x2="1.00495" y2="7.565" stroke="currentColor" stroke-width="1.13" stroke-linecap="round"/><path d="M9 3.00031V1.50031" stroke="currentColor" stroke-width="1.13" stroke-linecap="round" stroke-linejoin="round"/><path d="M7.0022 6C7.49787 6 7.90259 6.40337 7.90259 6.90039V7.5C7.90259 7.99702 7.49787 8.40039 7.0022 8.40039H6.20044C5.70493 8.4002 5.30005 7.99691 5.30005 7.5V6.90039C5.30005 6.40349 5.70493 6.00019 6.20044 6H7.0022Z" stroke="currentColor" stroke-miterlimit="10" stroke-linejoin="round"/><path d="M11.8022 6C12.2979 6 12.7026 6.40337 12.7026 6.90039V7.5C12.7026 7.99702 12.2979 8.40039 11.8022 8.40039H11.0005C10.505 8.4002 10.1001 7.99691 10.1001 7.5V6.90039C10.1001 6.40349 10.505 6.00019 11.0005 6H11.8022Z" stroke="currentColor" stroke-miterlimit="10" stroke-linejoin="round"/></svg>',
    models: '<svg width="20" height="20" viewBox="0 0 18 18" fill="none"><path d="M7.20061 14.9997H10.8007C13.8006 14.9997 15.0006 13.7997 15.0006 10.7997V7.19969C15.0006 4.19969 13.8006 2.99969 10.8007 2.99969H7.20061C4.20062 2.99969 3.00061 4.19969 3.00061 7.19969V10.7997C3.00061 13.7997 4.20062 14.9997 7.20061 14.9997Z" stroke="currentColor" stroke-width="1.13" stroke-linecap="round" stroke-linejoin="round"/><path d="M7.87561 12.7497H10.1257C12.0006 12.7497 12.7506 11.9997 12.7506 10.1247V7.87469C12.7506 5.99969 12.0006 5.24969 10.1257 5.24969H7.87561C6.00062 5.24969 5.25061 5.99969 5.25061 7.87469V10.1247C5.25061 11.9997 6.00062 12.7497 7.87561 12.7497Z" stroke="currentColor" stroke-width="1.13" stroke-linecap="round" stroke-linejoin="round"/><path d="M6.00818 3.00031V1.50031" stroke="currentColor" stroke-width="1.13" stroke-linecap="round" stroke-linejoin="round"/><path d="M9 3.00031V1.50031" stroke="currentColor" stroke-width="1.13" stroke-linecap="round" stroke-linejoin="round"/><path d="M12.0006 3.00031V1.50031" stroke="currentColor" stroke-width="1.13" stroke-linecap="round" stroke-linejoin="round"/><path d="M14.9994 6.00031H16.4994" stroke="currentColor" stroke-width="1.13" stroke-linecap="round" stroke-linejoin="round"/><path d="M14.9994 9H16.4994" stroke="currentColor" stroke-width="1.13" stroke-linecap="round" stroke-linejoin="round"/><path d="M14.9994 11.9997H16.4994" stroke="currentColor" stroke-width="1.13" stroke-linecap="round" stroke-linejoin="round"/><path d="M12.0006 15.0003V16.5003" stroke="currentColor" stroke-width="1.13" stroke-linecap="round" stroke-linejoin="round"/><path d="M9.00879 15.0003V16.5003" stroke="currentColor" stroke-width="1.13" stroke-linecap="round" stroke-linejoin="round"/><path d="M6.00818 15.0003V16.5003" stroke="currentColor" stroke-width="1.13" stroke-linecap="round" stroke-linejoin="round"/><path d="M1.49939 6.00031H2.99938" stroke="currentColor" stroke-width="1.13" stroke-linecap="round" stroke-linejoin="round"/><path d="M1.49939 9H2.99938" stroke="currentColor" stroke-width="1.13" stroke-linecap="round" stroke-linejoin="round"/><path d="M1.49939 11.9997H2.99938" stroke="currentColor" stroke-width="1.13" stroke-linecap="round" stroke-linejoin="round"/><path d="M8.99907 7.27472L8.29406 8.50471C8.13656 8.77471 8.26406 8.99971 8.57906 8.99971H9.41904C9.73404 8.99971 9.86157 9.22474 9.70407 9.49474L8.99907 10.7247" stroke="currentColor" stroke-width="1.13" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    mcp: '<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><path d="M7.50156 10.834C6.95156 11.109 6.49323 11.5173 6.15156 12.0257C5.9599 12.3173 5.9599 12.684 6.15156 12.9757C6.49323 13.484 6.95156 13.8923 7.50156 14.1673" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/><path d="M12.6719 10.834C13.2219 11.109 13.6802 11.5173 14.0219 12.0257C14.2135 12.3173 14.2135 12.684 14.0219 12.9757C13.6802 13.484 13.2219 13.8923 12.6719 14.1673" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/><path d="M7.4974 18.3327H12.4974C16.6641 18.3327 18.3307 16.666 18.3307 12.4993V7.49935C18.3307 3.33268 16.6641 1.66602 12.4974 1.66602H7.4974C3.33073 1.66602 1.66406 3.33268 1.66406 7.49935V12.4993C1.66406 16.666 3.33073 18.3327 7.4974 18.3327Z" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/><path d="M1.85938 6.67435L17.876 6.66602" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    scotty: '<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><path d="M15.8359 13.3333V5.41667C15.8359 4.5 15.0859 3.75 14.1693 3.75H9.58594" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/><path d="M11.6641 1.66602L9.16406 3.74935L11.6641 5.83268" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/><path d="M15.8359 18.334C17.2166 18.334 18.3359 17.2147 18.3359 15.834C18.3359 14.4533 17.2166 13.334 15.8359 13.334C14.4552 13.334 13.3359 14.4533 13.3359 15.834C13.3359 17.2147 14.4552 18.334 15.8359 18.334Z" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/><path d="M4.16406 6.66602V14.5827C4.16406 15.4993 4.91406 16.2493 5.83073 16.2493H10.4141" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/><path d="M8.33594 18.3327L10.8359 16.2493L8.33594 14.166" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/><path d="M4.16406 6.66602C5.54477 6.66602 6.66406 5.54673 6.66406 4.16602C6.66406 2.7853 5.54477 1.66602 4.16406 1.66602C2.78335 1.66602 1.66406 2.7853 1.66406 4.16602C1.66406 5.54673 2.78335 6.66602 4.16406 6.66602Z" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    marketing: '<svg width="20" height="20" viewBox="0 0 19 20" fill="none"><path d="M12.2207 0.0438971C12.5345 -0.0815426 12.8909 0.0710288 13.0166 0.384717C13.0799 0.542933 13.2103 0.815752 13.3047 1.1689C13.4028 1.53635 13.4685 1.99942 13.4688 2.65327C13.4689 3.0689 13.4693 3.6375 13.2998 4.37202C13.1357 5.08266 12.8169 5.9262 12.2148 6.94917C12.2827 7.04768 12.4217 7.19299 12.665 7.39839C12.9196 7.61328 13.2358 7.85232 13.6084 8.13667C13.9752 8.41664 14.3861 8.73328 14.8047 9.08687C16.4705 10.494 18.3671 12.5806 18.3672 15.7148C18.3667 16.9154 17.373 18.7708 14.3486 19.124C13.7708 19.1915 13.2082 19.3987 12.5283 19.5957C11.8642 19.788 10.9371 19.9284 9.74609 19.9785C9.69693 19.9912 9.64592 19.9999 9.59277 20C9.4536 20 9.31695 19.9973 9.18359 19.9951C9.05014 19.9973 8.91369 20 8.77441 20C8.72093 19.9999 8.66957 19.9914 8.62012 19.9785C7.42958 19.9283 6.50286 19.7879 5.83887 19.5957C5.15914 19.3987 4.59629 19.1915 4.01855 19.124C0.994192 18.7708 0.000495527 16.9154 0 15.7148C0.000107746 12.5806 1.89665 10.494 3.5625 9.08687C3.98105 8.73334 4.39203 8.4166 4.75879 8.13667C5.13126 7.85238 5.44761 7.61325 5.70215 7.39839C5.94535 7.19307 6.08446 7.04766 6.15234 6.94917C5.55025 5.92614 5.23147 5.08269 5.06738 4.37202C4.89784 3.63747 4.89831 3.06891 4.89844 2.65327C4.89866 1.99942 4.96436 1.53635 5.0625 1.1689C5.15687 0.815787 5.2873 0.542922 5.35059 0.384717C5.4763 0.0710967 5.83271 -0.0815293 6.14648 0.0438971C6.46013 0.169522 6.61258 0.526025 6.4873 0.839795C6.38747 1.08934 6.31423 1.22582 6.24512 1.48433C6.23039 1.53944 6.21641 1.6005 6.20312 1.66792C6.30854 1.68116 6.43539 1.69649 6.61914 1.72065C6.87917 1.75487 7.19238 1.80832 7.53125 1.91792C8.06384 2.09023 8.6319 2.39385 9.17969 2.94233C9.72745 2.39373 10.2955 2.0903 10.8281 1.91792C11.1669 1.80832 11.4802 1.75488 11.7402 1.72065C11.9277 1.69599 12.0564 1.68048 12.1631 1.66694C12.1499 1.59995 12.1367 1.53915 12.1221 1.48433C12.053 1.22577 11.9797 1.08937 11.8799 0.839795C11.7545 0.525917 11.9069 0.169446 12.2207 0.0438971ZM12.2422 2.89253C12.121 2.90717 11.9991 2.9214 11.8994 2.93452C11.6751 2.96406 11.444 3.00568 11.2051 3.08296C10.7426 3.23269 10.2032 3.53411 9.66992 4.24507C9.66479 4.2519 9.6577 4.25707 9.65234 4.26362C9.63997 4.27872 9.62629 4.29255 9.6123 4.30659C9.59599 4.32304 9.57929 4.33824 9.56152 4.35249C9.55631 4.35667 9.55226 4.3631 9.54688 4.36714C9.53976 4.37246 9.5307 4.37486 9.52344 4.37983C9.50205 4.39442 9.48082 4.40824 9.45801 4.41987C9.44414 4.427 9.43023 4.43342 9.41602 4.4394C9.39514 4.44811 9.37415 4.45554 9.35254 4.46187C9.33306 4.46762 9.31374 4.47275 9.29395 4.47651C9.27641 4.47982 9.25897 4.48256 9.24121 4.48433C9.22066 4.48639 9.20027 4.48727 9.17969 4.48726C9.15911 4.48724 9.13871 4.48642 9.11816 4.48433C9.09971 4.48246 9.08168 4.47906 9.06348 4.47554C9.04479 4.47189 9.02622 4.46827 9.00781 4.46284C8.98582 4.45642 8.96459 4.44829 8.94336 4.4394C8.9289 4.43329 8.91449 4.42717 8.90039 4.41987C8.87845 4.40861 8.85754 4.39579 8.83691 4.38179C8.82919 4.37652 8.82006 4.37281 8.8125 4.36714C8.80679 4.36285 8.80239 4.35694 8.79688 4.35249C8.77759 4.33694 8.75974 4.31986 8.74219 4.30171C8.7315 4.29071 8.72066 4.28014 8.71094 4.26851C8.70422 4.26044 8.69582 4.25356 8.68945 4.24507C8.15601 3.53392 7.61691 3.23263 7.1543 3.08296C6.91537 3.0057 6.68427 2.96405 6.45996 2.93452C6.36197 2.92164 6.24302 2.90783 6.12402 2.89351C6.1282 3.2348 6.14984 3.62031 6.25977 4.09663C6.37956 4.61549 6.60836 5.26058 7.05469 6.06538L7.25977 6.41987C7.51542 6.8461 7.39437 7.27334 7.20996 7.57124C7.0397 7.84608 6.76688 8.10301 6.49219 8.33491C6.20861 8.57427 5.86107 8.83621 5.50195 9.1103C5.13677 9.38903 4.74624 9.68987 4.35254 10.0224C2.81759 11.319 1.32172 13.024 1.22949 15.4746L1.22461 15.7148C1.22513 16.2258 1.68281 17.6178 4.16016 17.9072C4.27343 17.9204 4.38715 17.9396 4.50098 17.9609C4.54346 17.2699 4.7104 16.3469 5.36719 15.0332C5.51827 14.731 5.88619 14.6081 6.18848 14.7587C6.49078 14.9099 6.61381 15.2777 6.46289 15.58C5.8153 16.8752 5.7263 17.6843 5.71387 18.2802C5.87753 18.3305 6.034 18.3779 6.17871 18.4199C6.80295 18.6007 7.79479 18.7462 9.18262 18.7705C10.5715 18.7463 11.564 18.6008 12.1885 18.4199C12.331 18.3786 12.4846 18.3317 12.6455 18.2822C12.6332 17.6861 12.5448 16.8767 11.8965 15.58C11.7458 15.2778 11.8689 14.9099 12.1709 14.7587C12.4732 14.6079 12.8409 14.7311 12.9922 15.0332C13.6493 16.3475 13.816 17.2708 13.8584 17.9619C13.9748 17.9399 14.0912 17.9207 14.207 17.9072C16.6844 17.6178 17.1421 16.2258 17.1426 15.7148L17.1377 15.4746C17.0455 13.024 15.5496 11.319 14.0146 10.0224C13.6209 9.68982 13.2305 9.38907 12.8652 9.1103C12.5061 8.83616 12.1586 8.57431 11.875 8.33491C11.6002 8.10297 11.3275 7.84614 11.1572 7.57124C10.9728 7.27334 10.8517 6.84616 11.1074 6.41987L11.3125 6.06538C11.7588 5.26064 11.9876 4.61546 12.1074 4.09663C12.2174 3.61988 12.238 3.23404 12.2422 2.89253Z" fill="currentColor"/></svg>',
    builder: '<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><path d="M4.16406 7.5V13.3333" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/><path d="M4.3724 7.08268C5.86817 7.08268 7.08073 5.87012 7.08073 4.37435C7.08073 2.87858 5.86817 1.66602 4.3724 1.66602C2.87662 1.66602 1.66406 2.87858 1.66406 4.37435C1.66406 5.87012 2.87662 7.08268 4.3724 7.08268Z" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/><path d="M4.16406 18.334C5.54477 18.334 6.66406 17.2147 6.66406 15.834C6.66406 14.4533 5.54477 13.334 4.16406 13.334C2.78335 13.334 1.66406 14.4533 1.66406 15.834C1.66406 17.2147 2.78335 18.334 4.16406 18.334Z" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/><path d="M15.8359 18.334C17.2166 18.334 18.3359 17.2147 18.3359 15.834C18.3359 14.4533 17.2166 13.334 15.8359 13.334C14.4552 13.334 13.3359 14.4533 13.3359 15.834C13.3359 17.2147 14.4552 18.334 15.8359 18.334Z" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/><path d="M4.28125 7.5C4.65625 8.95833 5.98958 10.0417 7.56458 10.0333L10.4229 10.025C12.6063 10.0167 14.4646 11.4167 15.1479 13.3667" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  };

  const define = (name, render) => customElements.define(name, class extends HTMLElement {
    connectedCallback() {
      if (this.dataset.rendered) return;
      this.dataset.rendered = '1';
      const a = (k) => this.getAttribute(k);
      this.innerHTML = render(a, this);
    }
  });

  define('hp-feature-card', (a) => {
    // The priority (LCP) image keeps its original URL so it matches the <link rel="preload"> in index.html.
    const src = a('img-priority') !== null || !window.AitopiaMedia ? a('img') : window.AitopiaMedia.image(a('img'), 560);
    const img = a('img')
      ? `<img src="${esc(src)}" alt="" ${a('img-priority') !== null ? 'fetchpriority="high"' : 'loading="lazy"'} class="absolute inset-0 w-full h-full object-cover">`
      : '';
    const video = a('video') ? ` data-deferred-video-src="${esc(a('video'))}"` : '';
    return `<a href="${esc(a('href'))}" class="hf-card group block no-underline">
        <div class="hf-media relative rounded-[16px] overflow-hidden hp-surface"${video}>${img}${badge(a('badge'), false, 'absolute top-3 right-3 ')}</div>
        <h3 class="mt-3 text-[16px] font-[600] hp-text">${esc(a('title'))}</h3>
        <p class="mt-1 text-[13px] hp-muted">${esc(a('desc'))}</p>
      </a>`;
  });

  define('hp-link-card', (a) => {
    const title = `<h3 class="text-[16px] font-[500] hp-text">${esc(a('title'))}</h3>`;
    return `<a href="${esc(a('href'))}" class="hl-card flex flex-col justify-between gap-4 rounded-[16px] hp-surface p-4 no-underline">
          <span class="self-start rounded-md hp-chip text-[11px] hp-soft px-2.5 py-1">${esc(a('chip'))}</span>
          <div>
            ${a('badge') ? `<div class="flex items-center gap-2">${title}${badge(a('badge'), true)}</div>` : title}
            <p class="mt-1 text-[13px] hp-muted">${esc(a('desc'))}</p>
          </div>
        </a>`;
  });

  define('hp-tile', (a) => {
    const tone = esc(a('tone'));
    const label = String(a('label') || '').split(' ').map(esc).join('<br>');
    return `<a href="${esc(a('href'))}" class="ml-tile flex flex-col items-center justify-center gap-2 text-center no-underline" style="background:linear-gradient(160deg,hsl(var(--hp-tile-${tone}-a)),hsl(var(--hp-tile-${tone}-b)))">${ICONS[a('tone')] || ''}<span>${label}</span></a>`;
  });

  define('hp-banner', (a, el) => {
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const mq = window.matchMedia('(min-width: 640px)');
    const media = (desktop) => {
      const attr = document.readyState === 'complete' ? 'data-video-src' : 'data-deferred-video-src';
      const video = reduced ? '' : ` ${attr}="${esc(desktop ? a('video-desktop') : a('video-mobile'))}"`;
      return `<div class="hp-banner relative block w-full"${video}>
          <img data-lazy-src="${esc(desktop ? a('poster-desktop') : a('poster-mobile'))}" alt="" decoding="async" class="absolute inset-0 w-full h-full object-cover">
        </div>`;
    };
    mq.addEventListener('change', (e) => {
      const old = el.querySelector('.hp-banner');
      const v = old.querySelector('video');
      if (v) { v.pause(); v.removeAttribute('src'); v.load(); }
      old.outerHTML = media(e.matches);
      window.hpLazy.observe(el);
      const fresh = el.querySelector('.hp-banner[data-video-src]');
      if (fresh) window.AitopiaLazyMedia?.observeOne(fresh);
    });
    queueMicrotask(() => window.hpLazy.observe(el));
    return `<section class="hp-page pb-8 lg:pb-12">
    <div class="aa-head">
      <a href="${esc(a('href'))}" aria-label="${esc(a('label'))}" class="block overflow-hidden rounded-[16px] lg:rounded-[24px]">
        ${media(mq.matches)}
      </a>
    </div>
  </section>`;
  });

  // These rows sit screens below the fold: fetch them after load (or the first scroll) so they don't compete with first paint.
  const afterLoadOrScroll = (fn) => {
    if (document.readyState === 'complete') return void queueMicrotask(fn);
    const run = () => { window.removeEventListener('load', run); window.removeEventListener('scroll', run); fn(); };
    window.addEventListener('load', run, { once: true });
    window.addEventListener('scroll', run, { once: true, passive: true });
  };

  const RATIOS = ['9/16', '1/1', '4/5', '3/4', '16/10'];
  define('hp-creations', (a, el) => {
    const href = esc(a('href'));
    const heading = (extra = '') => `<h2 class="${extra}text-[22px] lg:text-[30px] font-[500] hp-text">${esc(a('heading'))}</h2>`;
    afterLoadOrScroll(async () => {
      let outputs = [];
      try {
        const res = await fetch(a('src'));
        const json = res.ok ? await res.json() : null;
        outputs = (json?.outputs || []).filter(o => o.preview?.url);
      } catch {}
      if (!outputs.length) return;
      const grid = el.querySelector('.mc-grid');
      grid.innerHTML = outputs.map((o, i) => {
        const p = o.preview;
        const url = esc(p.url);
        const media = p.kind === 'video' ? `data-video-src="${url}"` : '';
        const img = p.kind === 'video' ? '' : `<img data-lazy-src="${url}" alt="" decoding="async" class="absolute inset-0 w-full h-full object-cover">`;
        const itemHref = o.id ? `/marketplace/outputs.html?id=${encodeURIComponent(o.id)}` : href;
        return `<a href="${esc(itemHref)}" aria-label="${esc(o.title || a('cta'))}" class="mc-item" style="aspect-ratio:${RATIOS[i % RATIOS.length]}" ${media}>${img}</a>`;
      }).join('');
      el.querySelector('section').hidden = false;
      window.hpLazy.observe(grid);
      window.AitopiaLazyMedia?.observe(grid);
    });
    return `<section class="hp-page pb-8 lg:pb-12" hidden>
    <div class="aa-head">
      ${a('badge') ? `<div class="flex items-center gap-3 mb-5">${heading()}${badge(a('badge'))}</div>` : heading('mb-5 ')}
      <div class="mc-wrap">
        <div class="mc-grid"></div>
        <div class="mc-fade"></div>
        <a href="${href}" class="mc-btn absolute left-1/2 -translate-x-1/2 rounded-full text-[13px] font-[500] px-5 py-2.5 no-underline">${esc(a('cta'))}</a>
      </div>
    </div>
  </section>`;
  });
})();
