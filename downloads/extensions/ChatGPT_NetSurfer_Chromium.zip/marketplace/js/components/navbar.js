(function() {
  // Load CSP-compliant event delegation handlers (once)
  if (!window.__CSP_HANDLERS_LOADED__) {
    window.__CSP_HANDLERS_LOADED__ = true;
    import(/* @vite-ignore */ '/marketplace/js/csp-event-handlers.js').catch(function(){});
  }

  const NAVBAR_VERSION = 'navbar-v5';
  if (window.__AITOPIA_NAVBAR__ === NAVBAR_VERSION) return;
  window.__AITOPIA_NAVBAR__ = NAVBAR_VERSION;

  const getCache = () => window.AitopiaCache;
  const getUserProfile = () => getCache()?.getUserProfile?.() ?? null;
  const setUserProfile = (data) => getCache()?.setUserProfile?.(data);
  const getUserCredits = () => getCache()?.getUserCredits?.() ?? null;
  const setUserCredits = (credits) => getCache()?.setUserCredits?.(credits);
  const clearUserCache = () => getCache()?.clearUserData?.();

  let developerStatusPromise = null;

  // One login signal for the scripts that load after us: the generation dock
  // reads isLoggedIn() at start and follows the event. null = profile pending.
  let loggedIn = null;
  function publishAuth(value) {
    loggedIn = value;
    window.dispatchEvent(new CustomEvent('aitopia-auth-changed', { detail: { loggedIn: value } }));
  }

function setUrlCookie() {
  const currentPath = window.location.pathname;
  const unListingPages = ["pricing", "login", "register", "reset-password"];
  let checkPage = true;
  unListingPages.forEach((item) => {
    if (currentPath.indexOf(`/${item}`) !== -1) {
      checkPage = false;
    }
  });

  const cookieValue = checkPage ? window.location.href : window.location.origin;

  const expires = new Date(Date.now() + 3600000).toUTCString(); // 1 hour
  document.cookie = `aitopia_last_url=${encodeURIComponent(cookieValue)}; expires=${expires}; path=/; Secure; SameSite=None; Domain=.${window.location.hostname}`;
}

  async function fetchIsDeveloper(forceRefresh = false) {
    if (!forceRefresh && developerStatusPromise) return developerStatusPromise;
    developerStatusPromise = (async () => {
      await window.aitopiaLoadOrder?.wait('critical');
      try {
        const res = await fetch('https://aitopia.ai/api/developers/me?soft=1', {
          method: 'GET',
          credentials: 'include',
          headers: { Accept: 'application/json' },
        });
        return res.ok;
      } catch {
        return false;
      }
    })();
    return developerStatusPromise;
  }

  // Legacy /agents?q= and /models?search= links open the modal instead.
  const legacySearchQuery = (() => {
    try {
      const path = window.location.pathname;
      const keys = path === '/marketplace/agents.html' ? ['q'] : (path === '/marketplace/models.html' || path.startsWith('/models/') ? ['search', 'q'] : []);
      if (!keys.length) return '';
      const url = new URL(window.location.href);
      const query = keys.map((k) => url.searchParams.get(k)).find((v) => v && v.trim()) || '';
      if (!query) return '';
      keys.forEach((k) => url.searchParams.delete(k));
      window.history.replaceState(window.history.state, '', `${url.pathname}${url.search}${url.hash}`);
      return query.trim();
    } catch {
      return '';
    }
  })();

  const SEARCH_MODAL_URL = '/marketplace/js/search/search-modal.js';
  let searchModalModule = null;
  let keyboardHolder = null;

  function loadSearchModal() {
    if (!searchModalModule) {
      searchModalModule = import(SEARCH_MODAL_URL).catch((error) => {
        searchModalModule = null;
        throw error;
      });
    }
    return searchModalModule;
  }

  function prefetchSearch() {
    loadSearchModal().then((mod) => mod.prefetchSearchIndex()).catch(() => {});
  }

  function openSearch(query) {
    return loadSearchModal()
      .then((mod) => mod.openSearchModal({ query: typeof query === 'string' ? query : '' }))
      .catch((error) => {
        if (keyboardHolder && document.activeElement === keyboardHolder) keyboardHolder.blur();
        console.warn('[navbar] search modal unavailable', error);
      });
  }

  // iOS opens the keyboard only for a focus() inside the tap; hold it until the modal loads.
  function holdKeyboard() {
    if (!window.matchMedia || !window.matchMedia('(hover: none)').matches) return;
    if (!keyboardHolder) {
      keyboardHolder = document.createElement('input');
      keyboardHolder.type = 'text';
      keyboardHolder.setAttribute('aria-hidden', 'true');
      keyboardHolder.tabIndex = -1;
      keyboardHolder.style.cssText = 'position:fixed;top:0;left:0;width:1px;height:1px;opacity:0;font-size:16px;border:0;padding:0;pointer-events:none;';
      document.body.appendChild(keyboardHolder);
    }
    try { keyboardHolder.focus({ preventScroll: true }); } catch { keyboardHolder.focus(); }
  }

  function isEditableTarget(target) {
    if (!(target instanceof Element)) return false;
    if (target.closest('input, textarea, select, [contenteditable=""], [contenteditable="true"]')) return true;
    return false;
  }

  function bindHeaderSearch() {
    const button = document.getElementById('navbarSearchButton');
    if (!(button instanceof HTMLButtonElement)) return;
    if (button.dataset.searchTriggerBound === '1') return;
    button.dataset.searchTriggerBound = '1';

    button.addEventListener('pointerenter', prefetchSearch, { passive: true });
    button.addEventListener('touchstart', prefetchSearch, { passive: true });
    button.addEventListener('focus', prefetchSearch);
    button.addEventListener('click', () => {
      holdKeyboard();
      openSearch('');
    });
    button.addEventListener('keydown', (event) => {
      if (event.altKey || event.metaKey || event.ctrlKey) return;
      const printable = event.key.length === 1 && event.key !== ' ';
      if (!printable && event.key !== 'ArrowDown') return;
      event.preventDefault();
      openSearch(printable ? event.key : '');
    });

    if (legacySearchQuery) openSearch(legacySearchQuery);

    document.addEventListener('keydown', (event) => {
      if (event.defaultPrevented) return;
      const isShortcut = (event.metaKey || event.ctrlKey) && !event.altKey && !event.shiftKey && event.key.toLowerCase() === 'k';
      const isSlash = event.key === '/' && !event.metaKey && !event.ctrlKey && !event.altKey && !isEditableTarget(event.target);
      if (!isShortcut && !isSlash) return;
      event.preventDefault();
      if (searchModalModule) {
        searchModalModule.then((mod) => mod.toggleSearchModal()).catch(() => openSearch(''));
      } else {
        openSearch('');
      }
    });
  }

  const NAV_LINKS = [
    { label: 'Image', href: '/category/image', menu: 'image' },
    { label: 'Video', href: '/category/video', menu: 'video' },
    { label: 'Agents', href: '/marketplace/agents.html', exact: true },
    { label: 'Models', href: '/marketplace/models.html' },
    { label: 'Community', href: '/marketplace/outputs.html' },
    { label: 'Marketing Studio', href: '/agents/marketing-studio', studio: true },
    { label: 'Scotty', href: 'https://scotty.aitopia.ai/chat', external: true },
    { label: 'MCP &amp; API', href: '/mcp', studio: true },
    { label: 'Pricing', href: '/marketplace/pricing.html', id: 'nav-pricing-link' },
  ];

  const NAV_MENUS = {
    image: [
      {
        title: 'Features',
        items: [
          { title: 'Image Generator', desc: 'Generates high-quality AI images from text prompts.', href: '/agents/image-generator', icon: 'image-generator' },
          { title: 'Face Swap', desc: 'Swaps faces seamlessly between target photos.', href: '/agents/face-swap', icon: 'face-swap' },
          { title: 'Watermark Remover Image Pro', desc: 'Removes watermarks, logos & text from images', href: '/agents/watermark-remover-image', icon: 'watermark-remover' },
          { title: 'Relight', desc: 'Give any photo a lighting with different angle and color.', href: '/agents/relight', icon: 'relight' },
          { title: 'Inside the VR World', desc: 'Turn a VR photo into a cinematic in-game still.', href: '/agents/inside-the-vr-world', icon: 'inside-the-vr-world' },
          { title: '360 Turnaround Views', desc: 'Upload one photo and get a 360° turnaround photos.', href: '/agents/grok-360-turnaround', icon: 'turnaround-360' },
          { title: 'Short History Story', desc: 'Turns history topics into lessons with images.', href: '/agents/short-history-story',icon: 'short-history-story' },
          { title: 'Nano Strike', desc: 'Turns your photo into a cinematic tactical operator.', href: '/agents/nano-strike', icon: 'scene-generator' },
          { title: 'Product Life Style', desc: 'Turns products into magazine-style lifestyle shots.', href: '/agents/product-lifestyle', icon: 'cinematic-product-film' },
        ],
      },
      {
        title: 'Models',
        items: [
          { title: 'GPT Image 2.5 Sunburst', desc: 'High-vibrancy image model with rich colors.', href: '/openai/gpt-image-2.5-sunburst', img: 'https://v3b.fal.media/files/b/0aa9a3c6/xpKm5FzsZBuvm2Bf8xY7W.jpg' },
          { title: 'Gpt Image 2', desc: 'Advanced AI model for detailed image creation.', href: '/openai/gpt-image-2', img: 'https://aitopia.ai/model-images/gpt-image-2/gpt-image-2-cover.webp' },
          { title: 'Seedream 5 Lite', desc: 'Ultra-fast image generation for quick drafts.', href: '/bytedance/seedream-5-lite', img: 'https://aitopia.ai/model-images/seedream-5-lite/seedream-5-lite-cover.png' },
          { title: 'Nano Banana 2 Lite', desc: 'Lightweight engine for fast image outputs.', href: '/google/nano-banana-2-lite', img: 'https://aitopia.ai/model-images/nano-banana-2-lite/nano-banana-2-lite-cover.jpg' },
          { title: 'Nano Banana Pro', desc: 'High-fidelity model for complex image prompts.', href: '/google/nano-banana-pro', img: 'https://aitopia.ai/model-images/nano-banana-pro/nano-banana-pro-cover.jpg' },
          { title: 'V4 Pro', desc: 'Design-focused model for vector & graphic styles.', href: '/recraft/v4-pro', img: 'https://aitopia.ai/model-images/v4-pro/v4-pro-cover.jpg' },
          { title: 'Grok Imagine Image', desc: 'Creative image generator with strong prompt adherence.', href: '/xai/grok-imagine-image', img: 'https://aitopia.ai/model-images/grok-imagine-image/grok-imagine-image-cover.jpg' },
          { title: 'Qwen Image', desc: 'Versatile image model with accurate text rendering.', href: '/qwen/qwen-image', img: 'https://aitopia.ai/model-images/qwen-image/qwen-image-cover.webp' },
          { title: 'Flux 2', desc: 'Photorealistic model with ultra-detailed output.', href: '/black-forest-labs/flux-2', img: 'https://aitopia.ai/model-images/flux-2/flux-2-cover.jpg' },
        ],
      },
    ],
  };

  NAV_MENUS.video = [
    {
      title: 'Features',
      items: [
        { title: 'Cinematic Product Film', desc: 'Generates high-end cinematic product ads.', href: '/agents/cinematic-product-film-seedance', icon: 'cinematic-product-film' },
        { title: 'UGC Tries Product Video', desc: 'Creates authentic user-style product demos.', href: '/agents/ugc-tries-product-copy', icon: 'ugc-tries-product' },
        { title: 'Morpheus', desc: 'Creates 3D Scenes and turns them into videos.', href: '/agents/morpheus', highlight: true, badge: 'New', icon: 'morpheus' },
        { title: 'Video Generator', desc: 'Generates full AI videos directly from text prompts.', href: '/agents/video-generator', icon: 'video-generator' },
        { title: 'Video Transitions', desc: 'Adds seamless AI transitions between clips.', href: '/agents/transition-effects', icon: 'video-transitions' },
        { title: 'Closeup Clip', desc: 'Generates detailed close-up shot variations.', href: '/agents/closeup-clip-from-photo', icon: 'closeup-clip' },
        { title: 'Viral Dance Reel Creator', desc: 'Creates trending dance Reels for social media.', href: '/agents/viral-dance-reel-creator', icon: 'viral-dance-reel' },
        { title: 'Idea > Photo > Video', desc: 'Turns ideas/photos into images, then animated clips.', href: '/agents/idea-to-photo-to-video', icon: 'idea-photo-video' },
        { title: 'The Last Bond: You & Your Animal', desc: 'Turn you and your pet into a survival film.', href: '/agents/last-bond-pet-film', icon: 'last-bond-pet-film' },
        { title: 'Storm Change', desc: 'Recreate crowd videos with your character.', href: '/agents/storm-change', icon: 'storm-change' },
        { title: 'Garment Craft Film', desc: 'Upload clothing, get cinematic craft film.', href: '/agents/garment-craft-film', icon: 'garment-craft-film' },
      ],
    },
    {
      title: 'Models',
      items: [
        { title: 'Seedance 2.5', desc: 'Advanced AI video engine for smooth, realistic motion.', href: '/bytedance/seedance-2.5', video: 'https://aitopia.ai/model-images/seedance-2-5-cover.mp4' },
        { title: 'Seedance 2.0', desc: 'High-performance video generation with crisp detail.', href: '/bytedance/seedance-2.0', video: 'https://aitopia.ai/model-images/seedance-2-0/seedance-2-0-cover.mp4' },
        { title: 'Seedance Lite', desc: 'Lightweight model for ultra-fast video rendering.', href: '/bytedance/seedance-1-lite', img: 'https://aitopia.ai/model-images/seedance-1-lite/seedance-1-lite-cover.webp' },
        { title: 'Kling O3 Pro Video Edit', desc: 'Professional AI video editing and sequence control.', href: '/kwaivgi/kling-o3-pro-video-edit', img: 'https://v3b.fal.media/files/b/0a8cfcd0/jgn9feXep4nJXWf0tg1cf_6867c6921b6a4015a1906c8e02a7ef9d.jpg' },
        { title: 'MiniMax H3 Max', desc: 'Cinematic video generation with rich visual texture.', href: '/minimax/h3-max', img: 'https://v3b.fal.media/files/b/0aa7657e/LlavC7cCdZ_GGyvyglA82.jpg' },
        { title: 'Gemini Omni Flash', desc: 'Ultra-fast multimodal video generation and editing.', href: '/google/gemini-omni-flash', img: 'https://v3b.fal.media/files/b/0aa0649d/TFqtIbw6p_p4rMT-44N8X.jpg' },
        { title: 'Veo 3.1', desc: 'Photorealistic AI video with cinematic motion.', href: '/google/veo-3.1', video: 'https://aitopia.ai/model-images/veo-3-1/veo-3-1-cover.mp4' },
        { title: 'Happy Horse', desc: 'Playful stylized video model for fun animations.', href: '/alibaba/happy-horse', img: 'https://aitopia.ai/model-images/happy-horse/happy-horse-cover.jpg' },
        { title: 'Wan 2.6', desc: 'High-fidelity video synthesis with precise detail.', href: '/wan-video/wan-2.6-t2v', video: 'https://aitopia.ai/model-images/wan-2-6-t2v/wan-2-6-t2v-cover.mp4' },
        { title: 'Wan 2.2 Animate Replace', desc: 'Seamlessly replaces subjects and elements in video.', href: '/wan-video/wan-2.2-animate-replace', video: 'https://aitopia.ai/model-images/wan-2-2-animate-replace/wan-2-2-animate-replace-cover.mp4' },
        { title: 'Hailuo 2.3 Pro', desc: 'Pro video model built for high dynamic motion.', href: '/minimax/hailuo-2.3-pro', img: 'https://aitopia.ai/model-images/hailuo-2-3-pro/hailuo-2-3-pro-cover.jpg' },
        { title: 'Grok Imagine Video', desc: 'Generates creative visual videos from text prompts.', href: '/xai/grok-imagine-video', video: 'https://aitopia.ai/model-images/grok-imagine-video/grok-imagine-video-cover.mp4' },
      ],
    },
  ];

  function navMenuHTML(key) {
    const columns = NAV_MENUS[key].map((col) => {
      const items = col.items.map((item) => {
        const thumb = item.img
          ? `<img data-src="${item.img}" alt="">`
          : item.video
            ? `<video data-src="${item.video}#t=0.1" muted playsinline preload="metadata"></video>`
          : item.icon
            ? `<span class="nav-mega-icon" style="--icon: url('/marketplace/icons/nav-menu/${item.icon}.svg')"></span>`
            : '';
        return `<a href="${item.href}" class="nav-mega-item${item.highlight ? ' is-highlight' : ''}">
          ${item.badge
            ? `<span class="nav-mega-thumb-wrap"><span class="nav-mega-thumb" aria-hidden="true">${thumb}</span><span class="nav-mega-badge">${item.badge}</span></span>`
            : `<span class="nav-mega-thumb" aria-hidden="true">${thumb}</span>`}
          <span class="nav-mega-text"><span class="nav-mega-title">${item.title}</span><span class="nav-mega-desc">${item.desc}</span></span>
        </a>`;
      }).join('');
      return `<div class="nav-mega-col"><div class="nav-mega-heading">${col.title}</div>${items}</div>`;
    }).join('');
    return `<div class="nav-mega"><div class="nav-mega-panel">${columns}</div></div>`;
  }

  function navLinksHTML() {
    const path = window.location.pathname.replace(/\/+$/, '') || '/';
    return NAV_LINKS.map((link) => {
      const active = !link.external && (path === link.href || (!link.exact && path.startsWith(link.href + '/')));
      const cls = ['nav-link', link.studio ? 'nav-studio-link ms-border' : '', active ? 'is-active' : ''].filter(Boolean).join(' ');
      const id = link.id ? ` id="${link.id}"` : '';
      const current = active ? ' aria-current="page"' : '';
      const label = link.studio
        ? `<span class="ms-text">${link.label}</span><span class="ms-badge"><span class="ms-badge-text">NEW</span></span>`
        : link.label;
      const target = link.external ? ' target="_blank" rel="noopener"' : '';
      const anchor = `<a href="${link.href}"${id} class="${cls}"${current}${target}>${label}</a>`;
      return link.menu ? `<div class="nav-menu-wrap">${anchor}${navMenuHTML(link.menu)}</div>` : anchor;
    }).join('');
  }

  function alignStudioBadge() {
    const links = Array.from(document.querySelectorAll('.nav-studio-link'));
    if (!links.length) return;
    const place = () => links.forEach((link) => {
      const badge = link.querySelector('.ms-badge');
      if (!badge) return;
      const l = link.getBoundingClientRect();
      const b = badge.getBoundingClientRect();
      const x = l.left + l.width / 2 - b.left;
      const y = l.top + l.height / 2 - b.top;
      badge.style.setProperty('--ms-at', `${x}px ${y}px`);
      badge.firstElementChild?.style.setProperty('--ms-at', `${x - 6}px ${y}px`);
    });
    place();
    document.fonts?.ready.then(place);
    window.addEventListener('resize', place);
  }

  function navIcon(size, inner, cls = '') {
    return `<svg${cls ? ` class="${cls}"` : ''} width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${inner}</svg>`;
  }

  function navAvatarHTML(size, inner) {
    const r = size / 2 - 1;
    const c = 2 * Math.PI * r;
    const offset = (size - inner) / 2;
    return `<span class="nm-avatar" style="width:${size}px;height:${size}px">
      <svg width="${size}" height="${size}" aria-hidden="true">
        <circle r="${r}" cx="${size / 2}" cy="${size / 2}" fill="none" stroke="var(--nm-w10)" stroke-width="2"/>
        <circle class="nm-ring" r="${r}" cx="${size / 2}" cy="${size / 2}" fill="none" stroke="var(--nm-accent)" stroke-width="2" stroke-linecap="round" stroke-dasharray="${c}" stroke-dashoffset="${c}" data-circ="${c}"/>
      </svg>
      <span class="nm-avatar-img" style="left:${offset}px;top:${offset}px;width:${inner}px;height:${inner}px;font-size:${Math.round(inner * 0.42)}px">
        <span class="nm-avatar-letter"></span><img class="nm-avatar-pic hidden" alt="">
      </span>
    </span>`;
  }

  function setNavAvatar({ url, name } = {}) {
    document.querySelectorAll('#profileDropdown .nm-avatar').forEach((node) => {
      const letter = node.querySelector('.nm-avatar-letter');
      const img = node.querySelector('.nm-avatar-pic');
      if (letter && name) letter.textContent = String(name).trim().charAt(0).toUpperCase();
      if (img && url !== undefined) {
        img.classList.toggle('hidden', !url);
        if (url) img.src = url;
      }
    });
  }

  const CREDITS_POOL_KEY = 'nav_credits_pool';

  function readCreditsPool() {
    try { return Number(localStorage.getItem(CREDITS_POOL_KEY)) || 0; } catch { return 0; }
  }

  function renderMenuCredits(total, pool) {
    const left = document.getElementById('profileCreditsLeft');
    const bar = document.getElementById('profileCreditsBar');
    if (typeof pool === 'number' && pool > 0) {
      try { localStorage.setItem(CREDITS_POOL_KEY, String(pool)); } catch {}
    } else {
      pool = readCreditsPool();
    }
    const unlimited = total === -999;
    const known = typeof total === 'number' && Number.isFinite(total);
    const ratio = unlimited ? 1 : known && pool > 0 ? Math.min(1, Math.max(0, total / Math.max(pool, total))) : 0;
    if (left) left.textContent = unlimited ? 'Unlimited' : known ? `${total.toLocaleString('en-US')} left` : '—';
    if (bar) {
      const pct = ratio > 0 ? Math.max(2, Math.round(ratio * 100)) : 0;
      bar.style.width = `${pct}%`;
      bar.parentElement?.setAttribute('aria-valuenow', String(pct));
    }
    document.querySelectorAll('#profileDropdown .nm-ring').forEach((ring) => {
      const c = Number(ring.dataset.circ) || 0;
      ring.setAttribute('stroke-dashoffset', String(c * (1 - ratio)));
    });
  }

  function creditsPoolOf(balance) {
    if (!balance) return 0;
    return (Number(balance.dailyAllowanceCredits) || 0) + (Number(balance.paidCreditsBalance) || 0);
  }

  // Navbar HTML template
  function getNavbarHTML() {
    const searchWrapClass =
      'navbar-search flex flex-1 justify-center min-w-0 ml-6 sm:ml-10 md:ml-14 lg:ml-20 mr-2 sm:mr-10 lg:mr-16';
    const searchBoxClass = 'nav-search relative w-full min-w-0 max-w-[280px] sm:max-w-[320px] md:max-w-[360px]';

    return `
	  <header id="header" class="sticky top-0 z-50 w-full glass border-b border-border/40 safe-top transition-all duration-300">
    <div id="promo-announcement-bar" class="w-full overflow-hidden text-center bg-[var(--promo-bar-bg)] py-2 px-4" style="display:none;">
      <div class="relative flex items-center justify-center">
        <!-- Single marquee track — entire row scrolls together when it overflows -->
        <div id="promo-bar-inner" class="inline-flex items-center gap-2.5 whitespace-nowrap">
          <span class="inline-flex items-center gap-1.5 shrink-0 whitespace-nowrap rounded-full py-1 px-3 text-sm font-medium text-white bg-[var(--promo-bar-badge-bg)]">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" class="shrink-0"><path d="M12.9897 13.3478C12.7166 10.945 11.62 9.94907 10.8191 9.22282C10.2653 8.71876 9.99909 8.45657 9.99909 8.00001C9.99909 7.54969 10.2644 7.29251 10.8166 6.79876C11.6269 6.07469 12.7366 5.08282 12.9903 2.64751C13.0106 2.44291 12.9877 2.23633 12.9231 2.04114C12.8585 1.84594 12.7537 1.66649 12.6153 1.51438C12.4676 1.35192 12.2875 1.22221 12.0865 1.13361C11.8856 1.04502 11.6684 0.999505 11.4488 1.00001H4.5494C4.32951 0.999321 4.11191 1.04474 3.91066 1.13334C3.7094 1.22194 3.52896 1.35174 3.38096 1.51438C3.24304 1.6667 3.13858 1.84623 3.07431 2.0414C3.01005 2.23657 2.9874 2.44305 3.00784 2.64751C3.26065 5.07501 4.36628 6.05969 5.17346 6.77844C5.73096 7.27501 5.99909 7.53407 5.99909 8.00001C5.99909 8.47188 5.73034 8.73626 5.17096 9.24219C4.37409 9.96407 3.28034 10.9525 3.00846 13.3478C2.98641 13.5515 3.00757 13.7575 3.07058 13.9525C3.13358 14.1474 3.237 14.3268 3.37409 14.4791C3.52239 14.6436 3.70371 14.775 3.90622 14.8648C4.10873 14.9546 4.32789 15.0006 4.5494 15H11.4488C11.6703 15.0006 11.8894 14.9546 12.092 14.8648C12.2945 14.775 12.4758 14.6436 12.6241 14.4791C12.7612 14.3268 12.8646 14.1474 12.9276 13.9525C12.9906 13.7575 13.0118 13.5515 12.9897 13.3478ZM10.7272 13.5H5.2844C4.7969 13.5 4.6594 12.9375 5.00128 12.5888C5.82878 11.75 7.49909 11.1494 7.49909 10.1875V7.00001C7.49909 6.37969 6.31159 5.90626 5.5769 4.90001C5.45565 4.73407 5.46784 4.50001 5.77596 4.50001H10.2363C10.4991 4.50001 10.5557 4.73219 10.4363 4.89844C9.71221 5.90626 8.49909 6.37657 8.49909 7.00001V10.1875C8.49909 11.1416 10.24 11.6563 11.0116 12.5897C11.3225 12.9659 11.2138 13.5 10.7272 13.5Z" fill="#FFFFFF"/></svg>
            Discount Expires in <strong id="promo-bar-timer" class="text-sm font-bold tracking-[0.02em]">--h --m --s</strong>
          </span>
          <span id="promo-bar-text" class="text-[var(--promo-bar-text)] text-sm"></span>
          <a id="promo-bar-cta" href="/marketplace/pricing.html" class="text-[var(--promo-bar-text)] text-sm font-bold underline underline-offset-2 whitespace-nowrap"></a>
        </div>
        <!-- Close button -->
        <button id="promo-bar-close" data-action="dismissPromoBar" aria-label="Close" style="position:absolute;right:0;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;padding:4px;display:flex;align-items:center;opacity:0.6;" class="hover-fade">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>
        </button>
      </div>
    </div>
	    <div class="nav-row-wrap max-w-[1600px] mx-auto px-3 sm:px-4 lg:px-6">
	      <div class="flex h-16 items-center">
	        <!-- Logo Section -->
	        <div class="flex shrink-0 items-center gap-2">
          <!-- Logo -->
	          <a href="/marketplace/" class="flex items-center">
            <img src="/marketplace/Logo.svg" alt="AITOPIA" width="36" height="36" class="h-9 w-9 sm:hidden" />
            <img src="/marketplace/Logo_all.svg" alt="AITOPIA" height="36" class="hidden sm:block h-9 w-auto" />
          </a>
        </div>

        <!-- Header search -->
        <div class="${searchWrapClass}">
          <div id="navbarSearch" class="${searchBoxClass}" role="search">
            <button id="navbarSearchButton" type="button" aria-haspopup="dialog" aria-label="Search" aria-keyshortcuts="Meta+K Control+K /"
              class="relative flex items-center w-full min-w-0 h-10 pl-10 pr-4 rounded-full bg-[#F2F5F9]/80 dark:bg-[#262626]/80 border-0 text-sm text-left text-muted-foreground cursor-pointer focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all">
              <svg width="16" height="16" class="absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" aria-hidden="true" fill="none" viewBox="0 0 16 16" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round">
                <path d="M7.665 14a6.333 6.333 0 1 0 0-12.666 6.333 6.333 0 0 0 0 12.666Z"/><path d="m14.665 14.667-1.333-1.333"/>
              </svg>
              <span class="nav-search-label truncate">Search</span>
            </button>
          </div>
        </div>

        <nav class="nav-desktop-links" aria-label="Primary">
          ${navLinksHTML()}
        </nav>

        <!-- Right side -->
        <div class="ml-auto flex shrink-0 items-center gap-1">
          <span class="nav-search-slot"></span>

          <!-- Mobile Pricing button -->
          <div id="mobile-pricing-btn-wrap" class="lg:hidden relative">
            <a href="/marketplace/pricing.html" class="h-10 px-4 flex items-center justify-center rounded-full border border-border text-sm font-medium whitespace-nowrap hover:bg-secondary transition-colors">
              Pricing
            </a>
            <span id="mobile-pricing-badge" style="display:none;position:absolute;bottom:0;left:50%;transform:translate(-50%,50%);font-size:10px;font-weight:700;color:var(--promo-nav-badge-text);background:var(--promo-nav-badge-bg);border-radius:100px;padding:1px 7px;white-space:nowrap;letter-spacing:0.03em;pointer-events:none;z-index:10;"></span>
          </div>

          <!-- Generation dock slots (mobile / desktop). The dock (generation-dock.js)
               renders its trigger into them and owns visibility; nothing here toggles them. -->
          <span id="genDockSlotMobile" data-gen-dock-slot="mobile"></span>
          <span id="genDockSlot" data-gen-dock-slot="desktop"></span>

          <div class="hidden lg:flex items-center justify-end gap-0.5 flex-shrink-0 ml-4">
            <!-- Login Button (shown when not logged in) -->
            <a href="/marketplace/login.html" id="loginBtn" class="nav-signin hidden h-9 px-3 items-center justify-center gap-2 rounded-full transition-colors hover:bg-secondary">
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M10.0026 9.99935C12.3038 9.99935 14.1693 8.13387 14.1693 5.83268C14.1693 3.5315 12.3038 1.66602 10.0026 1.66602C7.70142 1.66602 5.83594 3.5315 5.83594 5.83268C5.83594 8.13387 7.70142 9.99935 10.0026 9.99935Z" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/><path d="M17.1604 18.3333C17.1604 15.1083 13.9521 12.5 10.0021 12.5C6.05208 12.5 2.84375 15.1083 2.84375 18.3333" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/></svg>
              Sign In
            </a>

            <!-- Profile Dropdown (shown when logged in) -->
            <div class="relative hidden" id="profileDropdown">
            <button data-action="NavbarComponent.toggleProfileDropdown" class="nm-trigger btn-press cursor-pointer" aria-label="Profile menu">
              ${navAvatarHTML(32, 24)}
            </button>
            <div id="profileMenu" class="hidden nm-menu">
              <div class="nm-col">
                <a id="profileLink" href="/marketplace/settings-profile.html" class="nm-head nm-hover">
                  ${navAvatarHTML(40, 30)}
                  <span class="nm-head-text">
                    <span class="nm-name"><span id="profileName" class="nm-ellipsis"></span><span id="profilePlanBadge" class="nm-badge hidden"></span></span>
                    <span class="nm-sub nm-ellipsis">View profile</span>
                  </span>
                  ${navIcon(16, '<path d="m9.5 18 6-6-6-6"/>', 'nm-muted')}
                </a>
                <div class="nm-credits-wrap">
                  <div class="nm-credits">
                    <div class="nm-credits-top">
                      <a href="/marketplace/owner.html?owner=usage" class="nm-credits-row">
                        <span class="nm-credits-label">Credits <span class="nm-info" title="Credits reset with your plan cycle">${navIcon(14, '<circle cx="12" cy="12" r="8.25"/><path d="M12 11v5M12 8h.01"/>')}</span></span>
                        <span class="nm-credits-left"><span id="profileCreditsLeft">—</span>${navIcon(12, '<path d="m9.5 18 6-6-6-6"/>')}</span>
                      </a>
                      <span class="nm-bar" role="progressbar" aria-label="Credits left" aria-valuemin="0" aria-valuemax="100"><span id="profileCreditsBar" class="nm-bar-fill"></span></span>
                    </div>
                    <div class="nm-pt4">
                      <a id="profileUpgradeBtn" href="/marketplace/pricing.html" class="nm-row nm-row-get">
                        <span class="nm-label"><span class="nm-ico">${navIcon(16, '<ellipse cx="9" cy="8" rx="5.25" ry="2.75"/><path d="M3.75 8v4c0 1.5 2.35 2.75 5.25 2.75s5.25-1.25 5.25-2.75V8"/><path d="M9.75 14.7v1.55c0 1.5 2.35 2.75 5.25 2.75s5.25-1.25 5.25-2.75v-4c0-1.4-2-2.55-4.6-2.72"/>')}</span>Get more credits</span>
                        <span class="nm-upgrade">Upgrade</span>
                      </a>
                    </div>
                  </div>
                </div>
                <div class="nm-divider"></div>
                <div class="nm-sec">
                  <a href="https://aitopia.ai/agent-builder" class="nm-row nm-hover"><span class="nm-label"><span class="nm-ico">${navIcon(16, '<rect x="5" y="8" width="14" height="11" rx="3"/><path d="M12 4.75V8M9.5 13h.01M14.5 13h.01M3 13v2M21 13v2"/>')}</span>My Agents</span></a>
                  <a href="https://aitopia.ai/aiconomy" class="nm-row nm-hover"><span class="nm-label"><span class="nm-ico">${navIcon(16, '<circle cx="12" cy="12" r="8.25"/><path d="M14.5 9.25c-.4-.9-1.3-1.5-2.5-1.5-1.5 0-2.5.8-2.5 2s1 1.7 2.5 2 2.5.8 2.5 2-1 2-2.5 2c-1.2 0-2.1-.6-2.5-1.5M12 6.25v1.5M12 16.25v1.5"/>')}</span>AICONOMY</span></a>
                  <a href="/marketplace/outputs.html?tab=mine" class="nm-row nm-hover"><span class="nm-label"><span class="nm-ico">${navIcon(16, '<rect x="4.75" y="4.75" width="6" height="6" rx="1.5"/><rect x="13.25" y="4.75" width="6" height="6" rx="1.5"/><rect x="4.75" y="13.25" width="6" height="6" rx="1.5"/><rect x="13.25" y="13.25" width="6" height="6" rx="1.5"/>')}</span>My Creations</span></a>
                  <a id="profileDeveloperLink" href="/marketplace/developers-dashboard.html" class="hidden nm-row nm-hover"><span class="nm-label"><span class="nm-ico">${navIcon(16, '<path d="m8.5 8-4 4 4 4M15.5 8l4 4-4 4M13.5 5.5l-3 13"/>')}</span>Developer Dashboard</span></a>
                  <a href="/marketplace/settings-api-keys.html" class="nm-row nm-hover"><span class="nm-label"><span class="nm-ico">${navIcon(16, '<circle cx="8.5" cy="15.5" r="3.75"/><path d="m11.2 12.8 8.05-8.05M16.25 7.75l2.5 2.5M14 10l2 2"/>')}</span>API keys</span></a>
                </div>
                <div class="nm-divider"></div>
                <div class="nm-sec">
                  <a href="/marketplace/settings-profile.html" class="nm-row nm-hover"><span class="nm-label"><span class="nm-ico">${navIcon(16, '<circle cx="12" cy="12" r="2.75"/><path d="M19.4 13.5a7.6 7.6 0 0 0 0-3l1.85-1.4-1.9-3.3-2.15.9a7.5 7.5 0 0 0-2.6-1.5L14.3 3h-3.8l-.3 2.2a7.5 7.5 0 0 0-2.6 1.5l-2.15-.9-1.9 3.3 1.85 1.4a7.6 7.6 0 0 0 0 3L3.55 14.9l1.9 3.3 2.15-.9a7.5 7.5 0 0 0 2.6 1.5l.3 2.2h3.8l.3-2.2a7.5 7.5 0 0 0 2.6-1.5l2.15.9 1.9-3.3Z"/>')}</span>Manage Account</span></a>
                </div>
                <div class="nm-divider"></div>
                <div class="nm-pt4">
                  <button type="button" data-action="NavbarComponent.handleLogout" class="nm-row nm-hover"><span class="nm-label"><span class="nm-ico">${navIcon(16, '<path d="M14.5 4.75H7a2 2 0 0 0-2 2v10.5a2 2 0 0 0 2 2h7.5M11 12h9.25M17 8.75 20.25 12 17 15.25"/>')}</span>Sign Out</span></button>
                </div>
              </div>
            </div>
          </div>
          </div>
        </div>
      </div>
    </div>
    <span id="nav-pricing-badge" style="display:none;position:absolute;bottom:0;transform:translate(-50%,50%);font-size:10px;font-weight:700;color:var(--promo-nav-badge-text);background:var(--promo-nav-badge-bg);border-radius:100px;padding:1px 7px;white-space:nowrap;letter-spacing:0.03em;pointer-events:none;z-index:10;"></span>
  </header>
    `;
  }

  window.NavbarComponent = {
    isLoggedIn: function() { return loggedIn; },

    invalidateCreditsCache: function(refresh = true) {
      window.AitopiaCache?.remove?.(window.AitopiaCache?.KEYS?.USER_CREDITS);
      if (refresh) {
        this.loadUserCredits();
      }
    },

    decrementCreditsOptimistic: function(deltaCredits) {
      const delta = Math.max(0, Math.trunc(Number(deltaCredits) || 0));
      if (!delta) return;

      const current = getUserCredits();
      if (typeof current !== 'number' || !Number.isFinite(current)) return;

      const next = Math.max(0, current - delta);
      setUserCredits(next);
      renderMenuCredits(next);
    },

    toggleTheme: function() {
      const html = document.documentElement;
      const isDark = html.classList.contains('dark');
      if (isDark) {
        html.classList.remove('dark');
        localStorage.setItem('theme', 'light');
      } else {
        html.classList.add('dark');
        localStorage.setItem('theme', 'dark');
      }
      if (typeof window.injectHeaderCss == 'function') window.injectHeaderCss();
    },

    toggleProfileDropdown: function() {
      const menu = document.getElementById('profileMenu');
      if (menu) menu.classList.toggle('hidden');
    },

    handleLogout: async function() {
      try {
        clearUserCache();
        try { localStorage.removeItem(CREDITS_POOL_KEY); } catch {}
        await fetch('https://aitopia.ai/auth/logout', { method: 'POST', credentials: 'include' });
      } catch (e) {
        console.error('Logout error:', e);
      }
      try { Object.keys(sessionStorage).filter((k) => k.startsWith('genDock.')).forEach((k) => sessionStorage.removeItem(k)); } catch {}
      window.location.reload();
    },

    loadUserProfile: async function() {
      const loginBtn = document.getElementById('loginBtn');
      const profileDropdown = document.getElementById('profileDropdown');
      const profileName = document.getElementById('profileName');
      const profilePlanBadge = document.getElementById('profilePlanBadge');
      const profileDeveloperLink = document.getElementById('profileDeveloperLink');

      const setDeveloperLinkVisible = (visible) => {
        if (!profileDeveloperLink) return;
        if (visible) {
          profileDeveloperLink.classList.remove('hidden');
          profileDeveloperLink.classList.add('flex');
          return;
        }
        profileDeveloperLink.classList.add('hidden');
        profileDeveloperLink.classList.remove('flex');
      };

      const updateUI = (profileData) => {
        if (!profileData) {
          if (loginBtn) {
            loginBtn.classList.remove('hidden');
            loginBtn.classList.add('flex');
          }
          if (profileDropdown) profileDropdown.classList.add('hidden');
          setDeveloperLinkVisible(false);
          developerStatusPromise = null;
          publishAuth(false);
          return;
        }

        const { fullName, plan } = profileData;
        if (loginBtn) {
          loginBtn.classList.add('hidden');
          loginBtn.classList.remove('flex');
        }
        if (profileDropdown) profileDropdown.classList.remove('hidden');
        if (profileName && !profileName.dataset.username) profileName.textContent = fullName;
        if (profilePlanBadge) {
          profilePlanBadge.textContent = plan ? String(plan).toUpperCase() : '';
          profilePlanBadge.classList.toggle('hidden', !plan);
        }
        setNavAvatar({ name: fullName });
        setDeveloperLinkVisible(false);
        void fetchIsDeveloper().then((isDeveloper) => {
          setDeveloperLinkVisible(Boolean(isDeveloper));
        });
        publishAuth(true);
      };

      const cached = getUserProfile();
      if (cached) {
        updateUI(cached);
        this.loadUserCredits();
        this.loadSocialProfile();
        return;
      }
      // User calls must not compete with the page's primary requests (agent + schema).
      await window.aitopiaLoadOrder?.wait('critical');
      const h = window.location.hostname;
      const parts = h.split(".");
      // Fall back to aitopia.ai when not on a real multi-part domain
      // (localhost, IPs, or a Chrome extension ID host have no usable root domain).
      const isLocal = h.indexOf("localhost") !== -1 || parts.length < 2;
      const rootDomain = parts.length > 2 ? parts.slice(-2).join(".") : h;
      const url = isLocal
      ? `https://extensions.aitopia.ai/extensions/app/key`
      : `https://extensions.${rootDomain}/extensions/app/key`;
      try {
        const aitopia_response = await fetch(
          url,
          { method: "GET", credentials: "include" },
        );
        if (aitopia_response?.key) {
          const domainAttr = isLocal ? "" : `; Domain=.${rootDomain}`;
          document.cookie = `hopekey=${aitopia_response?.key}; expires=${365 * 24 * 60 * 60 * 1000}; path=/; Secure; SameSite=None${domainAttr}`;
        }
      } catch (e) {}
      try {
        const response = await fetch('https://aitopia.ai/auth/me', { method: 'GET', credentials: 'include' });
        if (response.ok) {
          const resp = await response.json();
          if (window.AitopiaForceRedirect?.apply(resp)) return;
          const userData = resp?.data?.user || resp?.data || resp?.user || resp;
          const isLoggedIn = userData && !Array.isArray(userData) && typeof userData === 'object' && (userData.email || userData.key);

          // A verified session clears any stale gate left by an earlier load.
          if (isLoggedIn && !resp?.force_redirect) window.AitopiaForceRedirect?.clearVerifyPending?.();

          if (isLoggedIn) {
            const email = userData.email || '';
            const name = userData.name || '';
            const lastname = userData.lastname || '';
            const fullName = [name, lastname].filter(Boolean).join(' ') || (email ? email.split('@')[0] : 'User');
            const plan = resp?.data?.plan || resp?.data?.licences?.plan_type || userData.plan || userData.planName || '';
            const licences = resp?.data?.licences || null;
            const extra = resp?.data?.extra || null;

            const profileData = { fullName, email, plan, licences, extra };
            setUserProfile(profileData);
            updateUI(profileData);
            this.loadUserCredits();
            this.loadSocialProfile();
            // Hide promo elements for creator plan users
            if (String(plan || '').toLowerCase() === 'creator') {
              document.getElementById('nav-pricing-badge')?.style?.setProperty('display', 'none', 'important');
              document.getElementById('mobile-pricing-badge')?.style?.setProperty('display', 'none', 'important');
              const promoBar = document.getElementById('promo-announcement-bar');
              if (promoBar) promoBar.style.display = 'none';
              localStorage.removeItem('promo_bar_active');
            }
            return;
          }
        }
      } catch (e) {
      }

      updateUI(null);
    },

    loadUserCredits: async function() {
      const cached = getUserCredits();
      if (cached !== null) {
        renderMenuCredits(cached);
        if (readCreditsPool() > 0) return;
      }
      await window.aitopiaLoadOrder?.wait('critical');

      try {
        let balanceData;
        if (window.AitopiaCredits?.loadCreditsBalance) {
          balanceData = await window.AitopiaCredits.loadCreditsBalance();
        } else {
          const res = await fetch('https://aitopia.ai/api/credits/balance', { credentials: 'include' });
          if (res.ok) balanceData = await res.json();
        }
        if (!balanceData?.balance) {
          if (cached === null) renderMenuCredits(null);
          return;
        }
        const totalCredits = balanceData.balance.totalCredits ?? balanceData.balance.totalCreditsRemaining ?? 0;

        setUserCredits(totalCredits);
        renderMenuCredits(totalCredits, creditsPoolOf(balanceData.balance));
      } catch (e) {
        if (cached === null) renderMenuCredits(null);
      }
    },

    loadSocialProfile: async function() {
      await window.aitopiaLoadOrder?.wait('critical');
      await window.aitopiaPreAuth;
      try {
        window.__aitopiaMe = window.__aitopiaMe || fetch('https://aitopia.ai/api/users/me', { credentials: 'include' })
          .then(async (res) => ({ ok: res.ok, status: res.status, json: await res.json().catch(() => null) }))
          .catch(() => ({ ok: false, status: 0, json: null }));
        const pending = window.__aitopiaMe;
        const me = await pending;
        if (!me.ok) {
          if (window.__aitopiaMe === pending) window.__aitopiaMe = null;
          return;
        }
        const json = me.json;
        const username = json?.profile?.username;
        if (username) {
          const profileLink = document.getElementById('profileLink');
          if (profileLink) {
            profileLink.href = `/marketplace/profile.html?username=${encodeURIComponent(username)}`;
          }
          const profileName = document.getElementById('profileName');
          if (profileName) {
            profileName.textContent = username;
            profileName.dataset.username = username;
          }
        }
        setNavAvatar({ url: json?.profile?.avatarUrl || '', name: username || undefined });
      } catch (e) {
        // Ignore errors
      }
    },

    init: function() {
      const container = document.getElementById('navbar-container');

      if (!container) {
        console.warn('NavbarComponent: #navbar-container not found');
        return;
      }

      injectStickyStyles();
      container.innerHTML = getNavbarHTML();
      alignStudioBadge();
      initStickyHeader();
      initPromoBar();
      bindHeaderSearch();

      try {
        document.documentElement.classList.remove('global-nav-loading');
        document.documentElement.classList.add('global-nav-ready');
      } catch {}

      this.loadUserProfile();

      window.addEventListener('aitopia-credits-updated', (e) => {
        const totalCredits = e.detail?.balance?.totalCredits ?? e.detail?.balance?.totalCreditsRemaining;
        if (typeof totalCredits === 'number') {
          setUserCredits(totalCredits);
          renderMenuCredits(totalCredits, creditsPoolOf(e.detail?.balance));
        }
      });

      document.querySelectorAll('.nav-menu-wrap').forEach((wrap) => {
        const loadMedia = () => wrap.querySelectorAll('img[data-src], video[data-src]').forEach((v) => {
          const media = window.AitopiaMedia;
          const url = v.dataset.src;
          if (v.tagName === 'VIDEO') {
            const poster = media ? media.poster(url, 48) : '';
            if (poster) v.poster = poster;
            v.src = media ? media.preview(url, 48) : url;
          } else {
            v.src = media ? media.image(url, 48) : url;
          }
          v.removeAttribute('data-src');
        });
        wrap.addEventListener('mouseenter', loadMedia, { once: true });
        wrap.addEventListener('focusin', loadMedia, { once: true });
      });

      const wideSearch = window.matchMedia('(min-width: 1280px)');
      const placeSearch = () => {
        const box = document.getElementById('navbarSearch');
        const target = document.querySelector(wideSearch.matches ? '.nav-search-slot' : '.navbar-search');
        if (box && target && box.parentElement !== target) target.appendChild(box);
      };
      placeSearch();
      wideSearch.addEventListener('change', placeSearch);

      document.addEventListener('click', (e) => {
        const dropdown = document.getElementById('profileDropdown');
        if (dropdown && !dropdown.contains(e.target)) {
          const menu = document.getElementById('profileMenu');
          if (menu) menu.classList.add('hidden');
        }
      });
    }
  };

  window.toggleTheme = window.NavbarComponent.toggleTheme;
  window.handleLogout = window.NavbarComponent.handleLogout;
  window.toggleProfileDropdown = window.NavbarComponent.toggleProfileDropdown;

  const STICKY_STYLE_ID = 'navbarStickyStyles';
  // The bar materialises over the first scrolled pixels and is fully glass by the time content slides under it.
  const SCROLL_TRANSITION_PX = 64;

  function injectStickyStyles() {
    if (document.getElementById(STICKY_STYLE_ID)) return;
    if (!document.querySelector('link[href="/marketplace/css/design-tokens.css"]')) {
      const tokens = document.createElement('link');
      tokens.rel = 'stylesheet';
      tokens.href = '/marketplace/css/design-tokens.css';
      document.head.appendChild(tokens);
    }
    const style = document.createElement('style');
    style.id = STICKY_STYLE_ID;
    // #navbar-container is a block exactly as tall as the header, which caps the header's sticky
    // range at zero. Removing the wrapper's box lets #header's position:sticky reach the viewport.
    style.textContent = `
      #navbar-container { display: contents; }
      html { scroll-padding-top: var(--navbar-height, 4rem); }
      /* The header search sits inside that padding band, so each keystroke's caret scroll-into-view would pull the page up. */
      html:has(#header:focus-within) { scroll-padding-top: 0; }
      .below-navbar { top: calc(var(--navbar-height, 4rem) + 1rem); }
      #header {
        --navbar-scroll: 0;
        background-color: rgba(255, 255, 255, calc(0.6 * var(--navbar-scroll)));
        border-bottom-color: rgba(0, 0, 0, calc(0.08 * var(--navbar-scroll)));
        box-shadow: 0 8px 24px -12px rgba(0, 0, 0, calc(0.14 * var(--navbar-scroll)));
        /* Keep shared.css's opacity fade on global-nav-ready; this list replaces the header's transition-all. */
        transition: background-color 150ms linear, border-color 150ms linear, box-shadow 150ms linear, opacity 120ms ease-out;
      }
      /* shared.css forces dark headers to opaque #0A0A0A !important; keep the bar translucent glass instead. */
      .dark #header {
        --ait-m-secondary: 0 0% 15%;
        --ait-m-card: 0 0% 6%;
        --ait-m-border: 0 0% 18%;
        background-color: rgba(10, 10, 10, calc(0.7 * var(--navbar-scroll))) !important;
        border-bottom-color: rgba(255, 255, 255, calc(0.08 * var(--navbar-scroll)));
        box-shadow: 0 8px 24px -12px rgba(0, 0, 0, calc(0.55 * var(--navbar-scroll)));
      }
      @media (prefers-reduced-motion: reduce) { #header { transition: none; } }
      .nav-desktop-links { display: none; }
      .nav-link {
        height: 36px;
        padding: 0 14px;
        display: flex;
        align-items: center;
        white-space: nowrap;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 400;
        line-height: 20px;
        color: hsl(var(--ait-m-foreground) / 0.82);
        transition: color 150ms, background-color 150ms, padding 250ms cubic-bezier(0.2, 0, 0, 1);
      }
      .nav-link:hover, .nav-link.is-active { color: hsl(var(--ait-m-foreground)); background-color: hsl(var(--ait-m-secondary)); }
      @property --ms-angle { syntax: "<angle>"; inherits: true; initial-value: 0deg; }
      @keyframes ms-spin { to { --ms-angle: 360deg; } }
      .nav-link.nav-studio-link { height: auto; margin: 0 6px; padding: 5px 5px 5px 8px; gap: 6px; border-radius: 11px; display: inline-flex; align-self: center; }
      .ms-border { position: relative; isolation: isolate; animation: 3s linear infinite ms-spin; }
      .ms-border::before { content: ""; position: absolute; inset: 0; z-index: -1; padding: 1px; border-radius: inherit; background: conic-gradient(from var(--ms-angle), var(--ds-ms-glow-clear) 0deg, var(--ds-ms-glow-clear) 200deg, var(--ds-ms-glow) 280deg, var(--ds-ms-gold) 350deg, var(--ds-ms-gold-clear) 360deg), var(--ds-ms-tint); -webkit-mask: linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0); -webkit-mask-composite: xor; mask-composite: exclude; }
      .ms-text { background: linear-gradient(var(--ms-angle), var(--ds-ms-text-from), var(--ds-ms-gold)); -webkit-background-clip: text; background-clip: text; -webkit-text-fill-color: transparent; }
      .ms-badge { flex-shrink: 0; padding: 0 6px; border-radius: 6px; font-size: 10px; font-weight: 700; line-height: 16px; background: var(--ds-accent-soft); }
      .ms-badge-text { display: block; background: conic-gradient(from var(--ms-angle) at var(--ms-at, 50% 50%), var(--ds-accent-text) 0deg, var(--ds-accent-text) 200deg, var(--ds-ms-text-from) 280deg, var(--ds-ms-gold) 350deg, var(--ds-accent-text) 360deg); -webkit-background-clip: text; background-clip: text; -webkit-text-fill-color: transparent; }
      @media (prefers-reduced-motion: reduce) { .ms-border { animation: none; } }
      .nav-desktop-links { position: relative; }
      .nav-mega {
        position: absolute;
        top: 100%;
        left: 50%;
        padding-top: 14px;
        z-index: 70;
        visibility: hidden;
        opacity: 0;
        transform: translate(-50%, -4px);
        transition: opacity 150ms ease-out, transform 150ms ease-out, visibility 0s linear 150ms;
      }
      .nav-menu-wrap:hover .nav-mega, .nav-menu-wrap:focus-within .nav-mega {
        visibility: visible;
        opacity: 1;
        transform: translate(-50%, 0);
        transition-delay: 0s;
      }
      .nav-menu-wrap:hover > .nav-link { color: hsl(var(--ait-m-foreground)); background-color: hsl(var(--ait-m-secondary)); }
      .nav-mega-panel {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        column-gap: 48px;
        width: min(1000px, calc(100vw - 48px));
        max-height: calc(100vh - var(--navbar-height, 4rem) - 24px);
        overflow-y: auto;
        padding: 20px;
        border-radius: 20px;
        border: 1px solid hsl(var(--ait-m-border));
        background-color: hsl(var(--ait-m-card));
        box-shadow: 0 24px 48px -16px rgba(0, 0, 0, 0.45);
      }
      .nav-mega-heading { padding-bottom: 8px; font-family: Inter, ui-sans-serif, system-ui, sans-serif; font-size: 14px; font-weight: 500; line-height: 21px; color: hsl(var(--ait-m-foreground) / 0.5); }
      .nav-mega-item {
        display: flex;
        align-items: center;
        gap: 12px;
        height: 64px;
        margin: 0 -12px;
        padding: 8px 12px;
        border-radius: 12px;
        transition: background-color 150ms;
      }
      .nav-mega-item:hover { background-color: var(--panel-hover, hsl(var(--ait-m-secondary))); }
      .nav-mega-thumb {
        flex-shrink: 0;
        width: 48px;
        height: 48px;
        display: flex;
        align-items: center;
        justify-content: center;
        overflow: hidden;
        border-radius: 12px;
        background-color: hsl(var(--ait-m-secondary));
        color: hsl(var(--ait-m-foreground));
      }
      .nav-mega-thumb img, .nav-mega-thumb video { width: 100%; height: 100%; object-fit: cover; }
      .nav-mega-item.is-highlight .nav-mega-thumb { box-shadow: inset 0 0 0 1px hsl(var(--ait-m-primary)); }
      .nav-mega-thumb-wrap { position: relative; flex-shrink: 0; }
      .nav-mega-badge {
        position: absolute;
        top: -9px;
        left: 50%;
        transform: translateX(-50%);
        padding: 1px 6px;
        border-radius: 6px;
        background-color: hsl(var(--ait-m-primary));
        color: #fff;
        font-family: Inter, ui-sans-serif, system-ui, sans-serif;
        font-size: 10px;
        font-style: italic;
        font-weight: 700;
        line-height: 14px;
        white-space: nowrap;
      }
      .nav-mega-icon {
        width: 24px;
        height: 24px;
        background-color: currentColor;
        -webkit-mask: var(--icon) center / contain no-repeat;
        mask: var(--icon) center / contain no-repeat;
      }
      .nav-mega-text { display: flex; flex-direction: column; gap: 2px; min-width: 0; }
      .nav-mega-title, .nav-mega-desc { font-family: Inter, ui-sans-serif, system-ui, sans-serif; font-size: 14px; font-weight: 500; line-height: 21px; }
      .nav-mega-title { color: hsl(var(--ait-m-foreground)); }
      .nav-mega-desc { color: hsl(var(--ait-m-foreground) / 0.5); }
      .nav-mega-title, .nav-mega-desc { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
      .nav-search-slot { display: none; }
      @media (max-width: 639px) {
        #header .navbar-search { justify-content: flex-start; margin-left: 12px; margin-right: 12px; }
        #header .navbar-search .nav-search { max-width: none; }
        #header .navbar-search button { padding-left: 36px; padding-right: 10px; }
        #header .navbar-search svg { left: 13px; }
      }
      @media (max-width: 359px) {
        #header .navbar-search { margin-left: 8px; margin-right: 8px; }
        #header .navbar-search button { padding-left: 32px; padding-right: 6px; }
        #header .navbar-search svg { left: 11px; }
      }
      .dark { --nav-muted: 267 8% 77.8%; }
      .nav-signin { font-family: Inter, ui-sans-serif, system-ui, sans-serif; font-weight: 500; font-size: 14px; color: hsl(var(--nav-muted, var(--ait-m-muted-foreground))); }
      .nav-row-wrap { position: relative; }
      #header .nav-row-wrap { max-width: none; padding-left: clamp(12px, 5vw, 96px); padding-right: clamp(12px, 5vw, 96px); }
      @media (min-width: 1280px) {
        .nav-desktop-links { display: flex; flex: 1; min-width: 0; align-items: center; justify-content: center; gap: 2px; margin: 0 16px; }
        #header .navbar-search { display: none; }
        .nav-search-slot {
          display: block;
          flex-shrink: 0;
          width: 40px;
          height: 40px;
          margin-right: 4px;
        }
        .nav-search-slot .nav-search { width: 100%; max-width: none; }
        #header .nav-search-slot button { height: 40px; padding-right: 0; background-color: hsl(var(--ait-m-secondary)); }
        #header .nav-search-slot .nav-search-label { display: none; }
      }
      @media (min-width: 1280px) and (max-width: 1439px) {
        .nav-desktop-links { margin: 0 8px; gap: 0; }
        .nav-link { padding: 0 8px; font-size: 13px; }
      }
      #profileDropdown { --nm-card: var(--ds-card); --nm-w05: var(--ds-w05); --nm-w10: var(--ds-w10); --nm-w100: var(--ds-w100); --nm-muted2: var(--ds-muted2); --nm-accent: var(--ds-accent); --nm-accent-text: var(--ds-accent-text); --nm-accent-soft: var(--ds-accent-soft); --nm-on-accent: var(--ds-on-accent); --nm-shadow: var(--ds-menu-shadow); }
      .nm-trigger { display: flex; margin-left: 4px; padding: 0; border: 0; border-radius: 999px; background: transparent; }
      .nm-avatar { position: relative; display: inline-block; flex-shrink: 0; }
      .nm-avatar svg { position: absolute; inset: 0; transform: rotate(-90deg); }
      .nm-ring { transition: stroke-dashoffset .4s ease; }
      .nm-avatar-img { position: absolute; overflow: hidden; display: flex; align-items: center; justify-content: center; border-radius: 999px; background: linear-gradient(135deg, var(--nm-accent), var(--nm-accent-text)); color: var(--nm-on-accent); font-weight: 600; }
      .nm-avatar-pic { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; }
      .nm-menu { position: absolute; top: calc(100% + 8px); right: 0; z-index: 60; width: 290px; padding: 6px; border-radius: 20px; background: var(--nm-card); border: 1px solid var(--nm-w05); box-shadow: var(--nm-shadow); color: var(--nm-w100); }
      .nm-menu.hidden, .nm-menu .hidden, #profileDropdown .nm-avatar-pic.hidden { display: none !important; }
      .nm-col { display: flex; flex-direction: column; gap: 4px; }
      .nm-hover { transition: background-color .15s; }
      .nm-hover:hover { background-color: var(--nm-w05); }
      .nm-head { display: flex; align-items: center; gap: 12px; height: 52px; padding: 6px 8px; border-radius: 12px; color: inherit; text-decoration: none; }
      .nm-head-text { flex: 1; min-width: 0; display: flex; flex-direction: column; }
      .nm-name { display: flex; align-items: center; gap: 6px; min-width: 0; font-size: 12px; font-weight: 500; line-height: 18px; }
      .nm-ellipsis { white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
      .nm-badge { flex-shrink: 0; padding: 0 6px; border-radius: 6px; background: var(--nm-accent-soft); color: var(--nm-accent-text); font-size: 11px; font-weight: 700; line-height: 16px; letter-spacing: .04em; }
      .nm-sub { font-size: 12px; font-weight: 500; line-height: 18px; color: var(--nm-muted2); }
      .nm-muted { flex-shrink: 0; color: var(--nm-muted2); }
      .nm-credits-wrap { padding: 6px 0; }
      .nm-credits { display: flex; flex-direction: column; padding: 2px 4px 4px; border-radius: 16px; background: var(--nm-w05); }
      .nm-credits-top { display: flex; flex-direction: column; gap: 6px; padding: 8px; }
      .nm-credits-row { display: flex; align-items: center; justify-content: space-between; gap: 8px; color: inherit; text-decoration: none; }
      .nm-credits-label { display: flex; align-items: center; gap: 2px; font-size: 12px; font-weight: 500; line-height: 18px; }
      .nm-info { width: 20px; height: 20px; display: flex; align-items: center; justify-content: center; color: var(--nm-muted2); }
      .nm-credits-left { display: flex; align-items: center; gap: 2px; font-size: 12px; font-weight: 500; line-height: 18px; color: var(--nm-muted2); }
      .nm-bar { display: block; height: 8px; border-radius: 999px; overflow: hidden; background: var(--nm-w10); }
      .nm-bar-fill { display: block; width: 0; height: 100%; border-radius: inherit; background: linear-gradient(90deg, var(--nm-accent), var(--nm-accent-text)); transition: width .4s ease; }
      .nm-pt4 { padding-top: 4px; }
      .nm-sec { padding: 4px 0; }
      .nm-row { display: flex; align-items: center; justify-content: space-between; width: 100%; height: 32px; padding: 0 10px 0 4px; border: 0; border-radius: 99px; background: transparent; color: inherit; font: inherit; text-align: left; text-decoration: none; cursor: pointer; }
      .nm-row-get { padding: 8px 4px; }
      .nm-label { display: flex; align-items: center; gap: 6px; font-size: 12px; font-weight: 500; line-height: 18px; }
      .nm-ico { width: 24px; height: 24px; display: flex; align-items: center; justify-content: center; }
      .nm-upgrade { height: 24px; padding: 0 12px; border-radius: 99px; background: var(--nm-accent); color: var(--nm-on-accent); font-size: 11px; font-weight: 600; line-height: 24px; }
      .nm-divider { height: 1px; margin: 0 4px; background: var(--nm-w05); }
    `;
    document.head.appendChild(style);
  }

  function initStickyHeader() {
    const header = document.getElementById('header');
    if (!header) return;

    const publishHeight = () => {
      document.documentElement.style.setProperty('--navbar-height', `${header.offsetHeight}px`);
    };
    publishHeight();
    if (typeof window.ResizeObserver === 'function') {
      new window.ResizeObserver(publishHeight).observe(header);
    }

    let lastProgress = '';
    const onScroll = () => {
      const progress = Math.min(1, Math.max(0, window.scrollY / SCROLL_TRANSITION_PX)).toFixed(3);
      if (progress === lastProgress) return;
      lastProgress = progress;
      header.style.setProperty('--navbar-scroll', progress);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  function initPromoBar() {
    function applyPromoBar(cfg) {
      const text       = cfg.text         || 'NanoBanana 2 UNLIMITED on Premium. Nano Banana Pro 2K & Seedream 4.5K generations.';
      const ctaText    = cfg.ctaText      || 'Personal %52 OFF';
      const ctaHref    = cfg.ctaHref      || '/marketplace/pricing.html';
      const badgeText  = cfg.badgeText    || '%52 OFF';
      const durationMs = (cfg.durationHours ?? 3) * 3600000;

      const textEl  = document.getElementById('promo-bar-text');
      const ctaEl   = document.getElementById('promo-bar-cta');
      const timerEl = document.getElementById('promo-bar-timer');
      const cachedPlan = (getUserProfile()?.plan || '').toLowerCase();
      const hidePromo = cachedPlan === 'creator';
      const badgeEl = document.getElementById('nav-pricing-badge');
      if (badgeEl) badgeEl.textContent = badgeText;
      const mobileBadge = document.getElementById('mobile-pricing-badge');
      if (mobileBadge && !hidePromo) { mobileBadge.textContent = badgeText; mobileBadge.style.display = 'inline-block'; }
      if (!hidePromo) _positionPricingBadge();

      if (textEl) textEl.textContent = text;
      if (ctaEl) { ctaEl.textContent = ctaText; ctaEl.href = ctaHref; }

      // Enable marquee when content overflows the bar width
      requestAnimationFrame(function () {
        const inner = document.getElementById('promo-bar-inner');
        const outer = document.getElementById('promo-announcement-bar');
        if (!inner || !outer || inner.scrollWidth <= outer.clientWidth) return;
        // Duplicate content for seamless loop
        outer.style.textAlign = 'left';
        const sep = '<span style="display:inline-block;width:48px;flex-shrink:0;" aria-hidden="true"></span>';
        const original = inner.innerHTML;
        inner.innerHTML = original + sep + original + sep;
        inner.style.animation = 'promo-marquee 22s linear infinite';
      });

      if (!document.getElementById('promo-bar-timer')) return;

      const STORAGE_KEY = 'promo_expiry';
      let endMs = parseInt(localStorage.getItem(STORAGE_KEY), 10);
      if (!endMs || endMs < Date.now()) {
        endMs = Date.now() + durationMs;
        localStorage.setItem(STORAGE_KEY, endMs);
      }

      function fmt(n) { return String(n).padStart(2, '0'); }
      function tick() {
        const rem = Math.max(0, endMs - Date.now());
        const h = Math.floor(rem / 3600000);
        const m = Math.floor((rem % 3600000) / 60000);
        const s = Math.floor((rem % 60000) / 1000);
        const text = `${fmt(h)}h ${fmt(m)}m ${fmt(s)}s`;
        document.querySelectorAll('#promo-bar-timer').forEach(function (el) { el.textContent = text; });
        if (rem === 0) {
          endMs = Date.now() + durationMs;
          localStorage.setItem('promo_expiry', endMs);
        }
      }
      tick();
      setInterval(tick, 1000);
    }

    fetch('https://aitopia.ai/store/promo-config.json')
      .then(function (r) { return r.ok ? r.json() : {}; })
      .catch(function () { return {}; })
      .then(applyPromoBar);
  }

  function runInit() {
    if (window.__AITOPIA_NAVBAR_INIT_DONE__) return;
    window.__AITOPIA_NAVBAR_INIT_DONE__ = true;
    window.NavbarComponent.init();
    setUrlCookie();
    window.dismissPromoBar = function () {
      const bar = document.getElementById('promo-announcement-bar');
      if (bar) bar.style.display = 'none';
      localStorage.setItem('promo_bar_dismissed', '1');
      localStorage.removeItem('promo_bar_active');
    };
    if (localStorage.getItem('promo_bar_active') && !localStorage.getItem('promo_bar_dismissed')) {
      const bar = document.getElementById('promo-announcement-bar');
      if (bar) bar.style.display = '';
    }
  }
  if (document.getElementById('navbar-container')) {
    runInit();
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', runInit);
  } else {
    runInit();
  }


  function _positionPricingBadge() {
    const badge = document.getElementById('nav-pricing-badge');
    const link = document.getElementById('nav-pricing-link');
    if (!badge || !link) return;
    if (link.getBoundingClientRect().width === 0) {
      badge.style.display = 'none';
      return;
    }
    if (badge.parentElement !== link) {
      link.style.position = 'relative';
      link.appendChild(badge);
      badge.style.left = '50%';
      badge.style.bottom = '-10px';
    }
    badge.style.display = 'inline-block';
  }

  window.showNavPricingBadge = function () {
    _positionPricingBadge();
  };

  window.addEventListener('resize', () => {
    const badge = document.getElementById('nav-pricing-badge');
    if (badge) _positionPricingBadge();
  });

})();
