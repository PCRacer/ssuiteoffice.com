(function() {
  // Load CSP-compliant event delegation handlers (once)
  if (!window.__CSP_HANDLERS_LOADED__) {
    window.__CSP_HANDLERS_LOADED__ = true;
    import(/* @vite-ignore */ '/marketplace/js/csp-event-handlers.js').catch(function(){});
  }

  const NAVBAR_VERSION = 'navbar-v5';
  if (window.__AITOPIA_NAVBAR__ === NAVBAR_VERSION) return;
  window.__AITOPIA_NAVBAR__ = NAVBAR_VERSION;

  const getCache = () => window.AitopiaCache;
  const getUserProfile = () => getCache()?.getUserProfile?.() ?? null;
  const setUserProfile = (data) => getCache()?.setUserProfile?.(data);
  const getUserCredits = () => getCache()?.getUserCredits?.() ?? null;
  const setUserCredits = (credits) => getCache()?.setUserCredits?.(credits);
  const clearUserCache = () => getCache()?.clearUserData?.();

  let developerStatusPromise = null;

  // One login signal for the scripts that load after us: the generation dock
  // reads isLoggedIn() at start and follows the event. null = profile pending.
  let loggedIn = null;
  function publishAuth(value) {
    loggedIn = value;
    window.dispatchEvent(new CustomEvent('aitopia-auth-changed', { detail: { loggedIn: value } }));
  }

function setUrlCookie() {
  const currentPath = window.location.pathname;
  const unListingPages = ["pricing", "login", "register", "reset-password"];
  let checkPage = true;
  unListingPages.forEach((item) => {
    if (currentPath.indexOf(`/${item}`) !== -1) {
      checkPage = false;
    }
  });

  const cookieValue = checkPage ? window.location.href : window.location.origin;

  const expires = new Date(Date.now() + 3600000).toUTCString(); // 1 hour
  document.cookie = `aitopia_last_url=${encodeURIComponent(cookieValue)}; expires=${expires}; path=/; Secure; SameSite=None; Domain=.${window.location.hostname}`;
}

  async function fetchIsDeveloper(forceRefresh = false) {
    if (!forceRefresh && developerStatusPromise) return developerStatusPromise;
    developerStatusPromise = (async () => {
      try {
        const res = await fetch('https://aitopia.ai/api/developers/me?soft=1', {
          method: 'GET',
          credentials: 'include',
          headers: { Accept: 'application/json' },
        });
        return res.ok;
      } catch {
        return false;
      }
    })();
    return developerStatusPromise;
  }

  function getHeaderSearchContext() {
    const pathname = String(window.location?.pathname || '').toLowerCase();
    const inModels = pathname.startsWith('/marketplace/models.html') || pathname.startsWith('/model/');
    const inAgents = pathname.startsWith('/marketplace/agents.html') || pathname.startsWith('/agent/');

    if (inModels) {
      return {
        targetPath: '/marketplace/models.html',
        queryParam: 'search',
        linkedInputId: 'search-input',
        sectionOrder: ['owners', 'models', 'agents', 'categories'],
      };
    }

    if (inAgents) {
      return {
        targetPath: '/marketplace/agents.html',
        queryParam: 'q',
        linkedInputId: 'searchInput',
        sectionOrder: ['agents', 'owners', 'models', 'categories'],
      };
    }

    return { targetPath: '/marketplace/search.html', queryParam: 'q', linkedInputId: null };
  }

  function autoBindNavbarAutocomplete() {
    const ctx = getHeaderSearchContext();
    if (!ctx || !ctx.sectionOrder) return;
    import('/marketplace/js/search/navbar-autocomplete.js')
      .then((mod) => {
        mod.bindNavbarAutocomplete({
          sectionOrder: ctx.sectionOrder,
          fallbackUrl: ctx.targetPath,
          fallbackParam: ctx.queryParam,
        });
      })
      .catch((error) => {
        console.warn('[navbar] failed to load autocomplete', error);
      });
  }

  function bindHeaderSearch() {
    const form = document.getElementById('navbarHeaderSearchForm');
    const input = document.getElementById('navbarHeaderSearchInput') || document.getElementById('searchInput');
    if (!(form instanceof HTMLFormElement) || !(input instanceof HTMLInputElement)) return;

    const { targetPath, queryParam, linkedInputId } = getHeaderSearchContext();
    const linkedEl = linkedInputId ? document.getElementById(linkedInputId) : null;
    const linkedSearchInput = linkedEl instanceof HTMLInputElement ? linkedEl : null;

    const params = new URLSearchParams(window.location.search);
    const queryFromUrl = params.get(queryParam) || params.get('q') || params.get('search') || '';

    if (linkedSearchInput?.value) {
      input.value = linkedSearchInput.value;
    } else if (queryFromUrl) {
      input.value = queryFromUrl;
    }

    let syncing = false;
    let dispatchTimer = null;

    const fireLinkedEvent = () => {
      syncing = true;
      try { linkedSearchInput.dispatchEvent(new Event('input', { bubbles: true })); }
      finally { syncing = false; }
    };

    const syncToLinkedInput = (immediate) => {
      if (!linkedSearchInput || syncing) return false;
      syncing = true;
      try {
        const changed = linkedSearchInput.value !== input.value;
        if (changed) linkedSearchInput.value = input.value;
        if (dispatchTimer) clearTimeout(dispatchTimer);
        if (immediate) {
          fireLinkedEvent();
        } else if (changed) {
          dispatchTimer = setTimeout(fireLinkedEvent, 500);
        }
        return true;
      } finally {
        syncing = false;
      }
    };

    if (linkedSearchInput) {
      linkedSearchInput.addEventListener('input', () => {
        if (syncing) return;
        if (input.value !== linkedSearchInput.value) input.value = linkedSearchInput.value;
      });
      if (input.value) syncToLinkedInput(true);
    }

    let clearQueryTimer = null;
    input.addEventListener('input', () => {
      if (clearQueryTimer) { clearTimeout(clearQueryTimer); clearQueryTimer = null; }

      if (syncToLinkedInput(false)) return;

      if (input.value.trim() !== '') return;
      const url = new URL(window.location.href);
      const hadQuery = url.searchParams.has(queryParam) || url.searchParams.has('q') || url.searchParams.has('search');
      if (!hadQuery) return;
      clearQueryTimer = setTimeout(() => {
        url.searchParams.delete(queryParam);
        url.searchParams.delete('q');
        url.searchParams.delete('search');
        window.location.assign(`${url.pathname}${url.search}`);
      }, 300);
    });

    form.addEventListener('submit', (event) => {
      event.preventDefault();
      if (syncToLinkedInput(true)) return;

      const query = input.value.trim();
      const url = new URL(targetPath, window.location.origin);
      if (query) url.searchParams.set(queryParam, query);
      window.location.assign(`${url.pathname}${url.search}`);
    });
  }

  const NAV_LINKS = [
    { label: 'Image', href: '/category/image', menu: 'image' },
    { label: 'Video', href: '/category/video', menu: 'video' },
    { label: 'Agents', href: '/marketplace/agents.html', exact: true },
    { label: 'Models', href: '/marketplace/models.html' },
    { label: 'Community', href: '/marketplace/outputs.html' },
    { label: 'Marketing Studio', href: '/agents/marketing-studio', featured: true, badge: 'New' },
    { label: 'Scotty', href: 'https://scotty.aitopia.ai/chat', external: true },
    { label: 'MCP', href: '/mcp', featured: true, badge: 'New' },
    { label: 'Pricing', href: '/marketplace/pricing.html', id: 'nav-pricing-link' },
  ];

  const NAV_MENUS = {
    image: [
      {
        title: 'Features',
        items: [
          { title: 'Image Generator', desc: 'Generates high-quality AI images from text prompts.', href: '/agents/image-generator', icon: 'image-generator' },
          { title: 'Scene Generator', desc: 'Creates full composite scenes with multiple elements.', href: '/agents/scene-generator', icon: 'scene-generator' },
          { title: 'Sketch to Image', desc: 'Turns rough hand sketches into detailed AI visuals.', href: '/agents/sketch-to-image', icon: 'sketch-to-image' },
          { title: 'Face Swap', desc: 'Swaps faces seamlessly between target photos.', href: '/agents/face-swap', icon: 'face-swap' },
          { title: 'Watermark Remover Image Pro', desc: 'Removes watermarks, logos & text from images', href: '/agents/watermark-remover-image', icon: 'watermark-remover' },
          { title: 'Relight', desc: 'Give any photo a lighting with different angle and color.', href: '/agents/relight', icon: 'relight' },
          { title: 'Inside the VR World', desc: 'Turn a VR photo into a cinematic in-game still.', href: '/agents/inside-the-vr-world', icon: 'inside-the-vr-world' },
          { title: '360 Turnaround Views', desc: 'Upload one photo and get a 360° turnaround photos.', href: '/agents/grok-360-turnaround', icon: 'turnaround-360' },
          { title: 'Short History Story', desc: 'Turns history topics into lessons with images.', href: '/agents/short-history-story', icon: 'short-history-story' },
        ],
      },
      {
        title: 'Models',
        items: [
          { title: 'GPT Image 2.5 Sunburst', desc: 'High-vibrancy image model with rich colors.', href: '/openai/gpt-image-2.5-sunburst', img: 'https://v3b.fal.media/files/b/0aa9a3c6/xpKm5FzsZBuvm2Bf8xY7W.jpg' },
          { title: 'Gpt Image 2', desc: 'Advanced AI model for detailed image creation.', href: '/openai/gpt-image-2', img: 'https://aitopia.ai/model-images/gpt-image-2/gpt-image-2-cover.webp' },
          { title: 'Seedream 5 Lite', desc: 'Ultra-fast image generation for quick drafts.', href: '/bytedance/seedream-5-lite', img: 'https://aitopia.ai/model-images/seedream-5-lite/seedream-5-lite-cover.png' },
          { title: 'Nano Banana 2 Lite', desc: 'Lightweight engine for fast image outputs.', href: '/google/nano-banana-2-lite', img: 'https://aitopia.ai/model-images/nano-banana-2-lite/nano-banana-2-lite-cover.jpg' },
          { title: 'Nano Banana Pro', desc: 'High-fidelity model for complex image prompts.', href: '/google/nano-banana-pro', img: 'https://aitopia.ai/model-images/nano-banana-pro/nano-banana-pro-cover.jpg' },
          { title: 'V4 Pro', desc: 'Design-focused model for vector & graphic styles.', href: '/recraft/v4-pro', img: 'https://aitopia.ai/model-images/v4-pro/v4-pro-cover.jpg' },
          { title: 'Grok Imagine Image', desc: 'Creative image generator with strong prompt adherence.', href: '/xai/grok-imagine-image', img: 'https://aitopia.ai/model-images/grok-imagine-image/grok-imagine-image-cover.jpg' },
          { title: 'Qwen Image', desc: 'Versatile image model with accurate text rendering.', href: '/qwen/qwen-image', img: 'https://aitopia.ai/model-images/qwen-image/qwen-image-cover.webp' },
          { title: 'Flux 2', desc: 'Photorealistic model with ultra-detailed output.', href: '/black-forest-labs/flux-2', img: 'https://aitopia.ai/model-images/flux-2/flux-2-cover.jpg' },
        ],
      },
    ],
  };

  NAV_MENUS.video = [
    {
      title: 'Features',
      items: [
        { title: 'Viral Video Generator', desc: 'Creates engaging, trend-focused short videos.', href: '/agents/viral-video-generator', icon: 'viral-video-generator' },
        { title: 'Cinematic Product Film', desc: 'Generates high-end cinematic product ads.', href: '/agents/cinematic-product-film-seedance', icon: 'cinematic-product-film' },
        { title: 'Viral Photo Animator Pro', desc: 'Animates still photos with dynamic motion.', href: '/agents/image-animator', icon: 'viral-photo-animator' },
        { title: 'UGC Tries Product Video', desc: 'Creates authentic user-style product demos.', href: '/agents/ugc-tries-product-copy', icon: 'ugc-tries-product' },
        { title: 'Morpheus', desc: 'Creates 3D Scenes and turns them into videos.', href: '/agents/morpheus', highlight: true, badge: 'New', icon: 'morpheus' },
        { title: 'Video Generator', desc: 'Generates full AI videos directly from text prompts.', href: '/agents/video-generator', icon: 'video-generator' },
        { title: 'Video Transitions', desc: 'Adds seamless AI transitions between clips.', href: '/agents/transitions', icon: 'video-transitions' },
        { title: 'Lipsync Studio', desc: 'Syncs voice audio with realistic lip movements.', href: '/agents/lipsync-studio', icon: 'lipsync-studio' },
        { title: 'Closeup Clip', desc: 'Generates detailed close-up shot variations.', href: '/agents/closeup-clip-from-photo', icon: 'closeup-clip' },
        { title: 'Viral Dance Reel Creator', desc: 'Creates trending dance Reels for social media.', href: '/agents/viral-dance-reel-creator', icon: 'viral-dance-reel' },
        { title: 'Idea > Photo > Video', desc: 'Turns ideas/photos into images, then animated clips.', href: '/agents/idea-to-photo-to-video', icon: 'idea-photo-video' },
        { title: 'Pro Video Watermark Remover', desc: 'Removes watermarks and text overlays cleanly.', href: '/agents/watermark-remover-video', icon: 'video-watermark-remover' },
      ],
    },
    {
      title: 'Models',
      items: [
        { title: 'Seedance 2.5', desc: 'Advanced AI video engine for smooth, realistic motion.', href: '/bytedance/seedance-2.5', video: 'https://aitopia.ai/model-images/seedance-2-5-cover.mp4' },
        { title: 'Seedance 2.0', desc: 'High-performance video generation with crisp detail.', href: '/bytedance/seedance-2.0', video: 'https://aitopia.ai/model-images/seedance-2-0/seedance-2-0-cover.mp4' },
        { title: 'Seedance Lite', desc: 'Lightweight model for ultra-fast video rendering.', href: '/bytedance/seedance-1-lite', img: 'https://aitopia.ai/model-images/seedance-1-lite/seedance-1-lite-cover.webp' },
        { title: 'Kling O3 Pro Video Edit', desc: 'Professional AI video editing and sequence control.', href: '/kwaivgi/kling-o3-pro-video-edit', img: 'https://v3b.fal.media/files/b/0a8cfcd0/jgn9feXep4nJXWf0tg1cf_6867c6921b6a4015a1906c8e02a7ef9d.jpg' },
        { title: 'MiniMax H3 Max', desc: 'Cinematic video generation with rich visual texture.', href: '/minimax/h3-max', img: 'https://v3b.fal.media/files/b/0aa7657e/LlavC7cCdZ_GGyvyglA82.jpg' },
        { title: 'Gemini Omni Flash', desc: 'Ultra-fast multimodal video generation and editing.', href: '/google/gemini-omni-flash', img: 'https://v3b.fal.media/files/b/0aa0649d/TFqtIbw6p_p4rMT-44N8X.jpg' },
        { title: 'Veo 3.1', desc: 'Photorealistic AI video with cinematic motion.', href: '/google/veo-3.1', video: 'https://aitopia.ai/model-images/veo-3-1/veo-3-1-cover.mp4' },
        { title: 'Happy Horse', desc: 'Playful stylized video model for fun animations.', href: '/alibaba/happy-horse', img: 'https://aitopia.ai/model-images/happy-horse/happy-horse-cover.jpg' },
        { title: 'Wan 2.6', desc: 'High-fidelity video synthesis with precise detail.', href: '/wan-video/wan-2.6-t2v', video: 'https://aitopia.ai/model-images/wan-2-6-t2v/wan-2-6-t2v-cover.mp4' },
        { title: 'Wan 2.2 Animate Replace', desc: 'Seamlessly replaces subjects and elements in video.', href: '/wan-video/wan-2.2-animate-replace', video: 'https://aitopia.ai/model-images/wan-2-2-animate-replace/wan-2-2-animate-replace-cover.mp4' },
        { title: 'Hailuo 2.3 Pro', desc: 'Pro video model built for high dynamic motion.', href: '/minimax/hailuo-2.3-pro', img: 'https://aitopia.ai/model-images/hailuo-2-3-pro/hailuo-2-3-pro-cover.jpg' },
        { title: 'Grok Imagine Video', desc: 'Generates creative visual videos from text prompts.', href: '/xai/grok-imagine-video', video: 'https://aitopia.ai/model-images/grok-imagine-video/grok-imagine-video-cover.mp4' },
      ],
    },
  ];

  function navMenuHTML(key) {
    const columns = NAV_MENUS[key].map((col) => {
      const items = col.items.map((item) => {
        const thumb = item.img
          ? `<img data-src="${item.img}" alt="">`
          : item.video
            ? `<video data-src="${item.video}#t=0.1" muted playsinline preload="metadata"></video>`
          : item.icon
            ? `<span class="nav-mega-icon" style="--icon: url('/marketplace/icons/nav-menu/${item.icon}.svg')"></span>`
            : '';
        return `<a href="${item.href}" class="nav-mega-item${item.highlight ? ' is-highlight' : ''}">
          ${item.badge
            ? `<span class="nav-mega-thumb-wrap"><span class="nav-mega-thumb" aria-hidden="true">${thumb}</span><span class="nav-mega-badge">${item.badge}</span></span>`
            : `<span class="nav-mega-thumb" aria-hidden="true">${thumb}</span>`}
          <span class="nav-mega-text"><span class="nav-mega-title">${item.title}</span><span class="nav-mega-desc">${item.desc}</span></span>
        </a>`;
      }).join('');
      return `<div class="nav-mega-col"><div class="nav-mega-heading">${col.title}</div>${items}</div>`;
    }).join('');
    return `<div class="nav-mega"><div class="nav-mega-panel">${columns}</div></div>`;
  }

  function navLinksHTML() {
    const path = window.location.pathname.replace(/\/+$/, '') || '/';
    return NAV_LINKS.map((link) => {
      const active = !link.external && (path === link.href || (!link.exact && path.startsWith(link.href + '/')));
      const cls = ['nav-link', link.featured ? 'nav-featured-link' : '', active ? 'is-active' : ''].filter(Boolean).join(' ');
      const id = link.id ? ` id="${link.id}"` : '';
      const current = active ? ' aria-current="page"' : '';
      const label = link.featured
        ? `<span class="nav-featured-ring" aria-hidden="true"><span></span></span><span class="nav-featured-text">${link.label}</span>`
        : link.label;
      const badge = link.badge ? `<span class="nav-link-badge">${link.badge}</span>` : '';
      const target = link.external ? ' target="_blank" rel="noopener"' : '';
      const anchor = `<a href="${link.href}"${id} class="${cls}"${current}${target}>${label}${badge}</a>`;
      return link.menu ? `<div class="nav-menu-wrap">${anchor}${navMenuHTML(link.menu)}</div>` : anchor;
    }).join('');
  }

  // Navbar HTML template
  function getNavbarHTML() {
    const container = document.getElementById('navbar-container');
    const isHome = container && container.getAttribute('data-navbar-context') === 'home';
    const searchInputId = isHome ? 'searchInput' : 'navbarHeaderSearchInput';
    const searchWrapClass =
      'navbar-search flex flex-1 justify-center min-w-0 ml-6 sm:ml-10 md:ml-14 lg:ml-20 mr-2 sm:mr-10 lg:mr-16';
    const searchFormClass = 'relative w-full min-w-0 max-w-[280px] sm:max-w-[320px] md:max-w-[360px]';
    const autocompleteHtml = '<div id="searchAutocompleteHeader" class="hidden absolute top-full left-0 right-0 mt-2 z-50 bg-card border border-border rounded-ios-xl shadow-2xl max-h-[420px] overflow-y-auto"></div>';

    return `
	  <header id="header" class="sticky top-0 z-50 w-full glass border-b border-border/40 safe-top transition-all duration-300">
    <div id="promo-announcement-bar" class="w-full overflow-hidden text-center bg-[var(--promo-bar-bg)] py-2 px-4" style="display:none;">
      <div class="relative flex items-center justify-center">
        <!-- Single marquee track — entire row scrolls together when it overflows -->
        <div id="promo-bar-inner" class="inline-flex items-center gap-2.5 whitespace-nowrap">
          <span class="inline-flex items-center gap-1.5 shrink-0 whitespace-nowrap rounded-full py-1 px-3 text-sm font-medium text-white bg-[var(--promo-bar-badge-bg)]">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" class="shrink-0"><path d="M12.9897 13.3478C12.7166 10.945 11.62 9.94907 10.8191 9.22282C10.2653 8.71876 9.99909 8.45657 9.99909 8.00001C9.99909 7.54969 10.2644 7.29251 10.8166 6.79876C11.6269 6.07469 12.7366 5.08282 12.9903 2.64751C13.0106 2.44291 12.9877 2.23633 12.9231 2.04114C12.8585 1.84594 12.7537 1.66649 12.6153 1.51438C12.4676 1.35192 12.2875 1.22221 12.0865 1.13361C11.8856 1.04502 11.6684 0.999505 11.4488 1.00001H4.5494C4.32951 0.999321 4.11191 1.04474 3.91066 1.13334C3.7094 1.22194 3.52896 1.35174 3.38096 1.51438C3.24304 1.6667 3.13858 1.84623 3.07431 2.0414C3.01005 2.23657 2.9874 2.44305 3.00784 2.64751C3.26065 5.07501 4.36628 6.05969 5.17346 6.77844C5.73096 7.27501 5.99909 7.53407 5.99909 8.00001C5.99909 8.47188 5.73034 8.73626 5.17096 9.24219C4.37409 9.96407 3.28034 10.9525 3.00846 13.3478C2.98641 13.5515 3.00757 13.7575 3.07058 13.9525C3.13358 14.1474 3.237 14.3268 3.37409 14.4791C3.52239 14.6436 3.70371 14.775 3.90622 14.8648C4.10873 14.9546 4.32789 15.0006 4.5494 15H11.4488C11.6703 15.0006 11.8894 14.9546 12.092 14.8648C12.2945 14.775 12.4758 14.6436 12.6241 14.4791C12.7612 14.3268 12.8646 14.1474 12.9276 13.9525C12.9906 13.7575 13.0118 13.5515 12.9897 13.3478ZM10.7272 13.5H5.2844C4.7969 13.5 4.6594 12.9375 5.00128 12.5888C5.82878 11.75 7.49909 11.1494 7.49909 10.1875V7.00001C7.49909 6.37969 6.31159 5.90626 5.5769 4.90001C5.45565 4.73407 5.46784 4.50001 5.77596 4.50001H10.2363C10.4991 4.50001 10.5557 4.73219 10.4363 4.89844C9.71221 5.90626 8.49909 6.37657 8.49909 7.00001V10.1875C8.49909 11.1416 10.24 11.6563 11.0116 12.5897C11.3225 12.9659 11.2138 13.5 10.7272 13.5Z" fill="#FFFFFF"/></svg>
            Discount Expires in <strong id="promo-bar-timer" class="text-sm font-bold tracking-[0.02em]">--h --m --s</strong>
          </span>
          <span id="promo-bar-text" class="text-[var(--promo-bar-text)] text-sm"></span>
          <a id="promo-bar-cta" href="/marketplace/pricing.html" class="text-[var(--promo-bar-text)] text-sm font-bold underline underline-offset-2 whitespace-nowrap"></a>
        </div>
        <!-- Close button -->
        <button id="promo-bar-close" data-action="dismissPromoBar" aria-label="Close" style="position:absolute;right:0;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;padding:4px;display:flex;align-items:center;opacity:0.6;" class="hover-fade">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>
        </button>
      </div>
    </div>
	    <div class="nav-row-wrap max-w-[1600px] mx-auto px-3 sm:px-4 lg:px-6">
	      <div class="flex h-16 items-center">
	        <!-- Logo Section -->
	        <div class="flex shrink-0 items-center gap-2">
          <!-- Logo -->
	          <a href="/marketplace/" class="flex items-center">
            <img src="/marketplace/Logo.svg" alt="AITOPIA" width="36" height="36" class="h-9 w-9 sm:hidden" />
            <img src="/marketplace/Logo_all.svg" alt="AITOPIA" height="36" class="hidden sm:block h-9 w-auto" />
          </a>
        </div>

        <!-- Header search -->
        <div class="${searchWrapClass}">
          <form id="navbarHeaderSearchForm" class="${searchFormClass}">
            <label class="relative block min-w-0">
              <svg width="16" height="16" class="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" fill="none" viewBox="0 0 16 16" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round">
                <path d="M7.665 14a6.333 6.333 0 1 0 0-12.666 6.333 6.333 0 0 0 0 12.666Z"/><path d="m14.665 14.667-1.333-1.333"/>
              </svg>
              <input id="${searchInputId}" type="search" placeholder="Search..."
                class="w-full min-w-0 h-10 pl-10 pr-4 rounded-full bg-[#F2F5F9]/80 dark:bg-[#262626]/80 border-0 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all">
              ${autocompleteHtml}
            </label>
          </form>
        </div>

        <nav class="nav-desktop-links" aria-label="Primary">
          ${navLinksHTML()}
        </nav>

        <!-- Right side -->
        <div class="ml-auto flex shrink-0 items-center gap-1">
          <span class="nav-search-slot"></span>

          <!-- Mobile Pricing button -->
          <div id="mobile-pricing-btn-wrap" class="lg:hidden relative">
            <a href="/marketplace/pricing.html" class="h-10 px-4 flex items-center justify-center rounded-full border border-border text-sm font-medium whitespace-nowrap hover:bg-secondary transition-colors">
              Pricing
            </a>
            <span id="mobile-pricing-badge" style="display:none;position:absolute;bottom:0;left:50%;transform:translate(-50%,50%);font-size:10px;font-weight:700;color:var(--promo-nav-badge-text);background:var(--promo-nav-badge-bg);border-radius:100px;padding:1px 7px;white-space:nowrap;letter-spacing:0.03em;pointer-events:none;z-index:10;"></span>
          </div>

          <!-- Dark Mode Toggle (desktop only — inside hamburger drawer on mobile) -->
          <button data-action="NavbarComponent.toggleTheme" class="nav-icon-btn btn-press" aria-label="Toggle theme">
            <svg width="20" height="20" class="w-5 h-5 dark:hidden" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-width="2" d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
            </svg>
            <svg width="20" height="20" class="w-5 h-5 hidden dark:block" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <circle cx="12" cy="12" r="5" stroke-width="2"/>
              <path stroke-width="2" d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/>
            </svg>
          </button>
          <!-- Generation dock slots (mobile / desktop). The dock (generation-dock.js)
               renders its trigger into them and owns visibility; nothing here toggles them. -->
          <span id="genDockSlotMobile" data-gen-dock-slot="mobile"></span>
          <span id="genDockSlot" data-gen-dock-slot="desktop"></span>

          <div class="hidden lg:flex items-center justify-end gap-0.5 w-[130px] flex-shrink-0 ml-4">
            <!-- Credits Display -->
            <div id="creditsDisplay" class="hidden items-center gap-0.5 px-2 py-1.5 bg-primary/10 rounded-full w-[80px] flex-shrink-0 opacity-0 pointer-events-none">
              <svg width="16" height="16" class="w-4 h-4 text-primary/90 dark:text-primary flex-shrink-0" fill="currentColor" viewBox="0 0 14 14" xmlns="http://www.w3.org/2000/svg">
                <path d="M4.48963 7.68204H5.79855V11.5184C5.79855 12.0831 6.3577 12.3496 6.65422 11.9233L9.86088 7.34104C10.1405 6.94142 9.91595 6.31802 9.49235 6.31802H8.18342V2.48171C8.18342 1.91692 7.62426 1.65051 7.32774 2.07676L4.1211 6.65903C3.84576 7.05864 4.07026 7.68204 4.48963 7.68204Z"/>
              </svg>
              <span id="creditsAmount" class="text-sm font-semibold text-primary/90 dark:text-primary relative flex-1 text-right min-w-0">
                <span class="credits-shimmer inline-block">—</span>
              </span>
            </div>

            <!-- Login Button (shown when not logged in) -->
            <a href="/marketplace/login.html" id="loginBtn" class="nav-signin hidden h-9 px-4 items-center justify-center rounded-full text-sm font-medium transition-colors hover:bg-secondary">
              Sign In
            </a>

            <!-- Profile Dropdown (shown when logged in) -->
            <div class="relative hidden" id="profileDropdown">
            <button data-action="NavbarComponent.toggleProfileDropdown" class="flex items-center gap-2 h-10 px-3 rounded-full transition-colors btn-press cursor-pointer" aria-label="Profile menu">
              <div class="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                <svg width="16" height="16" class="w-4 h-4 text-primary/90 dark:text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                  <circle cx="12" cy="7" r="4"/>
                </svg>
              </div>
            </button>
            <div id="profileMenu" class="hidden absolute right-0 top-full mt-2 w-56 bg-card border border-border rounded-xl shadow-xl z-50 py-1 overflow-hidden">
              <!-- User info header -->
              <div id="profileHeader" class="px-4 py-3 border-b border-border">
                <div class="flex items-center justify-between gap-2">
                  <p id="profileName" class="text-sm font-medium truncate"></p>
                  <span id="profilePlanBadge" class="px-2 py-0.5 text-[10px] font-semibold uppercase rounded-full bg-primary/5 text-primary"></span>
                </div>
                <p id="profileEmailFull" class="text-xs text-muted-foreground truncate mt-0.5"></p>
                <a id="profileUpgradeBtn" href="/marketplace/pricing.html" class="mt-2 w-full flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-gradient-to-r from-primary to-primary/70 text-primary-foreground hover:opacity-90 transition-opacity">
                  <svg width="14" height="14" class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                    <path d="M13 10V3L4 14h7v7l9-11h-7z"/>
                  </svg>
                  Upgrade
                </a>
              </div>
              <a id="profileLink" href="/marketplace/settings-profile.html" class="flex items-center gap-3 px-4 py-2.5 text-sm hover:bg-muted transition-colors cursor-pointer">
                <svg width="16" height="16" class="w-4 h-4 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                  <circle cx="12" cy="7" r="4"/>
                </svg>
                Profile
              </a>
              <a href="https://aitopia.ai/agent-builder" class="flex items-center gap-3 px-4 py-2.5 text-sm hover:bg-muted transition-colors cursor-pointer">
                <svg width="16" height="16" class="w-4 h-4 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 18 18" stroke-width="1.13" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M7.2 15h3.6c3 0 4.2-1.2 4.2-4.2V7.2C15 4.2 13.8 3 10.8 3H7.2C4.2 3 3 4.2 3 7.2v3.6C3 13.8 4.2 15 7.2 15z"/>
                  <path d="M7.065 11.935h3.87M7.065 17.085h3.87M17.035 10.435v-2.87M1.005 10.435v-2.87M9 3V1.5"/>
                  <rect x="5.3" y="6" width="2.6" height="2.4" rx=".9"/><rect x="10.1" y="6" width="2.6" height="2.4" rx=".9"/>
                </svg>
                My Agents
              </a>
              <a href="/marketplace/outputs.html?tab=mine" class="flex items-center gap-3 px-4 py-2.5 text-sm hover:bg-muted transition-colors cursor-pointer">
                <svg width="16" height="16" class="w-4 h-4 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                  <path d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                </svg>
                My Creations
              </a>
              <!--
              <a href="/marketplace/create.html" class="flex items-center gap-3 px-4 py-2.5 text-sm hover:bg-muted transition-colors cursor-pointer">
                <svg width="16" height="16" class="w-4 h-4 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                  <path d="M12 4v16m8-8H4"/>
                </svg>
                Create
              </a>
              <a href="/marketplace/feed.html" class="flex items-center gap-3 px-4 py-2.5 text-sm hover:bg-muted transition-colors cursor-pointer">
                <svg width="16" height="16" class="w-4 h-4 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                  <path d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2"/>
                </svg>
                Feed
              </a>
              <a href="/marketplace/discover.html" class="flex items-center gap-3 px-4 py-2.5 text-sm hover:bg-muted transition-colors cursor-pointer">
                <svg width="16" height="16" class="w-4 h-4 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                  <circle cx="12" cy="12" r="10"/>
                  <polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76"/>
                </svg>
                Discover
              </a>
              -->
              <a href="/marketplace/owner.html?owner=aiconomy" class="flex items-center gap-3 px-4 py-2.5 text-sm hover:bg-muted transition-colors cursor-pointer">
                <svg width="16" height="16" class="w-4 h-4 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                  <line x1="12" y1="1" x2="12" y2="23"/>
                  <path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/>
                </svg>
                AICONOMY
              </a>
              <a id="profileDeveloperLink" href="/marketplace/developers-dashboard.html" class="hidden items-center gap-3 px-4 py-2.5 text-sm hover:bg-muted transition-colors cursor-pointer">
                <svg width="16" height="16" class="w-4 h-4 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                  <rect x="3" y="3" width="7" height="7" rx="1"/>
                  <rect x="14" y="3" width="7" height="7" rx="1"/>
                  <rect x="3" y="14" width="7" height="7" rx="1"/>
                  <rect x="14" y="14" width="7" height="7" rx="1"/>
                </svg>
                Developer Dashboard
              </a>
              <!--
              <a href="https://chat.aitopia.ai/app/profile" class="flex items-center gap-3 px-4 py-2.5 text-sm hover:bg-muted transition-colors cursor-pointer">
                <svg width="16" height="16" class="w-4 h-4 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                  <circle cx="12" cy="7" r="4"/>
                </svg>
                My Account
              </a>
              <a href="https://chat.aitopia.ai/subscription" class="flex items-center gap-3 px-4 py-2.5 text-sm hover:bg-muted transition-colors cursor-pointer">
                <svg width="16" height="16" class="w-4 h-4 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                  <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/>
                  <polyline points="3.27 6.96 12 12.01 20.73 6.96"/>
                  <line x1="12" y1="22.08" x2="12" y2="12"/>
                </svg>
                My Plan
              </a>
              <a href="https://chat.aitopia.ai/src/html/options.html?mode=contact" class="flex items-center gap-3 px-4 py-2.5 text-sm hover:bg-muted transition-colors cursor-pointer">
                <svg width="16" height="16" class="w-4 h-4 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                  <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
                </svg>
                Feedback
              </a>
              -->
              <div class="border-t border-border my-1"></div>
              <button data-action="NavbarComponent.handleLogout" class="w-full flex items-center gap-3 px-4 py-2.5 text-sm hover:bg-muted transition-colors text-red-500 cursor-pointer">
                <svg width="16" height="16" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                  <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
                  <polyline points="16 17 21 12 16 7"/>
                  <line x1="21" y1="12" x2="9" y2="12"/>
                </svg>
                Logout
              </button>
            </div>
          </div>
          </div>
        </div>
      </div>
    </div>
    <span id="nav-pricing-badge" style="display:none;position:absolute;bottom:0;transform:translate(-50%,50%);font-size:10px;font-weight:700;color:var(--promo-nav-badge-text);background:var(--promo-nav-badge-bg);border-radius:100px;padding:1px 7px;white-space:nowrap;letter-spacing:0.03em;pointer-events:none;z-index:10;"></span>
  </header>
    `;
  }

  window.NavbarComponent = {
    isLoggedIn: function() { return loggedIn; },

    invalidateCreditsCache: function(refresh = true) {
      window.AitopiaCache?.remove?.(window.AitopiaCache?.KEYS?.USER_CREDITS);
      if (refresh) {
        this.loadUserCredits();
      }
    },

    decrementCreditsOptimistic: function(deltaCredits) {
      const delta = Math.max(0, Math.trunc(Number(deltaCredits) || 0));
      if (!delta) return;

      const creditsAmount = document.getElementById('creditsAmount');
      const creditsShimmer = creditsAmount?.querySelector('.credits-shimmer');

      const currentCached = getUserCredits();
      const current =
        typeof currentCached === 'number' && Number.isFinite(currentCached)
          ? currentCached
          : (() => {
              const raw = creditsShimmer?.textContent ? String(creditsShimmer.textContent).trim() : '';
              const parsed = raw ? Number.parseInt(raw.replace(/[^0-9]/g, ''), 10) : NaN;
              return Number.isFinite(parsed) ? parsed : null;
            })();

      if (current === null) return;

      const next = Math.max(0, current - delta);
      setUserCredits(next);

      if (creditsShimmer) {
        creditsShimmer.textContent = String(next);
        creditsShimmer.classList.add('loaded');
      }
    },

    toggleTheme: function() {
      const html = document.documentElement;
      const isDark = html.classList.contains('dark');
      if (isDark) {
        html.classList.remove('dark');
        localStorage.setItem('theme', 'light');
      } else {
        html.classList.add('dark');
        localStorage.setItem('theme', 'dark');
      }
      if (typeof window.injectHeaderCss == 'function') window.injectHeaderCss();
    },

    toggleProfileDropdown: function() {
      const menu = document.getElementById('profileMenu');
      if (menu) menu.classList.toggle('hidden');
    },

    handleLogout: async function() {
      try {
        clearUserCache();
        await fetch('https://aitopia.ai/auth/logout', { method: 'POST', credentials: 'include' });
      } catch (e) {
        console.error('Logout error:', e);
      }
      try { Object.keys(sessionStorage).filter((k) => k.startsWith('genDock.')).forEach((k) => sessionStorage.removeItem(k)); } catch {}
      window.location.reload();
    },

    loadUserProfile: async function() {
      const loginBtn = document.getElementById('loginBtn');
      const profileDropdown = document.getElementById('profileDropdown');
      const creditsDisplay = document.getElementById('creditsDisplay');
      const profileName = document.getElementById('profileName');
      const profileEmailFull = document.getElementById('profileEmailFull');
      const profilePlanBadge = document.getElementById('profilePlanBadge');
      const profileDeveloperLink = document.getElementById('profileDeveloperLink');

      const setDeveloperLinkVisible = (visible) => {
        if (!profileDeveloperLink) return;
        if (visible) {
          profileDeveloperLink.classList.remove('hidden');
          profileDeveloperLink.classList.add('flex');
          return;
        }
        profileDeveloperLink.classList.add('hidden');
        profileDeveloperLink.classList.remove('flex');
      };

      const updateUI = (profileData) => {
        if (!profileData) {
          if (loginBtn) {
            loginBtn.classList.remove('hidden');
            loginBtn.classList.add('flex');
          }
          if (profileDropdown) profileDropdown.classList.add('hidden');
          if (creditsDisplay) {
            creditsDisplay.classList.add('hidden', 'opacity-0', 'pointer-events-none');
            creditsDisplay.classList.remove('flex', 'opacity-100');
          }
          setDeveloperLinkVisible(false);
          developerStatusPromise = null;
          publishAuth(false);
          return;
        }

        const { fullName, email, plan } = profileData;
        if (loginBtn) {
          loginBtn.classList.add('hidden');
          loginBtn.classList.remove('flex');
        }
        if (profileDropdown) profileDropdown.classList.remove('hidden');
        if (creditsDisplay) {
          creditsDisplay.classList.remove('hidden', 'opacity-0', 'pointer-events-none');
          creditsDisplay.classList.add('flex', 'opacity-100');
        }
        if (profileName) profileName.textContent = fullName;
        if (profileEmailFull) profileEmailFull.textContent = email;
        if (profilePlanBadge && plan) {
          profilePlanBadge.textContent = plan.toUpperCase();
        }
        setDeveloperLinkVisible(false);
        void fetchIsDeveloper().then((isDeveloper) => {
          setDeveloperLinkVisible(Boolean(isDeveloper));
        });
        publishAuth(true);
      };

      const cached = getUserProfile();
      if (cached) {
        updateUI(cached);
        this.loadUserCredits();
        this.loadSocialProfile();
        return;
      }
      const h = window.location.hostname;
      const parts = h.split(".");
      // Fall back to aitopia.ai when not on a real multi-part domain
      // (localhost, IPs, or a Chrome extension ID host have no usable root domain).
      const isLocal = h.indexOf("localhost") !== -1 || parts.length < 2;
      const rootDomain = parts.length > 2 ? parts.slice(-2).join(".") : h;
      const url = isLocal
      ? `https://extensions.aitopia.ai/extensions/app/key`
      : `https://extensions.${rootDomain}/extensions/app/key`;
      try {
        const aitopia_response = await fetch(
          url,
          { method: "GET", credentials: "include" },
        );
        if (aitopia_response?.key) {
          const domainAttr = isLocal ? "" : `; Domain=.${rootDomain}`;
          document.cookie = `hopekey=${aitopia_response?.key}; expires=${365 * 24 * 60 * 60 * 1000}; path=/; Secure; SameSite=None${domainAttr}`;
        }
      } catch (e) {}
      try {
        const response = await fetch('https://aitopia.ai/auth/me', { method: 'GET', credentials: 'include' });
        if (response.ok) {
          const resp = await response.json();
          if (window.AitopiaForceRedirect?.apply(resp)) return;
          const userData = resp?.data?.user || resp?.data || resp?.user || resp;
          const isLoggedIn = userData && !Array.isArray(userData) && typeof userData === 'object' && (userData.email || userData.key);

          // A verified session clears any stale gate left by an earlier load.
          if (isLoggedIn && !resp?.force_redirect) window.AitopiaForceRedirect?.clearVerifyPending?.();

          if (isLoggedIn) {
            const email = userData.email || '';
            const name = userData.name || '';
            const lastname = userData.lastname || '';
            const fullName = [name, lastname].filter(Boolean).join(' ') || (email ? email.split('@')[0] : 'User');
            const plan = resp?.data?.plan || resp?.data?.licences?.plan_type || userData.plan || userData.planName || '';
            const licences = resp?.data?.licences || null;
            const extra = resp?.data?.extra || null;

            const profileData = { fullName, email, plan, licences, extra };
            setUserProfile(profileData);
            updateUI(profileData);
            this.loadUserCredits();
            this.loadSocialProfile();
            // Hide promo elements for creator plan users
            if (String(plan || '').toLowerCase() === 'creator') {
              document.getElementById('nav-pricing-badge')?.style?.setProperty('display', 'none', 'important');
              document.getElementById('mobile-pricing-badge')?.style?.setProperty('display', 'none', 'important');
              const promoBar = document.getElementById('promo-announcement-bar');
              if (promoBar) promoBar.style.display = 'none';
              localStorage.removeItem('promo_bar_active');
            }
            return;
          }
        }
      } catch (e) {
      }

      updateUI(null);
    },

    loadUserCredits: async function() {
      const creditsAmount = document.getElementById('creditsAmount');
      const creditsShimmer = creditsAmount?.querySelector('.credits-shimmer');

      const updateCreditsUI = (credits, animate = false) => {
        if (creditsShimmer) {
          creditsShimmer.textContent = credits !== null ? String(credits) : '—';
          if (animate) {
            setTimeout(() => creditsShimmer.classList.add('loaded'), 300);
          } else {
            creditsShimmer.classList.add('loaded');
          }
        }
      };

      const cached = getUserCredits();
      if (cached !== null) {
        updateCreditsUI(cached, false);
        return;
      }
      if (creditsShimmer) {
        creditsShimmer.classList.remove('loaded');
      }

      try {
        let balanceData;
        if (window.AitopiaCredits?.loadCreditsBalance) {
          balanceData = await window.AitopiaCredits.loadCreditsBalance();
        } else {
          const res = await fetch('https://aitopia.ai/api/credits/balance', { credentials: 'include' });
          if (res.ok) balanceData = await res.json();
        }
        if (!balanceData?.balance) {
          updateCreditsUI(null, true);
          return;
        }
        const totalCredits = balanceData.balance.totalCredits ?? balanceData.balance.totalCreditsRemaining ?? 0;

        setUserCredits(totalCredits);
        updateCreditsUI(totalCredits, true);
      } catch (e) {
        updateCreditsUI(null, true);
      }
    },

    loadSocialProfile: async function() {
      try {
        const res = await fetch('https://aitopia.ai/api/users/me', { method: 'GET', credentials: 'include' });
        if (!res.ok) return;
        const json = await res.json();
        const username = json?.profile?.username;
        if (username) {
          const profileLink = document.getElementById('profileLink');
          if (profileLink) {
            profileLink.href = `/marketplace/profile.html?username=${encodeURIComponent(username)}`;
          }
        }
      } catch (e) {
        // Ignore errors
      }
    },

    init: function() {
      const container = document.getElementById('navbar-container');

      if (!container) {
        console.warn('NavbarComponent: #navbar-container not found');
        return;
      }

      injectStickyStyles();
      container.innerHTML = getNavbarHTML();
      initStickyHeader();
      initPromoBar();
      var ctx = getHeaderSearchContext();
      if (ctx && ctx.linkedInputId && !document.getElementById(ctx.linkedInputId)) {
        document.addEventListener('DOMContentLoaded', function () { bindHeaderSearch(); }, { once: true });
      } else {
        bindHeaderSearch();
      }
      autoBindNavbarAutocomplete();
      try {
        document.documentElement.classList.remove('global-nav-loading');
        document.documentElement.classList.add('global-nav-ready');
      } catch {}

      this.loadUserProfile();

      window.addEventListener('aitopia-credits-updated', (e) => {
        const totalCredits = e.detail?.balance?.totalCredits ?? e.detail?.balance?.totalCreditsRemaining;
        if (typeof totalCredits === 'number') {
          setUserCredits(totalCredits);
          const creditsShimmer = document.getElementById('creditsAmount')?.querySelector('.credits-shimmer');
          if (creditsShimmer) {
            creditsShimmer.textContent = String(totalCredits);
            creditsShimmer.classList.add('loaded');
          }
        }
      });

      document.querySelectorAll('.nav-menu-wrap').forEach((wrap) => {
        const loadMedia = () => wrap.querySelectorAll('img[data-src], video[data-src]').forEach((v) => {
          v.src = v.dataset.src;
          v.removeAttribute('data-src');
        });
        wrap.addEventListener('mouseenter', loadMedia, { once: true });
        wrap.addEventListener('focusin', loadMedia, { once: true });
      });

      const wideSearch = window.matchMedia('(min-width: 1280px)');
      const placeSearch = () => {
        const form = document.getElementById('navbarHeaderSearchForm');
        const target = document.querySelector(wideSearch.matches ? '.nav-search-slot' : '.navbar-search');
        if (form && target && form.parentElement !== target) target.appendChild(form);
      };
      placeSearch();
      wideSearch.addEventListener('change', placeSearch);
      initSearchExpand();

      document.addEventListener('click', (e) => {
        const dropdown = document.getElementById('profileDropdown');
        if (dropdown && !dropdown.contains(e.target)) {
          const menu = document.getElementById('profileMenu');
          if (menu) menu.classList.add('hidden');
        }
      });
    }
  };

  window.toggleTheme = window.NavbarComponent.toggleTheme;
  window.handleLogout = window.NavbarComponent.handleLogout;
  window.toggleProfileDropdown = window.NavbarComponent.toggleProfileDropdown;

  const STICKY_STYLE_ID = 'navbarStickyStyles';
  // The bar materialises over the first scrolled pixels and is fully glass by the time content slides under it.
  const SCROLL_TRANSITION_PX = 64;

  function injectStickyStyles() {
    if (document.getElementById(STICKY_STYLE_ID)) return;
    const style = document.createElement('style');
    style.id = STICKY_STYLE_ID;
    // #navbar-container is a block exactly as tall as the header, which caps the header's sticky
    // range at zero. Removing the wrapper's box lets #header's position:sticky reach the viewport.
    style.textContent = `
      #navbar-container { display: contents; }
      html { scroll-padding-top: var(--navbar-height, 4rem); }
      /* The header search sits inside that padding band, so each keystroke's caret scroll-into-view would pull the page up. */
      html:has(#header:focus-within) { scroll-padding-top: 0; }
      .below-navbar { top: calc(var(--navbar-height, 4rem) + 1rem); }
      #header {
        --navbar-scroll: 0;
        background-color: rgba(255, 255, 255, calc(0.6 * var(--navbar-scroll)));
        border-bottom-color: rgba(0, 0, 0, calc(0.08 * var(--navbar-scroll)));
        box-shadow: 0 8px 24px -12px rgba(0, 0, 0, calc(0.14 * var(--navbar-scroll)));
        /* Keep shared.css's opacity fade on global-nav-ready; this list replaces the header's transition-all. */
        transition: background-color 150ms linear, border-color 150ms linear, box-shadow 150ms linear, opacity 120ms ease-out;
      }
      /* shared.css forces dark headers to opaque #0A0A0A !important; keep the bar translucent glass instead. */
      .dark #header {
        --ait-m-secondary: 0 0% 15%;
        --ait-m-card: 0 0% 6%;
        --ait-m-border: 0 0% 18%;
        background-color: rgba(10, 10, 10, calc(0.7 * var(--navbar-scroll))) !important;
        border-bottom-color: rgba(255, 255, 255, calc(0.08 * var(--navbar-scroll)));
        box-shadow: 0 8px 24px -12px rgba(0, 0, 0, calc(0.55 * var(--navbar-scroll)));
      }
      @media (prefers-reduced-motion: reduce) { #header { transition: none; } }
      .nav-desktop-links { display: none; }
      .nav-link {
        height: 36px;
        padding: 0 14px;
        display: flex;
        align-items: center;
        white-space: nowrap;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 400;
        line-height: 20px;
        color: hsl(var(--ait-m-foreground) / 0.82);
        transition: color 150ms, background-color 150ms, padding 250ms cubic-bezier(0.2, 0, 0, 1);
      }
      .nav-link-badge {
        position: absolute;
        top: -8px;
        right: -10px;
        padding: 1px 5px;
        border-radius: 6px;
        background-color: hsl(var(--ait-m-primary));
        color: #fff;
        font-size: 9px;
        font-style: italic;
        font-weight: 700;
        line-height: 13px;
        pointer-events: none;
      }
      .nav-link:hover, .nav-link.is-active { color: hsl(var(--ait-m-foreground)); background-color: hsl(var(--ait-m-secondary)); }
      @keyframes featured-border-spin { to { transform: translate(-50%, -50%) rotate(360deg); } }
      .nav-featured-link { position: relative; margin: 0 8px; border-radius: 12px; }
      .nav-featured-ring {
        position: absolute;
        inset: 0;
        padding: 1px;
        border-radius: inherit;
        overflow: hidden;
        -webkit-mask: linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0);
        -webkit-mask-composite: xor;
        mask: linear-gradient(#000 0 0) content-box exclude, linear-gradient(#000 0 0);
        pointer-events: none;
      }
      .nav-featured-ring > span {
        position: absolute;
        left: 50%;
        top: 50%;
        width: 150%;
        aspect-ratio: 1;
        transform: translate(-50%, -50%);
        background: conic-gradient(from 270deg, hsl(var(--ait-m-foreground) / 0.45), hsl(var(--ait-m-primary)), hsl(var(--ait-m-foreground) / 0.45));
        animation: featured-border-spin 4s linear infinite;
      }
      @media (prefers-reduced-motion: reduce) { .nav-featured-ring > span { animation: none; } }
      .nav-link.nav-featured-link:hover, .nav-link.nav-featured-link.is-active { background-color: hsl(var(--ait-m-primary) / 0.12); }
      .nav-featured-text {
        background: linear-gradient(90deg, hsl(var(--ait-m-foreground)), hsl(var(--ait-m-primary)));
        -webkit-background-clip: text;
        background-clip: text;
        color: transparent;
      }
      .nav-desktop-links { position: relative; }
      .nav-mega {
        position: absolute;
        top: 100%;
        left: 50%;
        padding-top: 14px;
        z-index: 70;
        visibility: hidden;
        opacity: 0;
        transform: translate(-50%, -4px);
        transition: opacity 150ms ease-out, transform 150ms ease-out, visibility 0s linear 150ms;
      }
      .nav-menu-wrap:hover .nav-mega, .nav-menu-wrap:focus-within .nav-mega {
        visibility: visible;
        opacity: 1;
        transform: translate(-50%, 0);
        transition-delay: 0s;
      }
      .nav-menu-wrap:hover > .nav-link { color: hsl(var(--ait-m-foreground)); background-color: hsl(var(--ait-m-secondary)); }
      .nav-mega-panel {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        column-gap: 48px;
        width: min(1000px, calc(100vw - 48px));
        max-height: calc(100vh - var(--navbar-height, 4rem) - 24px);
        overflow-y: auto;
        padding: 20px;
        border-radius: 20px;
        border: 1px solid hsl(var(--ait-m-border));
        background-color: hsl(var(--ait-m-card));
        box-shadow: 0 24px 48px -16px rgba(0, 0, 0, 0.45);
      }
      .nav-mega-heading { padding-bottom: 8px; font-family: Inter, ui-sans-serif, system-ui, sans-serif; font-size: 14px; font-weight: 500; line-height: 21px; color: hsl(var(--ait-m-foreground) / 0.5); }
      .nav-mega-item {
        display: flex;
        align-items: center;
        gap: 12px;
        height: 64px;
        margin: 0 -12px;
        padding: 8px 12px;
        border-radius: 12px;
        transition: background-color 150ms;
      }
      .nav-mega-item:hover { background-color: var(--panel-hover, hsl(var(--ait-m-secondary))); }
      .nav-mega-thumb {
        flex-shrink: 0;
        width: 48px;
        height: 48px;
        display: flex;
        align-items: center;
        justify-content: center;
        overflow: hidden;
        border-radius: 12px;
        background-color: hsl(var(--ait-m-secondary));
        color: hsl(var(--ait-m-foreground));
      }
      .nav-mega-thumb img, .nav-mega-thumb video { width: 100%; height: 100%; object-fit: cover; }
      .nav-mega-item.is-highlight .nav-mega-thumb { box-shadow: inset 0 0 0 1px hsl(var(--ait-m-primary)); }
      .nav-mega-thumb-wrap { position: relative; flex-shrink: 0; }
      .nav-mega-badge {
        position: absolute;
        top: -9px;
        left: 50%;
        transform: translateX(-50%);
        padding: 1px 6px;
        border-radius: 6px;
        background-color: hsl(var(--ait-m-primary));
        color: #fff;
        font-family: Inter, ui-sans-serif, system-ui, sans-serif;
        font-size: 10px;
        font-style: italic;
        font-weight: 700;
        line-height: 14px;
        white-space: nowrap;
      }
      .nav-mega-icon {
        width: 24px;
        height: 24px;
        background-color: currentColor;
        -webkit-mask: var(--icon) center / contain no-repeat;
        mask: var(--icon) center / contain no-repeat;
      }
      .nav-mega-text { display: flex; flex-direction: column; gap: 2px; min-width: 0; }
      .nav-mega-title, .nav-mega-desc { font-family: Inter, ui-sans-serif, system-ui, sans-serif; font-size: 14px; font-weight: 500; line-height: 21px; }
      .nav-mega-title { color: hsl(var(--ait-m-foreground)); }
      .nav-mega-desc { color: hsl(var(--ait-m-foreground) / 0.5); }
      .nav-mega-title, .nav-mega-desc { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
      .nav-icon-btn {
        width: 40px;
        height: 40px;
        display: none;
        align-items: center;
        justify-content: center;
        border-radius: 9999px;
        transition: background-color 150ms;
      }
      .nav-icon-btn:hover { background-color: hsl(var(--ait-m-secondary)); }
      .nav-search-slot { display: none; }
      .nav-signin { color: hsl(var(--ait-m-foreground)); }
      .nav-row-wrap { position: relative; }
      @media (min-width: 1024px) {
        .nav-icon-btn { display: flex; }
      }
      @media (min-width: 1280px) {
        .nav-desktop-links { display: flex; flex: 1; min-width: 0; align-items: center; justify-content: center; gap: 2px; margin: 0 16px; }
        #header .navbar-search { display: none; }
        .nav-search-slot {
          display: block;
          flex-shrink: 0;
          width: 40px;
          height: 40px;
          margin-right: 4px;
          transition: width 250ms cubic-bezier(0.2, 0, 0, 1);
        }
        #header.search-active .nav-search-slot { width: var(--nav-search-width, 300px); }
        #header.search-measuring .nav-search-slot, #header.search-measuring .nav-link { transition: none; }
        #header.search-active .nav-link { padding: 0 6px; }
        .nav-search-slot form { position: relative; width: 100%; max-width: none; }
        #header .nav-search-slot input { height: 40px; padding-right: 12px; cursor: pointer; background-color: hsl(var(--ait-m-secondary)); }
        #header .nav-search-slot input:focus { cursor: text; }
        #header:not(.search-active) .nav-search-slot input::placeholder { color: transparent; }
        #header:not(.search-active) .nav-search-slot input { padding-right: 0; }
      }
      @media (min-width: 1280px) and (prefers-reduced-motion: reduce) {
        .nav-search-slot, .nav-link { transition: none; }
      }
      @media (min-width: 1280px) and (max-width: 1439px) {
        .nav-desktop-links { margin: 0 8px; gap: 0; }
        .nav-link { padding: 0 8px; font-size: 13px; }
        #header.search-active .nav-link { padding: 0 4px; }
        .nav-featured-link { margin: 0 6px; }
      }
    `;
    document.head.appendChild(style);
  }

  // The header search grows into the space the nav links free up by tightening their padding.
  function initSearchExpand() {
    const header = document.getElementById('header');
    const slot = header?.querySelector('.nav-search-slot');
    const nav = header?.querySelector('.nav-desktop-links');
    if (!slot || !nav) return;
    const input = () => slot.querySelector('input');

    const measure = () => {
      header.classList.add('search-measuring');
      const wasActive = header.classList.contains('search-active');
      header.classList.add('search-active');
      slot.style.setProperty('--nav-search-width', '40px');
      const items = nav.children;
      const content = items[items.length - 1].getBoundingClientRect().right - items[0].getBoundingClientRect().left;
      const free = nav.clientWidth - content;
      slot.style.setProperty('--nav-search-width', `${Math.max(160, Math.min(300, 40 + free - 16))}px`);
      if (!wasActive) header.classList.remove('search-active');
      void header.offsetWidth;
      header.classList.remove('search-measuring');
    };
    const followPricingBadge = () => {
      const badge = document.getElementById('nav-pricing-badge');
      if (!badge || badge.style.display === 'none') return;
      const end = performance.now() + 300;
      const step = () => {
        _positionPricingBadge();
        if (performance.now() < end) requestAnimationFrame(step);
      };
      requestAnimationFrame(step);
      setTimeout(_positionPricingBadge, 320);
    };
    const open = () => {
      if (header.classList.contains('search-active')) return;
      measure();
      header.classList.add('search-active');
      followPricingBadge();
    };
    const close = () => {
      if (input()?.value) return;
      header.classList.remove('search-active');
      followPricingBadge();
    };

    slot.addEventListener('focusin', open);
    slot.addEventListener('focusout', (e) => {
      if (!slot.contains(e.relatedTarget)) close();
    });
    slot.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') e.target.blur();
    });
    window.addEventListener('resize', () => {
      if (header.classList.contains('search-active')) measure();
    });
    if (input()?.value) open();
  }

  function initStickyHeader() {
    const header = document.getElementById('header');
    if (!header) return;

    const publishHeight = () => {
      document.documentElement.style.setProperty('--navbar-height', `${header.offsetHeight}px`);
    };
    publishHeight();
    if (typeof window.ResizeObserver === 'function') {
      new window.ResizeObserver(publishHeight).observe(header);
    }

    let lastProgress = '';
    const onScroll = () => {
      const progress = Math.min(1, Math.max(0, window.scrollY / SCROLL_TRANSITION_PX)).toFixed(3);
      if (progress === lastProgress) return;
      lastProgress = progress;
      header.style.setProperty('--navbar-scroll', progress);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  function initPromoBar() {
    function applyPromoBar(cfg) {
      const text       = cfg.text         || 'NanoBanana 2 UNLIMITED on Premium. Nano Banana Pro 2K & Seedream 4.5K generations.';
      const ctaText    = cfg.ctaText      || 'Personal %52 OFF';
      const ctaHref    = cfg.ctaHref      || '/marketplace/pricing.html';
      const badgeText  = cfg.badgeText    || '%52 OFF';
      const durationMs = (cfg.durationHours ?? 3) * 3600000;

      const textEl  = document.getElementById('promo-bar-text');
      const ctaEl   = document.getElementById('promo-bar-cta');
      const timerEl = document.getElementById('promo-bar-timer');
      const cachedPlan = (getUserProfile()?.plan || '').toLowerCase();
      const hidePromo = cachedPlan === 'creator';
      const badgeEl = document.getElementById('nav-pricing-badge');
      if (badgeEl) badgeEl.textContent = badgeText;
      const mobileBadge = document.getElementById('mobile-pricing-badge');
      if (mobileBadge && !hidePromo) { mobileBadge.textContent = badgeText; mobileBadge.style.display = 'inline-block'; }
      if (!hidePromo) _positionPricingBadge();

      if (textEl) textEl.textContent = text;
      if (ctaEl) { ctaEl.textContent = ctaText; ctaEl.href = ctaHref; }

      // Enable marquee when content overflows the bar width
      requestAnimationFrame(function () {
        const inner = document.getElementById('promo-bar-inner');
        const outer = document.getElementById('promo-announcement-bar');
        if (!inner || !outer || inner.scrollWidth <= outer.clientWidth) return;
        // Duplicate content for seamless loop
        outer.style.textAlign = 'left';
        const sep = '<span style="display:inline-block;width:48px;flex-shrink:0;" aria-hidden="true"></span>';
        const original = inner.innerHTML;
        inner.innerHTML = original + sep + original + sep;
        inner.style.animation = 'promo-marquee 22s linear infinite';
      });

      if (!document.getElementById('promo-bar-timer')) return;

      const STORAGE_KEY = 'promo_expiry';
      let endMs = parseInt(localStorage.getItem(STORAGE_KEY), 10);
      if (!endMs || endMs < Date.now()) {
        endMs = Date.now() + durationMs;
        localStorage.setItem(STORAGE_KEY, endMs);
      }

      function fmt(n) { return String(n).padStart(2, '0'); }
      function tick() {
        const rem = Math.max(0, endMs - Date.now());
        const h = Math.floor(rem / 3600000);
        const m = Math.floor((rem % 3600000) / 60000);
        const s = Math.floor((rem % 60000) / 1000);
        const text = `${fmt(h)}h ${fmt(m)}m ${fmt(s)}s`;
        document.querySelectorAll('#promo-bar-timer').forEach(function (el) { el.textContent = text; });
        if (rem === 0) {
          endMs = Date.now() + durationMs;
          localStorage.setItem('promo_expiry', endMs);
        }
      }
      tick();
      setInterval(tick, 1000);
    }

    fetch('https://aitopia.ai/store/promo-config.json')
      .then(function (r) { return r.ok ? r.json() : {}; })
      .catch(function () { return {}; })
      .then(applyPromoBar);
  }

  function runInit() {
    if (window.__AITOPIA_NAVBAR_INIT_DONE__) return;
    window.__AITOPIA_NAVBAR_INIT_DONE__ = true;
    window.NavbarComponent.init();
    setUrlCookie();
    window.dismissPromoBar = function () {
      const bar = document.getElementById('promo-announcement-bar');
      if (bar) bar.style.display = 'none';
      localStorage.setItem('promo_bar_dismissed', '1');
      localStorage.removeItem('promo_bar_active');
    };
    if (localStorage.getItem('promo_bar_active') && !localStorage.getItem('promo_bar_dismissed')) {
      const bar = document.getElementById('promo-announcement-bar');
      if (bar) bar.style.display = '';
    }
  }
  if (document.getElementById('navbar-container')) {
    runInit();
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', runInit);
  } else {
    runInit();
  }


  function _positionPricingBadge() {
    const badge = document.getElementById('nav-pricing-badge');
    const link = document.getElementById('nav-pricing-link');
    if (!badge || !link) return;
    if (link.getBoundingClientRect().width === 0) {
      badge.style.display = 'none';
      return;
    }
    if (badge.parentElement !== link) {
      link.style.position = 'relative';
      link.appendChild(badge);
      badge.style.left = '50%';
      badge.style.bottom = '-10px';
    }
    badge.style.display = 'inline-block';
  }

  window.showNavPricingBadge = function () {
    _positionPricingBadge();
  };

  window.addEventListener('resize', () => {
    const badge = document.getElementById('nav-pricing-badge');
    if (badge) _positionPricingBadge();
  });

})();
